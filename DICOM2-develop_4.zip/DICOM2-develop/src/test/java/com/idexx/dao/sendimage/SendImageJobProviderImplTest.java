/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dao.sendimage;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.dao.sendimage.DicomJobDao;
import com.idexx.dicom.mapper.EntityMapper;
import com.idexx.dicom.sendimage.SendImageJobProvider;
import com.idexx.dicom.sendimage.impl.SendImageJobProviderImpl;
/**
 * Test class from SendImageJobProviderImpl
 * @author vvanjarana
 * @version 1.3
 */
public class SendImageJobProviderImplTest {

    public static final String TESTJOBID = "Test Job Id";
    public static final String JOB_COUNT = "5";
    
    private DicomJobDao jobDao;
    private EntityMapper entityMapper;
    
    @InjectMocks
    private SendImageJobProvider objInTest = new SendImageJobProviderImpl();
    
    List<IdexxSendImageJob> resultList = new ArrayList<IdexxSendImageJob>();
    IdexxSendImageJob idexxjob = new IdexxSendImageJob();
    
    @Before
    public void setUp() throws Exception {
	jobDao = mock(DicomJobDao.class);
	entityMapper = mock(EntityMapper.class);
	idexxjob.setJobId(TESTJOBID);
	resultList.add(idexxjob);
	
	MockitoAnnotations.initMocks(this);	
    }
    
    @Test
    public void test_get_pending_jobs(){
	when(jobDao.getPendingJobs(JOB_COUNT)).thenReturn(resultList);
	List<IdexxSendImageJob> originalList = objInTest.getPendingJobs(JOB_COUNT);
	assertTrue(originalList.size()>0);
    }
    
    @Test
    public void test_update_inprogess_jobs(){
	doNothing().when(jobDao).updateAllInProgressJobs(anyString());
	objInTest.updateInProgressJobs(anyString());
	verify(jobDao, times(1)).updateAllInProgressJobs(anyString());
    }
    
    @Test
    public void test_update_jobs_to_inprogess(){
	doNothing().when(jobDao).updateJobsToInProgressStatus(anyObject());
	objInTest.updateJobsToInProgressStatus(anyObject());
	verify(jobDao, times(1)).updateJobsToInProgressStatus(anyObject());
    }  

}
