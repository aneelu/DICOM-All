/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dao.sendimage;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.anyObject;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import javax.persistence.Query;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.dao.sendimage.DicomJobDao;
import com.idexx.dicom.dao.sendimage.impl.DicomJobDaoImpl;

/**
 * Test class from DicomJobDaoImpl
 * @author vvanjarana
 * @version 1.3
 */
public class DicomJobDaoImplTest {
    
    
    private EntityManager entityManager;
    private Query query;
    
    public static final String TESTJOBID = "Test Job Id";
    
    @InjectMocks
    DicomJobDao objInTest = new DicomJobDaoImpl();
    
    List<IdexxSendImageJob> resultList = new ArrayList<IdexxSendImageJob>();
    IdexxSendImageJob idexxjob = new IdexxSendImageJob();
    
    @Before
    public void setUp() throws Exception {
	
	idexxjob.setJobId(TESTJOBID);
	resultList.add(idexxjob);
	
	entityManager = mock(EntityManager.class);
	query = mock(Query.class);
	MockitoAnnotations.initMocks(this);	
    }
    
    @Test
    public void test_getPendingJobs(){
	
	when(entityManager.createQuery(anyString())).thenReturn(query);	
	when(query.setParameter(anyString(), anyString())).thenReturn(query);
	when(query.setMaxResults(1)).thenReturn(query);
	when(query.setLockMode(LockModeType.PESSIMISTIC_WRITE)).thenReturn(query);
	when(query.getResultList()).thenReturn(resultList);
	List<IdexxSendImageJob> originalList = objInTest.getPendingJobs("1");
	verify(entityManager, atLeast(1)).createQuery(anyString());
	assertEquals(originalList, resultList);
    }
        
    @Test
    public void test_updateAll_Inprogress_Jobs(){	
	when(entityManager.createQuery(anyString())).thenReturn(query);	
	when(query.setParameter(anyString(), anyString())).thenReturn(query);	
	when(query.getResultList()).thenReturn(resultList);
	objInTest.updateAllInProgressJobs("1");
	verify(entityManager, atLeast(1)).createQuery(anyString());
	verify(entityManager, atLeast(1)).persist(anyObject());
    }
    
    @Test
    public void test_getJob_by_Id(){	
	when(entityManager.createQuery(anyString())).thenReturn(query);	
	when(query.setParameter(anyString(), anyString())).thenReturn(query);	
	when(query.getSingleResult()).thenReturn(idexxjob);
	objInTest.getJobByJobId(TESTJOBID);
	verify(entityManager, atLeast(1)).createQuery(anyString());	
    }
    
    @Test
    public void test_update_jobs_to_Inprogress(){	
	when(entityManager.createQuery(anyString())).thenReturn(query);	
	when(query.setParameter(anyString(), anyString())).thenReturn(query);	
	when(query.getResultList()).thenReturn(resultList);
	objInTest.updateJobsToInProgressStatus();
	verify(entityManager, atLeast(1)).createQuery(anyString());
	verify(entityManager, atLeast(1)).persist(anyObject());
    }
    
    @Test
    public void test_update_list_of_jobs_to_Inprogress(){	
	objInTest.updateJobsToInProgressStatus(resultList);	
	verify(entityManager, atLeast(1)).persist(anyObject());
    }

    @Test
    public void test_update_job(){	
	when(entityManager.createQuery(anyString())).thenReturn(query);	
	when(query.setParameter(anyString(), anyString())).thenReturn(query);	
	when(query.getSingleResult()).thenReturn(idexxjob);
	objInTest.updateJob(idexxjob);
	verify(entityManager, atLeast(1)).persist(anyObject());	
    }
}
