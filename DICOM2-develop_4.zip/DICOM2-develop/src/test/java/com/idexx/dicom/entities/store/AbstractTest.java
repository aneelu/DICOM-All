/**
 * 
 */
package com.idexx.dicom.entities.store;

import javax.persistence.EntityManager;

import org.junit.AfterClass;
import org.junit.BeforeClass;

import com.idexx.dicom.dao.store.util.EntityManagerUtil;


/**
 * @author smallela
 * @version 1.3
 */
public abstract class AbstractTest {
    protected static EntityManager entityManager;
    
    @BeforeClass
    public static void setUpClass() throws Exception {
        entityManager = EntityManagerUtil.getEntityManagerFactory("IDEXX_IM_PLGN_Test").createEntityManager();
        entityManager.getTransaction().begin();
    }
    
    @AfterClass
    public static void tearDownClass() throws Exception {
        if (entityManager.getTransaction().isActive()) {
            entityManager.getTransaction().commit();
        }
        if (entityManager.isOpen()) {
            entityManager.close();
        }
    }
}
