package com.idexx.dicom.ae.validator.impl.v13;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import com.idexx.dicom.services.dto.v13.IdexxFailureLogParamDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;


/**
 * <pre>Description of the class</pre>
 * @author rkaranam
 * @version 1.3
 */
@RunWith(JUnit4.class)
public class GetStoreServiceFailureValidatorTest {
    private GetStoreFailuresValidator validator;
    
    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {
    }
    
    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.GetStoreServiceFailureValidator #validate(com.idexx.dicom.services.dto.AETitleDTO)}
     * .
     */
    @Test
    public final void testValidate() {
        IdexxFailureLogParamDTO dto = new IdexxFailureLogParamDTO();
        dto.setEndDate("");
        dto.setStartDate("");
        validator = new GetStoreFailuresValidator();
        int val = 0;
        try {
            val = validator.validateInputFields(dto);
            fail("validation failed.");
        } catch (IdexxDicomAEConfigServiceException exp) {
        }
        dto.setEndDate("1997-12-31T23:59:59.1+05:30");
        dto.setStartDate("1997-12-31T25:59:59.1+05:30");
        try {
            val = validator.validateInputFields(dto);
            fail("validation failed.");
        } catch (IdexxDicomAEConfigServiceException exp) {
        }
        dto.setEndDate("1997-12-31T25:59:59.1+05:30");
        dto.setStartDate("1997-12-31T23:59:59.1+05:30");
        try {
            val = validator.validateInputFields(dto);
            fail("validation failed.");
        } catch (IdexxDicomAEConfigServiceException exp) {
        }
        
        dto.setEndDate("1997-12-31T22:59:59.1+05:30");
        dto.setStartDate("1997-12-31T23:59:59.1+05:30");
        try {
            val = validator.validateInputFields(dto);
            fail("validation failed.");
        } catch (IdexxDicomAEConfigServiceException exp) {
        }
        dto.setEndDate("1997-12-31T23:59:59.1+05:30");
        dto.setStartDate("1997-12-31T23:59:59.1+05:30");
        try {
            val = validator.validateInputFields(dto);
            assertTrue("Date Validation Failed", val == 1);
        } catch (IdexxDicomAEConfigServiceException exp) {
            fail("validation failed.");
        }
    }
    
}
