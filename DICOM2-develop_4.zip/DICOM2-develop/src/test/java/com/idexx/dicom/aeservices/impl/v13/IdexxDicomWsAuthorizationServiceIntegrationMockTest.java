/**
 * 
 */
package com.idexx.dicom.aeservices.impl.v13;

import static org.junit.Assert.assertTrue;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.action.VoidAction;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.springframework.test.util.ReflectionTestUtils;

import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.validator.impl.v13.AbstractAETitleValidator;
import com.idexx.dicom.aeservices.IdexxDicomWSAthorizationService;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.dto.v13.AETitleDTO;
import com.idexx.dicom.services.dto.v13.CreateAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;


/**
 * <pre>Test Cases Related IDEXX DICOM Authorization Services.</pre>
 * @author smallela
 * @version 1.3
 */

public class IdexxDicomWsAuthorizationServiceIntegrationMockTest {
     
public Mockery context = new JUnit4Mockery() {{
        setImposteriser(ClassImposteriser.INSTANCE);
    }};


AbstractAETitleValidator mockValidator = context.mock(AbstractAETitleValidator.class);    
AETitleDao mockDao = context.mock(AETitleDao.class);
IdexxDicomWSAthorizationServiceImpl idexxDicomWsAuthorizeService1 = context.mock(IdexxDicomWSAthorizationServiceImpl.class);

private AbstractAEServiceImpl service;

@Mock
private IdexxDicomWSAthorizationServiceImpl idexxDicomWsAuthorizeService;
private CreateAETitleDTO dto;
private AETitle aeTitle;
	
    /**
     * @throws java.lang.Exception
     */
    @Before
    public final void setUp() throws Exception {
        aeTitle = new AETitle();
        service = new CreateAETitleService();
        ReflectionTestUtils.setField(service, "validator", mockValidator);
        ReflectionTestUtils.setField(service, "aeTitleDao", mockDao);
        ReflectionTestUtils.setField(service, "idexxDicomWsAuthorizeService", idexxDicomWsAuthorizeService1);
        dto = new CreateAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setSapId("SAPID");
        dto.setInstituteName("TestIng");
        dto.setApiKey("TESTAPIKEY");
        dto.setIdentifiedByAeTitleOnly(true);
        aeTitle.setAeTitle(dto.getAeTitle());
        aeTitle.setApiKey(dto.getApiKey());
        aeTitle.setSapId(dto.getSapId());
        aeTitle.setInstituteName(dto.getInstituteName());
        aeTitle.setIdentifiedByaeTitleOnly(dto.isIdentifiedByAeTitleOnly());
    }
    
    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.AbstractAEServiceImpl#performService(com.idexx.dicom.services.dto.v13.AETitleDTO)}
     * . Test for positive: idexxDicomWsAuthorizeService.authorize will return
     * true
     */
    @Test
    public final void testPerformService1() throws IdexxDicomAEConfigServiceException {
        context.checking(new Expectations() {
            {
                oneOf(mockValidator).validate(with(any(AETitleDTO.class)));
                will(returnValue(1));
                oneOf(mockDao).createAETitle(with(any(AETitle.class)));
                will(VoidAction.INSTANCE);
                oneOf(idexxDicomWsAuthorizeService1).authorize(with(any(String.class)));
                will(returnValue(true));
            }
        });
        String errorCode = null;
        try {
        service.performService(dto);
        
        } catch (IdexxDicomAEConfigServiceException exp) {
            errorCode = exp.getErrorCode();
            throw exp;
        }Integer val = (Integer) service.sendResponse();
        assertTrue("Invalid Response recieved", 0 == val.intValue());
    }
    
    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.AbstractAEServiceImpl#performService(com.idexx.dicom.services.dto.v13.AETitleDTO)}
     * . Test for positive: idexxDicomWsAuthorizeService.authorize will return
     * true
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public final void testPerformService2() throws IdexxDicomAEConfigServiceException {
        context.checking(new Expectations() {
            {
                oneOf(idexxDicomWsAuthorizeService1).authorize(with(any(String.class)));
                will(throwException(new IdexxDicomAEConfigServiceException(IdexxDicomWSAthorizationService.INVALID_API_KEY)));
            }
        });
        String errorCode = null;
        try {
            service.performService(dto);
        } catch (IdexxDicomAEConfigServiceException exp) {
            errorCode = exp.getErrorCode();
            throw exp;
        }
        assertTrue("Invalid Response recieved", IdexxDicomWSAthorizationService.INVALID_API_KEY.equals(errorCode));
    }
    
}
