/**
 * JUNIT class for Query Data Element Extractor
 */
package com.idexx.dicom.query.request.impl;

import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.mockito.Mock;

import com.idexx.dicom.retrieve.download.impl.DownloadFileInfoProviderImplTest;


public class QueryRequestDatasetElementExtractorTest {

    
	@Mock
	private QueryRequestDatasetElementExtractor qrExtractor;
    
    private static final int PATIENT_NAME_TAG_ID = 1048592;


    /**
     * Test method for
     * {@link com.idexx.dicom.query.request.impl.QueryRequestDatasetElementExtractor#getElementsExtractedFromDataset(Dataset)}
     * .
     * @throws IOException 
     */
    @Test
    public final void testGetElementsExtractedFromDataset1() throws IOException {

        qrExtractor = new QueryRequestDatasetElementExtractor();
        Map<String, String> mappings = qrExtractor.getElementsExtractedFromDataset(DownloadFileInfoProviderImplTest
                .getTestDataset());
        assertNotNull("Unable to get mappings", mappings);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.query.request.impl.QueryRequestDatasetElementExtractor#getElementsExtractedFromDataset(Dataset)}
     * .
     * @throws IOException 
     */
    @Test
    public final void testGetElementsExtractedFromDataset2() throws IOException {
        final Map<String, Integer> tagMaps = new HashMap<String, Integer>();
        tagMaps.put("PatientDTO.patientName", PATIENT_NAME_TAG_ID);

        qrExtractor = new QueryRequestDatasetElementExtractor();
        Map<String, String> mappings = qrExtractor.getElementsExtractedFromDataset(DownloadFileInfoProviderImplTest
                .getTestDataset());
        assertNotNull("Unable to get mappings", mappings);
    }

}
