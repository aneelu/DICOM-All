/**
 * 
 */
package com.idexx.dicom.query.common.impl;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import static org.mockito.Mockito.*;

import com.idexx.dicom.dao.store.DicomImMappingDAO;
import com.idexx.dicom.entities.store.DicomIMMappings;
import com.idexx.dicom.query.common.TagsElementMappingService;

/**
 * @author vkandagatla
 *
 */
public class TagsElementMappingServiceImplTest {
	
	private static final String IMAGE_QUERY_COMPONENT_NAME = "IMAGE_QUERY";
	 private static final int IMAGE_QUERY_COMPONENT_REQUEST_TYPE = 1;
   
    @InjectMocks
    private TagsElementMappingService service;
    
    @Mock
    private DicomImMappingDAO dao;
    /**
     * @throws java.lang.Exception
     */
    @Before
    public final void setUp() throws Exception {
        service = new TagsElementMappingServiceImpl();
        MockitoAnnotations.initMocks(this);
    }
    
    /**
     * Test method for {@link com.idexx.dicom.query.common.impl.TagsElementMappingServiceImpl#getMappings()}.
     */
    @Test
    public final void testGetMappings() {
        final List<DicomIMMappings> list = new ArrayList<DicomIMMappings>();
        DicomIMMappings mapping = new DicomIMMappings();
        mapping.setDcmTagId(1);
        mapping.setImFieldName("Test");
        list.add(mapping);
        
        when(dao.getMappingsByComponent(IMAGE_QUERY_COMPONENT_NAME, IMAGE_QUERY_COMPONENT_REQUEST_TYPE)).thenReturn(list);
        
        Map<String, Integer> maps = service.getMappings();
        assertNotNull("Map not returned", maps);
        assertNotNull("RequestedObjectNotGet", maps.get("Test"));
    }
    
}
