/**
 *  
 */
package com.idexx.dicom.aeservices.impl;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.jmock.Expectations;
import org.jmock.auto.Mock;
import org.jmock.integration.junit4.JUnitRuleMockery;
import org.jmock.lib.action.VoidAction;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.springframework.test.util.ReflectionTestUtils;

import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.validator.AETitleValidator;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.dto.AETitleDTO;
import com.idexx.dicom.services.dto.SetEnabledAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;


/**
 * <pre>Test Cases Related SetAETitleStatusService</pre>
 * @author smallela
 * @version 1.3
 */

@RunWith(JUnit4.class)
public class SetAETitleStatusServiceTest {

    private SetAETitleStatusService service;

    @Rule
    public JUnitRuleMockery context = new JUnitRuleMockery();

    @Mock
    private AETitleDao mockDao;

    @Mock
    private AETitleValidator mockValidator;

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.DeleteAETitleService#validate(com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public final void testValidate() throws IdexxDicomAEConfigServiceException {
        AETitleDTO dto = new AETitleDTO();
        dto.setAeTitle("Test1");
        dto.setInstituteName("Testing");
        context.checking(new Expectations() {
            {
                oneOf(mockValidator).validate(with(any(AETitleDTO.class)));
                will(returnValue(1));

            }
        });
        service = new SetAETitleStatusService();
        ReflectionTestUtils.setField(service, "validator", mockValidator);

        int val = service.validate(dto);
        assertTrue("Set AE statusFailed#1", 1 == val);

    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.DeleteAETitleService#doService(com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public final void testDoService() throws IdexxDicomAEConfigServiceException {

        final AETitle aeTitle = new AETitle();
        final List<AETitle> registeredAEList = new ArrayList<AETitle>();
        SetEnabledAETitleDTO dto = new SetEnabledAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setInstituteName("TestIng");
        dto.setEnabled(true);
        aeTitle.setAeTitle(dto.getAeTitle());
        aeTitle.setInstituteName(dto.getInstituteName());
        aeTitle.setIdentifiedByaeTitleOnly(true);
        registeredAEList.add(aeTitle);
        context.checking(new Expectations() {
            {
                oneOf(mockDao).findAETitle("Test1");
                will(returnValue(registeredAEList));
                oneOf(mockDao).updateAETitle(aeTitle);
                will(VoidAction.INSTANCE);
            }
        });
        service = new SetAETitleStatusService();
        ReflectionTestUtils.setField(service, "aeTitleDao", mockDao);

        int val = service.doService(dto);
        assertTrue("Create AE Failed#1", 1 == val);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.DeleteAETitleService#doService(com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public final void testDoService2() throws IdexxDicomAEConfigServiceException {

        final AETitle aeTitle = new AETitle();
        final List<AETitle> registeredAEList = new ArrayList<AETitle>();
        final List<AETitle> registeredAEList2 = new ArrayList<AETitle>();
        SetEnabledAETitleDTO dto = new SetEnabledAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setInstituteName("TestIng");
        aeTitle.setAeTitle(dto.getAeTitle());
        aeTitle.setInstituteName(dto.getInstituteName());
        aeTitle.setIdentifiedByaeTitleOnly(false);
        registeredAEList.add(aeTitle);
        registeredAEList2.add(aeTitle);
        context.checking(new Expectations() {
            {
                oneOf(mockDao).findAETitle("Test1");
                will(returnValue(registeredAEList));
                oneOf(mockDao).findAETitle("Test1", "TestIng");
                will(returnValue(registeredAEList2));
                oneOf(mockDao).updateAETitle(aeTitle);
                will(VoidAction.INSTANCE);
            }
        });
        service = new SetAETitleStatusService();
        ReflectionTestUtils.setField(service, "aeTitleDao", mockDao);

        int val = service.doService(dto);
        assertTrue("Set AE status Failed#2", 1 == val);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.DeleteAETitleService#doService(com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public final void testDoService3() throws IdexxDicomAEConfigServiceException {

        final AETitle aeTitle = new AETitle();
        final List<AETitle> registeredAEList = new ArrayList<AETitle>();
        new ArrayList<AETitle>();
        SetEnabledAETitleDTO dto = new SetEnabledAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setInstituteName("TestIng");
        aeTitle.setAeTitle(dto.getAeTitle());
        aeTitle.setInstituteName(dto.getInstituteName());
        aeTitle.setIdentifiedByaeTitleOnly(false);
        registeredAEList.add(aeTitle);
        context.checking(new Expectations() {
            {
                oneOf(mockDao).findAETitle("Test1");
                will(throwException(new IdexxDicomAEConfigDbException()));
            }
        });
        service = new SetAETitleStatusService();
        ReflectionTestUtils.setField(service, "aeTitleDao", mockDao);
        service.doService(dto);
    }

}
