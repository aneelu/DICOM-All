/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dcm4che3.tool.dcmqrscp;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.ParameterExpression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Service;

import com.idexx.dicom.domain.Patient;
import com.idexx.dicom.domain.Patient_;
import com.idexx.dicom.domain.RequestDetails;
import com.idexx.dicom.domain.RequestDetails_;
import com.idexx.dicom.services.IdexxDicomServiceConstants;

/**
 * <pre>
 * Description of the class
 * </pre>
 * 
 * @author vvanjarana
 * @version 1.3
 */
@Service("patientQueryBuilder")
public class PatientQueryBuilder {

	@PersistenceContext
	private EntityManager entityManager;

	private ParameterExpression<Date> startDate = null, endDate = null;
	final List<Predicate> predicates = new ArrayList<Predicate>();
	
	public List<RequestDetails> buildSearchPatientQuery(
								final SearchDetailsDTO searchDetails) {
		final CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		final CriteriaQuery<RequestDetails> criteriaQuery = builder.createQuery(RequestDetails.class);
		final Root<RequestDetails> requestDetails = criteriaQuery.from(RequestDetails.class);
		criteriaQuery.select(requestDetails);
		
		Join<RequestDetails, Patient> patientJoin = requestDetails.join(RequestDetails_.patient, JoinType.LEFT);
		
		
		checkSapIdFilter(searchDetails, builder, requestDetails);
		
		checkPatientIdFilter(searchDetails, builder, patientJoin);		
		
		checkModalityFilter(searchDetails, requestDetails);
		
		checkPatientNameFilter(searchDetails, builder, patientJoin);
		
		checkDateRangeFilter(searchDetails, builder, requestDetails);
		
		checkStatusFilter(searchDetails, builder, requestDetails);

		criteriaQuery.where(builder.and(predicates.toArray(new Predicate[0])));
		
		final Query query = entityManager.createQuery(criteriaQuery);
		
		if (null != searchDetails.getStartDate() && null != searchDetails.getEndDate()) {
			query.setParameter(startDate, searchDetails.getStartDate());
			query.setParameter(endDate, searchDetails.getEndDate());
		}
		
		List<RequestDetails> listofRequestDetails = query.getResultList();
		predicates.clear();
		return listofRequestDetails;
	}

	private void checkStatusFilter(final SearchDetailsDTO searchDetails, final CriteriaBuilder builder,
			final Root<RequestDetails> requestDetails) {
		if (null != searchDetails.getStatus() && searchDetails.getStatus().size() > 0) {
			Expression<String> byStatus = requestDetails.get("status");
			
			Set<String> mppsStatuses = new HashSet<String>();
			
			for(String status : searchDetails.getStatus()){
				if(status.equalsIgnoreCase(IdexxDicomServiceConstants.MPPS_REQUEST_STATUS_SCHEDULED)){
					mppsStatuses.add(IdexxDicomServiceConstants.MPPS_REQUEST_STATUS_PENDING);
					mppsStatuses.add(IdexxDicomServiceConstants.MPPS_REQUEST_STATUS_INPROGRESS);
				}
				else {
					mppsStatuses.add("MPPS_" + status);			
				}
			}
			
			final Predicate statusFilter = byStatus.in(mppsStatuses);
			predicates.add(statusFilter);
		} 
		else 
		{
		    final Expression<String> byStatus = requestDetails.get("status");
		    final Predicate statusFilter = builder.notLike(byStatus, "MPPS_CANCEL");
			predicates.add(statusFilter);
		}
	}

	private void checkDateRangeFilter(final SearchDetailsDTO searchDetails, final CriteriaBuilder builder,
			final Root<RequestDetails> requestDetails) {
		if (null != searchDetails.getStartDate() && null != searchDetails.getEndDate()){			
			startDate = builder.parameter(Date.class);			
            endDate =  builder.parameter(Date.class);
            final Predicate dateRangeFilter = builder.
            		between(requestDetails.get(RequestDetails_.createTimeStamp), startDate, endDate);
            predicates.add(dateRangeFilter);						 
		}
	}

	private void checkPatientNameFilter(final SearchDetailsDTO searchDetails, final CriteriaBuilder builder,
			Join<RequestDetails, Patient> patientJoin) {
		if (null != searchDetails.getPatientName()&& searchDetails.getPatientName().length() > 0) {
			final Predicate patientNameFilter = builder.
					like(patientJoin.get(Patient_.patientName), searchDetails.getPatientName() + "%");			
			predicates.add(patientNameFilter);					
		}
	}

	private void checkModalityFilter(final SearchDetailsDTO searchDetails, final Root<RequestDetails> requestDetails) {
		if (null != searchDetails.getModalities() && searchDetails.getModalities().size() > 0) {
			Expression<String> byModality = requestDetails.get("modality");
			final Predicate modalityFilter =  byModality.in(searchDetails.getModalities());
			predicates.add(modalityFilter);					
		}
	}

	private void checkPatientIdFilter(final SearchDetailsDTO searchDetails, final CriteriaBuilder builder,
			Join<RequestDetails, Patient> patientJoin) {
		if (null != searchDetails.getPatientId() && searchDetails.getPatientId().length() > 0) {
			final Predicate applicationPatienIdFilter = builder.
					equal(patientJoin.get(Patient_.applicationPatientId), searchDetails.getPatientId());
			predicates.add(applicationPatienIdFilter);
		}
	}

	private void checkSapIdFilter(final SearchDetailsDTO searchDetails, final CriteriaBuilder builder,
			final Root<RequestDetails> requestDetails) {
		if (null != searchDetails.getSapId() && searchDetails.getSapId().length() > 0) {
			final Predicate sapIdFilter = builder.
					equal(requestDetails.get(RequestDetails_.sapId), searchDetails.getSapId());
			predicates.add(sapIdFilter);
		}
	}

}
