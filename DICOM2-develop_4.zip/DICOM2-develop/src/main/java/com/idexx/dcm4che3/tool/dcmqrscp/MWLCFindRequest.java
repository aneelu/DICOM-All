/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dcm4che3.tool.dcmqrscp;

import java.util.Date;

import org.joda.time.DateTime;

/**
 * <pre>Description of the class</pre>
 * @author rkaranam
 * @version 1.3
 */
public class MWLCFindRequest {
	
	private String patientBreedDescription;
	private Date patientBirthDate;
	private String patientSex;
	private String responsiblePerson;
	private String patientId;
	private String issuerOfPatientId;
	private String patientName;
	private String patientSpecies;
	private String mwlStatus;
	private Date mwlScheduledDate;
	private DateTime mwlScheduledTime;
	private String accessionNumber;
	private String studyId;
	private String studyInstanceUID;
	private String modality;
	private String seriesNumber;
	private String seriesInstanceUID;
	private String instanceNumber;
	private String instanceUID;
	private String requestingPhysician;
	
	public String getPatientBreedDescription() {
		return patientBreedDescription;
	}
	public void setPatientBreedDescription(String patientBreedDescription) {
		this.patientBreedDescription = patientBreedDescription;
	}
	public Date getPatientBirthDate() {
		return patientBirthDate;
	}
	public void setPatientBirthDate(Date patientBirthDate) {
		this.patientBirthDate = patientBirthDate;
	}
	public String getPatientSex() {
		return patientSex;
	}
	public void setPatientSex(String patientSex) {
		this.patientSex = patientSex;
	}
	public String getResponsiblePerson() {
		return responsiblePerson;
	}
	public void setResponsiblePerson(String responsiblePerson) {
		this.responsiblePerson = responsiblePerson;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getIssuerOfPatientId() {
		return issuerOfPatientId;
	}
	public void setIssuerOfPatientId(String issuerOfPatientId) {
		this.issuerOfPatientId = issuerOfPatientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getPatientSpecies() {
		return patientSpecies;
	}
	public void setPatientSpecies(String patientSpecies) {
		this.patientSpecies = patientSpecies;
	}
	public String getMwlStatus() {
		return mwlStatus;
	}
	public void setMwlStatus(String mwlStatus) {
		this.mwlStatus = mwlStatus;
	}
	public Date getMwlScheduledDate() {
		return mwlScheduledDate;
	}
	public void setMwlScheduledDate(Date mwlScheduledDate) {
		this.mwlScheduledDate = mwlScheduledDate;
	}
	public DateTime getMwlScheduledTime() {
		return mwlScheduledTime;
	}
	public void setMwlScheduledTime(DateTime mwlScheduledTime) {
		this.mwlScheduledTime = mwlScheduledTime;
	}
	public String getAccessionNumber() {
		return accessionNumber;
	}
	public void setAccessionNumber(String accessionNumber) {
		this.accessionNumber = accessionNumber;
	}
	public String getStudyId() {
		return studyId;
	}
	public void setStudyId(String studyId) {
		this.studyId = studyId;
	}
	public String getStudyInstanceUID() {
		return studyInstanceUID;
	}
	public void setStudyInstanceUID(String studyInstanceUID) {
		this.studyInstanceUID = studyInstanceUID;
	}
	public String getModality() {
		return modality;
	}
	public void setModality(String modality) {
		this.modality = modality;
	}
	public String getSeriesNumber() {
		return seriesNumber;
	}
	public void setSeriesNumber(String seriesNumber) {
		this.seriesNumber = seriesNumber;
	}
	public String getSeriesInstanceUID() {
		return seriesInstanceUID;
	}
	public void setSeriesInstanceUID(String seriesInstanceUID) {
		this.seriesInstanceUID = seriesInstanceUID;
	}
	public String getInstanceNumber() {
		return instanceNumber;
	}
	public void setInstanceNumber(String instanceNumber) {
		this.instanceNumber = instanceNumber;
	}
	public String getInstanceUID() {
		return instanceUID;
	}
	public void setInstanceUID(String instanceUID) {
		this.instanceUID = instanceUID;
	}
	public String getRequestingPhysician() {
		return requestingPhysician;
	}
	public void setRequestingPhysician(String requestingPhysician) {
		this.requestingPhysician = requestingPhysician;
	}
	
}
