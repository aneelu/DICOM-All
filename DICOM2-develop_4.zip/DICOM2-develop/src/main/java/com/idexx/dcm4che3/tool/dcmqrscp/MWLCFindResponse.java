/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dcm4che3.tool.dcmqrscp;

import java.util.Date;
import java.util.List;

import com.idexx.imaging.imagemanager.soap.ExternalPatientIdDTO;

/**
 * <pre>Description of the class</pre>
 * @author rkaranam
 * @version 1.3
 */
public class MWLCFindResponse {
	
	// Patient Module
	private String patientId;
	private String patientName;
	private Date dateOfBirth;
	private String species;
	private String breed;
	private String gender;
	private String applicationPatientId;
	private String sapId;
	private String weightUnit;
	private String edhdNumber;
	private int weight;
	private int activeFlag;
	private Date lastModifiedDate;
	
	private String requestedProcedureDescription;
	private String requestedProcedureId;
	
	private String studyInstanceUID;
	private String accessionNumber;
	
	// Client Module
	private String responsiblePeron;
	private String responsibleOrganization;	
	
	
	// Other Patient ID Sequence
	private String otherPatientId;
	private String otherIssuerOfPatientId;
	
	
	
	// Sequence
	private String scheduledProcedureStepId;
	private Date scheduledProcedureStepStartDate;
	private String scheduledProcedureStepStatus;
	private String modality;
	List<ExternalPatientIdDTO> externalPatientIdDTO;
	
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getSpecies() {
		return species;
	}
	public void setSpecies(String species) {
		this.species = species;
	}
	public String getBreed() {
		return breed;
	}
	public void setBreed(String breed) {
		this.breed = breed;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getApplicationPatientId() {
		return applicationPatientId;
	}
	public void setApplicationPatientId(String applicationPatientId) {
		this.applicationPatientId = applicationPatientId;
	}
	public String getSapId() {
		return sapId;
	}
	public void setSapId(String sapId) {
		this.sapId = sapId;
	}
	public String getWeightUnit() {
		return weightUnit;
	}
	public void setWeightUnit(String weightUnit) {
		this.weightUnit = weightUnit;
	}
	public String getEdhdNumber() {
		return edhdNumber;
	}
	public void setEdhdNumber(String edhdNumber) {
		this.edhdNumber = edhdNumber;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public int getActiveFlag() {
		return activeFlag;
	}
	public void setActiveFlag(int activeFlag) {
		this.activeFlag = activeFlag;
	}
	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}
	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getResponsiblePeron() {
		return responsiblePeron;
	}
	public void setResponsiblePeron(String responsiblePeron) {
		this.responsiblePeron = responsiblePeron;
	}
	public String getResponsibleOrganization() {
		return responsibleOrganization;
	}
	public void setResponsibleOrganization(String responsibleOrganization) {
		this.responsibleOrganization = responsibleOrganization;
	}
	public String getRequestedProcedureDescription() {
		return requestedProcedureDescription;
	}
	public void setRequestedProcedureDescription(String requestedProcedureDescription) {
		this.requestedProcedureDescription = requestedProcedureDescription;
	}
	public String getRequestedProcedureId() {
		return requestedProcedureId;
	}
	public void setRequestedProcedureId(String requestedProcedureId) {
		this.requestedProcedureId = requestedProcedureId;
	}
	public String getStudyInstanceUID() {
		return studyInstanceUID;
	}
	public void setStudyInstanceUID(String studyInstanceUID) {
		this.studyInstanceUID = studyInstanceUID;
	}
	public String getAccessionNumber() {
		return accessionNumber;
	}
	public void setAccessionNumber(String accessionNumber) {
		this.accessionNumber = accessionNumber;
	}
	public String getOtherPatientId() {
		return otherPatientId;
	}
	public void setOtherPatientId(String otherPatientId) {
		this.otherPatientId = otherPatientId;
	}
	public String getOtherIssuerOfPatientId() {
		return otherIssuerOfPatientId;
	}
	public void setOtherIssuerOfPatientId(String otherIssuerOfPatientId) {
		this.otherIssuerOfPatientId = otherIssuerOfPatientId;
	}
	public String getScheduledProcedureStepId() {
		return scheduledProcedureStepId;
	}
	public void setScheduledProcedureStepId(String scheduledProcedureStepId) {
		this.scheduledProcedureStepId = scheduledProcedureStepId;
	}
	public Date getScheduledProcedureStepStartDate() {
		return scheduledProcedureStepStartDate;
	}
	public void setScheduledProcedureStepStartDate(Date scheduledProcedureStepStartDate) {
		this.scheduledProcedureStepStartDate = scheduledProcedureStepStartDate;
	}
	public String getScheduledProcedureStepStatus() {
		return scheduledProcedureStepStatus;
	}
	public void setScheduledProcedureStepStatus(String scheduledProcedureStepStatus) {
		this.scheduledProcedureStepStatus = scheduledProcedureStepStatus;
	}
	public String getModality() {
		return modality;
	}
	public void setModality(String modality) {
		this.modality = modality;
	}
	public List<ExternalPatientIdDTO> getExternalPatientIdDTO() {
		return externalPatientIdDTO;
	}
	public void setExternalPatientIdDTO(List<ExternalPatientIdDTO> externalPatientIdDTO) {
		this.externalPatientIdDTO = externalPatientIdDTO;
	}
	
}
