package com.idexx.dcm4che3.tool.dcmqrscp;

import java.util.Date;
import java.util.List;

/**
 * <pre>Search Details DTO object</pre>
 * @author rkaranam
 * @version 1.3
 */
public class SearchDetailsDTO {
	
	private String patientName;
	private String patientId;
	private List<String> modalities;
	private Date startDate;
	private Date endDate;
	private List<String> status;
	private String sapId;
	
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}	
	public List<String> getModalities() {
		return modalities;
	}
	public void setModalities(List<String> modalities) {
		this.modalities = modalities;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public List<String> getStatus() {
		return status;
	}
	public void setStatus(List<String> status) {
		this.status = status;
	}
	public String getSapId() {
		return sapId;
	}
	public void setSapId(String sapId) {
		this.sapId = sapId;
	}
	
}
