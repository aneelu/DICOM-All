/**
 * 
 */
package com.idexx.dicom;

import java.io.IOException;

/**
 * @author sbitla
 * 
 */
public interface DicomObjectBuilder {
    void build() throws IOException;
}
