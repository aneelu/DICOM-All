/**
 * 
 */
package com.idexx.dicom.conversion;

import java.io.IOException;

import com.idexx.dicom.conversion.impl.ImageProperties;

/**
 * @author vkandagatla
 *
 */
public interface ImagePropertiesProvider {
    ImageProperties getImageProperties() throws IOException;
}
