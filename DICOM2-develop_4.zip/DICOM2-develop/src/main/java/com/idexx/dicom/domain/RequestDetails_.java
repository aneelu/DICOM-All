package com.idexx.dicom.domain;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(RequestDetails.class)
public abstract class RequestDetails_ {

	public static volatile SingularAttribute<RequestDetails, String> requestingDoctor;
	public static volatile SingularAttribute<RequestDetails, String> modality;
	public static volatile SingularAttribute<RequestDetails, String> apiKey;
	public static volatile SingularAttribute<RequestDetails, String> patientId;
	public static volatile SingularAttribute<RequestDetails, String> studyInstanceUID;
	public static volatile SingularAttribute<RequestDetails, Timestamp> createTimeStamp;
	public static volatile SingularAttribute<RequestDetails, Timestamp> updateTimeStamp;
	public static volatile SingularAttribute<RequestDetails, String> requestNotes;
	public static volatile SingularAttribute<RequestDetails, String> accessionNumber;
	public static volatile SingularAttribute<RequestDetails, Patient> patient;
	public static volatile SingularAttribute<RequestDetails, String> Id;
	public static volatile SingularAttribute<RequestDetails, String> sapId;
	public static volatile SingularAttribute<RequestDetails, String> status;

}

