/**
 * 
 */
package com.idexx.dicom.store;

import java.util.Map;

/**
 * @author vkandagatla
 *
 */
public interface DicomStoreServiceBuilder {

    /**
     * @param ctx
     * @return
     */
    Map<String, Object> buildService();
}
