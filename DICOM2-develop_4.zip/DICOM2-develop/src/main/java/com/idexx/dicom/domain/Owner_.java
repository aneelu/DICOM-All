package com.idexx.dicom.domain;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(Owner.class)
public abstract class Owner_ {

	public static volatile SingularAttribute<Owner, String> clientID;
	public static volatile SingularAttribute<Owner, String> patientID;
	public static volatile SingularAttribute<Owner, Patient> patient;
	public static volatile SingularAttribute<Owner, Boolean> primaryOwner;
	public static volatile SingularAttribute<Owner, Client> client;

}

