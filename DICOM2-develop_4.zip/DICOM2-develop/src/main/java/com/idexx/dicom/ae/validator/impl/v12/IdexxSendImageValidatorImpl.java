/**
 * Validator Implementation to chack input parameters for Send Image Web Service
 */
package com.idexx.dicom.ae.validator.impl.v12;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.validator.v12.IdexxSendImageValidator;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v12.SendImageJobParamDTO;

/**
 * @author vkandagatla
 * 
 */
@Service("idexxSendImageValidatorV12")
public class IdexxSendImageValidatorImpl implements IdexxSendImageValidator {
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.ae.validator.IdexxSendImageValidator#validate(com.idexx
     * .dicom.services.sendimage.dto.SendImageJobParamDTO)
     */
    public final int validate(final SendImageJobParamDTO dto) throws IdexxDicomAEConfigServiceException {
        if (StringUtils.isEmpty(dto.getApiKey())
                || StringUtils.isEmpty(dto.getDestinationAETitle())
                || StringUtils.isEmpty(dto.getDestinationHost())
                || StringUtils.isEmpty(dto.getDestinationPort())
                || StringUtils.isEmpty(dto.getImageAssetId())
                || StringUtils.isEmpty(dto.getSendingAETitle())) {
            throw new IdexxDicomAEConfigServiceException(
                    MISSING_MANDATORY, MISSING_MANDATORY);
        }
        if (dto.getDestinationPort() <= 0) {
            throw new IdexxDicomAEConfigServiceException(
                    MISSING_MANDATORY, MISSING_MANDATORY);
        }
        return 1;
    }
    
}
