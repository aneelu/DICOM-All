/**
 * 
 */
package com.idexx.dicom.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Map;
import java.util.SimpleTimeZone;
import java.util.TimeZone;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.idexx.dicom.services.IdexxDicomServiceConstants;
import com.idexx.imaging.imagemanager.soap.ImageDTO;

/**
 * @author vkandagatla
 * 
 */
public class CommonUtil {
	
	private static Logger LOG = Logger.getLogger(CommonUtil.class);

    private CommonUtil() {

    }

    /**
     * @param <E>
     * @param aCollectionToTest
     * @return
     */
    public static <E> boolean isEmpty(final Collection<E> aCollectionToTest) {
        return ((null == aCollectionToTest) || (aCollectionToTest.size() <= 0));
    }

    /**
     * @param dirName
     * @return
     */
    public static File createDir(final String dirName) {
        File dir = new File(dirName);
        if (!dir.exists()) {
            dir.mkdir();
        }
        return dir;
    }

    /**
     * @param parentDir
     * @param fileName
     * @return
     * @throws IOException
     */
    public static File createFile(final String parentDir, final String fileName) throws IOException {
        createDir(parentDir);
        File file = new File(parentDir, fileName);
        if (file.exists()) {
            file.delete();
        }
        file.createNewFile();
        return file;
    }

    /**
     * @param fileNameWithExtension
     * @return
     */
    public static String getFileNameWithOutExtension(final String fileNameWithExtension) {
        final int lastPeriodPos = fileNameWithExtension.lastIndexOf('.');
        String tmpFileName = fileNameWithExtension.substring(0, lastPeriodPos);
        return tmpFileName;
    }

    public static String getFileExtension(final String fileNameWithExtension) {
        final int lastPeriodPos = fileNameWithExtension.lastIndexOf('.');
        String tmpFileName = fileNameWithExtension.substring(lastPeriodPos + 1, fileNameWithExtension.length());
        return tmpFileName;
    }

    /**
     * @param extension
     * @param defaultExtension
     * @return
     */
    public static String getFileNameExtension(final String extension, final String defaultExtension) {
        String tmpExtn = extension;
        if (StringUtils.isEmpty(extension)) {
            tmpExtn = defaultExtension;
        }
        return removeDotCharInFileExtension(tmpExtn);
    }

    /**
     * @param extension
     * @return
     */
    public static String removeDotCharInFileExtension(final String extension) {
        String tmpExtn = extension;
        if (StringUtils.isEmpty(extension)) {
            tmpExtn = IdexxDicomServiceConstants.DICOM_FILE_EXTENSION1;
        } else if (extension.startsWith(".")) {
            tmpExtn = extension.replace('.', ' ').trim();
        }
        return tmpExtn;
    }

    /**
     * @param sourcePatientName
     * @param defaultPatientName
     * @return
     */
    public static String extractPatientFirstName(final String sourcePatientName, final String defaultPatientName) {
        String newPatientName = null;
        // when getTagValue return "" when tag not found in Dataset
        if (sourcePatientName == null || ("".equals(sourcePatientName) && sourcePatientName.length() == 0)) {
            newPatientName = defaultPatientName;
        } else {
            String[] tokens = sourcePatientName.split("\\^");
            if (tokens == null || tokens.length == 0) {
                newPatientName = defaultPatientName;
            } else if (tokens.length == 1) {
                newPatientName = tokens[0];
            } else {
                newPatientName = tokens[1];
            }

        }
        return newPatientName;
    }

    public static String extractPatientLastName(final String sourcePatientName, final String patientName,
            final String defaultPatientName) {
        String newPatientLastName = "";
        if (sourcePatientName != null && (!"".equals(sourcePatientName) && sourcePatientName.length() > 0)) {
            String[] tokens = sourcePatientName.split("\\^");
            if (tokens != null && tokens.length > 0) {
                newPatientLastName = tokens[0];
            }
        }

        int idx = patientName.indexOf("^");
        if (idx > 0 && (newPatientLastName == null || newPatientLastName.length() == 0)) {
            newPatientLastName = patientName.substring(0, idx);
        }
        if (newPatientLastName == null || newPatientLastName.length() == 0) {
            newPatientLastName = defaultPatientName;
        }
        return newPatientLastName;
    }

    /**
     * @param sourceFile
     * @return
     * @throws IOException
     */
    public static byte[] readBytesFromFile(final File sourceFile) throws IOException {
        InputStream is = new FileInputStream(sourceFile);
        byte[] bytes = new byte[(int) sourceFile.length()];
        int offset = 0;
        int numRead = 0;
        numRead = is.read(bytes, offset, bytes.length - offset);
        for (; offset < bytes.length && numRead >= 0; offset += numRead) {
            numRead = is.read(bytes, offset, bytes.length - offset);
        }
        is.close();
        return bytes;
    }

    /**
     * @param dcmElement
     * @return
     */
    public static String getDcmElementValue(/*final DcmElement dcmElement*/) {
        String val = "";
        return val;
    }

    public static String getTagValue(/*final Dataset ds, final int tag*/) {
        String val = "";
        return val;
    }

    /**
     * @param file
     * @return Image DTO
     */
    public static ImageDTO createImageDTO(final Map<String, String> imageManagerAttributes, final String contentType,
            final String fileType, final String defaultSOPInstanceId) {

        ImageDTO imageDTO = new ImageDTO();

        
        SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyyMMdd HHmmss");

        GregorianCalendar gc = new GregorianCalendar();
        sDateFormat.setCalendar(gc);
        LOG.info(" +: imageManagerAttributes " + imageManagerAttributes);
        
        String aquisitionTimestamp = imageManagerAttributes.get("aquisitionTimestamp");
        String aquisitionTimestamp1 = imageManagerAttributes.get("aquisitionTimestamp1");
        try {
            SimpleDateFormat sDateFormat1 = new SimpleDateFormat("yyyyMMddHHmmss");
            LOG.info("aquisitionTimestamp: " + aquisitionTimestamp + "  aquisitionTimestamp1:"
                    + aquisitionTimestamp1);
            if ((aquisitionTimestamp == null || "".equals(aquisitionTimestamp.trim()))
                    && (aquisitionTimestamp1 == null || "".equals(aquisitionTimestamp1.trim()))) {
                imageDTO.setAquisitionTimestamp(DatatypeFactory.newInstance().newXMLGregorianCalendar(gc));
            } else {
                if (aquisitionTimestamp == null || "".equals(aquisitionTimestamp.trim())) {
                    aquisitionTimestamp = aquisitionTimestamp1;
                }
                try {
                    Date nDate = sDateFormat1.parse(aquisitionTimestamp);
                    gc.setTime(nDate);
                    imageDTO.setAquisitionTimestamp(DatatypeFactory.newInstance().newXMLGregorianCalendar(gc));
                } catch (ParseException pe) {
                    LOG.error(pe.getMessage(), pe);
                    try {
                        Date nDate = sDateFormat.parse(aquisitionTimestamp);
                        LOG.info(" aquisitionTimestamp : nDate " + nDate);
                        gc.setTime(nDate);
                        imageDTO.setAquisitionTimestamp(DatatypeFactory.newInstance().newXMLGregorianCalendar(gc));
                    } catch (ParseException pe1) {
                        LOG.error(" aquisitionTimestamp : ParseException " + pe1.getMessage(),
                                pe1);
                        gc.setTime(new Date());
                        imageDTO.setAquisitionTimestamp(DatatypeFactory.newInstance().newXMLGregorianCalendar(gc));
                    }
                }

            }
            
        } catch (DatatypeConfigurationException dce) {
            LOG.error(dce.getMessage(), dce);
        }

        String dateCaptured = imageManagerAttributes.get("dateCaptured");

        try {
            if (dateCaptured != null && !dateCaptured.trim().equals("")&& !dateCaptured.startsWith("null")) {
                LOG.info(" dateCaptured " + dateCaptured + "length " + dateCaptured.length());
                try {
                    Date nDate = sDateFormat.parse(dateCaptured);
                    gc.setTime(nDate);
                    imageDTO.setDateCaptured(DatatypeFactory.newInstance().newXMLGregorianCalendar(gc));
                } catch (ParseException pe) {
                    LOG.error(" dateCaptured : ParseException " + pe.getMessage(), pe);
                    imageDTO.setDateCaptured(DatatypeFactory.newInstance().newXMLGregorianCalendar(
                            (GregorianCalendar) sDateFormat.getCalendar()));
                }

            } else {
                imageDTO.setDateCaptured(DatatypeFactory.newInstance().newXMLGregorianCalendar(
                        (GregorianCalendar) sDateFormat.getCalendar()));

            }
        } catch (DatatypeConfigurationException dce) {
            LOG.error(dce.getMessage(), dce);
        }

        String sopInstanceUID = imageManagerAttributes.get("originalSOPInstanceUID");
        if (sopInstanceUID != null) {
            imageDTO.setSopInstanceUid(sopInstanceUID);
            LOG.info("OriginalSOPInstanceUID: " + sopInstanceUID);
        } else {
            imageDTO.setSopInstanceUid(defaultSOPInstanceId);
            LOG.info("set default OriginalSOPInstanceUID: " + sopInstanceUID);
        }

        String imageTitle = imageManagerAttributes.get("ImageDTO.imageTitle");
        if (!org.apache.commons.lang.StringUtils.isEmpty(imageTitle)) {
            imageDTO.setImageTitle(imageTitle);
            LOG.info(" imageTitle: " + imageTitle);
        } 
        return imageDTO;

    }
    
    public static Calendar getCalendarUTC(final Date d) {
        TimeZone UTC = new SimpleTimeZone(0, "UTC");
        Calendar c = new GregorianCalendar(UTC);
        c.setTime(d);
        return c;
    }
    
    public static XMLGregorianCalendar getXMLDate(Date d) {
    	try {
			return DatatypeFactory.newInstance().newXMLGregorianCalendar(
			        (GregorianCalendar) getCalendarUTC(d));
		} catch (DatatypeConfigurationException e) {
			return null;
		}
    }
    
    public static File getFileToWriteDCMFile(String fileName) {
    	File dcmFile = null;
    	String destFolder = "";
    	try {
    	    destFolder = System.getProperty(IdexxDicomServiceConstants.JAVA_TEMP_LOCATION) + File.separator
    		    + "tempFiles";
    	    File dir = new File(destFolder);
    	    if (!dir.exists()) {
    		dir.mkdirs();
    	    }
    	    dcmFile = new File(dir.getAbsolutePath() + File.separator + fileName);
    	    LOG.info("File Created in temp location: " + dcmFile.getAbsolutePath());
    	} catch (Exception e) {
    	    LOG.error("Error in writing the dcm file to temp location : " + destFolder);
    	}
    	return dcmFile;
        }
    


}
