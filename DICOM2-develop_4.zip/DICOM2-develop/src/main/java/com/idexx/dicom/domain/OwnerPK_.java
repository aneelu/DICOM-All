package com.idexx.dicom.domain;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(OwnerPK.class)
public abstract class OwnerPK_ {

	public static volatile SingularAttribute<OwnerPK, String> clientID;
	public static volatile SingularAttribute<OwnerPK, String> patientID;

}

