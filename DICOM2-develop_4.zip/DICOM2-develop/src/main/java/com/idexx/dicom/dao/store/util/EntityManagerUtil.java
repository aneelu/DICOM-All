package com.idexx.dicom.dao.store.util;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class EntityManagerUtil {
    private static EntityManagerFactory instance;

    public static EntityManagerFactory getEntityManagerFactory() {
        if (null == instance) {
            instance = EntityManagerUtil.getEntityManagerFactory("IDEXX_IM_PLGN");
        }
        return instance;
    }

    public static EntityManagerFactory getEntityManagerFactory(final String context) {
        if (null == instance) {
            instance = Persistence.createEntityManagerFactory(context);
        }
        return instance;
    }
}
