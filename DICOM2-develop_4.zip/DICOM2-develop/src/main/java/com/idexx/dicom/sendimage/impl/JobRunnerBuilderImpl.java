/**
 * 
 */
package com.idexx.dicom.sendimage.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.entities.BaseDicomImPluginConfig;
import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.dao.ws.DicomConfigDao;
import com.idexx.dicom.mapper.EntityMapper;
import com.idexx.dicom.sendimage.ImagePresignedUrlProvider;
import com.idexx.dicom.sendimage.JobRunnerBuilder;
import com.idexx.dicom.sendimage.SendImage;
import com.idexx.dicom.sendimage.SendImageJobConstants;
import com.idexx.dicom.sendimage.SendImageJobProvider;
import com.idexx.dicom.sendimage.SendImageJobUpdateService;
import com.idexx.dicom.sendimage.TimedImageDownloader;
import com.idexx.dicom.services.sendimage.dto.SendImagePendingJobDTO;

/**
 * @author vkandagatla
 * 
 */
@Service("jobRunnerBuilder")
public class JobRunnerBuilderImpl implements JobRunnerBuilder {

    private static final Logger LOG = Logger.getLogger(JobRunnerBuilderImpl.class);

    @Autowired
    private SendImageJobProvider jobProvider;
    @Autowired
    private SendImageJobUpdateService jobUpdateService;
    @Autowired
    private ImagePresignedUrlProvider presignedUrlProvider;
    @Autowired
    private TimedImageDownloader imageDownloader;
    @Autowired
    private DicomConfigDao configDao;
    @Autowired
    private SendImage sendImageService;
    @Autowired
    private EntityMapper entityMapper;

    /**
     * Default
     */
    public JobRunnerBuilderImpl() {
	jobProvider = new SendImageJobProviderImpl();
    }

    /**
     * @return
     */
    @Transactional
    public final List<Runnable> build() {
	String jobCount = getConfigValueForSendImage(SendImageJobConstants.SEND_IMAGE_COUNT_PROCESS);
	List<IdexxSendImageJob> jobs = this.jobProvider.getPendingJobs(jobCount);
	boolean jobsExists = this.isJobExists(jobs);
	LOG.info("Jobs Exists: " + jobsExists);
	if (jobsExists) {
	    jobProvider.updateJobsToInProgressStatus(jobs);
	    return this.createJobProcessors(entityMapper.createPendingJobDto(jobs));
	} else {
	    return null;
	}
    }

    /**
     * @param jobs
     * @return
     */
    private List<Runnable> createJobProcessors(final List<SendImagePendingJobDTO> jobs) {
	List<Runnable> processors = new ArrayList<Runnable>();
	for (SendImagePendingJobDTO job : jobs) {
	    Runnable processor = new SendImageProcessorImpl(job, jobUpdateService, presignedUrlProvider,
		    imageDownloader, configDao, sendImageService);
	    processors.add(processor);
	}
	return processors;
    }

    /**
     * @param jobs
     * @return
     */
    private boolean isJobExists(final List<IdexxSendImageJob> jobs) {
	return ((null != jobs && !jobs.isEmpty()));
    }

    @Scheduled(cron = "0 0 0/1 1/1 * ?")
    @Transactional
    public void patchInProgresstoPending() {
	String oldRecordsCount = getConfigValueForSendImage(SendImageJobConstants.SEND_IMAGE_INPROGRESS);
	jobProvider.updateInProgressJobs(oldRecordsCount);
    }
    
    private String getConfigValueForSendImage(String paramValue) {
	LOG.info("Getting THREAD SLEEP CONFIG VALUE" + paramValue);
	String defaultCount = paramValue;
	BaseDicomImPluginConfig config = this.configDao
		.getConfig(String.valueOf(paramValue));

	String configValue = config.getConfigValue();
	if (!StringUtils.isEmpty(configValue)) {
	    try {
		defaultCount = configValue;
	    } catch (NumberFormatException nfe) {
		defaultCount = paramValue;
	    }
	}
	LOG.info("Getting number of records to process: " + defaultCount);
	return defaultCount;
    }    
    
}
