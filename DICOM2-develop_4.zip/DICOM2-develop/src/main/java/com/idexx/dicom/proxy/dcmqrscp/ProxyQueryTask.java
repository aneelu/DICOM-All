package com.idexx.dicom.proxy.dcmqrscp;

import java.util.ArrayList;
import java.util.List;

import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;
import org.dcm4che3.data.VR;
import org.dcm4che3.net.Association;
import org.dcm4che3.net.pdu.PresentationContext;
import org.dcm4che3.net.service.BasicQueryTask;
import org.dcm4che3.net.service.DicomServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.idexx.dicom.query.request.QueryWebserviceRequestHandler;
import com.idexx.dicom.query.response.QueryResponseHandler;
import com.idexx.dicom.query.soap.QRDataSet;
import com.idexx.dicom.query.soap.QRService11DicomQRRoot;

// TODO: Auto-generated Javadoc
/**
 * The Class ProxyQueryTask.
 */
public class ProxyQueryTask extends BasicQueryTask {

	/** The Constant PATIENT_SOPCLASSUID. */
	private static final String PATIENT_SOP_CLASS_UID = "1.2.840.10008.5.1.4.1.2.1.1";

	/** The Constant STUDY_SOPCLASSUID. */
	private static final String STUDY_SOP_CLASS_UID = "1.2.840.10008.5.1.4.1.2.2.1";

	/** The Constant PATIENTSTUDYONLY_SOPCLASSUID. */
	private static final String PATIENT_STUDY_ONLY_SOP_CLASS_UID = "1.2.840.10008.5.1.4.1.2.3.1";

	/** The Constant MODALITYWORKLIST_SOPCLASSUID. */
	private static final String MODALITY_WORKLIST_SOP_CLASS_UID = "1.2.840.10008.5.1.4.31";

	/** The Constant LOG. */
	static final Logger LOG = LoggerFactory.getLogger(ProxyQueryTask.class);

	/** The q r data set. */
	private List<QRDataSet> qRDataSet;

	/** The availability. */
	protected final String availability;

	/** The response handler. */
	@Autowired
	private QueryResponseHandler responseHandler;

	/** The qer. */
	@Autowired
	QueryWebserviceRequestHandler qer;

	/**
	 * Instantiates a new proxy query task.
	 *
	 * @param as
	 *            the as
	 * @param pc
	 *            the pc
	 * @param rq
	 *            the rq
	 * @param keys
	 *            the keys
	 * @param availability
	 *            the availability
	 */
	public ProxyQueryTask(Association as, PresentationContext pc, Attributes rq, Attributes keys, String availability) {
		super(as, pc, rq, keys);
		this.availability = availability;
	}

	/**
	 * Load qr data set.
	 */
	public void loadQRDataSet() {
		 String callingAET = as.getCallingAET();
		String effectedSOPClassUID = rq.getString(Tag.AffectedSOPClassUID);
		LOG.info(effectedSOPClassUID);
		QRService11DicomQRRoot root = QRService11DicomQRRoot.NONE;
		if (PATIENT_SOP_CLASS_UID.equals(effectedSOPClassUID)) {
			root = QRService11DicomQRRoot.PATIENT;
		} else if (STUDY_SOP_CLASS_UID.equals(effectedSOPClassUID)) {
			root = QRService11DicomQRRoot.STUDY;
		} else if (PATIENT_STUDY_ONLY_SOP_CLASS_UID.equals(effectedSOPClassUID)) {
			root = QRService11DicomQRRoot.PATIENTSTUDYONLY;
		} else if (MODALITY_WORKLIST_SOP_CLASS_UID.equals(effectedSOPClassUID)) {
			root = QRService11DicomQRRoot.MODALITYWORKLIST;
		}
//      QRDataSet data = new QRDataSet();
//      qRDataSet = new ArrayList<QRDataSet>();//qer.search(keys, root, callingAET).getQRDataSet();
      qRDataSet = qer.search(keys, root, callingAET).getQRDataSet();
//      qRDataSet.add(data);//TODO remove this line
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.dcm4che3.net.service.BasicQueryTask#hasMoreMatches()
	 */
	@Override
	public boolean hasMoreMatches() throws DicomServiceException {
		if (qRDataSet != null && qRDataSet.size() != 0) {
			return true;
		}
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.dcm4che3.net.service.BasicQueryTask#nextMatch()
	 */
	@Override
	public Attributes nextMatch() throws DicomServiceException {
		QRDataSet dataSet = qRDataSet.remove(0);
		return responseHandler.getDicomDataset(dataSet);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.dcm4che3.net.service.BasicQueryTask#adjust(org.dcm4che3.data.
	 * Attributes)
	 */
	@Override
	protected Attributes adjust(Attributes match) throws DicomServiceException {
		Attributes adjust = super.adjust(match);
		adjust.remove(Tag.DirectoryRecordType);
		if (keys.contains(Tag.SOPClassUID))
			adjust.setString(Tag.SOPClassUID, VR.UI, match.getString(Tag.ReferencedSOPClassUIDInFile));
		if (keys.contains(Tag.SOPInstanceUID))
			adjust.setString(Tag.SOPInstanceUID, VR.UI, match.getString(Tag.ReferencedSOPInstanceUIDInFile));
		adjust.setString(Tag.QueryRetrieveLevel, VR.CS, keys.getString(Tag.QueryRetrieveLevel));
		adjust.setString(Tag.RetrieveAETitle, VR.AE, as.getCalledAET());
		if (availability != null)
			adjust.setString(Tag.InstanceAvailability, VR.CS, availability);
		// adjust.setString(Tag.StorageMediaFileSetID, VR.SH,
		// ddr.getFileSetID());
		// adjust.setString(Tag.StorageMediaFileSetUID, VR.UI,
		// ddr.getFileSetUID());
		match.setString(Tag.SOPClassUID, VR.UI, match.getString(Tag.ReferencedSOPClassUIDInFile));
		match.setString(Tag.SOPInstanceUID, VR.UI, match.getString(Tag.ReferencedSOPInstanceUIDInFile));

		return adjust;
	}
}
