package com.idexx.dicom.sendimage.impl;

import java.io.File;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Arrays;

import org.apache.log4j.Logger;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.io.DicomInputStream;
import org.dcm4che3.net.ApplicationEntity;
import org.dcm4che3.net.Connection;
import org.dcm4che3.net.IncompatibleConnectionException;
import org.dcm4che3.tool.storescu.StoreSCU;
import org.springframework.stereotype.Service;

import com.idexx.dicom.sendimage.SendImage;
import com.idexx.dicom.services.sendimage.dto.SendImagePendingJobDTO;

/**
 * SendImage DICOM service to send image from one DICOM modality to another
 * modality
 * 
 * @author vvanjarana
 * @version 1.3
 */
@Service("sendImage")
public final class SendImageImpl implements SendImage {
    private Logger logger = Logger.getLogger(SendImageImpl.class);
    
    private ApplicationEntity ae = null;
    private Connection conn = null;

    public void init(ApplicationEntity ae, Connection conn) {	
	this.ae = ae;
	this.conn = conn;
    }

    /**
     * Send Image to the Destination AE
     * 
     * @param SendImagePendingJobDTO
     *            Pending Job
     * @throws InterruptedException
     * @throws IOException
     * @throws GeneralSecurityException 
     * @throws IncompatibleConnectionException 
     */
    public void sendImage(final SendImagePendingJobDTO dto)
	    throws SendImageException, InterruptedException, IOException {
	logger.info("SendImage Job Started: ");
	String destinationAET = dto.getDestinationAETitle();
	String destinationHost = dto.getDestinationHostName();
	int destinationPort = dto.getDestinationPort();
	String filePath = dto.getDownloadedIMFilePath();
	File dcmFile = new File(filePath);
	logger.info("Send Image File Path: " + filePath);

	try(DicomInputStream in = new DicomInputStream(dcmFile)) {	
	    logger.info("checking the input file is supported by destinationAET" + in.toString());
	} catch (IOException exp) {
	    throw new SendImageException("Failed to parse VL Photographic Image Storage not supported by "
		    + destinationAET + " - skipping file: " + dcmFile.getAbsolutePath());
	} 	
	StoreSCU main = null;
	try {
	    main = new StoreSCU(ae);
	} catch (IOException e) {
	    logger.error("Unable to send image to the dicom server: " + e);
	}

	main.getAAssociateRQ().setCalledAET(destinationAET);
	main.getRemoteConnection().setHostname(destinationHost);
	main.getRemoteConnection().setPort(destinationPort);
	main.getRemoteConnection().setTlsCipherSuites(conn.getTlsCipherSuites());
	main.getRemoteConnection().setTlsProtocols(conn.getTlsProtocols());
	main.setAttributes(new Attributes());
	try {
	    main.scanFiles(Arrays.asList(dcmFile.getAbsolutePath()), false);
	    main.open();
	    main.sendFiles();
	} catch (IOException | IncompatibleConnectionException|GeneralSecurityException exc) {
	    logger.error("Unable to send Image with files the dicom server: " + exc);
	} finally {
	    try {
		main.close();
	    } catch (IOException e) {
		logger.error("Unable to send image the dicom server: " + e);
	    }
	}

    }

}
