/**
 * Configuration table entity for AE Services and Store services.
 */
package com.idexx.dicom.ae.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author vkandagatla
 * 
 */
@Entity
@Table(name = "Dicom_IM_Plugin_Config")
public class BaseDicomImPluginConfig implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 5675173423834150761L;
    private int id;
    private String configName;
    private String configValue;
    
    /**
     * @return the id
     */
    @Id
    public int getId() {
        return id;
    }
    
    /**
     * @param id
     *            the id to set
     */
    public void setId(final int id) {
        this.id = id;
    }
    
    /**
     * @return the configName
     */
    @Column(name = "CONFIG_NAME")
    public String getConfigName() {
        return configName;
    }
    
    /**
     * @param configName
     *            the configName to set
     */
    public void setConfigName(final String configName) {
        this.configName = configName;
    }
    
    /**
     * @return the configValue
     */
    @Column(name = "CONFIG_VALUE")
    public String getConfigValue() {
        return configValue;
    }
    
    /**
     * @param configValue
     *            the configValue to set
     */
    public void setConfigValue(final String configValue) {
        this.configValue = configValue;
    }
    
}
