/**
 * Get OpenRequests Service implementation to pims like Neo and Animana
 */
package com.idexx.dicom.services.requestservice;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.idexx.dcm4che3.tool.dcmqrscp.SearchDetailsDTO;
import com.idexx.dicom.aeservices.impl.v13.IdexxDicomWSAthorizationServiceImpl;
import com.idexx.dicom.domain.RequestDetails;
import com.idexx.dicom.mapper.EntityMapper;
import com.idexx.dicom.service.ws.impl.MWLCFindServiceImpl;
import com.idexx.dicom.services.IdexxDicomServiceConstants;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.requestservice.dto.CreateRequestErrorCodesConstants;
import com.idexx.dicom.services.requestservice.dto.GetOpenRequestDTO;
import com.idexx.dicom.services.requestservice.validator.ErrorDTO;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;

/**
 * <pre>
 * GetOpenRequestsService Implementation to open request Service Jobs based on PENDING status.
 * </pre>
 * 
 * @author smallela
 * @version 1.3
 */
@Service
public class GetOpenRequestsServiceImpl {

	private static final Logger LOG = Logger.getLogger(GetOpenRequestsServiceImpl.class);

	@Autowired
	private EntityMapper entityMapper;

	@Autowired
	@Qualifier("idexxDicomWSAthorizationServiceImplV13")
	private IdexxDicomWSAthorizationServiceImpl idexxDicomWsAuthorizeService;
	
	@Autowired
	private MWLCFindServiceImpl mwlCfindService;

	/**
	 * <pre>
	 * GetOpenRequestsService Implementation to open request Service Jobs based on PENDING status and return all request details related to pending status
	 * </pre>
	 * 
	 * @return List<GetOpenRequestDTO>
	 * @throws IdexxDicomAEConfigServiceException
	 * @throws IdexxServiceException_Exception
	 * 
	 */
	public List<GetOpenRequestDTO> getOpenRequests(String apiKey, String sapId, List<ErrorDTO> listofErrors)
			throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {

		List<GetOpenRequestDTO> listOpenRequest = new ArrayList<GetOpenRequestDTO>();
		if (StringUtils.isBlank(apiKey)) {
			listofErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.API_KEY_ERROR_CODE,
					CreateRequestErrorCodesConstants.API_KEY_ERROR_CODE_MSG));
		}
		if (StringUtils.isBlank(sapId)) {
			listofErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.SAP_ID_ERROR_CODE,
					CreateRequestErrorCodesConstants.SAP_ID_ERROR_CODE_MSG));
		}
		if (!listofErrors.isEmpty()) {
			return null;
		}
		try {
			idexxDicomWsAuthorizeService.authorize(apiKey);
		} catch (IdexxDicomAEConfigServiceException e) {
			listofErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.INVALID_API_KEY_ERROR_CODE,
					CreateRequestErrorCodesConstants.INVALID_API_KEY_ERROR_CODE_MSG));
			return null;
		}
		List<String> status = new ArrayList<String>();
		status.add(IdexxDicomServiceConstants.STATUS_PENDING);
		
		SearchDetailsDTO searchDto = new SearchDetailsDTO();
		searchDto.setSapId(sapId);
		searchDto.setStatus(status);		
		List<RequestDetails> listReqDetails = mwlCfindService.findRequestDetails(searchDto);
		if (null != listReqDetails && listReqDetails.size()>0) {
			for (RequestDetails req : listReqDetails) {
				GetOpenRequestDTO getOpenRequestDTO = new GetOpenRequestDTO();
				getOpenRequestDTO.setPatientDTO(entityMapper.getPatient(req.getPatient()));
				getOpenRequestDTO.setAccessionNumber(req.getAccessionNumber());
				getOpenRequestDTO.setModality(req.getModality());
				getOpenRequestDTO.setRequestingDoctor(req.getRequestingDoctor());
				getOpenRequestDTO.setRequestNotes(req.getRequestNotes());
				getOpenRequestDTO.setStudyInstanceUID(req.getStudyInstanceUID());
				getOpenRequestDTO.setStatus(req.getStatus());
				getOpenRequestDTO.setCreateTimestamp(req.getCreateTimeStamp());
				getOpenRequestDTO.setUpdateTimestamp(req.getUpdateTimeStamp());

				listOpenRequest.add(getOpenRequestDTO);
			}
		} else {
			LOG.info("No Records found for : apiKey: " + apiKey + " sapId: " + sapId);
		}
		return listOpenRequest;
	}
}
