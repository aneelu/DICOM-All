package com.idexx.dicom.domain;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(ExternalPatient.class)
public abstract class ExternalPatient_ {

	public static volatile SingularAttribute<ExternalPatient, String> pimsPatientId;
	public static volatile SingularAttribute<ExternalPatient, String> patientID;
	public static volatile SingularAttribute<ExternalPatient, Patient> patient;
	public static volatile SingularAttribute<ExternalPatient, String> issuerOfPatientID;

}

