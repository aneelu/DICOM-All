/**
 * 
 */
package com.idexx.dicom.aeservices;

import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.SendImageJobParamDTO;

/**
 * @author mdindukurthi
 * 
 */
public interface SendImageJobService {
    String performService(SendImageJobParamDTO dto) throws IdexxDicomAEConfigServiceException;
    
    
}
