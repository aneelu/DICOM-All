/**
 * 
 */
package com.idexx.dicom.dto;

import java.util.List;

import com.idexx.imaging.imagemanager.soap.ImageDTO;
import com.idexx.imaging.imagemanager.soap.SeriesDTO;

/**
 * @author vkandagatla
 *
 */
public class SeriesDTOTest extends SeriesDTO {
    private List<ImageDTO> images;

    /**
     * @return the images
     */
    public final List<ImageDTO> getImages() {
        return images;
    }

    /**
     * @param images
     *            the images to set
     */
    public final void setImages(final List<ImageDTO> images) {
        this.images = images;
    }
}
