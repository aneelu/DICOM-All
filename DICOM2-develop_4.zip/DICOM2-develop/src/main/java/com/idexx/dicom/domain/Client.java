package com.idexx.dicom.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CLIENT")
public class Client {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID")
	private String iD;

	@Column(name="FIRST_NAME")
	private String firstName;

	@Column(name="LAST_NAME")
	private String lastName;

	@Column(name="SAP_ID")
	private String sapId;

	@Column(name="EMAIl")
	private String email;

	@Column(name="APPLICATION_CLIENT_ID")
	private String applicationClientId;

	/**
	 * @return the id
	 */
	public String getID() {
		return iD;
	}

	/**
	 * @param id the id to set
	 */
	public void setID(String iD) {
		this.iD = iD;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the sapId
	 */
	public String getSapId() {
		return sapId;
	}

	/**
	 * @param sapId the sapId to set
	 */
	public void setSapId(String sapId) {
		this.sapId = sapId;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the applicationClientId
	 */
	public String getApplicationClientId() {
		return applicationClientId;
	}

	/**
	 * @param applicationClientId the applicationClientId to set
	 */
	public void setApplicationClientId(String applicationClientId) {
		this.applicationClientId = applicationClientId;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
