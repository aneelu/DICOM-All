/**
 * 
 */
package com.idexx.dicom.exceptions;

/**
 * @author vkandagatla
 *
 */
public class IdexxDicomAuthorizationException extends IdexxDicomPluginException {
    
    /**
     * Eclipse Generated
     */
    private static final long serialVersionUID = 6796272159199740003L;

    /**
     * Default
     */
    public IdexxDicomAuthorizationException() {
    }
    
    /**
     * @param message
     */
    public IdexxDicomAuthorizationException(final String message) {
        super(message);
    }
    
    /**
     * @param cause
     */
    public IdexxDicomAuthorizationException(final Throwable cause) {
        super(cause);
    }
    
    /**
     * @param message
     * @param cause
     */
    public IdexxDicomAuthorizationException(final String message, final Throwable cause) {
        super(message, cause);
    }
    
}
