/* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is part of dcm4che, an implementation of DICOM(TM) in
 * Java(TM), hosted at https://github.com/gunterze/dcm4che.
 *
 * The Initial Developer of the Original Code is
 * Agfa Healthcare.
 * Portions created by the Initial Developer are Copyright (C) 2011
 * the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 * See @authors listed below
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */

package com.idexx.dicom.proxy.dcmqrscp;

import java.io.IOException;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.ResourceBundle;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;
import org.dcm4che3.data.UID;
import org.dcm4che3.media.DicomDirReader;
import org.dcm4che3.media.DicomDirWriter;
import org.dcm4che3.media.RecordFactory;
import org.dcm4che3.net.ApplicationEntity;
import org.dcm4che3.net.Association;
import org.dcm4che3.net.Connection;
import org.dcm4che3.net.Device;
import org.dcm4che3.net.Dimse;
import org.dcm4che3.net.QueryOption;
import org.dcm4che3.net.Status;
import org.dcm4che3.net.TransferCapability;
import org.dcm4che3.net.pdu.AAssociateRQ;
import org.dcm4che3.net.pdu.ExtendedNegotiation;
import org.dcm4che3.net.pdu.PresentationContext;
import org.dcm4che3.net.service.BasicCEchoSCP;
import org.dcm4che3.net.service.BasicCFindSCP;
import org.dcm4che3.net.service.BasicCGetSCP;
import org.dcm4che3.net.service.BasicCMoveSCP;
import org.dcm4che3.net.service.BasicCStoreSCU;
import org.dcm4che3.net.service.BasicRetrieveTask;
import org.dcm4che3.net.service.CStoreSCU;
import org.dcm4che3.net.service.DicomServiceException;
import org.dcm4che3.net.service.DicomServiceRegistry;
import org.dcm4che3.net.service.InstanceLocator;
import org.dcm4che3.net.service.QueryRetrieveLevel;
import org.dcm4che3.net.service.QueryTask;
import org.dcm4che3.net.service.RetrieveTask;
import org.dcm4che3.tool.common.CLIUtils;
import org.dcm4che3.tool.common.FilesetInfo;
import org.dcm4che3.util.AttributesFormat;
import org.dcm4che3.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.stereotype.Component;

import com.idexx.dicom.ae.entities.AEEntity;
import com.idexx.dicom.dao.ws.AETitleDao;

// TODO: Auto-generated Javadoc
/**
 * The Class DcmQRSCPProxy.
 *
 * @author Gunter Zeilinger <gunterze@gmail.com>
 * @param <T>
 *            the generic type
 */
@Component("dcmQRSCPProxy")
public class DcmQRSCPProxy<T extends InstanceLocator> {

	/** The Constant LOG. */
	private static final Logger LOG = LoggerFactory.getLogger(DcmQRSCPProxy.class);

	/** The Constant PATIENT_ROOT_LEVELS. */
	private static final String[] PATIENT_ROOT_LEVELS = { "PATIENT", "STUDY", "SERIES", "IMAGE" };

	/** The Constant STUDY_ROOT_LEVELS. */
	private static final String[] STUDY_ROOT_LEVELS = { "STUDY", "SERIES", "IMAGE" };

	/** The Constant PATIENT_STUDY_ONLY_LEVELS. */
	private static final String[] PATIENT_STUDY_ONLY_LEVELS = { "PATIENT", "STUDY" };

	/** The rb. */
	private static ResourceBundle resourceBundle = ResourceBundle.getBundle("org.dcm4che3.tool.dcmqrscp.messages");

	/** The device. */
	private Device device = null;

	/** The ae. */
	private ApplicationEntity applicationEntity = null;

	/** The conn. */
	private Connection conn = null;

	/** The file path format. */
	private AttributesFormat filePathFormat;

	/** The rec fact. */
	private RecordFactory recFact;

	/** The availability. */
	private String availability;

	/** The stg cmt on same assoc. */
	private boolean stgCmtOnSameAssoc;

	/** The send pending c get. */
	private boolean sendPendingCGet;

	/** The send pending c move interval. */
	private int sendPendingCMoveInterval;

	/** The fs info. */
	private final FilesetInfo fsInfo = new FilesetInfo();

	/** The dd reader. */
	private DicomDirReader ddReader;

	/** The dd writer. */
	private DicomDirWriter ddWriter;

	/** The bean factory. */
	@Autowired
	private AutowireCapableBeanFactory beanFactory;

    @Autowired
    private AETitleDao aeTitleDao;

    /**
	 * The Class CFindSCPImpl.
	 */
	private final class CFindSCPImpl extends BasicCFindSCP {

		/** The qr levels. */
		private final String[] qrLevels;

		/** The root level. */
		private final QueryRetrieveLevel rootLevel;

		/**
		 * Instantiates a new c find scp impl.
		 *
		 * @param sopClass
		 *            the sop class
		 * @param qrLevels
		 *            the qr levels
		 */
		public CFindSCPImpl(String sopClass, String... qrLevels) {
			super(sopClass);
			this.qrLevels = qrLevels;
			this.rootLevel = QueryRetrieveLevel.valueOf(qrLevels[0]);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * org.dcm4che3.net.service.BasicCFindSCP#calculateMatches(org.dcm4che3.
		 * net.Association, org.dcm4che3.net.pdu.PresentationContext,
		 * org.dcm4che3.data.Attributes, org.dcm4che3.data.Attributes)
		 */
		@Override
		protected QueryTask calculateMatches(Association association, PresentationContext presentationContext,
				Attributes reqAttributes, Attributes attributesKeys) throws DicomServiceException {
			QueryRetrieveLevel level = QueryRetrieveLevel.valueOf(attributesKeys, qrLevels);
			level.validateQueryKeys(attributesKeys, rootLevel,
					rootLevel == QueryRetrieveLevel.IMAGE || relational(association, reqAttributes));
			String availability = getInstanceAvailability();
			ProxyQueryTask bean = new ProxyQueryTask(association, presentationContext, reqAttributes, attributesKeys,
					availability);
			beanFactory.autowireBean(bean);
			bean.loadQRDataSet();
			return bean;
		}

		/**
		 * Relational.
		 *
		 * @param association
		 *            the as
		 * @param reqAttributes
		 *            the rq
		 * @return true, if successful
		 */
		private boolean relational(Association association, Attributes reqAttributes) {
			String cuid = reqAttributes.getString(Tag.AffectedSOPClassUID);
			ExtendedNegotiation extNeg = association.getAAssociateAC().getExtNegotiationFor(cuid);
			return QueryOption.toOptions(extNeg).contains(QueryOption.RELATIONAL);
		}
	}

	/**
	 * The Class CGetSCPImpl.
	 */
	private final class CGetSCPImpl extends BasicCGetSCP {

		/** The qr levels. */
		private final String[] qrLevels;

		/** The without bulk data. */
		private final boolean withoutBulkData;

		/** The root level. */
		private final QueryRetrieveLevel rootLevel;

		/**
		 * Instantiates a new c get scp impl.
		 *
		 * @param sopClass
		 *            the sop class
		 * @param qrLevels
		 *            the qr levels
		 */
		public CGetSCPImpl(String sopClass, String... qrLevels) {
			super(sopClass);
			this.qrLevels = qrLevels;
			this.withoutBulkData = qrLevels.length == 0;
			this.rootLevel = withoutBulkData ? QueryRetrieveLevel.IMAGE : QueryRetrieveLevel.valueOf(qrLevels[0]);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * org.dcm4che3.net.service.BasicCGetSCP#calculateMatches(org.dcm4che3.
		 * net.Association, org.dcm4che3.net.pdu.PresentationContext,
		 * org.dcm4che3.data.Attributes, org.dcm4che3.data.Attributes)
		 */
		@Override
		protected RetrieveTask calculateMatches(Association association, PresentationContext presentationContext,
				Attributes reqAttributes, Attributes attributesKeys) throws DicomServiceException {
			QueryRetrieveLevel level = withoutBulkData ? QueryRetrieveLevel.IMAGE
					: QueryRetrieveLevel.valueOf(attributesKeys, qrLevels);
			level.validateRetrieveKeys(attributesKeys, rootLevel, relational(association, reqAttributes));

			ProxyRetrieveTask<T> bean = new ProxyRetrieveTask<T>(attributesKeys, association.getLocalAET(),
					association.getCalledAET());

			beanFactory.autowireBean(bean);
			List<T> matches = bean.performTask();
			if (matches.isEmpty())
				return null;

			CStoreSCU<T> storescu = new CStoreSCUImpl<T>(withoutBulkData);

			BasicRetrieveTask<T> retrieveTask = new BasicRetrieveTask<T>(Dimse.C_GET_RQ, association,
					presentationContext, reqAttributes, matches, association, storescu);
			retrieveTask.setSendPendingRSP(isSendPendingCGet());
			return retrieveTask;
		}

		/**
		 * Relational.
		 *
		 * @param association
		 *            the as
		 * @param reqAttributes
		 *            the rq
		 * @return true, if successful
		 */
		private boolean relational(Association association, Attributes reqAttributes) {
			String cuid = reqAttributes.getString(Tag.AffectedSOPClassUID);
			ExtendedNegotiation extNeg = association.getAAssociateAC().getExtNegotiationFor(cuid);
			return QueryOption.toOptions(extNeg).contains(QueryOption.RELATIONAL);
		}

	}

	/**
	 * The Class CMoveSCPImpl.
	 */
	private final class CMoveSCPImpl extends BasicCMoveSCP {

		/** The qr levels. */
		private final String[] qrLevels;

		/** The root level. */
		private final QueryRetrieveLevel rootLevel;

		/**
		 * Instantiates a new c move scp impl.
		 *
		 * @param sopClass
		 *            the sop class
		 * @param qrLevels
		 *            the qr levels
		 */
		public CMoveSCPImpl(String sopClass, String... qrLevels) {
			super(sopClass);
			this.qrLevels = qrLevels;
			this.rootLevel = QueryRetrieveLevel.valueOf(qrLevels[0]);
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see
		 * org.dcm4che3.net.service.BasicCMoveSCP#calculateMatches(org.dcm4che3.
		 * net.Association, org.dcm4che3.net.pdu.PresentationContext,
		 * org.dcm4che3.data.Attributes, org.dcm4che3.data.Attributes)
		 */
		@Override
		protected RetrieveTask calculateMatches(Association association, PresentationContext presentationContext,
				final Attributes reqAttributes, Attributes keys) throws DicomServiceException {
			QueryRetrieveLevel level = QueryRetrieveLevel.valueOf(keys, qrLevels);
			level.validateRetrieveKeys(keys, rootLevel, relational(association, reqAttributes));
			String moveDest = reqAttributes.getString(Tag.MoveDestination);
			List<AEEntity> aeList = aeTitleDao.findAE(moveDest);
			Connection remote = null;
			if(aeList != null && aeList.size() > 0) {
				AEEntity ae = aeList.get(0);
				try {
					remote = new Connection();
					remote.setHostname(ae.getHostName());
					remote.setPort(ae.getPort());
				} catch (Exception e) {
					throw new IllegalArgumentException("Unable to connect to destination host");
				}
			}
			if (remote == null)
				throw new DicomServiceException(Status.MoveDestinationUnknown,
						"Move Destination: " + moveDest + " unknown");

			ProxyRetrieveTask<T> bean = new ProxyRetrieveTask<T>(keys, association.getLocalAET(),
					reqAttributes.getString(Tag.MoveDestination));
			beanFactory.autowireBean(bean);
			List<T> matches = bean.performTask();
			if (matches.isEmpty())
				return null;

			AAssociateRQ aarq = makeAAssociateRQ(association.getLocalAET(), moveDest, matches);
			Association storeas = openStoreAssociation(association, remote, aarq);

			BasicRetrieveTask<T> retrieveTask = new BasicRetrieveTask<T>(Dimse.C_MOVE_RQ, association,
					presentationContext, reqAttributes, matches, storeas, new BasicCStoreSCU<T>());
			retrieveTask.setSendPendingRSPInterval(getSendPendingCMoveInterval());
			return retrieveTask;
		}

		/**
		 * Open store association.
		 *
		 * @param Association
		 *            the as
		 * @param remote
		 *            the remote
		 * @param aassociateRQ
		 *            the aarq
		 * @return the association
		 * @throws DicomServiceException
		 *             the dicom service exception
		 */
		private Association openStoreAssociation(Association Association, Connection remote, AAssociateRQ aassociateRQ)
				throws DicomServiceException {
			try {
				return Association.getApplicationEntity().connect(Association.getConnection(), remote, aassociateRQ);
			} catch (Exception e) {
				throw new DicomServiceException(Status.UnableToPerformSubOperations, e);
			}
		}

		/**
		 * Make a associate rq.
		 *
		 * @param callingAET
		 *            the calling aet
		 * @param calledAET
		 *            the called aet
		 * @param matches
		 *            the matches
		 * @return the a associate rq
		 */
		private AAssociateRQ makeAAssociateRQ(String callingAET, String calledAET, List<T> matches) {
			AAssociateRQ aassociateRQ = new AAssociateRQ();
			aassociateRQ.setCalledAET(calledAET);
			aassociateRQ.setCallingAET(callingAET);
			for (InstanceLocator match : matches) {
				if (aassociateRQ.addPresentationContextFor(match.cuid, match.tsuid)) {
					if (!UID.ExplicitVRLittleEndian.equals(match.tsuid))
						aassociateRQ.addPresentationContextFor(match.cuid, UID.ExplicitVRLittleEndian);
					if (!UID.ImplicitVRLittleEndian.equals(match.tsuid))
						aassociateRQ.addPresentationContextFor(match.cuid, UID.ImplicitVRLittleEndian);
				}
			}
			return aassociateRQ;
		}

		/**
		 * Relational.
		 *
		 * @param association
		 *            the as
		 * @param reqAttributes
		 *            the rq
		 * @return true, if successful
		 */
		private boolean relational(Association association, Attributes reqAttributes) {
			String cuid = reqAttributes.getString(Tag.AffectedSOPClassUID);
			ExtendedNegotiation extNeg = association.getAAssociateAC().getExtNegotiationFor(cuid);
			return QueryOption.toOptions(extNeg).contains(QueryOption.RELATIONAL);
		}
	}

	/**
	 * Instantiates a new dcm qrscp proxy.
	 *
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public DcmQRSCPProxy() throws IOException {
	}

	/**
	 * Inits the.
	 *
	 * @param args
	 *            the args
	 * @param device
	 *            the device
	 * @param applicationEntity
	 *            the ae
	 * @param conn
	 *            the conn
	 * @param serviceRegistry
	 *            the service registry
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public void init(String[] args, Device device, ApplicationEntity applicationEntity, Connection conn,
			DicomServiceRegistry serviceRegistry) throws IOException {

		this.device = device;
		this.applicationEntity = applicationEntity;
		this.conn = conn;

		try {
			CommandLine commandLine = parseComandLine(args);

			CLIUtils.configure(fsInfo, commandLine);
			CLIUtils.configureBindServer(conn, applicationEntity, commandLine);
			CLIUtils.configure(conn, commandLine);
			DcmQRSCPProxy.configureTransferCapability(this, commandLine);
			DcmQRSCPProxy.configureInstanceAvailability(this, commandLine);
			DcmQRSCPProxy.configureStgCmt(this, commandLine);
			DcmQRSCPProxy.configureSendPending(this, commandLine);
			this.init(serviceRegistry);
		} catch (ParseException e) {
			LOG.error("ParseException in dcmqrscp: " + e.getMessage());
		} catch (Exception e) {
			LOG.error("Exception in dcmqrscp: " + e.getMessage());
		}

	}

	/**
	 * Inits the.
	 *
	 * @param serviceRegistry
	 *            the service registry
	 */
	public void init(DicomServiceRegistry serviceRegistry) {
		device.setDimseRQHandler(createServiceRegistry(serviceRegistry));
	}

	/**
	 * Creates the service registry.
	 *
	 * @param serviceRegistry
	 *            the service registry
	 * @return the dicom service registry
	 */
	private DicomServiceRegistry createServiceRegistry(DicomServiceRegistry serviceRegistry) {
		serviceRegistry.addDicomService(new BasicCEchoSCP());

		serviceRegistry.addDicomService(
				new CFindSCPImpl(UID.PatientRootQueryRetrieveInformationModelFIND, PATIENT_ROOT_LEVELS));
		serviceRegistry
				.addDicomService(new CFindSCPImpl(UID.StudyRootQueryRetrieveInformationModelFIND, STUDY_ROOT_LEVELS));
		serviceRegistry.addDicomService(new CFindSCPImpl(UID.PatientStudyOnlyQueryRetrieveInformationModelFINDRetired,
				PATIENT_STUDY_ONLY_LEVELS));
		serviceRegistry
				.addDicomService(new CGetSCPImpl(UID.PatientRootQueryRetrieveInformationModelGET, PATIENT_ROOT_LEVELS));
		serviceRegistry
				.addDicomService(new CGetSCPImpl(UID.StudyRootQueryRetrieveInformationModelGET, STUDY_ROOT_LEVELS));
		serviceRegistry.addDicomService(new CGetSCPImpl(UID.PatientStudyOnlyQueryRetrieveInformationModelGETRetired,
				PATIENT_STUDY_ONLY_LEVELS));
		serviceRegistry.addDicomService(new CGetSCPImpl(UID.CompositeInstanceRetrieveWithoutBulkDataGET));
		serviceRegistry.addDicomService(
				new CMoveSCPImpl(UID.PatientRootQueryRetrieveInformationModelMOVE, PATIENT_ROOT_LEVELS));
		serviceRegistry
				.addDicomService(new CMoveSCPImpl(UID.StudyRootQueryRetrieveInformationModelMOVE, STUDY_ROOT_LEVELS));
		serviceRegistry.addDicomService(new CMoveSCPImpl(UID.PatientStudyOnlyQueryRetrieveInformationModelMOVERetired,
				PATIENT_STUDY_ONLY_LEVELS));
		return serviceRegistry;
	}

	/**
	 * Gets the device.
	 *
	 * @return the device
	 */
	public final Device getDevice() {
		return device;
	}

	/**
	 * Sets the device.
	 *
	 * @param device
	 *            the new device
	 */
	public void setDevice(Device device) {
		this.device = device;
	}

	/**
	 * Sets the application entity.
	 *
	 * @param ae
	 *            the new application entity
	 */
	public void setApplicationEntity(ApplicationEntity ae) {
		this.applicationEntity = ae;
	}

	/**
	 * Gets the file path format.
	 *
	 * @return the file path format
	 */
	public final AttributesFormat getFilePathFormat() {
		return filePathFormat;
	}

	/**
	 * Sets the file path format.
	 *
	 * @param pattern
	 *            the new file path format
	 */
	public void setFilePathFormat(String pattern) {
		this.filePathFormat = new AttributesFormat(pattern);
	}

	/**
	 * Sets the instance availability.
	 *
	 * @param availability
	 *            the new instance availability
	 */
	public final void setInstanceAvailability(String availability) {
		this.availability = availability;
	}

	/**
	 * Gets the instance availability.
	 *
	 * @return the instance availability
	 */
	public final String getInstanceAvailability() {
		return availability;
	}

	/**
	 * Checks if is stg cmt on same assoc.
	 *
	 * @return true, if is stg cmt on same assoc
	 */
	public boolean isStgCmtOnSameAssoc() {
		return stgCmtOnSameAssoc;
	}

	/**
	 * Sets the stg cmt on same assoc.
	 *
	 * @param stgCmtOnSameAssoc
	 *            the new stg cmt on same assoc
	 */
	public void setStgCmtOnSameAssoc(boolean stgCmtOnSameAssoc) {
		this.stgCmtOnSameAssoc = stgCmtOnSameAssoc;
	}

	/**
	 * Sets the send pending c get.
	 *
	 * @param sendPendingCGet
	 *            the new send pending c get
	 */
	public final void setSendPendingCGet(boolean sendPendingCGet) {
		this.sendPendingCGet = sendPendingCGet;
	}

	/**
	 * Checks if is send pending c get.
	 *
	 * @return true, if is send pending c get
	 */
	public final boolean isSendPendingCGet() {
		return sendPendingCGet;
	}

	/**
	 * Sets the send pending c move interval.
	 *
	 * @param sendPendingCMoveInterval
	 *            the new send pending c move interval
	 */
	public final void setSendPendingCMoveInterval(int sendPendingCMoveInterval) {
		this.sendPendingCMoveInterval = sendPendingCMoveInterval;
	}

	/**
	 * Gets the send pending c move interval.
	 *
	 * @return the send pending c move interval
	 */
	public final int getSendPendingCMoveInterval() {
		return sendPendingCMoveInterval;
	}

	/**
	 * Sets the record factory.
	 *
	 * @param recFact
	 *            the new record factory
	 */
	public final void setRecordFactory(RecordFactory recFact) {
		this.recFact = recFact;
	}

	/**
	 * Gets the record factory.
	 *
	 * @return the record factory
	 */
	public final RecordFactory getRecordFactory() {
		return recFact;
	}

	/**
	 * Parses the comand line.
	 *
	 * @param args
	 *            the args
	 * @return the command line
	 * @throws ParseException
	 *             the parse exception
	 */
	private static CommandLine parseComandLine(String[] args) throws ParseException {
		Options options = new Options();
		CLIUtils.addFilesetInfoOptions(options);
		CLIUtils.addBindServerOption(options);
		CLIUtils.addConnectTimeoutOption(options);
		CLIUtils.addAcceptTimeoutOption(options);
		CLIUtils.addAEOptions(options);
		CLIUtils.addCommonOptions(options);
		CLIUtils.addResponseTimeoutOption(options);
		addDicomDirOption(options);
		addTransferCapabilityOptions(options);
		addInstanceAvailabilityOption(options);
		addStgCmtOptions(options);
		addSendingPendingOptions(options);
		addRemoteConnectionsOption(options);
		return CLIUtils.parseComandLine(args, options, resourceBundle, DcmQRSCPProxy.class);
	}

	/**
	 * Adds the instance availability option.
	 *
	 * @param options
	 *            the options
	 */
	@SuppressWarnings("static-access")
	private static void addInstanceAvailabilityOption(Options options) {
		options.addOption(OptionBuilder.hasArg().withArgName("code")
				.withDescription(resourceBundle.getString("availability")).withLongOpt("availability").create());
	}

	/**
	 * Adds the stg cmt options.
	 *
	 * @param options
	 *            the options
	 */
	private static void addStgCmtOptions(Options options) {
		options.addOption(null, "stgcmt-same-assoc", false, resourceBundle.getString("stgcmt-same-assoc"));
	}

	/**
	 * Adds the sending pending options.
	 *
	 * @param options
	 *            the options
	 */
	@SuppressWarnings("static-access")
	private static void addSendingPendingOptions(Options options) {
		options.addOption(null, "pending-cget", false, resourceBundle.getString("pending-cget"));
		options.addOption(OptionBuilder.hasArg().withArgName("s")
				.withDescription(resourceBundle.getString("pending-cmove")).withLongOpt("pending-cmove").create());
	}

	/**
	 * Adds the dicom dir option.
	 *
	 * @param options
	 *            the options
	 */
	@SuppressWarnings("static-access")
	private static void addDicomDirOption(Options options) {
		options.addOption(OptionBuilder.hasArg().withArgName("file")
				.withDescription(resourceBundle.getString("dicomdir")).withLongOpt("dicomdir").create());
		options.addOption(OptionBuilder.hasArg().withArgName("pattern")
				.withDescription(resourceBundle.getString("filepath")).withLongOpt("filepath").create(null));
	}

	/**
	 * Adds the transfer capability options.
	 *
	 * @param options
	 *            the opts
	 */
	@SuppressWarnings("static-access")
	private static void addTransferCapabilityOptions(Options options) {
		options.addOption(null, "all-storage", false, resourceBundle.getString("all-storage"));
		options.addOption(null, "no-storage", false, resourceBundle.getString("no-storage"));
		options.addOption(null, "no-query", false, resourceBundle.getString("no-query"));
		options.addOption(null, "no-retrieve", false, resourceBundle.getString("no-retrieve"));
		options.addOption(null, "relational", false, resourceBundle.getString("relational"));
		options.addOption(OptionBuilder.hasArg().withArgName("file|url")
				.withDescription(resourceBundle.getString("storage-sop-classes")).withLongOpt("storage-sop-classes")
				.create());
		options.addOption(OptionBuilder.hasArg().withArgName("file|url")
				.withDescription(resourceBundle.getString("query-sop-classes")).withLongOpt("query-sop-classes")
				.create());
		options.addOption(OptionBuilder.hasArg().withArgName("file|url")
				.withDescription(resourceBundle.getString("retrieve-sop-classes")).withLongOpt("retrieve-sop-classes")
				.create());
	}

	/**
	 * Adds the remote connections option.
	 *
	 * @param options
	 *            the options
	 */
	@SuppressWarnings("static-access")
	private static void addRemoteConnectionsOption(Options options) {
		options.addOption(OptionBuilder.hasArg().withArgName("file|url")
				.withDescription(resourceBundle.getString("ae-config")).withLongOpt("ae-config").create());
	}

	/**
	 * Configure instance availability.
	 *
	 * @param main
	 *            the main
	 * @param commandLine
	 *            the command line
	 */
	private static void configureInstanceAvailability(DcmQRSCPProxy main, CommandLine commandLine) {
		main.setInstanceAvailability(commandLine.getOptionValue("availability"));
	}

	/**
	 * Configure stg cmt.
	 *
	 * @param main
	 *            the main
	 * @param commandLine
	 *            the command line
	 */
	private static void configureStgCmt(DcmQRSCPProxy main, CommandLine commandLine) {
		main.setStgCmtOnSameAssoc(commandLine.hasOption("stgcmt-same-assoc"));
	}

	/**
	 * Configure send pending.
	 *
	 * @param main
	 *            the main
	 * @param commandLine
	 *            the command line
	 */
	private static void configureSendPending(DcmQRSCPProxy main, CommandLine commandLine) {
		main.setSendPendingCGet(commandLine.hasOption("pending-cget"));
		if (commandLine.hasOption("pending-cmove"))
			main.setSendPendingCMoveInterval(Integer.parseInt(commandLine.getOptionValue("pending-cmove")));
	}

	/**
	 * Checks if is writeable.
	 *
	 * @return true, if is writeable
	 */
	public boolean isWriteable() {
		return false;
	}

	/**
	 * Configure transfer capability.
	 *
	 * @param main
	 *            the main
	 * @param commandLine
	 *            the cl
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	private static void configureTransferCapability(DcmQRSCPProxy main, CommandLine commandLine) throws IOException {
		ApplicationEntity applicationEntity = main.applicationEntity;
		EnumSet<QueryOption> queryOptions = commandLine.hasOption("relational") ? EnumSet.of(QueryOption.RELATIONAL)
				: EnumSet.noneOf(QueryOption.class);
		boolean storage = !commandLine.hasOption("no-storage") && main.isWriteable();
		if (storage && commandLine.hasOption("all-storage")) {
			TransferCapability transferCapability = new TransferCapability(null, "*", TransferCapability.Role.SCP, "*");
			transferCapability.setQueryOptions(queryOptions);
			applicationEntity.addTransferCapability(transferCapability);
		} else {
			applicationEntity.addTransferCapability(new TransferCapability(null, UID.VerificationSOPClass,
					TransferCapability.Role.SCP, UID.ImplicitVRLittleEndian));
			Properties storageSOPClasses = CLIUtils.loadProperties(
					commandLine.getOptionValue("storage-sop-classes", "resource:storage-sop-classes.properties"), null);
			if (storage)
				addTransferCapabilities(applicationEntity, storageSOPClasses, TransferCapability.Role.SCP, null);
			if (!commandLine.hasOption("no-retrieve")) {
				addTransferCapabilities(applicationEntity, storageSOPClasses, TransferCapability.Role.SCU, null);
				Properties Properties = CLIUtils.loadProperties(
						commandLine.getOptionValue("retrieve-sop-classes", "resource:retrieve-sop-classes.properties"),
						null);
				addTransferCapabilities(applicationEntity, Properties, TransferCapability.Role.SCP, queryOptions);
			}
			if (!commandLine.hasOption("no-query")) {
				Properties properties = CLIUtils.loadProperties(
						commandLine.getOptionValue("query-sop-classes", "resource:query-sop-classes.properties"), null);
				addTransferCapabilities(applicationEntity, properties, TransferCapability.Role.SCP, queryOptions);
			}
		}
	}

	/**
	 * Adds the transfer capabilities.
	 *
	 * @param applicationEntity
	 *            the ae
	 * @param properties
	 *            the p
	 * @param role
	 *            the role
	 * @param queryOptions
	 *            the query options
	 */
	private static void addTransferCapabilities(ApplicationEntity applicationEntity, Properties properties,
			TransferCapability.Role role, EnumSet<QueryOption> queryOptions) {
		for (String cuid : properties.stringPropertyNames()) {
			String transferSyntax = properties.getProperty(cuid);
			TransferCapability transferCapability = new TransferCapability(null, CLIUtils.toUID(cuid), role,
					CLIUtils.toUIDs(transferSyntax));
			transferCapability.setQueryOptions(queryOptions);
			applicationEntity.addTransferCapability(transferCapability);
		}
	}


	/**
	 * Gets the dicom dir reader.
	 *
	 * @return the dicom dir reader
	 */
	final DicomDirReader getDicomDirReader() {
		return ddReader;
	}

	/**
	 * Sets the dicom dir reader.
	 *
	 * @param ddReader
	 *            the new dicom dir reader
	 */
	public void setDicomDirReader(DicomDirReader ddReader) {
		this.ddReader = ddReader;
	}

	/**
	 * Gets the dicom dir writer.
	 *
	 * @return the dicom dir writer
	 */
	final DicomDirWriter getDicomDirWriter() {
		return ddWriter;
	}

	/**
	 * Calculate c move matches.
	 *
	 * @param keys
	 *            the keys
	 * @return the list
	 */
	public List<T> calculateCMoveMatches(Attributes keys) {

		return null;
	}

	/**
	 * Gets the connection.
	 *
	 * @return the connection
	 */
	public Connection getConnection() {
		return conn;
	}

	/**
	 * Gets the application entity.
	 *
	 * @return the application entity
	 */
	public ApplicationEntity getApplicationEntity() {
		return applicationEntity;
	}

}
