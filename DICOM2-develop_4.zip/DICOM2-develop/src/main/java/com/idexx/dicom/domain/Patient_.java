package com.idexx.dicom.domain;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SetAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(Patient.class)
public abstract class Patient_ {

	public static volatile SingularAttribute<Patient, String> patientName;
	public static volatile SingularAttribute<Patient, String> clinicId;
	public static volatile SingularAttribute<Patient, String> gender;
	public static volatile SingularAttribute<Patient, Timestamp> lastModifiedDate;
	public static volatile SingularAttribute<Patient, Integer> weight;
	public static volatile SingularAttribute<Patient, String> applicationPatientId;
	public static volatile SingularAttribute<Patient, String> breed;
	public static volatile SetAttribute<Patient, Owner> ownersWithClient;
	public static volatile SingularAttribute<Patient, String> species;
	public static volatile SingularAttribute<Patient, Timestamp> dob;
	public static volatile ListAttribute<Patient, ExternalPatient> externalPatientIds;
	public static volatile SingularAttribute<Patient, String> edhdNumber;
	public static volatile SingularAttribute<Patient, String> iD;
	public static volatile SetAttribute<Patient, Owner> ownersWithPatient;
	public static volatile SingularAttribute<Patient, String> weightUnit;
	public static volatile SingularAttribute<Patient, Integer> activeFlag;

}

