package com.idexx.dicom.query.response.impl;

import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;
import org.dcm4che3.data.VR;
import org.springframework.stereotype.Component;

import com.idexx.dicom.query.response.QueryResponseHandler;
import com.idexx.dicom.query.soap.QRDataSet;

@Component
public class QueryResponseHandlerImpl implements QueryResponseHandler {

    @Override
    public final Attributes getDicomDataset(final QRDataSet qrDataSet) {
    	//TODO this has been mocked, need to unmock
/*    	Attributes rspData = new Attributes();
            rspData.setString(Tag.SpecificCharacterSet, VR.CS, "");
            rspData.setString(Tag.StudyDate, VR.DA, "20141027");
            rspData.setString(Tag.StudyTime, VR.TM, "120945.294");
            rspData.setString(Tag.AccessionNumber, VR.SH, "69");
            rspData.setString(Tag.QueryRetrieveLevel, VR.CS, "PATIENT");
            rspData.setString(Tag.InstanceNumber, VR.IS, "2");
            rspData.setString(Tag.ModalitiesInStudy, VR.CS, "DX");
            rspData.setString(Tag.StudyDescription, VR.LO, "27/10/14 12:09 PM");
            rspData.setString(Tag.PatientName, VR.PN, "RR@^RR2");
            rspData.setString(Tag.PatientID, VR.LO, "33");
            rspData.setString(Tag.PatientBirthDate, VR.DA, "20111027");
            rspData.setString(Tag.PatientSex, VR.CS, "F");
            rspData.setString(Tag.StudyInstanceUID, VR.UI, "1.2.826.0.1.3680043.2.950.999510.54.20141027120945");
            rspData.setString(Tag.Modality, VR.CS, "DX");
            rspData.setString(Tag.ReferringPhysicianName, VR.PN, "");
            rspData.setString(Tag.SeriesNumber, VR.IS, "69");
            rspData.setString(Tag.SeriesInstanceUID, VR.UI, "1.2.826.0.1.3680043.2.950.999510.20141027120945.69");
            rspData.setString(Tag.StudyID, VR.SH, "54");
            rspData.setString(Tag.NumberOfPatientRelatedStudies, VR.IS, "3");
            rspData.setString(Tag.NumberOfPatientRelatedSeries, VR.IS, "4");
            rspData.setString(Tag.NumberOfPatientRelatedInstances, VR.IS, "5");
            rspData.setString(Tag.NumberOfStudyRelatedSeries, VR.IS, "6");
            rspData.setString(Tag.NumberOfStudyRelatedInstances, VR.IS, "7");
            rspData.setString(Tag.NumberOfSeriesRelatedInstances, VR.IS, "8");
        return rspData;
*/        
    	
    	
        
    	Attributes rspData = new Attributes();
        if (qrDataSet.getCharset() != null) {
            rspData.setString(Tag.SpecificCharacterSet, VR.CS, qrDataSet.getCharset().getValue());
        }
        if (qrDataSet.getStudyDate() != null) {
            rspData.setString(Tag.StudyDate, VR.DA, qrDataSet.getStudyDate().getValue());
        }
        if (qrDataSet.getStudyTime() != null) {
            rspData.setString(Tag.StudyTime, VR.TM, qrDataSet.getStudyTime().getValue());
        }
        if (qrDataSet.getAccessionNumber() != null) {
            rspData.setString(Tag.AccessionNumber, VR.SH, qrDataSet.getAccessionNumber().getValue());
        }
        if (qrDataSet.getQueryLevel() != null) {
            rspData.setString(Tag.QueryRetrieveLevel, VR.CS, qrDataSet.getQueryLevel().value());
        }
        if (qrDataSet.getInstanceNumber() != null) {
            rspData.setString(Tag.InstanceNumber, VR.IS, qrDataSet.getInstanceNumber().getValue());
        }
        if (qrDataSet.getModalitiesInStudy() != null) {
            rspData.setString(Tag.ModalitiesInStudy, VR.CS, qrDataSet.getModalitiesInStudy().getValue());
        }
        if (qrDataSet.getStudyDescription() != null) {
            rspData.setString(Tag.StudyDescription, VR.LO, qrDataSet.getStudyDescription().getValue());
        }
        if (qrDataSet.getPatientName() != null) {
            try {
            rspData.setString(Tag.PatientName, VR.PN, qrDataSet.getPatientName().getValue());
            } catch (Exception exp) {
                rspData.setString(Tag.PatientName, VR.PN, "UNKNOWN");
            }
        }
        if (qrDataSet.getPatientID() != null) {
            rspData.setString(Tag.PatientID, VR.LO, qrDataSet.getPatientID().getValue());
        }
        if (qrDataSet.getDateOfBirth() != null) {
            rspData.setString(Tag.PatientBirthDate, VR.DA, qrDataSet.getDateOfBirth().getValue());
        }
        if (qrDataSet.getSex() != null) {
            rspData.setString(Tag.PatientSex, VR.CS, qrDataSet.getSex().getValue());
        }
        if (qrDataSet.getStudyUID() != null && qrDataSet.getStudyUID().getValue() != null) {
            rspData.setString(Tag.StudyInstanceUID, VR.UI, qrDataSet.getStudyUID().getValue());
        }
        if (qrDataSet.getModality() != null) {
            rspData.setString(Tag.Modality, VR.CS, qrDataSet.getModality().getValue());
        }
        if (qrDataSet.getReferringPhysicianDICOM() != null) {
            rspData.setString(Tag.ReferringPhysicianName, VR.PN, qrDataSet.getReferringPhysicianDICOM().getValue());
        }
        if (qrDataSet.getSeriesNumber() != null) {
            rspData.setString(Tag.SeriesNumber, VR.IS, qrDataSet.getSeriesNumber().getValue());
        }            
        if (qrDataSet.getSeriesUID() != null && qrDataSet.getSeriesUID().getValue() != null) {
            rspData.setString(Tag.SeriesInstanceUID, VR.UI, qrDataSet.getSeriesUID().getValue());
        }
        if (qrDataSet.getStudyID() != null) {
            rspData.setString(Tag.StudyID, VR.SH, qrDataSet.getStudyID().getValue());
        }
        
        if (qrDataSet.getStudiesInPatient() != null) {
            rspData.setString(Tag.NumberOfPatientRelatedStudies, VR.IS, qrDataSet.getStudiesInPatient().getValue());
        }
        if (qrDataSet.getSeriesInPatient() != null) {
            rspData.setString(Tag.NumberOfPatientRelatedSeries, VR.IS, qrDataSet.getSeriesInPatient().getValue());
        }
        if (qrDataSet.getInstancesInPatient() != null) {
            rspData.setString(Tag.NumberOfPatientRelatedInstances, VR.IS, qrDataSet.getInstancesInPatient().getValue());
        }
        if (qrDataSet.getSeriesInStudy() != null) {
            rspData.setString(Tag.NumberOfStudyRelatedSeries, VR.IS, qrDataSet.getSeriesInStudy().getValue());
        }
        if (qrDataSet.getInstancesInStudy() != null) {
            rspData.setString(Tag.NumberOfStudyRelatedInstances, VR.IS, qrDataSet.getInstancesInStudy().getValue());
        }
        if (qrDataSet.getInstancesInSeries() != null) {
            rspData.setString(Tag.NumberOfSeriesRelatedInstances, VR.IS, qrDataSet.getInstancesInSeries().getValue());
        }                
        return rspData;

    }
    
}
