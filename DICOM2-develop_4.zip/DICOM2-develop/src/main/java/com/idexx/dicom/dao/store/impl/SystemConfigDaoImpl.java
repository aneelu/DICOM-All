/**
 * 
 */
package com.idexx.dicom.dao.store.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.idexx.dicom.dao.store.SystemConfigDao;
import com.idexx.dicom.entities.store.DicomImPluginConfig;

/**
 * @author vkandagatla
 * 
 */
@Repository
public class SystemConfigDaoImpl implements SystemConfigDao {

    private static final String DCM_CONFIG_HQL = "SELECT CONF FROM DicomImPluginConfig CONF ";
    private static final String DCM_CONFIG_BY_CONFIG_NAME_HQL = "SELECT CONF FROM DicomImPluginConfig "
            + "CONF WHERE CONF.configName=:CONFIG_NAME_PARAM ";
    
    @PersistenceContext
    EntityManager entityManager;
    
    public SystemConfigDaoImpl() {
        super();        
    }

    /**
     * return DicomImPluginConfig elements List
     */
    @Override
    @Transactional
    public final Map<String, String> getConfigValues() {
        Map<String, String> configurationMap = new HashMap<String, String>();
        @SuppressWarnings("unchecked")
        List<DicomImPluginConfig> dicomImPluginConfigList = entityManager.createQuery(DCM_CONFIG_HQL).getResultList();
        
        for (DicomImPluginConfig dConfig : dicomImPluginConfigList) {
            configurationMap.put(dConfig.getConfigName(), dConfig.getConfigValue());
        }
        return configurationMap;
        
    }
    
    @Transactional
    public final String getConfigValueByConfigName(final String configName) {
        DicomImPluginConfig config = (DicomImPluginConfig) entityManager.createQuery(DCM_CONFIG_BY_CONFIG_NAME_HQL)
                .setParameter("CONFIG_NAME_PARAM", configName).getSingleResult();
        String configValue = null;
        if (null != config) {
            configValue = config.getConfigValue();
        }
        return configValue;
    }
    
}
