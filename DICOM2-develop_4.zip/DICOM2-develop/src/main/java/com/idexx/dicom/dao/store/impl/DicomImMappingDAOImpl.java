/**
 * 
 */
package com.idexx.dicom.dao.store.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.idexx.dicom.dao.store.DicomImMappingDAO;
import com.idexx.dicom.entities.store.DicomIMMappings;
import com.idexx.dicom.entities.store.DicomImageManagerMapping;

/**
 * @author vkandagatla
 * 
 */
@Repository
public class DicomImMappingDAOImpl implements DicomImMappingDAO {

    /**	
     * @param entityManager
     */
    
    @PersistenceContext
    EntityManager entityManager;
    
    /*public DicomImMappingDAOImpl(final EntityManager entityManager) {
        super(entityManager);
    }*/
    
    public DicomImMappingDAOImpl(){
	
    }

    private static final String DISTINCT_ENABLED_IM_FIELDS_HQL = "select distinct d.imFieldName "
            + "from DicomIMMappings d WHERE d.componentName = :COMPONENT_NAME AND d.requestType = :REQUEST_TYPE";

    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.store.dao.DicomImMappingDAO#getEnabledImFieldNames()
     */
    @Override
    @Transactional
    public final List<String> getEnabledImFieldNames() {
        @SuppressWarnings("unchecked")
        List<String> mappings = entityManager.createQuery(DISTINCT_ENABLED_IM_FIELDS_HQL)
                .setParameter(COMPONENT_NAME_PARAM, IMAGE_STORE_COMPONENT_NAME)
                .setParameter(REQUEST_TYPE_PARAMS, IMAGE_STORE_COMPONENT_REQUEST_TYPE).getResultList();
        return mappings;
    }

    private static final String TAGS_BY_IM_FIELD_NAMES_HQL = "SELECT D FROM "
            + "DicomIMMappings D WHERE D.imFieldName = :IM_FIELD_NAME "
            + "AND D.componentName = :COMPONENT_NAME AND D.requestType = :REQUEST_TYPE";

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.store.dao.DicomImMappingDAO#getTagsByImFieldName(java
     * .lang.String)
     */
    @Override
    @Transactional
    public final List<DicomImageManagerMapping> getTagsByImFieldName(final String imFieldName) {

        @SuppressWarnings("unchecked")
        List<DicomIMMappings> tags = entityManager.createQuery(TAGS_BY_IM_FIELD_NAMES_HQL)
                .setParameter("IM_FIELD_NAME", imFieldName)
                .setParameter(COMPONENT_NAME_PARAM, IMAGE_STORE_COMPONENT_NAME)
                .setParameter(REQUEST_TYPE_PARAMS, IMAGE_STORE_COMPONENT_REQUEST_TYPE).getResultList();
        List<DicomImageManagerMapping> mappings = convert(tags);
        return mappings;
    }

    private List<DicomImageManagerMapping> convert(final List<DicomIMMappings> mappings) {

        List<DicomImageManagerMapping> tags = null;
        if (null != mappings && !mappings.isEmpty()) {
            if (null == tags) {
                tags = new ArrayList<DicomImageManagerMapping>();
            }
            for (DicomIMMappings imMapping : mappings) {
                DicomImageManagerMapping mapping = new DicomImageManagerMapping();
                mapping.setDcmTagId(imMapping.getDcmTagId());
                mapping.setImFieldName(imMapping.getImFieldName());
                tags.add(mapping);
            }
        }
        return tags;
    }

    @SuppressWarnings("unchecked")
    @Transactional    
    public final List<DicomIMMappings> getMappingsByComponent(final String component, final int requestType) {
        String hql = "SELECT M FROM DicomIMMappings M "
                + "WHERE M.componentName = :COMPONENT_NAME AND M.requestType = :REQUEST_TYPE";
        List<DicomIMMappings> mappings = entityManager.createQuery(hql).setParameter(COMPONENT_NAME_PARAM, component)
                .setParameter(REQUEST_TYPE_PARAMS, requestType).getResultList();
        return mappings;
    }

}
