#!/bin/bash

case "${ENV^^}" in
  LOCAL)
    echo "local environment"
    touch ${_tomcatHomeDir}/${_tomcatVersion}/bin/local.properties
    ;;

  DEV)
    echo "dev"
    #Optional download environment specific config or credentials file from s3
    ;;

  QA)
    echo "qa"
     #Optional download environment specific config or credentials file from s3
    ;;

  PROD)
    echo "prod"
     #Optional download environment specific config or credentials file from s3
    ;;

  *)
    echo "invalid environment"
    exit 1
    ;;
esac

# Setup Tomcat
sed -i -e "s/<ENV>/${ENV,,}/" ${_tomcatHomeDir}/${_tomcatVersion}/bin/setenv.sh
sed -i -e "s,<TOMCAT_HOMEDIR>,${_tomcatHomeDir}," ${_tomcatHomeDir}/${_tomcatVersion}/bin/setenv.sh
sed -i -e "s/<TOMCAT_VERSION>/${_tomcatVersion}/" ${_tomcatHomeDir}/${_tomcatVersion}/bin/setenv.sh
sed -i -e "s/<ENV>/${_proxyNameEnv}/" ${_tomcatHomeDir}/${_tomcatVersion}/conf/server.xml
sed -i -e "s/<JVM_HEAP>/${jvmHeap}/" ${_tomcatHomeDir}/${_tomcatVersion}/bin/setenv.sh

# Start Tomcat - Note this launches into foreground, and will keep container alive until Tomcat exits prematurely
${_tomcatHomeDir}/${_tomcatVersion}/bin/catalina.sh run >> "${_tomcatHomeDir}/${_tomcatVersion}/logs/catalina.out" 2>&1
