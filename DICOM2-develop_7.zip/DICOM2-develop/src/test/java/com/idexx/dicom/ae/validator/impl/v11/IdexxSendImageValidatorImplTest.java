package com.idexx.dicom.ae.validator.impl.v11;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;

import com.idexx.dicom.constants.IdexxDicomTestConstants;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v11.SendImageJobParamDTO;

// TODO: Auto-generated Javadoc
/**
 * The Class IdexxSendImageValidatorImplTest.
 *
 * @author smallela
 * @version 1.3
 */
public class IdexxSendImageValidatorImplTest {

	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(IdexxSendImageValidatorImplTest.class);

	/** The idexx send image validator. */
	@InjectMocks
	private IdexxSendImageValidatorImpl idexxSendImageValidator = new IdexxSendImageValidatorImpl();

	/** The send image job param dto. */
	SendImageJobParamDTO sendImageJobParamDTO;

	/**
	 * Sets the up.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Before
	public void setUp() throws Exception {

		sendImageJobParamDTO = new SendImageJobParamDTO();
	}

	/**
	 * Test validate.
	 */
	@Test
	public void testValidate() {

		try {
			idexxSendImageValidator.validate(sendImageJobParamDTO);
			fail("SendImageValidator Failed to validate 1.0 ");
		} catch (IdexxDicomAEConfigServiceException exp) {
			LOG.error(exp);
			assertTrue("SendImageValidator Failed to validate 1.1 ",
					IdexxSendImageValidatorImpl.MISSING_MANDATORY.equalsIgnoreCase(exp.getErrorCode()));
		}
		sendImageJobParamDTO.setApiKey(IdexxDicomTestConstants.APIKEY);
		try {
			idexxSendImageValidator.validate(sendImageJobParamDTO);
			fail("SendImageValidator Failed to validate 2.0 ");
		} catch (IdexxDicomAEConfigServiceException exp) {
			LOG.error(exp);
			assertTrue("SendImageValidator Failed to validate 2.1 ",
					IdexxSendImageValidatorImpl.MISSING_MANDATORY.equalsIgnoreCase(exp.getErrorCode()));
		}
		sendImageJobParamDTO.setDestinationAETitle(IdexxDicomTestConstants.DESTINATIONAETITLE);
		try {
			idexxSendImageValidator.validate(sendImageJobParamDTO);
			fail("SendImageValidator Failed to validate 3.0 ");
		} catch (IdexxDicomAEConfigServiceException exp) {
			LOG.error(exp);
			assertTrue("SendImageValidator Failed to validate 3.1 ",
					IdexxSendImageValidatorImpl.MISSING_MANDATORY.equalsIgnoreCase(exp.getErrorCode()));
		}
		sendImageJobParamDTO.setDestinationHost(IdexxDicomTestConstants.DESTINATIONHOST);
		try {
			idexxSendImageValidator.validate(sendImageJobParamDTO);
			fail("SendImageValidator Failed to validate 4.0 ");
		} catch (IdexxDicomAEConfigServiceException exp) {
			LOG.error(exp);
			assertTrue("SendImageValidator Failed to validate 4.1 ",
					IdexxSendImageValidatorImpl.MISSING_MANDATORY.equalsIgnoreCase(exp.getErrorCode()));
		}
		sendImageJobParamDTO.setDestinationPort(0);
		try {
			idexxSendImageValidator.validate(sendImageJobParamDTO);
			fail("SendImageValidator Failed to validate 5.0 ");
		} catch (IdexxDicomAEConfigServiceException exp) {
			LOG.error(exp);
			assertTrue("SendImageValidator Failed to validate 5.1 ",
					IdexxSendImageValidatorImpl.MISSING_MANDATORY.equalsIgnoreCase(exp.getErrorCode()));
		}
		sendImageJobParamDTO.setDestinationPort(IdexxDicomTestConstants.DESTINATIONPORT);
		try {
			idexxSendImageValidator.validate(sendImageJobParamDTO);
			fail("SendImageValidator Failed to validate 6.0 ");
		} catch (IdexxDicomAEConfigServiceException exp) {
			LOG.error(exp);
			assertTrue("SendImageValidator Failed to validate 6.1 ",
					IdexxSendImageValidatorImpl.MISSING_MANDATORY.equalsIgnoreCase(exp.getErrorCode()));
		}
		sendImageJobParamDTO.setImageAssetId(IdexxDicomTestConstants.IMAGEASSETID);
		try {
			idexxSendImageValidator.validate(sendImageJobParamDTO);
			fail("SendImageValidator Failed to validate 7.0 ");
		} catch (IdexxDicomAEConfigServiceException exp) {
			LOG.error(exp);
			assertTrue("SendImageValidator Failed to validate 7.1 ",
					IdexxSendImageValidatorImpl.MISSING_MANDATORY.equalsIgnoreCase(exp.getErrorCode()));
		}
		sendImageJobParamDTO.setSendingAETitle(IdexxDicomTestConstants.SENDINGAETITLE);
		try {
			int val = idexxSendImageValidator.validate(sendImageJobParamDTO);
			assertTrue("SendImageValidator Failed to validate 8.0 ", 1 == val);
		} catch (IdexxDicomAEConfigServiceException exp) {
			LOG.error(exp);
			fail("SendImageValidator Failed to validate 8.1 ");
		}

	}
}
