/**
 * 
 */
package com.idexx.dicom.ae.validator.impl;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.idexx.dicom.services.dto.AETitleDTO;
import com.idexx.dicom.services.dto.ReadAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * @author vkandagatla
 * 
 */
@Service("readAETitleValidator")
public class ReadAETitleValidator extends AbstractAETitleValidator {
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.ae.validator.impl.AbstractAETitleValidator#
     * validateInputFields
     * (com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)
     */
    @Override
    protected final int validateInputFields(final AETitleDTO dto)
            throws IdexxDicomAEConfigServiceException {
        ReadAETitleDTO readDTO = (ReadAETitleDTO) dto;
        if (StringUtils.isEmpty(readDTO.getAeTitle())
                && StringUtils.isEmpty(readDTO.getSapId())) {
            throw new IdexxDicomAEConfigServiceException(
                    "Mandatory input missing", MISSING_MANDATORY);
        }
        
        return 1;
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.ae.validator.impl.AbstractAETitleValidator#validateDBFields
     * (com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)
     */
    @Override
    protected final int validateDBFields(final AETitleDTO dto) {
        // No DB validation needed
        return 1;
    }
    
}
