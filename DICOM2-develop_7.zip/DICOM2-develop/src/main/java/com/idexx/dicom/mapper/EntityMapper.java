/**
 * 
 */
package com.idexx.dicom.mapper;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.domain.Client;
import com.idexx.dicom.domain.ExternalPatient;
import com.idexx.dicom.domain.MPPSNCreate;
import com.idexx.dicom.domain.MPPSNSet;
import com.idexx.dicom.domain.Owner;
import com.idexx.dicom.domain.Patient;
import com.idexx.dicom.domain.RequestDetails;
import com.idexx.dicom.sendimage.SendImageJobConstants;
import com.idexx.dicom.services.IdexxDicomServiceConstants;
import com.idexx.dicom.services.mpps.dto.MPPSNCreateDTO;
import com.idexx.dicom.services.mpps.dto.MPPSNSetDTO;
import com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO;
import com.idexx.dicom.services.sendimage.dto.SendImagePendingJobDTO;
import com.idexx.dicom.util.CommonUtil;
import com.idexx.imaging.imagemanager.soap.ClientDTO;
import com.idexx.imaging.imagemanager.soap.ExternalPatientIdDTO;
import com.idexx.imaging.imagemanager.soap.ImageDTO;
import com.idexx.imaging.imagemanager.soap.PatientDTO;
import com.idexx.imaging.imagemanager.soap.PatientSearchRequestDTO;
import com.idexx.imaging.imagemanager.soap.StoreImageMetaDataDTO;
import com.idexx.imaging.imagemanager.soap.StudyDTO;

/**
 * 
 * Mapper class for Create Request service.
 * 
 * @author smallela
 * @version 1.3
 */

@Component("entityMapper")
public class EntityMapper {

	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(EntityMapper.class);

	/** The Constant INVALID_DATE_FORMAT. */
	public static final String INVALID_DATE_FORMAT = "Invalid date format";

	/**
	 * Method returns RequestDetails.
	 *
	 * @param requestDetailsDTO
	 *            the request details dto
	 * @return the request details
	 */
	public RequestDetails dtoToEntityMapper(final RequestDetailsDTO requestDetailsDTO) {
		RequestDetails requestDetails = new RequestDetails();
		requestDetails.setAccessionNumber(requestDetailsDTO.getAccessionNumber());
		requestDetails.setApiKey(requestDetailsDTO.getApiKey());
		requestDetails.setModality(requestDetailsDTO.getModality());
		requestDetails.setPatientId(requestDetailsDTO.getPatientId());
		requestDetails.setRequestingDoctor(requestDetailsDTO.getRequestingDoctor());
		requestDetails.setRequestNotes(requestDetailsDTO.getRequestNotes());
		requestDetails.setSapId(requestDetailsDTO.getSapId());
		requestDetails.setStudyInstanceUID(requestDetailsDTO.getStudyInstanceUID());
		requestDetails.setCreateTimeStamp(new Timestamp(System.currentTimeMillis()));
		requestDetails.setStatus(IdexxDicomServiceConstants.MPPS_REQUEST_STATUS_PENDING);
		return requestDetails;
	}

	/**
	 * Method returns RequestDetailsDTO.
	 *
	 * @param requestDetails
	 *            the request details
	 * @return the request details dto
	 */
	public RequestDetailsDTO entityToDtoMapper(final RequestDetails requestDetails) {
		RequestDetailsDTO requestDetailsDTO = new RequestDetailsDTO();
		requestDetailsDTO.setAccessionNumber(requestDetails.getAccessionNumber());
		requestDetailsDTO.setApiKey(requestDetails.getApiKey());
		requestDetailsDTO.setModality(requestDetails.getModality());
		requestDetailsDTO.setPatientId(requestDetails.getPatientId());
		requestDetailsDTO.setRequestingDoctor(requestDetails.getRequestingDoctor());
		requestDetailsDTO.setRequestNotes(requestDetails.getRequestNotes());
		requestDetailsDTO.setSapId(requestDetails.getSapId());
		requestDetailsDTO.setStudyInstanceUID(requestDetails.getStudyInstanceUID());
		requestDetailsDTO.setCreateTimeStamp(new Timestamp(System.currentTimeMillis()));
		requestDetailsDTO.setStatus(IdexxDicomServiceConstants.MPPS_REQUEST_STATUS_PENDING);
		return requestDetailsDTO;
	}

	/**
	 * Method returns PatientSearchRequestDTO.
	 *
	 * @param requestDetailsDTO
	 *            the request details dto
	 * @return the patient search request dto
	 */
	public PatientSearchRequestDTO getPatientSearchRequestDTO(final RequestDetailsDTO requestDetailsDTO) {
		PatientSearchRequestDTO patientSearchRequestDTO = new PatientSearchRequestDTO();
		patientSearchRequestDTO.setApiKey(requestDetailsDTO.getApiKey());
		patientSearchRequestDTO.setClientFirstName(requestDetailsDTO.getClientFirstName());
		patientSearchRequestDTO.setClientLastName(requestDetailsDTO.getClientLastName());
		patientSearchRequestDTO.setIncludeDeletes(true);
		patientSearchRequestDTO.setIncludeInactivePatients(true);
		patientSearchRequestDTO.setClinicId(Integer.parseInt(requestDetailsDTO.getSapId()));
		patientSearchRequestDTO.setIssuerOfPatientId(requestDetailsDTO.getPimsIssuer());
		patientSearchRequestDTO.setApplicationPatientId(requestDetailsDTO.getPatientId());
		return patientSearchRequestDTO;
	}

	/**
	 * Dto to entity mapper.
	 *
	 * @param dto
	 *            the dto
	 * @return the MPPSN create
	 */
	public MPPSNCreate dtoToEntityMapper(final MPPSNCreateDTO dto) {
		MPPSNCreate req = new MPPSNCreate();
		req.setId(dto.getId());
		req.setMppsSOPInstanceUID(dto.getMppsSOPInstanceUID());
		req.setPatientId(dto.getPatientId());
		req.setPerformedStationAETitle(dto.getPerformedStationAETitle());
		req.setPerformedProcedureStepStartDate(dto.getPerformedProcedureStepStartDate());
		req.setPerformedProcedureStepEndDate(dto.getPerformedProcedureStepEndDate());
		req.setPerformedStationName(dto.getPerformedStationName());
		req.setPerformedLocation(dto.getPerformedLocation());
		req.setPerformedProcedureStepStatus(dto.getPerformedProcedureStepStatus());
		req.setStudyInstanceUID(dto.getStudyInstanceUID());
		req.setScheduledProcedureStepId(dto.getScheduledProcedureStepId());
		req.setCreateTimestamp(dto.getCreateTimestamp());
		req.setUpdateTimestamp(dto.getUpdateTimestamp());
		return req;
	}

	/**
	 * Entity to dto mapper.
	 *
	 * @param entity
	 *            the entity
	 * @return the MPPSN create dto
	 */
	public MPPSNCreateDTO entityToDTOMapper(final MPPSNCreate entity) {
		MPPSNCreateDTO req = new MPPSNCreateDTO();

		req.setId(entity.getId());
		req.setMppsSOPInstanceUID(entity.getMppsSOPInstanceUID());
		req.setPatientId(entity.getPatientId());
		req.setPerformedStationAETitle(entity.getPerformedStationAETitle());
		req.setPerformedProcedureStepStartDate(entity.getPerformedProcedureStepStartDate());
		req.setPerformedProcedureStepEndDate(entity.getPerformedProcedureStepEndDate());
		req.setPerformedStationName(entity.getPerformedStationName());
		req.setPerformedLocation(entity.getPerformedLocation());
		req.setPerformedProcedureStepStatus(entity.getPerformedProcedureStepStatus());
		req.setStudyInstanceUID(entity.getStudyInstanceUID());
		req.setScheduledProcedureStepId(entity.getScheduledProcedureStepId());
		req.setCreateTimestamp(entity.getCreateTimestamp());
		req.setUpdateTimestamp(entity.getUpdateTimestamp());
		return req;
	}

	/**
	 * Dto to entity mapper.
	 *
	 * @param dto
	 *            the dto
	 * @return the MPPSN set
	 */
	public MPPSNSet dtoToEntityMapper(final MPPSNSetDTO dto) {
		MPPSNSet req = new MPPSNSet();

		req.setId(dto.getId());
		req.setMppsNCreateId(dto.getMppsNCreateId());
		req.setRetrieveAETitle(dto.getRetrieveAETitle());
		req.setReferencedSOPInstanceUIDs(dto.getReferencedSOPInstanceUIDs());
		req.setSeriesDescription(dto.getSeriesDescription());
		req.setPerformingPhysicianName(dto.getPerformingPhysicianName());
		req.setProtocolName(dto.getProtocolName());
		req.setOperatorsName(dto.getOperatorsName());
		req.setSeriesInstanceUID(dto.getSeriesInstanceUID());
		req.setCreateTimestamp(dto.getCreateTimestamp());
		req.setUpdateTimestamp(dto.getUpdateTimestamp());
		return req;
	}

	/**
	 * 
	 * Method to generate Study Instance Unique ID.
	 *
	 * @param requestDetailsDTO
	 *            the request details dto
	 * @return the string
	 */
	public String generateStudyInstanceUid(final RequestDetailsDTO requestDetailsDTO) {
		SimpleDateFormat studySDF = new SimpleDateFormat(SendImageJobConstants.SIMPLE_DATE_FORMAT);
		String studyTimestamp = studySDF.format(new Date());
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(SendImageJobConstants.IDEXX_DICOM_PREFIX).append(".").append(requestDetailsDTO.getSapId())
				.append(".").append(studyTimestamp);
		return stringBuilder.toString();
	}

	/**
	 * Method returns PatientDTO.
	 *
	 * @param req
	 *            the req
	 * @return the patient
	 */
	public PatientDTO getPatient(final RequestDetailsDTO req) {

		PatientDTO patientDTO = new PatientDTO();

		ExternalPatientIdDTO externalPatientDTO = new ExternalPatientIdDTO();
		externalPatientDTO.setIssuerOfPatientId(req.getPimsIssuer());
		externalPatientDTO.setPimsPatientId(req.getPatientId());
		patientDTO.setApplicationPatientId(req.getPatientId());
		patientDTO.setBreed(req.getBreed());
		patientDTO.setClientFirstName(req.getClientFirstName());
		patientDTO.setClientLastName(req.getClientLastName());
		patientDTO.setClinicId(req.getSapId());
		patientDTO.setDob(getFormatDOB(req.getPatientDOB()));
		patientDTO.setGender(req.getSex());
		patientDTO.setPatientName(req.getPatientName());
		patientDTO.setSpecies(req.getSpecies());
		patientDTO.getExternalPatientIds().add(externalPatientDTO);

		return patientDTO;
	}

	/**
	 * Method returns PatientDTO.
	 *
	 * @param req
	 *            the req
	 * @return the patient
	 */
	public PatientDTO getPatient(final Patient req) {
		PatientDTO patientDTO = new PatientDTO();
		patientDTO.setBreed(req.getBreed());
		patientDTO.setActiveFlag(req.getActiveFlag());
		patientDTO.setApplicationPatientId(req.getApplicationPatientId());
		patientDTO.setDob(CommonUtil.getXMLDate(req.getDob()));
		patientDTO.setId(req.getID());
		patientDTO.setGender(req.getGender());
		patientDTO.setPatientName(req.getPatientName());
		patientDTO.setSpecies(req.getSpecies());
		patientDTO.setWeight(req.getWeight());
		patientDTO.setWeightUnit(req.getWeightUnit());
		patientDTO.getExternalPatientIds().addAll(convertExternalPatientsListToDto(req.getExternalPatientIds()));
		List<ClientDTO> owners = getClientFromOwner(req.getOwnersWithPatient());
		for (ClientDTO owner : owners) {
			boolean primary;
			try {
				primary = owner.isPrimaryOwner();
				if (primary) {
					patientDTO.setClientFirstName(owner.getClientFirstName());
					patientDTO.setClientLastName(owner.getClientLastName());
				}
			} catch (Exception exc) {
				LOG.error("Exception in get patient.", exc);
				primary = false;
			}

		}
		patientDTO.getOwners().addAll(owners);
		return patientDTO;
	}

	/**
	 * Gets the client from owner.
	 *
	 * @param ownerDTO
	 *            the owner dto
	 * @return the client from owner
	 */
	private List<ClientDTO> getClientFromOwner(final Set<Owner> ownerDTO) {
		List<ClientDTO> listClientDTO = new ArrayList<ClientDTO>();
		for (Owner owner : ownerDTO) {
			Client c = owner.getClient();
			ClientDTO clientDTO = new ClientDTO();
			clientDTO.setClientFirstName(c.getFirstName());
			clientDTO.setClientLastName(c.getLastName());
			clientDTO.setEmail(c.getEmail());
			clientDTO.setId(c.getID());
			clientDTO.setPrimaryOwner(owner.isPrimaryOwner());
			listClientDTO.add(clientDTO);
		}
		return listClientDTO;
	}

	/**
	 * Store Image Data DTO.
	 *
	 * @param req
	 *            the req
	 * @return the store image meta data
	 */
	public StoreImageMetaDataDTO getStoreImageMetaData(final RequestDetailsDTO req) {

		StoreImageMetaDataDTO storeImageMetaDataDTO = new StoreImageMetaDataDTO();
		ImageDTO imageDTO = new ImageDTO();

		storeImageMetaDataDTO.setApiKey(req.getApiKey());
		storeImageMetaDataDTO.setClinicId(Integer.parseInt(req.getSapId()));
		storeImageMetaDataDTO.setImage(imageDTO);
		storeImageMetaDataDTO.setPatient(getPatient(req));
		storeImageMetaDataDTO.setStudy(getStudy(req));

		return storeImageMetaDataDTO;
	}

	/**
	 * Method to set the Study DTOs.
	 *
	 * @param req
	 *            the req
	 * @return the study
	 */
	public StudyDTO getStudy(final RequestDetailsDTO req) {
		StudyDTO studyDTO = new StudyDTO();
		studyDTO.setStudyDate(getStudydDate());
		studyDTO.setStudyInstanceUid(req.getStudyInstanceUID());
		studyDTO.setDoctor(req.getRequestingDoctor());
		return studyDTO;
	}

	/**
	 * Gets the external patient from dto.
	 *
	 * @param eDTOList
	 *            the e dto list
	 * @return the external patient from dto
	 */
	public List<ExternalPatient> getExternalPatientFromDTO(final List<ExternalPatientIdDTO> eDTOList) {
		List<ExternalPatient> externalPatientList = new ArrayList<ExternalPatient>();
		for (ExternalPatientIdDTO eDTO : eDTOList) {
			ExternalPatient eEntity = new ExternalPatient();
			eEntity.setIssuerOfPatientID(eDTO.getIssuerOfPatientId());
			eEntity.setPimsPatientId(eDTO.getPimsPatientId());
			externalPatientList.add(eEntity);
		}
		return externalPatientList;
	}

	/**
	 * Convert external patients list to dto.
	 *
	 * @param extPatients
	 *            the ext patients
	 * @return the list
	 */
	public List<ExternalPatientIdDTO> convertExternalPatientsListToDto(final List<ExternalPatient> extPatients) {
		List<ExternalPatientIdDTO> externalPatientIdsList = new ArrayList<ExternalPatientIdDTO>();
		for (ExternalPatient externalPatient : extPatients) {
			ExternalPatientIdDTO dto = new ExternalPatientIdDTO();
			dto.setIssuerOfPatientId(externalPatient.getIssuerOfPatientID());
			dto.setPimsPatientId(externalPatient.getPimsPatientId());
			externalPatientIdsList.add(dto);
		}
		return externalPatientIdsList;

	}

	/**
	 * Return Study date in XMLGregorianCalendar format.
	 *
	 * @return the studyd date
	 */
	protected XMLGregorianCalendar getStudydDate() {
		XMLGregorianCalendar xmlGC = null;

		SimpleDateFormat studySDF = new SimpleDateFormat(SendImageJobConstants.CREATE_PATIENT_DATE_FORMAT);
		String studyDate = studySDF.format(new Date());
		try {
			xmlGC = DatatypeFactory.newInstance().newXMLGregorianCalendar(studyDate);
		} catch (DatatypeConfigurationException e) {
			LOG.error("Exception in Study date format.", e);
		}

		return xmlGC;
	}

	/**
	 * Return date in XMLGregorianCalendar format.
	 *
	 * @param strDdate
	 *            the str ddate
	 * @return the format dob
	 */
	protected XMLGregorianCalendar getFormatDOB(final String strDdate) {
		String strPatientDOB = null;
		XMLGregorianCalendar xmlGC = null;
		SimpleDateFormat sdf = new SimpleDateFormat(SendImageJobConstants.PATIENT_DOB_FORMAT);

		try {
			Date dobDate = sdf.parse(strDdate);
			SimpleDateFormat sdf1 = new SimpleDateFormat(SendImageJobConstants.CREATE_PATIENT_DATE_FORMAT);
			strPatientDOB = sdf1.format(dobDate);

			xmlGC = DatatypeFactory.newInstance().newXMLGregorianCalendar(strPatientDOB);
		} catch (ParseException e) {
			LOG.error(INVALID_DATE_FORMAT, e);
		} catch (DatatypeConfigurationException e) {
			LOG.error(INVALID_DATE_FORMAT, e);
		}

		return xmlGC;
	}

	/**
	 * Return date in String format.
	 *
	 * @param strDdate
	 *            the str ddate
	 * @return the date from xml gregorian calendar
	 */
	public String getDateFromXMLGregorianCalendar(final XMLGregorianCalendar strDdate) {
		String strPatientDOB = null;
		try {
			SimpleDateFormat sdf1 = new SimpleDateFormat(SendImageJobConstants.CREATE_PATIENT_DATE_FORMAT);
			strPatientDOB = sdf1.format(strDdate.toGregorianCalendar().getTime());
		} catch (Exception e) {
			LOG.error(INVALID_DATE_FORMAT, e);
		}

		return strPatientDOB;
	}

	/**
	 * Gets the string from timestamp.
	 *
	 * @param timestamp
	 *            the timestamp
	 * @return the string from timestamp
	 */
	public String getStringFromTimestamp(final Timestamp timestamp) {
		String str = null;
		try {
			SimpleDateFormat sdf1 = new SimpleDateFormat(SendImageJobConstants.PATIENT_DOB_FORMAT);
			str = sdf1.format(timestamp.getTime());
		} catch (Exception e) {
			LOG.error(INVALID_DATE_FORMAT, e);
		}
		return str;
	}

	/**
	 * Gets the string date time from timestamp.
	 *
	 * @param timestamp
	 *            the timestamp
	 * @return the string date time from timestamp
	 */
	public String getStringDateTimeFromTimestamp(final Timestamp timestamp) {
		String str = null;
		try {
			SimpleDateFormat sdf1 = new SimpleDateFormat(SendImageJobConstants.CREATE_PATIENT_DATE_FORMAT);
			str = sdf1.format(timestamp.getTime());
		} catch (Exception e) {
			LOG.error(INVALID_DATE_FORMAT, e);
		}
		return str;
	}

	/**
	 * Creates the pending jobs.
	 *
	 * @param jobEntity
	 *            the job entity
	 * @return Creates single SendImagePendingJobDTO using IdexxSendImageJob
	 */
	public SendImagePendingJobDTO createPendingJobs(final IdexxSendImageJob jobEntity) {
		SendImagePendingJobDTO dto = new SendImagePendingJobDTO(jobEntity.getJobId(), jobEntity.getJobStatus(),
				jobEntity.getJobStatusDescription());
		dto.setDestinationAETitle(jobEntity.getDestinationAETitle());
		dto.setDestinationHostName(jobEntity.getDestinationHostName());
		dto.setDestinationPort(jobEntity.getDestinationPort());
		dto.setDownloadedIMFilePath(jobEntity.getDownloadedIMFilePath());
		dto.setRetriesCount(jobEntity.getRetriesCount());
		dto.setSendingAETitle(jobEntity.getSendingAETitle());
		dto.setImageAssetId(jobEntity.getImageAssetId());
		return dto;

	}

	/**
	 * Creates the pending job dto.
	 *
	 * @param jobDtos
	 *            the job dtos
	 * @return Creates single SendImagePendingJobDTO using IdexxSendImageJob
	 */
	public List<SendImagePendingJobDTO> createPendingJobDto(final List<IdexxSendImageJob> jobDtos) {
		List<SendImagePendingJobDTO> jobEntites = new ArrayList<SendImagePendingJobDTO>();
		for (IdexxSendImageJob jobs : jobDtos) {
			SendImagePendingJobDTO jobEntity = new SendImagePendingJobDTO();
			LOG.info("Jobs InProgress:" + jobs.getJobId());
			jobEntity.setJobId(jobs.getJobId());
			jobEntity.setDestinationAETitle(jobs.getDestinationAETitle());
			jobEntity.setDestinationHostName(jobs.getDestinationHostName());
			jobEntity.setDestinationPort(jobs.getDestinationPort());
			jobEntity.setDownloadedIMFilePath(jobs.getDownloadedIMFilePath());
			jobEntity.setRetriesCount(jobs.getRetriesCount());
			jobEntity.setSendingAETitle(jobs.getSendingAETitle());
			jobEntity.setImageAssetId(jobs.getImageAssetId());
			jobEntites.add(jobEntity);
		}
		return jobEntites;

	}

}
