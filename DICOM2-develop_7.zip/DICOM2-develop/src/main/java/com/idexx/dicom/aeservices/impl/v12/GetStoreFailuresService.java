/**
 * 
 */
package com.idexx.dicom.aeservices.impl.v12;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.entities.IdexxDicomServiceFailureLog;
import com.idexx.dicom.ae.validator.v12.StoreFailureServiceValidator;
import com.idexx.dicom.aeservices.v12.GetStoreFailuresServiceIntf;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.dao.ws.FailureServiceDao;
import com.idexx.dicom.services.dto.v12.IdexxFailureLogDTO;
import com.idexx.dicom.services.dto.v12.IdexxFailureLogParamDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.util.CommonUtil;

/**
 * @author rmalla
 * 
 */
@Service("getStoreFailuresServiceV12")
public class GetStoreFailuresService implements GetStoreFailuresServiceIntf {

	private static final Logger LOG = Logger.getLogger(GetStoreFailuresService.class);

	@Autowired
	@Qualifier("getStoreFailuresValidatorV12")
	private StoreFailureServiceValidator validator;

	private List<IdexxFailureLogDTO> dtos;

	@Autowired
	private FailureServiceDao failureLogDAO;

	@Autowired
	private AETitleDao aeTitleDao;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.idexx.dicom.aeservices.AEService#performService()
	 */
	@Transactional
	@Override
	public final List<IdexxFailureLogDTO> performService(final IdexxFailureLogParamDTO dto)
			throws IdexxDicomAEConfigServiceException {
		this.validate(dto);
		this.doService(dto);
		return dtos;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.idexx.dicom.aeservices.impl.AbstractAEServiceImpl#validate(com.idexx
	 * .dicom.services.dto.IdexxDicomApplicationEntityDTO)
	 */

	protected final int validate(final IdexxFailureLogParamDTO dto) throws IdexxDicomAEConfigServiceException {
		IdexxFailureLogParamDTO failureParamDTO = (IdexxFailureLogParamDTO) dto;
		return validator.validate(failureParamDTO);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.idexx.dicom.aeservices.impl.AbstractAEServiceImpl#doService(com.idexx
	 * .dicom.services.dto.IdexxDicomApplicationEntityDTO)
	 */

	protected final int doService(final IdexxFailureLogParamDTO dto) throws IdexxDicomAEConfigServiceException {
		List<IdexxDicomServiceFailureLog> failureLogList = null;
		IdexxFailureLogParamDTO iflDto = (IdexxFailureLogParamDTO) dto;
		failureLogList = failureLogDAO.getFailureLog(CommonUtil.convertToDate(iflDto.getStartDate()),
			CommonUtil.convertToDate(iflDto.getEndDate()));
		setDTOList(failureLogList);
		return 1;
	}

	/**
	 * This method set the AETitles to IdexxDicomApplicationEntityDTO list
	 * 
	 * @param aeTitleList
	 */
	private void setDTOList(final List<IdexxDicomServiceFailureLog> failureLogList) {
		List<AETitle> aeTitles = aeTitleDao.getAllAETitles();
		dtos = new ArrayList<IdexxFailureLogDTO>();
		IdexxFailureLogDTO dto = null;
		Calendar calender = Calendar.getInstance();

		for (IdexxDicomServiceFailureLog failureLog : failureLogList) {
			if (isUnregisteredAeTitle(aeTitles, failureLog)) {
				dto = new IdexxFailureLogDTO();
				dto.setIpAddress(failureLog.getIpAddress());
				dto.setAeTitle(failureLog.getAeTitle());
				dto.setInstituteName(failureLog.getInstituteName());
				dto.setManufacturer(failureLog.getManufacturer());
				dto.setManufacturerModelName(failureLog.getManufacturerModelName());
				dto.setModality(failureLog.getModality());
				dto.setPatientName(failureLog.getPatientName());
				calender.setTime(failureLog.getFailedDateTime());
				dto.setFailedDateTime(CommonUtil.convertDateToUTCString(calender.getTime()));
				String responsiblePersonName = failureLog.getResponsiblePersonName();
				if (StringUtils.isEmpty(responsiblePersonName)) {
					responsiblePersonName = "";
				}
				dto.setResponsiblePersonName(responsiblePersonName);
				String hostName = failureLog.getHostName();
				if (StringUtils.isEmpty(hostName)) {
					hostName = "";
				}
				dto.setHostName(hostName);
				dtos.add(dto);
			}
		}
	}

	private boolean isUnregisteredAeTitle(List<AETitle> aeTitles, IdexxDicomServiceFailureLog failureLog) {
		boolean unregistered = true;
		for (AETitle aeTitle : aeTitles) {
			if (aeTitle.getAeTitle().trim().equals(failureLog.getAeTitle().trim())
					&& aeTitle.getInstituteName().trim().equals(failureLog.getInstituteName().trim())) {
				unregistered = false;
			}
		}
		return unregistered;
	}

}
