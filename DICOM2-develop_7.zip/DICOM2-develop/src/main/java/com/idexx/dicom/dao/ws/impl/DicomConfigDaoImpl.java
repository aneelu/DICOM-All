/**
 * 
 */
package com.idexx.dicom.dao.ws.impl;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.idexx.dicom.ae.entities.BaseDicomImPluginConfig;
import com.idexx.dicom.dao.ws.DicomConfigDao;

/**
 * @author vkandagatla
 * 
 */
@Repository
public class DicomConfigDaoImpl implements DicomConfigDao {
    @PersistenceContext
    private EntityManager entityManager;
    private static final String DCM_CONFIG_BY_CONFIG_NAME_HQL = "SELECT CONF FROM BaseDicomImPluginConfig "
            + "CONF WHERE CONF.configName=:CONFIG_NAME_PARAM ";
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.dao.ws.DicmConfigDao#getConfig(java.lang.String)
     */
    @Override
    public BaseDicomImPluginConfig getConfig(final String configName) {
        BaseDicomImPluginConfig config = (BaseDicomImPluginConfig) entityManager.createQuery(DCM_CONFIG_BY_CONFIG_NAME_HQL)
                .setParameter("CONFIG_NAME_PARAM", configName).getSingleResult();
        return config;
    }
    
}
