/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dicom.services.sendimage.dto.v13;

import javax.xml.bind.annotation.XmlElement;

import com.idexx.dicom.services.dto.v13.IdexxAuthenticationDTO;

/**
 * <pre>
 * Description of the class
 * </pre>
 * 
 * @author nayeemuddin
 * @version 1.3
 */
public class SendImageJobParamDTO extends IdexxAuthenticationDTO {

	private String destinationAETitle;
	private String destinationHost;
	private int destinationPort;
	private String imageAssetId;
	private String sendingAETitle;

	/**
	 * Default Constructor
	 */
	public SendImageJobParamDTO() {

	}

	/**
	 * 
	 * @param destinationAETitle
	 * @param destinationHost
	 * @param destinationPort
	 * @param imageAssetId
	 * @param sendingAETitle
	 * @param apiKey
	 */
	public SendImageJobParamDTO(final String destinationAETitle, final String destinationHost,
			final int destinationPort, final String imageAssetId, final String sendingAETitle, final String apiKey) {
		super(apiKey);
		this.destinationAETitle = destinationAETitle;
		this.destinationHost = destinationHost;
		this.destinationPort = destinationPort;
		this.imageAssetId = imageAssetId;
		this.sendingAETitle = sendingAETitle;
	}

	/**
	 * @return the destinationAETitle
	 */
	 @XmlElement(nillable = true, required = true)
	public String getDestinationAETitle() {
		return destinationAETitle;
	}

	/**
	 * @param destinationAETitle
	 *            the destinationAETitle to set
	 */
	public void setDestinationAETitle(String destinationAETitle) {
		this.destinationAETitle = destinationAETitle;
	}

	/**
	 * @return the destinationHost
	 */
	public String getDestinationHost() {
		return destinationHost;
	}

	/**
	 * @param destinationHost
	 *            the destinationHost to set
	 */
	public void setDestinationHost(String destinationHost) {
		this.destinationHost = destinationHost;
	}

	/**
	 * @return the destinationPort
	 */
	public int getDestinationPort() {
		return destinationPort;
	}

	/**
	 * @param destinationPort
	 *            the destinationPort to set
	 */
	public void setDestinationPort(int destinationPort) {
		this.destinationPort = destinationPort;
	}

	/**
	 * @return the imageAssetId
	 */
	public String getImageAssetId() {
		return imageAssetId;
	}

	/**
	 * @param imageAssetId
	 *            the imageAssetId to set
	 */
	public void setImageAssetId(String imageAssetId) {
		this.imageAssetId = imageAssetId;
	}

	/**
	 * @return the sendingAETitle
	 */
	public String getSendingAETitle() {
		return sendingAETitle;
	}

	/**
	 * @param sendingAETitle
	 *            the sendingAETitle to set
	 */
	public void setSendingAETitle(String sendingAETitle) {
		this.sendingAETitle = sendingAETitle;
	}

}
