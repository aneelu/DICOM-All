/**
 * <h1>Create Request Service Response DTO.</h1>
 */
package com.idexx.dicom.services.requestservice.dto;

import java.util.List;

import javax.ws.rs.core.Response.Status;

import com.idexx.dicom.services.requestservice.validator.ErrorDTO;

/**
 * <pre>Create Request Service Response DTO.</pre>
 * @author nayeemuddin
 * @version 1.3
 */
public class CreateRequestServiceResponseDTO {
	
	private String studyInstanceUID;
	private List<ErrorDTO> errors;
	private Status httpStatusCode;
	
	/**
	 * @return the studyInstanceUID
	 */
	public String getStudyInstanceUID() {
		return studyInstanceUID;
	}
	/**
	 * @param studyInstanceUID the studyInstanceUID to set
	 */
	public void setStudyInstanceUID(String studyInstanceUID) {
		this.studyInstanceUID = studyInstanceUID;
	}

	/**
	 * @return the errors
	 */
	public List<ErrorDTO> getErrors() {
	    return errors;
	}
	/**
	 * @param errors the errors to set
	 */
	public void setErrors(List<ErrorDTO> errors) {
	    this.errors = errors;
	}
	/**
	 * @return the httpStatusCode
	 */
	public Status getHttpStatusCode() {
		return httpStatusCode;
	}
	
	/**
	 * @param httpStatusCode the httpStatusCode to set
	 */
	public void setHttpStatusCode(Status httpStatusCode) {
		this.httpStatusCode = httpStatusCode;
	}
	


}
