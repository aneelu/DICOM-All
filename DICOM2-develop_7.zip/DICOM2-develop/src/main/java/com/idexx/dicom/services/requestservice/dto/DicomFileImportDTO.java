/**
 * 
 */
package com.idexx.dicom.services.requestservice.dto;

import java.net.URL;

/**
 * @author smallela
 * @version 1.3
 */
public class DicomFileImportDTO {

	private String apiKey;
	private String sapID;
	private URL dicomFileURL;

	/**
	 * @return the apiKey
	 */
	public String getApiKey() {
		return apiKey;
	}

	/**
	 * @param apiKey
	 *            the apiKey to set
	 */
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}

	/**
	 * @return the sapID
	 */
	public String getSapID() {
		return sapID;
	}

	/**
	 * @param sapID
	 *            the sapID to set
	 */
	public void setSapID(String sapID) {
		this.sapID = sapID;
	}

	/**
	 * @return the dicomFileURL
	 */
	public URL getDicomFileURL() {
		return dicomFileURL;
	}

	/**
	 * @param dicomFileURL
	 *            the dicomFileURL to set
	 */
	public void setDicomFileURL(URL dicomFileURL) {
		this.dicomFileURL = dicomFileURL;
	}
}
