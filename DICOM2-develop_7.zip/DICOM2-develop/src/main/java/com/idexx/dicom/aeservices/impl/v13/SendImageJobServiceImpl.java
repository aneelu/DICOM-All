/**
 * <h1>Web service for to perform Send Image Job service.</h1>
 */
package com.idexx.dicom.aeservices.impl.v13;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.ae.validator.impl.v13.IdexxSendImageValidatorImpl;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.IdexxSendImageJobDao;
import com.idexx.dicom.services.IdexxDicomServiceConstants;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v13.SendImageJobParamDTO;

/**
 * <pre>Web service for to perform Send Image Job service.</pre>
 * @author nayeemuddin
 * @version 1.3
 */
@Service("getIdexxSendImageValidatorV13")
public class SendImageJobServiceImpl{
	
	private static final Logger LOG = Logger.getLogger(SendImageJobServiceImpl.class);
	
	@Autowired
    @Qualifier("idexxSendImageValidatorV13")
    private IdexxSendImageValidatorImpl validator;

    @Autowired
    private IdexxSendImageJobDao sendImageJobDao;

    @Autowired
    private IdexxDicomWSAthorizationServiceImpl idexxDicomWsAuthorizeService;
    
   
    /**
     * 
     * <pre>Method to perform required validation and authorization check.</pre>
     * @param dto
     * @return
     * @throws IdexxDicomAEConfigServiceException
     *
     */
    @Transactional
	public String performService(SendImageJobParamDTO dto)
			throws IdexxDicomAEConfigServiceException {
    	 String jobId = null;
         boolean authorized = false;
         authorized = idexxDicomWsAuthorizeService.authorize(dto.getApiKey());
         if (authorized) {
             this.validate(dto);
             jobId = this.doService(dto);
         }

         return jobId;
	}
	
    
    /**
     * 
     * <pre>Method validates the send image job parameters.</pre>
     * @param imageParamDTO
     * @return
     * @throws IdexxDicomAEConfigServiceException
     *
     */
    protected int validate(final SendImageJobParamDTO dto) throws IdexxDicomAEConfigServiceException{
    	 return validator.validate(dto);
    } 
    
    /**
     * 
     * <pre>Method to create DTO with required parameters to create send image Job.</pre>
     * @param dto
     * @return
     * @throws IdexxDicomAEConfigServiceException
     *
     */
    protected String doService(final SendImageJobParamDTO dto) throws IdexxDicomAEConfigServiceException{
    	 String jobId = null;
         try {
             IdexxSendImageJob sendImageJob = new IdexxSendImageJob();
             sendImageJob.setDestinationAETitle(dto.getDestinationAETitle());
             sendImageJob.setDestinationHostName(dto.getDestinationHost());
             sendImageJob.setDestinationPort(dto.getDestinationPort());
             sendImageJob.setImageAssetId(dto.getImageAssetId());
             sendImageJob.setJobStatus(IdexxDicomServiceConstants.STATUS_PENDING);
             sendImageJob.setJobStatusDescription(IdexxDicomServiceConstants.PENDING_INIT_DESC);
             sendImageJob.setRetriesCount(IdexxDicomServiceConstants.DEFAULT_SEND_RETRY_COUNT);
             sendImageJob.setSendingAETitle(dto.getSendingAETitle());
             jobId = sendImageJobDao.createJob(sendImageJob);

         } catch (Exception exp) {
             LOG.error(exp.getLocalizedMessage(), exp);
             throw new IdexxDicomAEConfigDbException(exp);
         }
         
         return jobId;
    	
    }

		
}
