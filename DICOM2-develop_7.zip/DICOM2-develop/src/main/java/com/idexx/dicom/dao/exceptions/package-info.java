/**
 * @author vkandagatla
 *
 */
package com.idexx.dicom.dao.exceptions;
