/**
 * 
 */
package com.idexx.dicom.services.requestservice;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Iterator;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.FileImageInputStream;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.imageio.plugins.dcm.DicomImageReader;
import org.dcm4che3.imageio.plugins.dcm.DicomMetaData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.idexx.dicom.dto.IdexxAuthorizationObject;
import com.idexx.dicom.store.DicomStoreServiceWithMetadataExtraction;
import com.idexx.dicom.store.impl.DicomStoreIMPluginService;
import com.idexx.dicom.util.CommonUtil;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;

// TODO: Auto-generated Javadoc
/**
 * 
 * This service download the DICOM file from URL, Save the DICOM file to
 * temporary Folder, Extract the Meta Data from DICOM file, Store the meta Data
 * of DICOM file to Image Manager, Save the DICOM file to Image Manager.
 * 
 * @author smallela
 * @version 1.3
 */
@Component
public class DicomFileImporter {

	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(DicomFileImporter.class);

	/** The dicom store im plugin service. */
	@Autowired
	private DicomStoreIMPluginService dicomStoreIMPluginService;

	/** The dicom store service. */
	@Autowired
	private DicomStoreServiceWithMetadataExtraction dicomStoreService;

	/** The idexx authorization object. */
	private IdexxAuthorizationObject idexxAuthorizationObject;

	/** The dicom file url. */
	private URL dicomFile;

	/** The destination file. */
	private File destinationFile;

	/**
	 * Instantiates a new dicom file importer.
	 */
	public DicomFileImporter() {
	}

	/**
	 * Instantiates a new dicom file importer.
	 *
	 * @param idexxAuthorizationObject
	 *            the idexx authorization object
	 * @param dicomFile
	 *            the dicom file
	 */
	public DicomFileImporter(final IdexxAuthorizationObject idexxAuthorizationObject, final URL dicomFile) {
		this.idexxAuthorizationObject = idexxAuthorizationObject;
		this.dicomFile = dicomFile;
	}

	/**
	 * Gets the idexx authorization object.
	 *
	 * @return the idexx authorization object
	 */
	public IdexxAuthorizationObject getIdexxAuthorizationObject() {
		return idexxAuthorizationObject;
	}

	/**
	 * Sets the idexx authorization object.
	 *
	 * @param idexxAuthorizationObject
	 *            the new idexx authorization object
	 */
	public void setIdexxAuthorizationObject(final IdexxAuthorizationObject idexxAuthorizationObject) {
		this.idexxAuthorizationObject = idexxAuthorizationObject;
	}

	/**
	 * Gets the dicom file.
	 *
	 * @return the dicomFile
	 */
	public URL getDicomFile() {
		return dicomFile;
	}

	/**
	 * Sets the dicom file.
	 *
	 * @param dicomFile
	 *            the dicomFile to set
	 */
	public void setDicomFile(URL dicomFile) {
		this.dicomFile = dicomFile;
	}

	/**
	 * Perform import file.
	 *
	 * @return the string
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 * @throws IdexxServiceException_Exception
	 *             the idexx service exception_ exception
	 */
	protected String performImportFile() throws IOException, IdexxServiceException_Exception {
		Map<String, Object> props = dicomStoreIMPluginService.buildService();
		destinationFile = CommonUtil.getFileToWriteDCMFile(System.currentTimeMillis() + "." + props.get("fileType"));
		String storedImageReponse = "";
		FileUtils.copyURLToFile(dicomFile, destinationFile);
		Attributes attr = getDicomTags();
		storedImageReponse = dicomStoreService.callStoreImgMetaDataService(attr, idexxAuthorizationObject, null, props);
		storedImageReponse = dicomStoreService.callStoreUploadImgService(destinationFile, idexxAuthorizationObject,
				storedImageReponse, destinationFile.getName(), props);
		LOG.info(storedImageReponse + ": Successfully Imported and uploaded the DICOM file");
		return storedImageReponse;
	}

	/**
	 * Gets the dicom tags.
	 *
	 * @return the dicom tags
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	private Attributes getDicomTags() throws IOException {
		Attributes attributes = null;
		DicomImageReader dicomImageReader = null;
		try (FileImageInputStream fileImageInputStream = new FileImageInputStream(destinationFile)) {
			Iterator<ImageReader> imgReaders = ImageIO.getImageReadersByFormatName("dicom");
			dicomImageReader = (DicomImageReader) imgReaders.next();

			dicomImageReader.setInput(fileImageInputStream);
			DicomMetaData metaData = (DicomMetaData) dicomImageReader.getStreamMetadata();
			attributes = metaData.getAttributes();
		} finally {
			if (dicomImageReader != null) {
				dicomImageReader.dispose();
			}
		}
		return attributes;
	}
}
