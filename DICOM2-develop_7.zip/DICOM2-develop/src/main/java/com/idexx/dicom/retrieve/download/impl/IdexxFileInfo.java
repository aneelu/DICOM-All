package com.idexx.dicom.retrieve.download.impl;


import java.io.Serializable;

/**
 * @author vkandagatla
 *
 */
public class IdexxFileInfo implements Serializable {

    private static final long serialVersionUID = 7851930689047771597L;

    private long pk = -1;

    private String patID = null;

    private String patName = null;

    private String studyIUID = null;

    private String seriesIUID = null;

    private String sopIUID = null;

    private String sopCUID = null;

    private String extRetrieveAET = null;
    
    private String fileRetrieveAET = null;

    private String basedir = null;

    private String fsGroupID = null;

    private String fileID = null;

    private String tsUID = null;

    private String md5 = null;

    private long size = 0;

    private int status = 0;
    
    private int availability = 0;
    
    public IdexxFileInfo() {
    }

    /**
     * @return the pk
     */
    public final long getPk() {
        return pk;
    }

    /**
     * @param pk the pk to set
     */
    public final void setPk(final long pk) {
        this.pk = pk;
    }

    /**
     * @return the patID
     */
    public final String getPatID() {
        return patID;
    }

    /**
     * @param patID the patID to set
     */
    public final void setPatID(final String patID) {
        this.patID = patID;
    }

    /**
     * @return the patName
     */
    public final String getPatName() {
        return patName;
    }

    /**
     * @param patName the patName to set
     */
    public final void setPatName(final String patName) {
        this.patName = patName;
    }

    /**
     * @return the studyIUID
     */
    public final String getStudyIUID() {
        return studyIUID;
    }

    /**
     * @param studyIUID the studyIUID to set
     */
    public final void setStudyIUID(final String studyIUID) {
        this.studyIUID = studyIUID;
    }

    /**
     * @return the seriesIUID
     */
    public final String getSeriesIUID() {
        return seriesIUID;
    }

    /**
     * @param seriesIUID the seriesIUID to set
     */
    public final void setSeriesIUID(final String seriesIUID) {
        this.seriesIUID = seriesIUID;
    }

    /**
     * @return the sopIUID
     */
    public final String getSopIUID() {
        return sopIUID;
    }

    /**
     * @param sopIUID the sopIUID to set
     */
    public final void setSopIUID(final String sopIUID) {
        this.sopIUID = sopIUID;
    }

    /**
     * @return the sopCUID
     */
    public final String getSopCUID() {
        return sopCUID;
    }

    /**
     * @param sopCUID the sopCUID to set
     */
    public final void setSopCUID(final String sopCUID) {
        this.sopCUID = sopCUID;
    }

    /**
     * @return the extRetrieveAET
     */
    public final String getExtRetrieveAET() {
        return extRetrieveAET;
    }

    /**
     * @param extRetrieveAET the extRetrieveAET to set
     */
    public final void setExtRetrieveAET(final String extRetrieveAET) {
        this.extRetrieveAET = extRetrieveAET;
    }

    /**
     * @return the fileRetrieveAET
     */
    public final String getFileRetrieveAET() {
        return fileRetrieveAET;
    }

    /**
     * @param fileRetrieveAET the fileRetrieveAET to set
     */
    public final void setFileRetrieveAET(final String fileRetrieveAET) {
        this.fileRetrieveAET = fileRetrieveAET;
    }

    /**
     * @return the basedir
     */
    public final String getBasedir() {
        return basedir;
    }

    /**
     * @param basedir the basedir to set
     */
    public final void setBasedir(final String basedir) {
        this.basedir = basedir;
    }

    /**
     * @return the fsGroupID
     */
    public final String getFsGroupID() {
        return fsGroupID;
    }

    /**
     * @param fsGroupID the fsGroupID to set
     */
    public final void setFsGroupID(final String fsGroupID) {
        this.fsGroupID = fsGroupID;
    }

    /**
     * @return the fileID
     */
    public final String getFileID() {
        return fileID;
    }

    /**
     * @param fileID the fileID to set
     */
    public final void setFileID(final String fileID) {
        this.fileID = fileID;
    }

    /**
     * @return the tsUID
     */
    public final String getTsUID() {
        return tsUID;
    }

    /**
     * @param tsUID the tsUID to set
     */
    public final void setTsUID(final String tsUID) {
        this.tsUID = tsUID;
    }

    /**
     * @return the md5
     */
    public final String getMd5() {
        return md5;
    }

    /**
     * @param md5 the md5 to set
     */
    public final void setMd5(final String md5) {
        this.md5 = md5;
    }

    /**
     * @return the size
     */
    public final long getSize() {
        return size;
    }

    /**
     * @param size the size to set
     */
    public final void setSize(final long size) {
        this.size = size;
    }

    /**
     * @return the status
     */
    public final int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public final void setStatus(final int status) {
        this.status = status;
    }

    /**
     * @return the availability
     */
    public final int getAvailability() {
        return availability;
    }

    /**
     * @param availability the availability to set
     */
    public final void setAvailability(final int availability) {
        this.availability = availability;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public final String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("IdexxFileInfo [getPk()=");
        builder.append(getPk());
        builder.append(", getPatID()=");
        builder.append(getPatID());
        builder.append(", getPatName()=");
        builder.append(getPatName());
        builder.append(", getStudyIUID()=");
        builder.append(getStudyIUID());
        builder.append(", getSeriesIUID()=");
        builder.append(getSeriesIUID());
        builder.append(", getSopIUID()=");
        builder.append(getSopIUID());
        builder.append(", getSopCUID()=");
        builder.append(getSopCUID());
        builder.append(", getExtRetrieveAET()=");
        builder.append(getExtRetrieveAET());
        builder.append(", getFileRetrieveAET()=");
        builder.append(getFileRetrieveAET());
        builder.append(", getBasedir()=");
        builder.append(getBasedir());
        builder.append(", getFsGroupID()=");
        builder.append(getFsGroupID());
        builder.append(", getFileID()=");
        builder.append(getFileID());
        builder.append(", getTsUID()=");
        builder.append(getTsUID());
        builder.append(", getMd5()=");
        builder.append(getMd5());
        builder.append(", getSize()=");
        builder.append(getSize());
        builder.append(", getStatus()=");
        builder.append(getStatus());
        builder.append(", getAvailability()=");
        builder.append(getAvailability());
        builder.append("]");
        return builder.toString();
    }

}
