package com.idexx.dicom.services.dto.v13;
import javax.xml.bind.annotation.XmlElement;

import org.springframework.stereotype.Component;

/**
 * <pre>IdexxAuthenticationDTO hold information About apiKey</pre>
 * @author smallela
 * @version 1.3
 */
@Component
public abstract class IdexxAuthenticationDTO {
    private String apiKey;

    /*
     * Default Constructor
     */
    public IdexxAuthenticationDTO() {
    }

    /**
     * @param apiKey
     */
    public IdexxAuthenticationDTO(final String apiKey) {
        this.apiKey = apiKey;
    }

    /**
     * @return the apiKey
     */
    @XmlElement(nillable = true, required = true)
    public String getApiKey() {
        return apiKey;
    }

    /**
     * @param apiKey
     *            the apiKey to set
     */
    public void setApiKey(final String apiKey) {
        this.apiKey = apiKey;
    }
}