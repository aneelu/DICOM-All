/**
 * <h1>Service to create request to integrate pims like Neo & Animana.</h1>
 */
package com.idexx.dicom.services.requestservice;

import java.util.List;

import javax.transaction.Transactional;
import javax.ws.rs.core.Response.Status;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.idexx.dicom.aeservices.impl.v13.IdexxDicomWSAthorizationServiceImpl;
import com.idexx.dicom.mapper.EntityMapper;
import com.idexx.dicom.repo.RequestDetailsRepository;
import com.idexx.dicom.sendimage.ImageManagerStoreServiceProviderWraper;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.requestservice.dto.CreateRequestErrorCodesConstants;
import com.idexx.dicom.services.requestservice.dto.CreateRequestServiceResponseDTO;
import com.idexx.dicom.services.requestservice.dto.ExternalPimsIdDTO;
import com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO;
import com.idexx.dicom.services.requestservice.validator.CreateRequestValidator;
import com.idexx.dicom.services.requestservice.validator.ErrorDTO;
import com.idexx.imaging.imagemanager.soap.IDEXXImageManagerServices;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;
import com.idexx.imaging.imagemanager.soap.PatientDTO;

/**
 * <pre>
 * Service to create request to integrate pims like Neo & Animana
 * </pre>
 * 
 * @author vvanjarana
 * @version 1.3
 */
@Service("createRequestServiceImpl")
public class CreateRequestServiceImpl {

	private static final Logger LOG = Logger.getLogger(CreateRequestServiceImpl.class);

	@Autowired
	private RequestDetailsRepository requestDetailsDao;

	@Autowired
	@Qualifier("entityMapper")
	private EntityMapper entityMapper;

	@Autowired
	@Qualifier("idexxDicomWSAthorizationServiceImplV13")
	private IdexxDicomWSAthorizationServiceImpl idexxDicomWsAuthorizeService;

	@Autowired
	private ImageManagerStoreServiceProviderWraper imageManagerStoreServiceProviderWraper;

	@Autowired
	@Qualifier("requestServiceValidator")
	private CreateRequestValidator createRequestValidator;

	/**
	 * 
	 * <pre>
	 * Method to create request in Dicom host DB.
	 * </pre>
	 * 
	 * @param requestDetails
	 * @return
	 * @throws IdexxDicomAEConfigServiceException
	 * @throws IdexxServiceException_Exception
	 *
	 */
	public CreateRequestServiceResponseDTO createRequest(RequestDetailsDTO requestDetails)
			throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {
		String studyInstanceUid = null;
		boolean authorize = false;
		CreateRequestServiceResponseDTO createRequestServiceResponseDTO = new CreateRequestServiceResponseDTO();
		// Validate all the Mandatory input parameter
		List<ErrorDTO> listofErrors = createRequestValidator.validate(requestDetails);
		LOG.info("Errors List Size : " + listofErrors.size());

		if (listofErrors.isEmpty()) {
			// Authorize API Key
			authorize = idexxDicomWsAuthorizeService.authorize(requestDetails.getApiKey());

			if (authorize) {
				studyInstanceUid = processRequest(requestDetails);
				createRequestServiceResponseDTO.setStudyInstanceUID(studyInstanceUid);
			}
		} else {
			createRequestServiceResponseDTO.setErrors(listofErrors);
		}

		return createRequestServiceResponseDTO;
	}

	public Status getHttpStatusCodeBasedonError(ErrorDTO errorDTO) {
		String errocode = errorDTO.getErrorCode();
		switch (errocode) {
		case CreateRequestErrorCodesConstants.UNREGISTERED_MODALITY_ERROR_CODE:
		case CreateRequestErrorCodesConstants.MODALITY_ERROR_CODE:
		case CreateRequestErrorCodesConstants.PIMS_ISSUER_ERROR_CODE:
		case CreateRequestErrorCodesConstants.API_KEY_ERROR_CODE:
		case CreateRequestErrorCodesConstants.SAP_ID_ERROR_CODE:
		case CreateRequestErrorCodesConstants.SAP_ID_NUMERIC_ERROR_CODE:
			return CreateRequestErrorCodesConstants.UNAUTHORIZED_HTTP_STATUS_CODE;
		}

		return CreateRequestErrorCodesConstants.BAD_REQUEST_HTTP_STATUS_CODE;
	}

	/**
	 * 
	 * <pre>
	 * Method to process the create request
	 * 
	 * This method will first try to find patient using searchPatient service in image manager. 
	 * If not found, it will create one using storeImageMetaData service. 
	 * Then it will again find that patient using searchPatient service to get ID and insert 
	 * in REQUEST_DETAILS table.
	 * </pre>
	 * 
	 * @param requestDetails
	 * @return
	 * @throws IdexxDicomAEConfigServiceException
	 * @throws IdexxServiceException_Exception
	 *
	 */
	@Transactional
	protected String processRequest(RequestDetailsDTO requestDetails)
			throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {
		boolean isPatientExist = true;

		String studyInstanceUid = entityMapper.generateStudyInstanceUid(requestDetails);
		requestDetails.setStudyInstanceUID(studyInstanceUid);

		IDEXXImageManagerServices idexxImService = imageManagerStoreServiceProviderWraper.getService();

		List<PatientDTO> listPatient = findPatient(idexxImService, requestDetails);
		try {
			if (null != listPatient && listPatient.isEmpty()) {
				String result = idexxImService.storeImageMetaData(entityMapper.getStoreImageMetaData(requestDetails));
				listPatient = idexxImService.searchPatient(entityMapper.getPatientSearchRequestDTO(
						requestDetails, requestDetails.getPatientId(), requestDetails.getPimsIssuer()));
				LOG.info("storeImageMetaDataResponse = " + result);
			}
			if (listPatient != null && !listPatient.isEmpty()) {
				String id = listPatient.get(0).getId();
				requestDetails.setPatientId(id);
			} else {
				LOG.error("Unable to create Patient record");
				isPatientExist = false;
				throw new IdexxServiceException_Exception("Unable to create Patient record", null);
			}
		} catch (IdexxServiceException_Exception exp) {
			LOG.error("Unable to create Patient record", exp);
			isPatientExist = false;
			throw new IdexxServiceException_Exception("Unable to create Patient record", null, exp);
		}

		if (isPatientExist) {
			requestDetailsDao.save(entityMapper.dtoToEntityMapper(requestDetails));
		}
		LOG.info("Create Request Created Successfully.");

		return studyInstanceUid;
	}
	
	private List<PatientDTO> findPatient(IDEXXImageManagerServices idexxImService, 
										 RequestDetailsDTO requestDetails) throws IdexxServiceException_Exception {
		List<PatientDTO> listPatient = idexxImService.searchPatient(entityMapper.getPatientSearchRequestDTO(
				requestDetails, requestDetails.getPatientId(), requestDetails.getPimsIssuer()));
		if (null != listPatient && listPatient.isEmpty()) {
			if (null != requestDetails.getExternalPimsIds() && !requestDetails.getExternalPimsIds().isEmpty()) {
				for (ExternalPimsIdDTO externalPims : requestDetails.getExternalPimsIds()) {
					listPatient = idexxImService.searchPatient(entityMapper.getPatientSearchRequestDTO(
							requestDetails, externalPims.getPatientId(), externalPims.getPimsIssuer()));
					if (null != listPatient && !listPatient.isEmpty()) {
						break;
					}
				}
			}
		}
		return listPatient;
	}

}
