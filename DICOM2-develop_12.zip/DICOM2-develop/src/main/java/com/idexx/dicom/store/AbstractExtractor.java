/**
 * 
 */
package com.idexx.dicom.store;

import java.util.List;

import org.dcm4che3.data.Attributes;

import com.idexx.dicom.entities.store.DicomImageManagerMapping;

/**
 * @author vkandagatla
 * 
 */
public abstract class AbstractExtractor implements ImageManagerAttributeExtractorFromDicomElement {
    public static final int SH_LENGTH = 16;
    public static final int UL_LENGTH = 4;
    public static final int FD_LENGTH = 8;
    public static final int DT_LENGTH = 26;
    public static final int IS_LENGTH = 12;
    public static final int PN_LENGTH = 64;
    public static final int ST_LENGTH = 1024;
    public static final int LT_LENGTH = 10240;

    protected List<DicomImageManagerMapping> mapping;

    /**
     * @param mapping
     */
    public AbstractExtractor(final List<DicomImageManagerMapping> mapping) {
        super();
        this.mapping = mapping;
    }


    /**
     * @param tag
     * @param dataset
     * @return
     */
    protected final String getTagValueAsString(final Integer tag, final Attributes dataset) {
        String value = "";
        value = dataset.getString(tag);
        if(null!=value && "null".equalsIgnoreCase(value)) {
            return "";
        }   
        if (value == null) {
        	value = "";
        }
        return value;
    }

}
