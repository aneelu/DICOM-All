package com.idexx.dicom.dao.query.impl;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.idexx.dicom.dao.query.QueryBuilder;

public class QueryBuilderImpl implements QueryBuilder {

	private static final Logger LOG = Logger.getLogger(QueryBuilderImpl.class);

	/**
	 * Builds the native SQL query
	 * 
	 * @return
	 */
	@Override
	public String getSelectQuery(final String aeTitle,
			final String instituteName, final String errorType) {

		StringBuilder sql = new StringBuilder(
				" FROM IdexxDicomServiceFailureLog IDFL WHERE ");
		sql.append(" IDFL.failedDateTime >= :START_DATE ");
		sql.append(" AND IDFL.failedDateTime <= :END_DATE ");

		if (!StringUtils.isEmpty(aeTitle)) {
			sql.append(" AND IDFL.aeTitle = :AE_TITLE");
		}

		if (!StringUtils.isEmpty(instituteName)) {
			sql.append(" AND IDFL.instituteName = :INSTITUTE_NAME ");
		}

		if (!StringUtils.isEmpty(errorType)) {
			sql.append(" AND IDFL.errorType = :ERROR_TYPE ");
		}

		LOG.info(
				"Failure Log Query is ::: " + sql.toString());

		return sql.toString();
	}
}
