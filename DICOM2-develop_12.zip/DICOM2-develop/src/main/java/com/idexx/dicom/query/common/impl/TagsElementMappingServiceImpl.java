/**
 * 
 */
package com.idexx.dicom.query.common.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.idexx.dicom.dao.store.DicomImMappingDAO;
import com.idexx.dicom.entities.store.DicomIMMappings;
import com.idexx.dicom.query.common.TagsElementMappingService;

/**
 * @author vkandagatla
 * 
 */
@Component
public class TagsElementMappingServiceImpl implements TagsElementMappingService {
    
	@Autowired
	private DicomImMappingDAO mappingDAO;
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.query.common.TagsElementMappingService#getMappings()
     */
    @Override
    public final Map<String, Integer> getMappings() {
        List<DicomIMMappings> mappings = mappingDAO.getMappingsByComponent(IMAGE_QUERY_COMPONENT_NAME, IMAGE_QUERY_COMPONENT_REQUEST_TYPE);
        return convert(mappings);
    }
    
    /**
     * @param mappings
     * @return
     */
    private Map<String, Integer> convert(final List<DicomIMMappings> mappings) {
        Map<String, Integer> map = null;
        if (null != mappings && !mappings.isEmpty()) {
            if (null == map) {
                map = new HashMap<String, Integer>();
            }
            for (DicomIMMappings mapping : mappings) {
                map.put(mapping.getImFieldName(), mapping.getDcmTagId());
            }
        }
        return map;
    }
    
}
