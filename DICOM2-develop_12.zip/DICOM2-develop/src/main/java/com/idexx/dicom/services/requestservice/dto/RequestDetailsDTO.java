/**
 * 
 */
package com.idexx.dicom.services.requestservice.dto;

import java.sql.Timestamp;
import java.util.List;
/**
 * @author vvanjarana
 *
 */
public class RequestDetailsDTO {
	

	private String Id;
	private String patientName;
	private String patientId;
	private String studyInstanceUID;
	private String breed;
	private String sex;
	private String patientDOB;
	private String clientFirstName;
	private String clientLastName;
	private String species;
	private String pimsIssuer;
	private String apiKey;
	private String sapId;
	private String modality;
	private String requestNotes;
	private String requestingDoctor;
	private String accessionNumber;
	private String status;
	private Timestamp createTimeStamp;
	private Timestamp updateTimeStamp;
	private boolean isAllInputsAvailable;
	private List<ExternalPimsIdDTO> externalPimsIds;
	
	/**
	 * @return the id
	 */
	public String getId() {
		return Id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		Id = id;
	}
	/**
	 * @return the patientName
	 */
	public String getPatientName() {
		return patientName;
	}
	/**
	 * @param patientName the patientName to set
	 */
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	/**
	 * @return the patientId
	 */
	public String getPatientId() {
		return patientId;
	}
	/**
	 * @param patientId the patientId to set
	 */
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	/**
	 * @return the breed
	 */
	public String getBreed() {
		return breed;
	}
	/**
	 * @param breed the breed to set
	 */
	public void setBreed(String breed) {
		this.breed = breed;
	}
	/**
	 * @return the sex
	 */
	public String getSex() {
		return sex;
	}
	/**
	 * @param sex the sex to set
	 */
	public void setSex(String sex) {
		this.sex = sex;
	}
	/**
	 * @return the patientDOB
	 */
	public String getPatientDOB() {
		return patientDOB;
	}
	/**
	 * @param patientDOB the patientDOB to set
	 */
	public void setPatientDOB(String patientDOB) {
		this.patientDOB = patientDOB;
	}
	/**
	 * @return the clientFirstName
	 */
	public String getClientFirstName() {
		return clientFirstName;
	}
	/**
	 * @param clientFirstName the clientFirstName to set
	 */
	public void setClientFirstName(String clientFirstName) {
		this.clientFirstName = clientFirstName;
	}
	/**
	 * @return the clientLastName
	 */
	public String getClientLastName() {
		return clientLastName;
	}
	/**
	 * @param clientLastName the clientLastName to set
	 */
	public void setClientLastName(String clientLastName) {
		this.clientLastName = clientLastName;
	}
	/**
	 * @return the species
	 */
	public String getSpecies() {
		return species;
	}
	/**
	 * @param species the species to set
	 */
	public void setSpecies(String species) {
		this.species = species;
	}
	/**
	 * @return the pimsIssuer
	 */
	public String getPimsIssuer() {
		return pimsIssuer;
	}
	/**
	 * @param pimsIssuer the pimsIssuer to set
	 */
	public void setPimsIssuer(String pimsIssuer) {
		this.pimsIssuer = pimsIssuer;
	}
	/**
	 * @return the apiKey
	 */
	public String getApiKey() {
		return apiKey;
	}
	/**
	 * @param apiKey the apiKey to set
	 */
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}
	/**
	 * @return the sapId
	 */
	public String getSapId() {
		return sapId;
	}
	/**
	 * @param sapId the sapId to set
	 */
	public void setSapId(String sapId) {
		this.sapId = sapId;
	}
	/**
	 * @return the modality
	 */
	public String getModality() {
		return modality;
	}
	/**
	 * @param modality the modality to set
	 */
	public void setModality(String modality) {
		this.modality = modality;
	}
	/**
	 * @return the requestNotes
	 */
	public String getRequestNotes() {
		return requestNotes;
	}
	/**
	 * @param requestNotes the requestNotes to set
	 */
	public void setRequestNotes(String requestNotes) {
		this.requestNotes = requestNotes;
	}
	/**
	 * @return the requestingDoctor
	 */
	public String getRequestingDoctor() {
		return requestingDoctor;
	}
	/**
	 * @param requestingDoctor the requestingDoctor to set
	 */
	public void setRequestingDoctor(String requestingDoctor) {
		this.requestingDoctor = requestingDoctor;
	}
	/**
	 * @return the accessionNumber
	 */
	public String getAccessionNumber() {
		return accessionNumber;
	}
	/**
	 * @param accessionNumber the accessionNumber to set
	 */
	public void setAccessionNumber(String accessionNumber) {
		this.accessionNumber = accessionNumber;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the createTimeStamp
	 */
	public Timestamp getCreateTimeStamp() {
		return createTimeStamp;
	}
	/**
	 * @param createTimeStamp the createTimeStamp to set
	 */
	public void setCreateTimeStamp(Timestamp createTimeStamp) {
		this.createTimeStamp = createTimeStamp;
	}
	/**
	 * @return the updateTimeStamp
	 */
	public Timestamp getUpdateTimeStamp() {
		return updateTimeStamp;
	}
	/**
	 * @param updateTimeStamp the updateTimeStamp to set
	 */
	public void setUpdateTimeStamp(Timestamp updateTimeStamp) {
		this.updateTimeStamp = updateTimeStamp;
	}
	public String getStudyInstanceUID() {
	    return studyInstanceUID;
	}
	public void setStudyInstanceUID(String studyInstanceUID) {
	    this.studyInstanceUID = studyInstanceUID;
	}
	/**
	 * @return the isAllInputsAvailable
	 */
	public boolean isAllInputsAvailable() {
		return isAllInputsAvailable;
	}
	/**
	 * @param isAllInputsAvailable the isAllInputsAvailable to set
	 */
	public void setAllInputsAvailable(boolean isAllInputsAvailable) {
		this.isAllInputsAvailable = isAllInputsAvailable;
	}

	public List<ExternalPimsIdDTO> getExternalPimsIds() {
		return externalPimsIds;
	}
	
	public void setMappingRules(List<ExternalPimsIdDTO> externalPimsIds) {
		this.externalPimsIds = externalPimsIds;
	}
}
