/**
 * 
 */
package com.idexx.dicom.services.dto.v12;

import javax.xml.bind.annotation.XmlElement;

/**
 * @author vkandagatla
 * 
 */
public class IdexxFailureLogParamDTO {

    private String startDate;
    private String endDate;

    /**
     * @return the startDate
     */
    @XmlElement(nillable = true, required = true)
    public final String getStartDate() {
        return startDate;
    }

    /**
     * @param startDate
     *            the startDate to set
     */
    public final void setStartDate(final String startDate) {
        this.startDate = startDate;
    }

    /**
     * @return the endDate
     */
    @XmlElement(nillable = true, required = true)
    public final String getEndDate() {
        return endDate;
    }

    /**
     * @param endDate
     *            the endDate to set
     */
    public final void setEndDate(final String endDate) {
        this.endDate = endDate;
    }

}
