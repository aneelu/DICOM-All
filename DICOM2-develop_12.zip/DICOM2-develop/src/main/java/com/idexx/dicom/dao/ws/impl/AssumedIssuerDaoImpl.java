package com.idexx.dicom.dao.ws.impl;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.idexx.dicom.ae.entities.AssumedIssuer;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.AssumedIssuerDao;

@Repository
@SuppressWarnings("unchecked")
public class AssumedIssuerDaoImpl implements AssumedIssuerDao {

    @PersistenceContext
    private EntityManager entityManager;

    private static final String AI_PARAM1 = "SAP_ID";

    public AssumedIssuerDaoImpl() {
        super();
    }
    
    /**
     * @param createEntityManager
     */
    public AssumedIssuerDaoImpl(EntityManager entityManager) {
        super();
        this.entityManager = entityManager;
    }

    @Override
    public List<AssumedIssuer> findAssumedIssuerBySapId(final String sapId) {
        try {
            final String query = "SELECT AI FROM AssumedIssuer AI WHERE AI.sapId=:" + AI_PARAM1;
            return entityManager.createQuery(query).setParameter(AI_PARAM1, sapId).getResultList();
        } catch (Exception e) {
            throw new IdexxDicomAEConfigDbException(e);
        }
    }

    @Override
    public void createAssumedIssuer(AssumedIssuer assumedIssuer) throws IdexxDicomAEConfigDbException {
        try {
            entityManager.merge(assumedIssuer);
        } catch (Exception e) {
            throw new IdexxDicomAEConfigDbException(e);
        }
    }

    @Override
    public void updateAssumedIssuer(AssumedIssuer assumedIssuer) throws IdexxDicomAEConfigDbException {
        try {
            assumedIssuer.setLastUpdatedDateTime(new Timestamp(new Date().getTime()));
            entityManager.merge(assumedIssuer);
        } catch (Exception e) {
            throw new IdexxDicomAEConfigDbException(e);
        }

    }
}
