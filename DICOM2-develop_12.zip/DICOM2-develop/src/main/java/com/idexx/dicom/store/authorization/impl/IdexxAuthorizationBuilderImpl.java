/**
 * 
 */
package com.idexx.dicom.store.authorization.impl;

import org.springframework.stereotype.Component;

import com.idexx.dicom.dto.IdexxAuthorizationObject;
import com.idexx.dicom.store.authorization.IdexxAuthorization;
import com.idexx.dicom.store.authorization.IdexxAuthorizationBuilder;

// TODO: Auto-generated Javadoc
/**
 * The Class IdexxAuthorizationBuilderImpl.
 *
 * @author vkandagatla
 */
@Component
public class IdexxAuthorizationBuilderImpl implements IdexxAuthorizationBuilder {

	/**
	 * Default.
	 */
	IdexxAuthorizationBuilderImpl() {
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.idexx.dicom.store.authorization.IdexxAuthorizationBuilder#
	 * createAuthorization(boolean, java.lang.String, java.lang.String,
	 * java.lang.String, boolean, java.lang.String)
	 */
	@Override
	public IdexxAuthorization createAuthorization(final boolean isAuthenticated, final String aeTitle,
			final String instituteName, final String apiKey, final boolean isIdentifiedByAEOnly, final String sapId) {
		IdexxAuthorizationObject authObj = new IdexxAuthorizationObject(aeTitle, instituteName, apiKey,
				isIdentifiedByAEOnly, sapId);
		IdexxAuthorizationImpl authorization = new IdexxAuthorizationImpl(authObj);
		authorization.setAuthorized(isAuthenticated);
		return authorization;
	}

}
