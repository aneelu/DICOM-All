package com.idexx.dicom.services;

import static org.quartz.CronScheduleBuilder.cronSchedule;
import static org.quartz.JobBuilder.newJob;
import static org.quartz.TriggerBuilder.newTrigger;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;

import org.apache.log4j.Logger;
import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.TriggerKey;
import org.quartz.ee.servlet.QuartzInitializerListener;
import org.quartz.impl.StdSchedulerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.entities.BaseDicomImPluginConfig;
import com.idexx.dicom.dao.ws.DicomConfigDao;
import com.idexx.dicom.sendimage.JobRunnerBuilder;
import com.idexx.dicom.sendimage.SendImageJobConstants;
import com.idexx.dicom.sendimage.impl.SchedulerJob;

/**
 * Servlet implementation class SendImageDispatcherServlet
 */
@Controller
public class SendImageJobSchedulerController extends QuartzInitializerListener {

	private static final Logger LOG = Logger.getLogger(SendImageJobSchedulerController.class);

	private static final String JOB_NAME = "SendImageJob";
	private static final String TRIGGER_NAME = "SendImageJob";
	private static final String GROUP_NAME = "SendImageJobGroup";

	private JobKey jobKey;
	private TriggerKey triggerKey;
	@Autowired
	private DicomConfigDao configDao;

	@Autowired
	private JobRunnerBuilder jobRunnerBuilder;

	public SendImageJobSchedulerController() {
		super();
		jobKey = new JobKey(JOB_NAME, GROUP_NAME);
		triggerKey = new TriggerKey(TRIGGER_NAME, GROUP_NAME);
	}

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		super.contextInitialized(sce);
		ServletContext ctx = sce.getServletContext();
		try {
			StdSchedulerFactory factory = (StdSchedulerFactory) ctx
					.getAttribute(QuartzInitializerListener.QUARTZ_FACTORY_KEY);
			Scheduler scheduler = factory.getScheduler();
			LOG.info("Got Scheduler" + scheduler.getSchedulerName());

			JobDetail job = this.createJob(scheduler);
			LOG.info("Created JOB Detail: " + job.getDescription());

			String triggerExpression = this.getFrequency();
			CronTrigger trigger = newTrigger().withIdentity(triggerKey).withSchedule(cronSchedule(triggerExpression))
					.build();
			LOG.info("Created Cron Trigger: " + triggerExpression);

			Date ft = scheduler.scheduleJob(job, trigger);
			LOG.info(job.getKey() + " has scheduled to run at: " + ft + " and repeat based on expression: "
					+ trigger.getCronExpression());

			LOG.info("Starting Scheduler");
			scheduler.start();

		} catch (SchedulerException sexp) {
			LOG.error("SchedulerException is " + sexp);
		}
	}

	private JobDetail createJob(final Scheduler scheduler) throws SchedulerException {
		boolean jobExists = scheduler.checkExists(jobKey);
		if (jobExists) {
			scheduler.unscheduleJob(triggerKey);
			scheduler.deleteJob(jobKey);
		}
		JobDetail job = newJob(SchedulerJob.class).withIdentity(jobKey).build();
		// tell the job to delay some small amount... to simulate
		// work...
		long timeDelay = (long) (getDefaultThreadSleap());
		job.getJobDataMap().put(SchedulerJob.DELAY_TIME, timeDelay);
		job.getJobDataMap().put(SchedulerJob.JOB_BUILDER, jobRunnerBuilder);
		job.getJobDataMap().put(SchedulerJob.CONFIG_DAO, configDao);
		return job;
	}

	/**
	 * @return
	 */
	private String getFrequency() {

		BaseDicomImPluginConfig config = configDao.getConfig(SendImageJobConstants.SEND_IMAGE_CRON_EXPRESSION);
		String expression = SendImageJobConstants.DEFAULT_SEND_IMAGE_CRON_EXPRESSION;
		if (null != config && !StringUtils.isEmpty(config.getConfigValue())) {
			expression = config.getConfigValue();
		}
		LOG.info("Scheduler Frequency: " + expression);
		return expression;
	}

	public final boolean canSchedule() throws UnknownHostException {
		LOG.info("Checking whether to execute");
		BaseDicomImPluginConfig config = configDao
				.getConfig(SendImageJobConstants.SEND_IMAGE_SCHEDULER_STATE_CONFIG_NAME);
		String configValue = config.getConfigValue();
		LOG.info("SEND_IMAGE_STATE: " + configValue);
		return SendImageJobConstants.SEND_IMAGE_SEND_IMAGE_STATE_SCHEDULED.equalsIgnoreCase(configValue)
				&& this.canRunFromThisHost();
	}

	private boolean canRunFromThisHost() throws UnknownHostException {
		return this.getHostName().equalsIgnoreCase(this.getSchedulerHost());
	}

	private String getSchedulerHost() {
		BaseDicomImPluginConfig config = configDao.getConfig(SendImageJobConstants.SCHEDULER_RUN_HOST_CONFIG_NAME);
		String hostName = SendImageJobConstants.DEFAULT_SCHEDULER_RUN_HOST;
		if (null != config) {
			hostName = config.getConfigValue();
		}
		LOG.info("SCHEDULER_RUN_HOST_NAME: " + hostName);
		return hostName;
	}

	private String getHostName() throws UnknownHostException {
		String hostName = null;
		InetAddress ia = InetAddress.getLocalHost();
		hostName = ia.getCanonicalHostName();
		LOG.info("Host Name: " + hostName);
		return hostName;
	}

	/**
	 * @return
	 */
	private int getDefaultThreadSleap() {
		LOG.info("Getting THREAD SLEEP CONFIG VALUE");
		int defaultCount = SendImageJobConstants.DEFAULT_SEND_IMAGE_SCHEDULER_SLEEP_TIME;
		BaseDicomImPluginConfig config = configDao
				.getConfig(SendImageJobConstants.SEND_IMAGE_SCHEDULER_SLEEP_TIME_CONFIG_VALUE);

		String configValue = config.getConfigValue();
		if (!StringUtils.isEmpty(configValue)) {
			try {
				defaultCount = Integer.valueOf(configValue);
			} catch (NumberFormatException nfe) {
				defaultCount = SendImageJobConstants.DEFAULT_SEND_IMAGE_SCHEDULER_SLEEP_TIME;
			}
		}
		LOG.info("THREAD SLEEP CONFIG VALUIS: " + defaultCount);
		return defaultCount;
	}

}
