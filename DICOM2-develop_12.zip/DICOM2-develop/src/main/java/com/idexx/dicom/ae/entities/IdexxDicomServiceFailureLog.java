/**
 * Entity for IDEXX DICOM ServicesFailure 
 */
package com.idexx.dicom.ae.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author vkandagatla
 * 
 */
@Entity
@Table(name = "idx_failure_log")
public class IdexxDicomServiceFailureLog implements Serializable {
    
    /**
     * Eclipse Generated
     */
    private static final long serialVersionUID = -6950273886499969860L;
    
    private int id;
    private String ipAddress;
    private String aeTitle;
    private String instituteName;
    private String manufacturer;
    private String manufacturerModelName;
    private String modality;
    private Timestamp failedDateTime;
    private String patientName;
    private String hostName;
    private String responsiblePersonName;
    private String errorType;
    private String errorMessage;
    
	/**
     * @return the id
     */
    @Id @GeneratedValue(strategy=GenerationType.AUTO)
    public int getId() {
        return id;
    }
    
    /**
     * @param id
     *            the id to set
     */
    public void setId(final int id) {
        this.id = id;
    }
    
    /**
     * @return the ipAddress
     */
    @Column(name = "IP_ADDRESS")
    public String getIpAddress() {
        return ipAddress;
    }
    
    /**
     * @param ipAddress
     *            the ipAddress to set
     */
    public void setIpAddress(final String ipAddress) {
        this.ipAddress = ipAddress;
    }
    
    /**
     * @return the aeTitle
     */
    @Column(name = "AETITLE")
    public String getAeTitle() {
        return aeTitle;
    }
    
    /**
     * @param aeTitle
     *            the aeTitle to set
     */
    public void setAeTitle(final String aeTitle) {
        this.aeTitle = aeTitle;
    }
    
    /**
     * @return the instituteName
     */
    @Column(name = "INSTITUTE_NAME")
    public String getInstituteName() {
        return instituteName;
    }
    
    /**
     * @param instituteName
     *            the instituteName to set
     */
    public void setInstituteName(final String instituteName) {
        this.instituteName = instituteName;
    }
    
    /**
     * @return the manufacturer
     */
    @Column(name = "MANUFATURER")
    public String getManufacturer() {
        return manufacturer;
    }
    
    /**
     * @param manufacturer
     *            the manufacturer to set
     */
    public void setManufacturer(final String manufacturer) {
        this.manufacturer = manufacturer;
    }
    
    /**
     * @return the manufacturerModelName
     */
    @Column(name = "MANUFACTURER_MODEL_NAME")
    public String getManufacturerModelName() {
        return manufacturerModelName;
    }
    
    /**
     * @param manufacturerModelName
     *            the manufacturerModelName to set
     */
    public void setManufacturerModelName(final String manufacturerModelName) {
        this.manufacturerModelName = manufacturerModelName;
    }
    
    /**
     * @return the modality
     */
    @Column(name = "MODALITY")
    public String getModality() {
        return modality;
    }
    
    /**
     * @param modality
     *            the modality to set
     */
    public void setModality(final String modality) {
        this.modality = modality;
    }
    
    /**
     * @return the failedDateTime
     */
    @Column(name = "FAILED_DATE_TIME ")
    public Timestamp getFailedDateTime() {
        return failedDateTime;
    }
    
    /**
     * @param failedDateTime
     *            the failedDateTime to set
     */
    public void setFailedDateTime(Timestamp failedDateTime) {
        this.failedDateTime = failedDateTime;
    }
    
    /**
     * @return the patientName
     */
    @Column(name = "PATIENT_NAME")
    public String getPatientName() {
        return patientName;
    }
    
    /**
     * @param patientName
     *            the patientName to set
     */
    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }
    
    /**
     * @return
     */
    @Column(name = "CALLING_HOST_NAME")
	public String getHostName() {
		return hostName;
	}

	/**
	 * @param hostName
	 */
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	
	/**
	 * @return
	 */
	@Column(name = "RESPONSIBLE_PERSON_NAME")
	public String getResponsiblePersonName() {
		return responsiblePersonName;
	}

	/**
	 * @param responsiblePersonName
	 */
	public void setResponsiblePersonName(String responsiblePersonName) {
		this.responsiblePersonName = responsiblePersonName;
	}

	/**
	 * 
	 * @return
	 */
	@Column(name = "ERROR_TYPE")
    public String getErrorType() {
		return errorType;
	}

	/**
	 * 
	 * @param errorType
	 */
	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}

	/**
	 * 
	 * @return
	 */
	@Column(name = "ERROR_MESSAGE")
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * 
	 * @param errorMessage
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

}
