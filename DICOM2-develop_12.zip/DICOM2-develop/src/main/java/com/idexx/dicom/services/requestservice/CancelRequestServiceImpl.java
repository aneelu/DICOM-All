/**
 * 
 */
package com.idexx.dicom.services.requestservice;

import java.sql.Timestamp;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.idexx.dicom.aeservices.impl.v13.IdexxDicomWSAthorizationServiceImpl;
import com.idexx.dicom.domain.RequestDetails;
import com.idexx.dicom.repo.RequestDetailsRepository;
import com.idexx.dicom.services.IdexxDicomServiceConstants;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.requestservice.dto.CancelResponseDTO;
import com.idexx.dicom.services.requestservice.dto.CreateRequestErrorCodesConstants;
import com.idexx.dicom.services.requestservice.validator.ErrorDTO;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;

/**
 * 
 * CancelRequestService Implementation to cancel request Service Jobs.
 * 
 * @author smallela
 * @version 1.3
 */
@Service
public class CancelRequestServiceImpl {

	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(CancelRequestServiceImpl.class);

	/** The request details dao. */
	@Autowired
	private RequestDetailsRepository requestDetailsDao;

	/** The idexx dicom ws authorize service. */
	@Autowired
	@Qualifier("idexxDicomWSAthorizationServiceImplV13")
	private IdexxDicomWSAthorizationServiceImpl idexxDicomWsAuthorizeService;

	/**
	 * Cancel Request takes StudyInstanceUID as input and process the cancel
	 * request and return json response as Update Successful or StudyInstanceUID
	 * does not exist.
	 *
	 * @param studyInstanceUID
	 *            the study instance uid
	 * @param apiKey
	 *            the api key
	 * @param sapId
	 *            the sap id
	 * @param listofErrors
	 *            the listof errors
	 * @return String
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 * @throws IdexxServiceException_Exception
	 *             the idexx service exception_ exception
	 */
	@Transactional
	public CancelResponseDTO cancelRequest(String studyInstanceUID, String apiKey, String sapId, List<ErrorDTO> listofErrors)
			throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {
		String message = "";
		if (StringUtils.isBlank(apiKey)) {
			listofErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.API_KEY_ERROR_CODE,
					CreateRequestErrorCodesConstants.API_KEY_ERROR_CODE_MSG));
		}
		if (StringUtils.isBlank(sapId)) {
			listofErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.SAP_ID_ERROR_CODE,
					CreateRequestErrorCodesConstants.SAP_ID_ERROR_CODE_MSG));
		}
		if (!listofErrors.isEmpty()) {
			return null;
		}
		try {
			idexxDicomWsAuthorizeService.authorize(apiKey);
		} catch (IdexxDicomAEConfigServiceException e) {
			listofErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.INVALID_API_KEY_ERROR_CODE,
					CreateRequestErrorCodesConstants.INVALID_API_KEY_ERROR_CODE_MSG));
			LOG.error("IdexxDicomAEConfigServiceException is " + e);
			return null;
		}

		List<RequestDetails> listReqDetails = requestDetailsDao.findOneByStudyInstanceUIDAndSapId(studyInstanceUID,
				sapId);

		if (null != listReqDetails && !listReqDetails.isEmpty()) {
			RequestDetails reqDetails = listReqDetails.get(0);
			reqDetails.setStatus(IdexxDicomServiceConstants.REQUEST_STATUS_CANCEL);
			reqDetails.setUpdateTimeStamp(new Timestamp(System.currentTimeMillis()));
			requestDetailsDao.save(reqDetails);			
			message = "Update Successful";
		} else {
			message = "StudyInstanceUID does not exist";
		}
		CancelResponseDTO cancelResponDTO = new CancelResponseDTO(message);
		return cancelResponDTO;
	}

}
