/**
 * Authorize all webservices for IDEXX DICOM using API KEY
 */
package com.idexx.dicom.aeservices;

import com.idexx.dicom.ae.validator.AETitleValidator;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * @author vkandagatla
 * 
 */
public interface IdexxDicomWSAthorizationService {
    String MISSING_MANDATORY = AETitleValidator.MISSING_MANDATORY;
    String INVALID_API_KEY = "ERR_invalid_api_key";
    
    /**
     * @param apiKey
     * @return
     * @throws IdexxDicomAEConfigServiceException
     *             Verifies if the given API Key is valid. If valid returns
     *             true. Also if the API Key is empty/invalid throws
     *             IdexxDicomAEConfigServiceException. If API KEY is missing in
     *             the request , the exception should contain the error code as
     *             AETitleValidator.MISSING_MANDATORY. If API KEY is not valid,
     *             the exception should contain the error code as
     *             INVALID_API_KEY.
     *             The API KEY Validation should check from idx_api_keys DATABASE Table
     */
    boolean authorize(String apiKey) throws IdexxDicomAEConfigServiceException;
}
