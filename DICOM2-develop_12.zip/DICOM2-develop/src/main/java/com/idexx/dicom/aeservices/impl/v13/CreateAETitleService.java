
/**
 * 
 */
package com.idexx.dicom.aeservices.impl.v13;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.idexx.dicom.ae.entities.AEEntity;
import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.validator.impl.v13.AbstractAETitleValidator;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.dto.v13.AETitleDTO;
import com.idexx.dicom.services.dto.v13.CreateAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;


/**
 * <pre>CreateAETitleService Implementation to create AETitle Service Jobs.</pre>
 * @author smallela
 * @version 1.3
 */

@Service("createAETitleServiceV13")
public class CreateAETitleService extends AbstractAEServiceImpl {
	
	private static final Logger LOG = Logger.getLogger(CreateAETitleService.class);
	
    @Autowired
    @Qualifier("createAETitleValidatorV13")
    private AbstractAETitleValidator validator;

    @Autowired
    private AETitleDao aeTitleDao;

    /**
     * <pre>Validate apiKey,aeTitle,instituteName of Create AETitle service Job</pre>
     * @param dto
     * @return int
     * @throws IdexxDicomAEConfigServiceException
     * 
     */
    
    
    @Override
    @Transactional
	public int validate(final AETitleDTO dto) throws IdexxDicomAEConfigServiceException {
        return validator.validate(dto);
    }

    /**
     * <pre>To provide services of apiKey,aeTitle,instituteName for Create AETitle service Job</pre>
     * @param dto
     * @return int
     * @throws IdexxDicomAEConfigServiceException
     * 
     */
    
    
    @Override
    @Transactional
    public int doService(final AETitleDTO dto) throws IdexxDicomAEConfigServiceException {

        CreateAETitleDTO createAEDTO = (CreateAETitleDTO) dto;
        try {
            LOG.info("isDvmSpecialist " + createAEDTO.isDvmSpecialist());
            LOG.info("AeTitle " + createAEDTO.getAeTitle());
            LOG.info("HostName " + createAEDTO.getHostName());
            LOG.info("Port " + createAEDTO.getPort());
            if (createAEDTO.isDvmSpecialist()) {
                AEEntity aeEntity = new AEEntity();
                aeEntity.setAeTitle(createAEDTO.getAeTitle());
                aeEntity.setHostName(createAEDTO.getHostName());
                aeEntity.setPort(createAEDTO.getPort());
                aeTitleDao.createAE(aeEntity);
            } else {
                String instituteName = null;
                AETitle aeTitle = new AETitle();
                aeTitle.setAeTitle(createAEDTO.getAeTitle());
                aeTitle.setApiKey(createAEDTO.getApiKey());
                aeTitle.setSapId(createAEDTO.getSapId());
                aeTitle.setModalityTypeCode(createAEDTO.getModalityTypeCode());
                aeTitle.setEnabled(true);
                instituteName = createAEDTO.getInstituteName();
                if (instituteName == null) {
                    instituteName = "*";
                }
                aeTitle.setInstituteName(instituteName);
                aeTitle.setIdentifiedByaeTitleOnly(createAEDTO.isIdentifiedByAeTitleOnly());
                aeTitleDao.createAETitle(aeTitle);

            }
        } catch (IdexxDicomAEConfigDbException e) {
        	LOG.error(e);
        	throw new IdexxDicomAEConfigServiceException(GENERAL_DB_FAILURE, GENERAL_DB_FAILURE);
        } catch (Exception e) {
            LOG.error(e);
            throw new IdexxDicomAEConfigServiceException(GENERAL_DB_FAILURE, GENERAL_DB_FAILURE);
        }
        return 1;
    }

}
