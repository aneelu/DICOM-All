/**
 * Storage entity for IDEXX API Keys
 */
package com.idexx.dicom.ae.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author rmalla
 * 
 */
@Entity
@Table(name = "APPLICATION")
public class IdexxAPIKey implements Serializable {
    
    /**
     * Eclipse Generated
     */
    private static final long serialVersionUID = -7532560365266187370L;
    
    private String id;
    
    private String name;
    
    private String apiKey;
    
    @Id
    @Column(name = "ID")
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    @Column(name = "NAME")
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    @Column(name = "API_KEY")
    public String getApiKey() {
        return apiKey;
    }
    
    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }
    
}
