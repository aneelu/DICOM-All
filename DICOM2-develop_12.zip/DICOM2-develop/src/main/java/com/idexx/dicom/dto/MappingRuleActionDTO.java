package com.idexx.dicom.dto;

import java.io.Serializable;


public class MappingRuleActionDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2535944269295740178L;
	private String id;
	private String tagKey;
	private String actionType;
	private String replaceValue;
	private Boolean doActionIfNull =false;

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType=actionType;
	}

	public String getReplaceValue() {
		return replaceValue;
	}

	public void setReplaceValue(String replaceValue) {
		this.replaceValue=replaceValue;
	}

	public Boolean getDoActionIfNull() {
		return doActionIfNull;
	}

	public void setDoActionIfNull(Boolean doActionIfNull) {
		this.doActionIfNull=doActionIfNull;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTagKey() {
		return tagKey;
	}

	public void setTagKey(String tagKey) {
		this.tagKey = tagKey;
	}

}
