package com.idexx.dicom.domain;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "MPPS_N_SET")
public class MPPSNSet {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "system-uuid")
    @GenericGenerator(name = "system-uuid", strategy = "uuid")
	private String id;

	@Column(name="MPPS_N_CREATE_ID")
	private String mppsNCreateId;

	@Column(name="RETRIEVE_AE_TITLE")
	private String retrieveAETitle;

	@Column(name="REFERENCED_SOP_INSTANCE_UIDS")
	private String referencedSOPInstanceUIDs;

	@Column(name="SERIES_DESCRIPTION")
	private String seriesDescription;

	@Column(name="PERFORMING_PHYSICIAN_NAME")
	private String performingPhysicianName;

	@Column(name="PROTOCOL_NAME")
	private String protocolName;

	@Column(name="OPERATORS_NAME")
	private String operatorsName;

	@Column(name="SERIES_INSTANCE_UID")
	private String seriesInstanceUID;

	@Column(name="CREATE_TIMESTAMP")
	private Timestamp createTimestamp;

	@Column(name="UPDATE_TIMESTAMP")
	private Timestamp updateTimestamp;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the mppsNCreateId
	 */
	public String getMppsNCreateId() {
		return mppsNCreateId;
	}

	/**
	 * @param mppsNCreateId the mppsNCreateId to set
	 */
	public void setMppsNCreateId(String mppsNCreateId) {
		this.mppsNCreateId = mppsNCreateId;
	}

	/**
	 * @return the retrieveAETitle
	 */
	public String getRetrieveAETitle() {
		return retrieveAETitle;
	}

	/**
	 * @param retrieveAETitle the retrieveAETitle to set
	 */
	public void setRetrieveAETitle(String retrieveAETitle) {
		this.retrieveAETitle = retrieveAETitle;
	}

	/**
	 * @return the referencedSOPInstanceUIDs
	 */
	public String getReferencedSOPInstanceUIDs() {
		return referencedSOPInstanceUIDs;
	}

	/**
	 * @param referencedSOPInstanceUIDs the referencedSOPInstanceUIDs to set
	 */
	public void setReferencedSOPInstanceUIDs(String referencedSOPInstanceUIDs) {
		this.referencedSOPInstanceUIDs = referencedSOPInstanceUIDs;
	}

	/**
	 * @return the seriesDescription
	 */
	public String getSeriesDescription() {
		return seriesDescription;
	}

	/**
	 * @param seriesDescription the seriesDescription to set
	 */
	public void setSeriesDescription(String seriesDescription) {
		this.seriesDescription = seriesDescription;
	}

	/**
	 * @return the performingPhysicianName
	 */
	public String getPerformingPhysicianName() {
		return performingPhysicianName;
	}

	/**
	 * @param performingPhysicianName the performingPhysicianName to set
	 */
	public void setPerformingPhysicianName(String performingPhysicianName) {
		this.performingPhysicianName = performingPhysicianName;
	}

	/**
	 * @return the protocolName
	 */
	public String getProtocolName() {
		return protocolName;
	}

	/**
	 * @param protocolName the protocolName to set
	 */
	public void setProtocolName(String protocolName) {
		this.protocolName = protocolName;
	}

	/**
	 * @return the operatorsName
	 */
	public String getOperatorsName() {
		return operatorsName;
	}

	/**
	 * @param operatorsName the operatorsName to set
	 */
	public void setOperatorsName(String operatorsName) {
		this.operatorsName = operatorsName;
	}

	/**
	 * @return the seriesInstanceUID
	 */
	public String getSeriesInstanceUID() {
		return seriesInstanceUID;
	}

	/**
	 * @param seriesInstanceUID the seriesInstanceUID to set
	 */
	public void setSeriesInstanceUID(String seriesInstanceUID) {
		this.seriesInstanceUID = seriesInstanceUID;
	}

	/**
	 * @return the createTimestamp
	 */
	public Timestamp getCreateTimestamp() {
		return createTimestamp;
	}

	/**
	 * @param createTimestamp the createTimestamp to set
	 */
	public void setCreateTimestamp(Timestamp createTimestamp) {
		this.createTimestamp = createTimestamp;
	}

	/**
	 * @return the updateTimestamp
	 */
	public Timestamp getUpdateTimestamp() {
		return updateTimestamp;
	}

	/**
	 * @param updateTimestamp the updateTimestamp to set
	 */
	public void setUpdateTimestamp(Timestamp updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
