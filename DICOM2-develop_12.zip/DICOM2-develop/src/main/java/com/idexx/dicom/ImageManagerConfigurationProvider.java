package com.idexx.dicom;

import java.util.Map;

public interface ImageManagerConfigurationProvider {
    
    Map<String, String> geCofingurationValues();
    
    String getConfigurationValue(String configName);
    
}
