package com.idexx.dicom.ae.entities;

import java.sql.Timestamp;
import java.util.Date;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

/**
 * The Class IdexxSendImageJob_.
 */
@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(IdexxSendImageJob.class)
public abstract class IdexxSendImageJob_ {

	/** The destination port. */
	public static volatile SingularAttribute<IdexxSendImageJob, Integer> destinationPort;

	/** The retries count. */
	public static volatile SingularAttribute<IdexxSendImageJob, Integer> retriesCount;

	/** The job status. */
	public static volatile SingularAttribute<IdexxSendImageJob, String> jobStatus;

	/** The created date time. */
	public static volatile SingularAttribute<IdexxSendImageJob, Timestamp> createdDateTime;

	/** The s3 image url. */
	public static volatile SingularAttribute<IdexxSendImageJob, String> s3ImageUrl;

	/** The destination host name. */
	public static volatile SingularAttribute<IdexxSendImageJob, String> destinationHostName;

	/** The updated date time. */
	public static volatile SingularAttribute<IdexxSendImageJob, Timestamp> updatedDateTime;

	/** The job id. */
	public static volatile SingularAttribute<IdexxSendImageJob, String> jobId;

	/** The downloaded im file path. */
	public static volatile SingularAttribute<IdexxSendImageJob, String> downloadedIMFilePath;

	/** The job status description. */
	public static volatile SingularAttribute<IdexxSendImageJob, String> jobStatusDescription;

	/** The image asset id. */
	public static volatile SingularAttribute<IdexxSendImageJob, String> imageAssetId;

	/** The sending ae title. */
	public static volatile SingularAttribute<IdexxSendImageJob, String> sendingAETitle;

	/** The destination ae title. */
	public static volatile SingularAttribute<IdexxSendImageJob, String> destinationAETitle;

	public static volatile SingularAttribute<IdexxSendImageJob, Date> scheduleTimestamp;
}
