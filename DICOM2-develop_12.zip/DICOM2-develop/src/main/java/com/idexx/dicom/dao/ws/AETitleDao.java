/**
 * Database Paeristance for AE Title Related CRUD Operations.
 * Every Method will throw a run time exception IdexxDicomAEConfigDbException
 * Because, A functional requirement is explicitly stating, the software need to show DB related exceptions.
 */
package com.idexx.dicom.dao.ws;

import java.util.List;

import com.idexx.dicom.ae.entities.AEEntity;
import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.entities.IdexxAPIKey;
import com.idexx.dicom.ae.entities.IdexxInvalidAE;
import com.idexx.dicom.services.requestservice.validator.ErrorDTO;

/**
 * @author vkandagatla
 * 
 */
public interface AETitleDao {
    
    List<AETitle> getAllAETitles();
    
    List<AETitle> findAETitle(String aeTitle);
    
    List<AETitle> findAETitle(String aeTitle, String instituteName);
    
    List<AETitle> findAETitle(String aeTitle, String instituteName, String sapId);
    
    List<AETitle> findAETitleBySapId(String sapId);
    
    List<AETitle> findAETitleByAETitleAndSapId(String aeTitle, String sapId);
    
    List<AETitle> findAETitleBySapIdAndInstituteName(String sapId, String instituteName);
    
    List<ErrorDTO> validateSapIdAndModality(String sapId, String modalityTypeCode);
    
    List<AEEntity> findAE(String aeTitle);
    
    void createAETitle(AETitle aeTitle);
    
    void createAE(AEEntity aeEntity);
    
    void deleteAETitle(AETitle aeTitle);
    
    void updateAETitle(AETitle aeTitle);
    
    IdexxInvalidAE getInvalidAETitle(String aeTitle);
    
    IdexxAPIKey getIdexxAPIKey(String apiKey);
}
