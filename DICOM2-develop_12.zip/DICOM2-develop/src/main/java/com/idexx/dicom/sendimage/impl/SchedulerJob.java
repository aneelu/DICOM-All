/**
 * 
 */
package com.idexx.dicom.sendimage.impl;

import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.idexx.dicom.dao.ws.DicomConfigDao;
import com.idexx.dicom.sendimage.JobRunnerBuilder;
import com.idexx.dicom.sendimage.ThreadController;

/**
 * @author vkandagatla
 * 
 */

public class SchedulerJob implements Job {
	
	private static final Logger LOG = Logger.getLogger(SchedulerJob.class);
	
    private JobRunnerBuilder builder;
    private DicomConfigDao configDao;
    public static final String DELAY_TIME = "delay time";
    public static final String JOB_BUILDER = "JOB_BUILDER";
    public static final String CONFIG_DAO = "CONFIG_DAO";

    /*
     * (non-Javadoc)
     * 
     * @see org.quartz.Job#execute(org.quartz.JobExecutionContext)
     */
    @Override
    public final void execute(final JobExecutionContext jobContext) throws JobExecutionException {
    	LOG.info("Executing Scheduler Job");

        Object obj = jobContext.getJobDetail().getJobDataMap().get(JOB_BUILDER);
        this.builder = (JobRunnerBuilder) obj;

        obj = jobContext.getJobDetail().getJobDataMap().get(CONFIG_DAO);
        this.configDao = (DicomConfigDao) obj;
        List<Runnable> runners = this.builder.build();

        if (null != runners && !runners.isEmpty()) {
            Queue<Runnable> runnersQue = new ConcurrentLinkedQueue<Runnable>(runners);
            ThreadController controller = new ThreadControllerImpl(runnersQue, configDao);
            controller.start();
        } else {
            LOG.info("No Jobs in Queue");
        }

        // wait for a period of time
        long delayTime = jobContext.getJobDetail().getJobDataMap().getLong(DELAY_TIME);

        try {
            LOG.info("Sleaping to default: " + delayTime);
            Thread.sleep(delayTime);
            LOG.info("Completed all in the QUEUE");
        } catch (Exception e) {
            LOG.error(e.getLocalizedMessage(), e);
        }
    }
    
    


}
