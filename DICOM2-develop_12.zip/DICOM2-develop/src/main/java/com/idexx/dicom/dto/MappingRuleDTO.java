package com.idexx.dicom.dto;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class MappingRuleDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1347497541010844520L;
	private String id;
	private String sapId;
	private String name;
	
	private Set<MappingRuleTriggerDTO> mappingRuleTriggers = new HashSet<MappingRuleTriggerDTO>(0);

	private Set<MappingRuleActionDTO> mappingRuleActions = new HashSet<MappingRuleActionDTO>(0);
	
	public MappingRuleDTO() {
		super();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name=name;
	}

	public Set<MappingRuleTriggerDTO> getMappingRuleTriggers() {
		return mappingRuleTriggers;
	}

	public void setMappingRuleTriggers(Set<MappingRuleTriggerDTO> mappingRuleTriggers) {
		this.mappingRuleTriggers=mappingRuleTriggers;
	}

	public Set<MappingRuleActionDTO> getMappingRuleActions() {
		return mappingRuleActions;
	}

	public void setMappingRuleActions(Set<MappingRuleActionDTO> mappingRuleActions) {
		this.mappingRuleActions=mappingRuleActions;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSapId() {
		return sapId;
	}

	public void setSapId(String sapId) {
		this.sapId = sapId;
	}
}
