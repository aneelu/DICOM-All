/**
 * 
 */
package com.idexx.dicom.aeservices.v12;

import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v12.SendImageJobParamDTO;

/**
 * @author mdindukurthi
 * 
 */
public interface SendImageJobService {
    String performService(SendImageJobParamDTO dto) throws IdexxDicomAEConfigServiceException;
    
    
}
