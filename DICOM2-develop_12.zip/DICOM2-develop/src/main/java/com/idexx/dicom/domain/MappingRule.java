package com.idexx.dicom.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="DS_MAPPING_RULE")
public class MappingRule implements Serializable {
	private static final long serialVersionUID = -4934775536951172572L;

	@Id
	@GeneratedValue(generator = "system-uuid")
    @GenericGenerator(name = "system-uuid", strategy = "uuid")
	@Column(name="ID", unique=true, nullable=false)
	private String id;
	
	@NotNull
	@Column(name = "SAP_ID")
	private String sapId;
	
	@Column(name="NAME")
	private String name;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATE_DATE")
	private Date  createDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATE_TIMESTAMP")
	private Date  updateDate;
	
	@OneToMany(fetch = FetchType.EAGER, mappedBy = "mappingRule", cascade = CascadeType.ALL, orphanRemoval=true)
	private Set<MappingRuleTrigger> mappingRuleTriggers = new HashSet<MappingRuleTrigger>(0);

	@OneToMany(fetch = FetchType.EAGER, mappedBy = "mappingRule", cascade = CascadeType.ALL, orphanRemoval=true)
	private Set<MappingRuleAction> mappingRuleActions = new HashSet<MappingRuleAction>(0);
	
	public MappingRule() {
		super();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name=name;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate=createDate;
	}

	public Set<MappingRuleTrigger> getMappingRuleTriggers() {
		return mappingRuleTriggers;
	}

	public void setMappingRuleTriggers(Set<MappingRuleTrigger> mappingRuleTriggers) {
		this.mappingRuleTriggers=mappingRuleTriggers;
	}

	public Set<MappingRuleAction> getMappingRuleActions() {
		return mappingRuleActions;
	}

	public void setMappingRuleActions(Set<MappingRuleAction> mappingRuleActions) {
		this.mappingRuleActions=mappingRuleActions;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSapId() {
		return sapId;
	}

	public void setSapId(String sapId) {
		this.sapId = sapId;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	
	@PrePersist
	void createdAt() {
		this.createDate = this.updateDate = new Date();
	}

	@PreUpdate
	void updatedAt() {
		this.updateDate = new Date();
	}

}
