package com.idexx.dicom.services.requestservice.dto;

public class ExternalPimsIdDTO {
	
	private String patientId;
	
	private String pimsIssuer;

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getPimsIssuer() {
		return pimsIssuer;
	}

	public void setPimsIssuer(String pimsIssuer) {
		this.pimsIssuer = pimsIssuer;
	}

}
