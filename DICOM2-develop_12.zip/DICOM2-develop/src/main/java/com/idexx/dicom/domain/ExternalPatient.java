package com.idexx.dicom.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

// TODO: Auto-generated Javadoc
/**
 * The Class ExternalPatient.
 */
@Entity
@Table(name = "EXTERNAL_PATIENT_LINK")
@IdClass(ExternalPatientPK.class)
public class ExternalPatient implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The issuer of patient id. */
	private String issuerOfPatientID;

	/** The pims patient id. */
	private String pimsPatientId;

	/** The patient id. */
	private String patientID;

	/** The patient. */
	private Patient patient;

	/**
	 * Gets the issuer of patient id.
	 *
	 * @return the issuerOfPatientID
	 */
	@Id
	@Column(name = "ISSUER_OF_PATIENT_ID")
	public String getIssuerOfPatientID() {
		return issuerOfPatientID;
	}

	/**
	 * Sets the issuer of patient id.
	 *
	 * @param issuerOfPatientID
	 *            the issuerOfPatientID to set
	 */
	public void setIssuerOfPatientID(String issuerOfPatientID) {
		this.issuerOfPatientID = issuerOfPatientID;
	}

	/**
	 * Gets the pims patient id.
	 *
	 * @return the pims patient id
	 */
	@Column(name = "PIMS_PATIENT_ID")
	public String getPimsPatientId() {
		return pimsPatientId;
	}

	/**
	 * Sets the pims patient id.
	 *
	 * @param pimsPatientId
	 *            the new pims patient id
	 */
	public void setPimsPatientID(String pimsPatientId) {
		this.pimsPatientId = pimsPatientId;
	}

	/**
	 * Gets the patient id.
	 *
	 * @return the patientID
	 */
	@Id
	@Column(name = "PATIENT_ID")
	public String getPatientID() {
		return patientID;
	}

	/**
	 * Sets the patient id.
	 *
	 * @param patientID
	 *            the patientID to set
	 */
	public void setPatientID(String patientID) {
		this.patientID = patientID;
	}

	/**
	 * Sets the pims patient id.
	 *
	 * @param pimsPatientId
	 *            the pimsPatientId to set
	 */
	public void setPimsPatientId(String pimsPatientId) {
		this.pimsPatientId = pimsPatientId;
	}

	/**
	 * Gets the patient.
	 *
	 * @return the patient
	 */
	@ManyToOne(targetEntity = Patient.class)
	@JoinColumn(name = "PATIENT_ID", insertable = false, updatable = false)
	public Patient getPatient() {
		return patient;
	}

	/**
	 * Sets the patient.
	 *
	 * @param patient
	 *            the new patient
	 */
	public void setPatient(Patient patient) {
		this.patient = patient;
	}
}
