package com.idexx.dcm4che3.tool.dcmqrscp;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Sequence;
import org.dcm4che3.data.Tag;
import org.dcm4che3.data.VR;
import org.dcm4che3.net.Association;
import org.dcm4che3.net.pdu.PresentationContext;
import org.dcm4che3.net.service.DicomServiceException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.constants.IdexxDicomTestConstants;
import com.idexx.dicom.domain.ExternalPatient;
import com.idexx.dicom.domain.MPPSNCreate;
import com.idexx.dicom.domain.Patient;
import com.idexx.dicom.domain.RequestDetails;
import com.idexx.dicom.services.mwl.MWLCFindServiceImpl;
import com.idexx.dicom.services.requestservice.dto.MWLCFindResponseDTO;
import com.idexx.dicom.services.requestservice.dto.SearchDetailsDTO;
import com.idexx.imaging.imagemanager.soap.ExternalPatientIdDTO;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;

public class IdexxPatientQueryTaskTest  {
	
	@Mock
	private Association associations;
	
	@Mock
	private PresentationContext presentationContext;
	
	@Mock
	private Attributes reqAttributes;
	
	@Mock
	private Attributes keys;
	
	@Mock
	private List<ExternalPatientIdDTO> externalPatientIdDTOList;
	
	@Mock
	private Iterator<ExternalPatientIdDTO> externalPatientIdIterator;
	
	List<MWLCFindResponseDTO> cFindTestResponses = new ArrayList<MWLCFindResponseDTO>();
	
	List<ExternalPatient> extPatients = new ArrayList<ExternalPatient>();
	List<ExternalPatientIdDTO> extPatientDTOs = new ArrayList<ExternalPatientIdDTO>();
	List<MPPSNCreate> sequenceData = new ArrayList<MPPSNCreate>();
	
	@InjectMocks
	IdexxPatientQueryTask objectUnderTest = new IdexxPatientQueryTask(associations, presentationContext, reqAttributes, keys, IdexxDicomTestConstants.AVAILABILITY, IdexxDicomTestConstants.CALLINGAETITLE);
	
	@Mock
	private MWLCFindServiceImpl mwlCFindServiceMock;	
	
	@Before
	public void setup() throws IdexxServiceException_Exception {
		
		MockitoAnnotations.initMocks(this);
		
		List<String> modalities = new ArrayList<String>();
		
		modalities.add("MODALITY1");
		modalities.add("MODALITY2");
		
		List<String> status = new ArrayList<String>(0);
		
		SearchDetailsDTO searchObject = new SearchDetailsDTO();
		searchObject.setPatientId("PATIENTID");		
		searchObject.setModalities(modalities);
		searchObject.setPatientName("PATIENTNAME");
		searchObject.setSapId("SAPID");
		searchObject.setStartDate(new Date());
		searchObject.setEndDate(new Date());
		searchObject.setStatus(status);
		
		RequestDetails requestDetails = new RequestDetails();
		requestDetails.setAccessionNumber("ACCESSION NUMBER");
		requestDetails.setApiKey("API KEY");
		requestDetails.setCreateTimeStamp(new Timestamp(System.currentTimeMillis()));
		requestDetails.setId("ID");
		requestDetails.setModality("MODALITY");
		requestDetails.setPatientId("PATIENTID");
		requestDetails.setRequestingDoctor("REQUESTING DOCTOR");
		requestDetails.setRequestNotes("REQUEST NOTES");
		requestDetails.setSapId("SAPID");
		requestDetails.setStatus("STATUS");
		requestDetails.setStudyInstanceUID("STUDY INSTANCE UID");
		requestDetails.setUpdateTimeStamp(new Timestamp(System.currentTimeMillis()));
		
		Patient patientObject = new Patient();
		patientObject.setID("ID");
		patientObject.setPatientName("PATIENTNAME");
		patientObject.setDob(new Timestamp(System.currentTimeMillis()));
		patientObject.setBreed("BREED");
		patientObject.setGender("GENDER");
		patientObject.setWeight(new Integer(0));
		patientObject.setApplicationPatientId("APPLICATION PATIENTID");
		requestDetails.setPatient(patientObject);
		
		MWLCFindResponseDTO response1 = new MWLCFindResponseDTO();
		response1.setStudyInstanceUID("STUDYINSTANCEUID");
		response1.setPatientId("PATIENTID");
		response1.setPatientName("PATIENTNAME");
		response1.setDateOfBirth(new Date());		
		response1.setGender("SEX");
		response1.setSpecies("SPECIES");
		response1.setBreed("BREED");
		response1.setWeight(0);
		response1.setResponsiblePeron("RESPONSIBLE PERSON");
		response1.setResponsibleOrganization("RESPONSIBLE ORGANIZATION");
		response1.setModality("MODALITY");
		
		List<ExternalPatientIdDTO> externalPatientIdList = new ArrayList<ExternalPatientIdDTO>();
		ExternalPatientIdDTO externalPatientIdDTO = new ExternalPatientIdDTO();
		externalPatientIdDTO.setPimsPatientId("OTHER PATIENT ID");
		externalPatientIdDTO.setIssuerOfPatientId("OTHER ISSUER OF PATIENT ID");		
		externalPatientIdList.add(externalPatientIdDTO);		
		response1.setExternalPatientIdDTO(externalPatientIdList);
		
		response1.setAccessionNumber("ACCESSION NUMBER");
		response1.setRequestedProcedureId("");
		response1.setRequestedProcedureDescription("REQUESTED PROCEDURE DESCRIPTION");
		response1.setScheduledProcedureStepStartDate(new Date());
		response1.setScheduledProcedureStepId("SCHEDULED PROCEDURE STEP ID");
		response1.setScheduledProcedureStepStatus("SCHEDULED PROCEDURE STEP STATUS");
		
		cFindTestResponses.add(response1);
		
		objectUnderTest.setcFindResponses(cFindTestResponses);
		
	}
	
	
	@Test
	public void nextMatchTest() throws DicomServiceException {
		
		
		MWLCFindResponseDTO response = cFindTestResponses.get(0);
		
		Attributes expectedAttributes = new Attributes(2);
		Attributes seqAttributes = new Attributes(2);

		expectedAttributes.setString(Tag.StudyInstanceUID, VR.LO, response.getStudyInstanceUID());
		expectedAttributes.setString(Tag.PatientID, VR.LO, response.getPatientId());
		expectedAttributes.setString(Tag.PatientName, VR.PN, response.getPatientName());
		expectedAttributes.setDate(Tag.PatientBirthDate, VR.DA, response.getDateOfBirth());
		expectedAttributes.setString(Tag.PatientSex, VR.CS, response.getGender());
		expectedAttributes.setString(Tag.PatientSpeciesDescription, VR.LO, response.getSpecies());
		expectedAttributes.setString(Tag.PatientBreedDescription, VR.LO, response.getBreed());
		expectedAttributes.setString(Tag.PatientWeight, VR.DS, String.valueOf(response.getWeight()));

		expectedAttributes.setString(Tag.ResponsiblePerson, VR.PN,
				response.getResponsiblePeron() == null ? "" : response.getResponsiblePeron());
		expectedAttributes.setString(Tag.ResponsibleOrganization, VR.LO, response.getResponsibleOrganization());

		expectedAttributes.setString(Tag.Modality, VR.CS, response.getModality());
		expectedAttributes.setString(Tag.AccessionNumber, VR.SH, response.getAccessionNumber());

		expectedAttributes.setString(Tag.RequestedProcedureID, VR.SH, response.getRequestedProcedureId());
		expectedAttributes.setString(Tag.RequestedProcedureDescription, VR.LO, response.getRequestedProcedureDescription());

		Sequence otherPatientSeq = expectedAttributes.ensureSequence(Tag.OtherPatientIDsSequence, 2);

		when(externalPatientIdIterator.hasNext()).thenReturn(true, false);
		
		when(externalPatientIdIterator.next()).thenReturn(response.getExternalPatientIdDTO().get(0));
		
		when(externalPatientIdDTOList.iterator()).thenReturn(externalPatientIdIterator);		
		
		Attributes otherPatientIdsAttributes = new Attributes(2);
		otherPatientIdsAttributes.setString(Tag.PatientID, VR.LO, response.getOtherPatientId());
		otherPatientIdsAttributes.setString(Tag.IssuerOfPatientID, VR.LO, response.getOtherIssuerOfPatientId());
		otherPatientSeq.add(otherPatientIdsAttributes);

		Sequence seq = expectedAttributes.ensureSequence(Tag.ScheduledProcedureStepSequence, 2);
		seqAttributes.setDate(Tag.ScheduledProcedureStepStartDate, VR.DA, response.getScheduledProcedureStepStartDate());
		seqAttributes.setString(Tag.ScheduledProcedureStepID, VR.SH, response.getScheduledProcedureStepId());
		seqAttributes.setString(Tag.ScheduledProcedureStepStatus, VR.CS, response.getScheduledProcedureStepStatus());
		seqAttributes.setString(Tag.Modality, VR.CS, response.getModality());

		seq.add(seqAttributes);
		
		Attributes actualAttributes = objectUnderTest.nextMatch();
		
		assertEquals(expectedAttributes.getString(Tag.PatientName), actualAttributes.getString(Tag.PatientName));		
	}
	

}
