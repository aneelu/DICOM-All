#!/bin/bash

## tomcat vars

if [[ -z "${_tomcatHomeDir}" ]]
then
	_tomcatHomeDir=/opt/tomcat
fi

if [[ -z "${_tomcatUser}" ]]
then
	_tomcatUser=tomcat
fi

adduser ${_tomcatUser} -d ${_tomcatHomeDir}

_tomcatArchive=/tmp/common-bin/${_tomcatVersion}.tar.gz
_tomcatTemp=$(mktemp -p ${_tomcatHomeDir} --suffix .tar.gz)

## tomcat deploy
tar xfvz ${_tomcatArchive} -C ${_tomcatHomeDir}
yum install -y epel-release
yum install -y tomcat-native

chown -R ${_tomcatUser}: ~tomcat

## de-turd tomcat
rm -rf ${_tomcatHomeDir}/${_tomcatVersion}/webapps/*

## Copy in conf files
mv /tmp/tomcat/setenv.sh ${_tomcatHomeDir}/${_tomcatVersion}/bin/setenv.sh
#mv /tmp/tomcat/server.xml ${_tomcatHomeDir}/${_tomcatVersion}/conf/server.xml

## Install New Relic
yum install -y unzip
pushd "${_tomcatHomeDir}/${_tomcatVersion}" && unzip /tmp/common-bin/newrelic-java.zip && popd
mv /tmp/tomcat/newrelic.yml  ${_tomcatHomeDir}/${_tomcatVersion}/newrelic/newrelic.yml
chown -R ${_tomcatUser}: ${_tomcatHomeDir}/${_tomcatVersion}/newrelic
