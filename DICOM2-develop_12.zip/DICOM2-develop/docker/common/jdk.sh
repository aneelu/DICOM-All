#!/bin/bash

_jdkHome=/opt/jdk/${_jdkVersion}
_jdkArchive=/tmp/common-bin/${_jdkVersion}.gz

## jdk deploy

mkdir -p ${_jdkHome}
tar xfvz ${_jdkArchive} -C ${_jdkHome} --strip 1
chown -R root: ${_jdkHome}
alternatives --install /usr/bin/java java ${_jdkHome}/bin/java 20000
alternatives --set java ${_jdkHome}/bin/java

## add idexx self signed cert into jdk

_certTemp=/tmp/common/idexx_it_root_selfsigned.cer

${_jdkHome}/bin/keytool -importcert -alias idexx_it_root_selfsigned -keystore ${_jdkHome}/jre/lib/security/cacerts -storepass changeit -file ${_certTemp} -noprompt

## PimsDW Requires this cert
_certTemp2=/tmp/common/idexx_base_cert.cer

${_jdkHome}/bin/keytool -importcert -trustcacerts -alias idexx_base -keystore ${_jdkHome}/jre/lib/security/cacerts -storepass changeit -file ${_certTemp2} -noprompt

export JAVA_HOME=${_jdkHome}
echo "export JAVA_HOME=${_jdkHome}" > /etc/profile.d/java.sh

## jai install
tar xfvz /tmp/common-bin/jai-1_1_3-lib-linux-amd64.tar.gz -C /tmp/
cp /tmp/jai-1_1_3/lib/libmlib_jai.so ${_jdkHome}/jre/lib/amd64/
cp /tmp/jai-1_1_3/lib/*.jar ${_jdkHome}/jre/lib/ext/

tar xfvz /tmp/common-bin/jai_imageio-1_1-lib-linux-amd64.tar.gz -C /tmp/
cp /tmp/jai_imageio-1_1/lib/*.jar ${_jdkHome}/jre/lib/ext/
cp /tmp/jai_imageio-1_1/lib/libclib_jiio.so ${_jdkHome}/jre/lib/amd64/

