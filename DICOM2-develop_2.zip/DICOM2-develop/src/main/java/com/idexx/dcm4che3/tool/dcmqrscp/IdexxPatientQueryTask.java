package com.idexx.dcm4che3.tool.dcmqrscp;

import java.util.ArrayList;
import java.util.List;

import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Sequence;
import org.dcm4che3.data.Tag;
import org.dcm4che3.data.VR;
import org.dcm4che3.net.Association;
import org.dcm4che3.net.pdu.PresentationContext;
import org.dcm4che3.net.service.BasicQueryTask;
import org.dcm4che3.net.service.DicomServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;

import com.idexx.dicom.domain.Client;
import com.idexx.dicom.domain.ExternalPatient;
import com.idexx.dicom.domain.MPPSNCreate;
import com.idexx.dicom.domain.Owner;
import com.idexx.dicom.domain.Patient;
import com.idexx.dicom.domain.RequestDetails;
import com.idexx.dicom.repo.ClientRepo;
import com.idexx.dicom.repo.ExternalPatientRepo;
import com.idexx.dicom.repo.OwnerRepo;
import com.idexx.dicom.repo.PatientRepo;
import com.idexx.dicom.service.ws.impl.MWLCFindServiceImpl;
import com.idexx.dicom.services.IdexxDicomServiceConstants;
import com.idexx.imaging.imagemanager.soap.ClientDTO;
import com.idexx.imaging.imagemanager.soap.ExternalPatientIdDTO;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;

/**
 * <pre>
 * Description of the class
 * </pre>
 * 
 * @author rkaranam
 * @version 1.3
 */
public class IdexxPatientQueryTask extends BasicQueryTask {

    protected final String availability;
    protected final String[] patIDs;
    protected Attributes patRec;
    protected final String callingAETitle;

    private static final Logger LOG = LoggerFactory.getLogger(IdexxPatientQueryTask.class);

    private List<MWLCFindResponse> cFindResponses;

    private MWLCFindServiceImpl mwlCFindService;

    private ApplicationContext applicationContext;

    private PatientRepo patientRepo;
    private ExternalPatientRepo externalPatientRepo;
    private OwnerRepo ownerRepo;
    private ClientRepo clientRepo;

    public IdexxPatientQueryTask(Association as, PresentationContext pc, Attributes rq, Attributes keys,
	    String availability, ApplicationContext applicationContext)
		    throws DicomServiceException, IdexxServiceException_Exception {
	super(as, pc, rq, keys);
	this.availability = availability;
	this.patIDs = keys.getStrings(Tag.PatientID);
	this.applicationContext = applicationContext;
	callingAETitle = as.getCallingAET();

	mwlCFindService = (MWLCFindServiceImpl) applicationContext.getBean("mwlCFindService");
	patientRepo = (PatientRepo) applicationContext.getBean(PatientRepo.class);
	externalPatientRepo = (ExternalPatientRepo) applicationContext.getBean(ExternalPatientRepo.class);
	ownerRepo = (OwnerRepo) applicationContext.getBean(OwnerRepo.class);
	clientRepo = (ClientRepo) applicationContext.getBean(ClientRepo.class);

	loadRequests(keys);
    }

    @Override
    public boolean hasMoreMatches() throws DicomServiceException {
	return cFindResponses.size() != 0;
    }

    @Override
    public Attributes nextMatch() throws DicomServiceException {

	LOG.debug("MWL C-Find nextMatch() is invoked");

	MWLCFindResponse response = cFindResponses.get(0);
	Attributes attrs = new Attributes(2);
	Attributes seqAttributes = new Attributes(2);

	attrs.setString(Tag.StudyInstanceUID, VR.LO, response.getStudyInstanceUID());
	attrs.setString(Tag.PatientID, VR.LO, response.getApplicationPatientId());
	attrs.setString(Tag.PatientName, VR.PN, response.getPatientName());
	attrs.setDate(Tag.PatientBirthDate, VR.DA, response.getDateOfBirth());
	attrs.setString(Tag.PatientSex, VR.CS, response.getGender());
	attrs.setString(Tag.PatientSpeciesDescription, VR.LO, response.getSpecies());
	attrs.setString(Tag.PatientBreedDescription, VR.LO, response.getBreed());
	attrs.setString(Tag.PatientWeight, VR.DS, String.valueOf(response.getWeight()));

	attrs.setString(Tag.ResponsiblePerson, VR.PN,
		response.getResponsiblePeron() == null ? "" : response.getResponsiblePeron());
	attrs.setString(Tag.ResponsibleOrganization, VR.LO, response.getResponsibleOrganization());

	attrs.setString(Tag.Modality, VR.CS, response.getModality());
	attrs.setString(Tag.AccessionNumber, VR.SH, response.getAccessionNumber());
	attrs.setString(Tag.IssuerOfPatientID, VR.LO, response.getIssuerOfPatientId());

	attrs.setString(Tag.RequestedProcedureID, VR.SH, "");
	attrs.setString(Tag.RequestedProcedureDescription, VR.LO, response.getRequestedProcedureDescription());

	Sequence otherPatientSeq = attrs.ensureSequence(Tag.OtherPatientIDsSequence, 2);

	for (ExternalPatientIdDTO dto : response.getExternalPatientIdDTO()) {
	    Attributes otherPatientIdsAttributes = new Attributes(2);
	    otherPatientIdsAttributes.setString(Tag.PatientID, VR.LO, dto.getPimsPatientId());
	    otherPatientIdsAttributes.setString(Tag.IssuerOfPatientID, VR.LO, dto.getIssuerOfPatientId());
	    otherPatientSeq.add(otherPatientIdsAttributes);
	}

	Sequence seq = attrs.ensureSequence(Tag.ScheduledProcedureStepSequence, 2);
	seqAttributes.setDate(Tag.ScheduledProcedureStepStartDate, VR.DA,
		response.getScheduledProcedureStepStartDate());
	seqAttributes.setString(Tag.ScheduledProcedureStepID, VR.SH, response.getScheduledProcedureStepId());
	seqAttributes.setString(Tag.ScheduledProcedureStepStatus, VR.CS, response.getScheduledProcedureStepStatus());
	seqAttributes.setString(Tag.Modality, VR.CS, response.getModality());

	seq.add(seqAttributes);

	cFindResponses.remove(0);
	return attrs;
    }

    @Override
    protected Attributes adjust(Attributes match) throws DicomServiceException {
	Attributes adjust = super.adjust(match);
	return adjust;
    }

    private void loadRequests(Attributes keys) throws IdexxServiceException_Exception, DicomServiceException {

	LOG.debug("MWL C-Find loadRequests is invoked");

	cFindResponses = new ArrayList<MWLCFindResponse>();

	MWLCFindRequest request = new MWLCFindRequest();
	request.setPatientId(keys.getValue(Tag.PatientID).toString());
	request.setIssuerOfPatientId(keys.getString(Tag.IssuerOfPatientID));
	String sapId = "";

	List<String> distinctAeTitle = mwlCFindService.findDistinctAeTitleBySapId(callingAETitle);
	if (distinctAeTitle != null && distinctAeTitle.size() == 1) {
	    sapId = distinctAeTitle.get(0);
	} else {
	    LOG.error("Unable to find single sapId for given AE Title " + callingAETitle);
	    DicomServiceException exc = new DicomServiceException(0x0106,
		    "Unable to find single sapId for given AE Title " + callingAETitle);
	    throw exc;
	}

	List<RequestDetails> mwlCFindRequests = null;

	String issuerPatientId = request.getIssuerOfPatientId() == null ? "" : request.getIssuerOfPatientId();
	String patientId = request.getPatientId() == null ? "" : request.getPatientId();

	boolean ONLY_PATIENT_ID_EXISTS = (patientId.length() > 0 && issuerPatientId.length() == 0);
	boolean ONLY_ISSUER_OF_PATIENT_ID_EXISTS = (patientId.length() == 0 && issuerPatientId.length() > 0);
	boolean BOTH_PATIENT_ID_AND_ISSUER_OF_PATIENT_ID_EXISTS = (patientId.length() > 0
		&& issuerPatientId.length() > 0);

	if (ONLY_PATIENT_ID_EXISTS) {
	    // SAP_ID AND PATIENT_ID
	    mwlCFindRequests = mwlCFindService.findByPatientIdAndSapId(patientId, sapId);
	} else if (ONLY_ISSUER_OF_PATIENT_ID_EXISTS) {
	    // SAP_ID AND ISSUER_OF_PATIENT_ID
	    mwlCFindRequests = mwlCFindService.findByIssuerOfPatientIdAndSapId(issuerPatientId, sapId);
	} else if (BOTH_PATIENT_ID_AND_ISSUER_OF_PATIENT_ID_EXISTS) {
	    // SAP_ID AND PATIENT_ID AND ISSUER_OF_PATIENT_ID
	    mwlCFindRequests = mwlCFindService.findByPatientIdIssuerOfPatientIdAndSapId(patientId, issuerPatientId,
		    sapId);
	} else {
	    // SAP_ID
	    mwlCFindRequests = mwlCFindService.findBySapId(sapId);
	}

	MWLCFindResponse response;

	for (RequestDetails req : mwlCFindRequests) {
	    Patient patientDetails = patientRepo.findByID(req.getPatientId());
	    List<ExternalPatient> extPatients = externalPatientRepo.findByPatientID(req.getPatientId());
	    List<ExternalPatientIdDTO> extPatientDTOs = new ArrayList<ExternalPatientIdDTO>();
	    for(ExternalPatient externalPatient : extPatients) {
		ExternalPatientIdDTO dto = new ExternalPatientIdDTO();
		dto.setIssuerOfPatientId(externalPatient.getIssuerOfPatientID());
		dto.setPimsPatientId(externalPatient.getPimsPatientId());
		extPatientDTOs.add(dto);
	    }
		
	    List<Owner> owners = ownerRepo.findByPatientID(req.getPatientId());
	    List<ClientDTO> clients = new ArrayList<ClientDTO>();
	    for(Owner owner: owners) {
		Client client = clientRepo.findByID(owner.getClientID());
		ClientDTO dto = new ClientDTO();
		dto.setClientFirstName(client.getFirstName());
		dto.setClientLastName(client.getLastName());
		dto.setEmail(client.getEmail());
		dto.setId(client.getID());
		boolean primary = false;
		try {
		    primary = new Boolean(owner.getPrimaryOwner());
		} catch(Exception exc) {
		    primary = false;
		}
		dto.setPrimaryOwner(primary);
		clients.add(dto);
	    }

	    response = new MWLCFindResponse();

	    // Patient Module
	    response.setPatientId(patientDetails.getID());
	    response.setPatientName(patientDetails.getPatientName());
	    response.setDateOfBirth(patientDetails.getDob());
	    response.setBreed(patientDetails.getBreed());
	    response.setGender(patientDetails.getGender());
	    response.setApplicationPatientId(patientDetails.getApplicationPatientId());
	    response.setWeightUnit(patientDetails.getWeightUnit());

	    // Other Patient Id Sequence
	    response.setExternalPatientIdDTO(extPatientDTOs);

	    response.setStudyInstanceUID(req.getStudyInstanceUID());
	    response.setModality(req.getModality());
	    response.setIssuerOfPatientId(req.getPimsIssuer());
	    response.setAccessionNumber(req.getAccessionNumber());
	    response.setRequestedProcedureDescription(req.getRequestNotes());

	    // Client Module
	    if (null != clients && clients.size() > 0) {
		response.setResponsiblePeron(
			patientDetails.getPatientName() + "^" + clients.get(0).getClientFirstName());
	    }

	    response.setResponsibleOrganization("");
	    response.setScheduledProcedureStepId("");
	    response.setScheduledProcedureStepStartDate(req.getCreateTimeStamp());
	    if (req.getStatus().equalsIgnoreCase(IdexxDicomServiceConstants.MPPS_REQUEST_STATUS_PENDING)) {
		response.setScheduledProcedureStepStatus(IdexxDicomServiceConstants.MPPS_REQUEST_STATUS_SCHEDULED);
	    } else {
		List<MPPSNCreate> sequenceData = mwlCFindService.findSequence(req.getStudyInstanceUID());
		if (null != sequenceData && sequenceData.size() > 0) {
		    response.setScheduledProcedureStepStatus(sequenceData.get(0).getPerformedProcedureStepStatus());
		} else {
		    response.setScheduledProcedureStepStatus("");
		}
	    }
	    response.setModality(req.getModality());
	    cFindResponses.add(response);
	}
	LOG.info("C-FIND success");
    }

}
