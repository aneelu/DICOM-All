/**
 * 
 */
package com.idexx.dicom.ae.validator.impl.v11;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.validator.v11.IdexxSendImageStatusValidator;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v11.SendImageStatusParamDTO;

/**
 * @author vkandagatla
 * 
 */
@Service("idexxSendImageStatusValidatorV11")
public class IdexxSendImageStatusValidatorImpl implements IdexxSendImageStatusValidator {
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.ae.validator.IdexxSendImageStatusValidator
     * 
     * #validate(com.idexx.dicom.services.sendimage.dto.SendImageStatusParamDTO)
     */
    public final int validate(final SendImageStatusParamDTO dto) throws IdexxDicomAEConfigServiceException {
        if (StringUtils.isEmpty(dto.getApiKey())) {
            throw new IdexxDicomAEConfigServiceException(
                    MISSING_MANDATORY, MISSING_MANDATORY);
        }
        if (StringUtils.isEmpty(dto.getJobId())) {
            throw new IdexxDicomAEConfigServiceException(
                    MISSING_MANDATORY, MISSING_MANDATORY);
        }
        
        if (dto.getJobId().size() == 1 && StringUtils.isEmpty(dto.getJobId().get(0))) {
            throw new IdexxDicomAEConfigServiceException(
                    MISSING_MANDATORY, MISSING_MANDATORY);
        }
        return 1;
    }
    
}
