/**
 * 
 */
package com.idexx.dicom.store.authorization.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.idexx.dicom.store.authorization.AuthorizationFailureService;

/**
 * @author anarayana
 * 
 */
@Service
public class IdexxDicomErrorHandlerImpl {
    @Autowired
    private AuthorizationFailureService failureService;
    
    public IdexxDicomErrorHandlerImpl() {
        
    }
    
    
    public void storeErrorLogs(String aeTitle, String instituteName, String ip, String hostName,
            String manufacturer, String manufacturerModelName, String modality, String patientName, 
            String respPerName) {
        failureService.logIdexxStoreFailure(aeTitle, instituteName, ip, hostName, manufacturer, 
                manufacturerModelName, modality, patientName, "");
    }

    public void uploadErrorLogs(String aeTitle, String instituteName, String ip, String hostName,
            String manufacturer, String manufacturerModelName, String modality, String patientName, 
            String respPerName) {
        failureService.logIdexxUploadFailure(aeTitle, instituteName, ip, hostName, manufacturer, 
                manufacturerModelName, modality, patientName, "");
    }
}
