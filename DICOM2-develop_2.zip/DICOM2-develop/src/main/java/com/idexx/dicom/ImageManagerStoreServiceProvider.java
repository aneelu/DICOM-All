/**
 * Interfacing ImageManagerStore
 */
package com.idexx.dicom;

import com.idexx.dicom.query.soap.IQRService11;
import com.idexx.imaging.imagemanager.soap.IDEXXImageManagerServices;

/**
 * @author sbitla
 * 
 */
public interface ImageManagerStoreServiceProvider {
    /**
     * @return the service interface for Image Manager
     * All the configurations will be supplied to WS Image Manager
     */
    IDEXXImageManagerServices getService();

    /**
     * @return Query server for DVM Insight
     */
    IQRService11 getQueryService();

}
