/**
 * 
 */
package com.idexx.dicom.store;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author vkandagatla
 * 
 */
public class DateTimeStampProvider implements DefaultValueProvider<String> {

    private Date date;

    /**
     * @param date
     */
    public DateTimeStampProvider(final Date date) {
        super();
        this.date = date;
    }

    /**
     * 
     */
    public DateTimeStampProvider() {
        super();
        date = new Date();
    }

    private static final String DEFAULT_DT_FORMAT = "yyyyMMdd hhmmss";

    @Override
    public final String getValue() {
        SimpleDateFormat dateFormatter = new SimpleDateFormat(DEFAULT_DT_FORMAT);
        return dateFormatter.format(date);
    }

}
