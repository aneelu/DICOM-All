/**
 * 
 */
package com.idexx.dicom.services.dto.v12;

import java.sql.Timestamp;

/**
 * @author vkandagatla
 * 
 */
public class IdexxDicomApplicationEntityDTO extends ReadAETitleDTO {

    private boolean enabled;

    private String createdDateTime;

    private String lastAccessed;

    private boolean identifiedByAeTitleOnly;

    /**
     * @return the identifiedByAeTitleOnly
     */
    public final boolean isIdentifiedByAeTitleOnly() {
        return identifiedByAeTitleOnly;
    }

    /**
     * @param identifiedByAeTitleOnly
     *            the identifiedByAeTitleOnly to set
     */
    public final void setIdentifiedByAeTitleOnly(final boolean identifiedByAeTitleOnly) {
        this.identifiedByAeTitleOnly = identifiedByAeTitleOnly;
    }

    public IdexxDicomApplicationEntityDTO() {
        enabled = true;
    }

    /**
     * @return the enabled
     */
    public final boolean isEnabled() {
        return enabled;
    }

    /**
     * @param enabled
     *            the enabled to set
     */
    public final void setEnabled(final boolean enabled) {
        this.enabled = enabled;
    }

    public final String getCreatedDateTime() {
        return createdDateTime;
    }

    public final void setCreatedDateTime(final String createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public final void setCreatedDateTime(final Timestamp createdDateTime) {
        final int lengthOfString = 19;
        this.createdDateTime = createdDateTime.toString().substring(0, lengthOfString);
    }

    public final String getLastAccessed() {
        return lastAccessed;
    }

    public final void setLastAccessed(final String lastAccessed) {
        this.lastAccessed = lastAccessed;
    }

    public final void setLastAccessed(final Timestamp lastAccessed) {
        this.lastAccessed = lastAccessed.toString();
    }
}
