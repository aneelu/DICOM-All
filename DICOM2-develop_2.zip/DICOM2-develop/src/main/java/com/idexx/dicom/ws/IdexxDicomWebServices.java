package com.idexx.dicom.ws;

import javax.jws.WebService;

@WebService
public interface IdexxDicomWebServices {
}
