/**
 * 
 */
package com.idexx.dicom.sendimage.impl;


import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.dao.sendimage.DicomJobDao;
import com.idexx.dicom.sendimage.SendImageJobProvider;
import com.idexx.dicom.services.sendimage.dto.SendImagePendingJobDTO;

/**
 * @author vkandagatla
 * 
 */
@Service
public class SendImageJobProviderImpl implements SendImageJobProvider {
	
	private static final Logger LOG = Logger.getLogger(SendImageJobProviderImpl.class);
	
    @Autowired
    private DicomJobDao jobDao;
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.sendimage.SendImageJobProvider#getPendingJobs()
     */
    @Override
    public final List<SendImagePendingJobDTO> getPendingJobs() {
        LOG.info("Getting JOBS");
        return this.createPendingJobs(this.jobDao.getPendingJobs());
    }
    
    
    @Override
    public final  void updateInProgressJobs() {
        LOG.info("Update IN-PROGRESS JOBS");
        jobDao.updateAllInProgressJobs();
    }
    /**
     * @param jobs
     * @return
     * Creates list of SendImagePendingJobDTO from List of IdexxSendImageJob
     */
    private List<SendImagePendingJobDTO> createPendingJobs(final List<IdexxSendImageJob> jobs) {
        List<SendImagePendingJobDTO> dtos = null;
        LOG.info("JOBS are: " + jobs);
        
        if (null != jobs && jobs.size() > 0) {
            dtos = new ArrayList<SendImagePendingJobDTO>(jobs.size());
            for (IdexxSendImageJob job : jobs) {
                dtos.add(this.createPendingJobDto(job));
            }
        }
        return dtos;
    }
    
    /**
     * @param jobEntity
     * @return Creates single SendImagePendingJobDTO using IdexxSendImageJob
     */
    private SendImagePendingJobDTO createPendingJobDto(final IdexxSendImageJob jobEntity) {
        SendImagePendingJobDTO dto = new SendImagePendingJobDTO(jobEntity.getJobId(),
                jobEntity.getJobStatus(),
                jobEntity.getJobStatusDescription());
        dto.setDestinationAETitle(jobEntity.getDestinationAETitle());
        dto.setDestinationHostName(jobEntity.getDestinationHostName());
        dto.setDestinationPort(jobEntity.getDestinationPort());
        dto.setDownloadedIMFilePath(jobEntity.getDownloadedIMFilePath());
        dto.setRetriesCount(jobEntity.getRetriesCount());
        dto.setSendingAETitle(jobEntity.getSendingAETitle());
        dto.setImageAssetId(jobEntity.getImageAssetId());
        return dto;
        
    }
    
}
