package com.idexx.dicom.echo.v12;

public interface DicomEchoService {
    String remoteHostname = "aws-dico-jboss-dev01.dicom.idexxi.com";
    int remotePortNumber = 11112;
    String defaultCalledAET = "DCM4CHEE_MAIN";
    
    boolean echo(String callingAET, String hostName, int port) throws InterruptedException;
    boolean echo(String callingAET) throws InterruptedException;
    boolean echo(String callingAET, String calledAET) throws InterruptedException;
    boolean echo(String callingAET, String calledAET, String hostName, int port) throws InterruptedException; 
}
