/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dicom.services.requestservice.dto;

/**
 * <pre>
 * Description of the class
 * </pre>
 * 
 * @author smallela
 * @version 1.3
 */
public class CancelRequestDTO {

	private String studyInstanceUID;
	private String apiKey;
	private String sapId;

	/**
	 * @return the studyInstanceUID
	 */
	public String getStudyInstanceUID() {
		return studyInstanceUID;
	}

	/**
	 * @param studyInstanceUID
	 *            the studyInstanceUID to set
	 */
	public void setStudyInstanceUID(String studyInstanceUID) {
		this.studyInstanceUID = studyInstanceUID;
	}

	/**
	 * @return the apiKey
	 */
	public String getApiKey() {
		return apiKey;
	}

	/**
	 * @param apiKey
	 *            the apiKey to set
	 */
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}

	/**
	 * @return the sapId
	 */
	public String getSapId() {
		return sapId;
	}

	/**
	 * @param sapId
	 *            the sapId to set
	 */
	public void setSapId(String sapId) {
		this.sapId = sapId;
	}

}
