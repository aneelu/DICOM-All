package com.idexx.dicom.services.mpps.dto;

import java.sql.Timestamp;

public class MPPSNSetDTO {

	private String id;
	private String mppsNCreateId;
	private String retrieveAETitle;
	private String referencedSOPInstanceUIDs;
	private String seriesDescription;
	private String performingPhysicianName;
	private String protocolName;
	private String operatorsName;
	private String seriesInstanceUID;
	private Timestamp createTimestamp;
	private Timestamp updateTimestamp;
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the mppsNCreateId
	 */
	public String getMppsNCreateId() {
		return mppsNCreateId;
	}
	/**
	 * @param mppsNCreateId the mppsNCreateId to set
	 */
	public void setMppsNCreateId(String mppsNCreateId) {
		this.mppsNCreateId = mppsNCreateId;
	}
	/**
	 * @return the retrieveAETitle
	 */
	public String getRetrieveAETitle() {
		return retrieveAETitle;
	}
	/**
	 * @param retrieveAETitle the retrieveAETitle to set
	 */
	public void setRetrieveAETitle(String retrieveAETitle) {
		this.retrieveAETitle = retrieveAETitle;
	}
	/**
	 * @return the referencedSOPInstanceUIDs
	 */
	public String getReferencedSOPInstanceUIDs() {
		return referencedSOPInstanceUIDs;
	}
	/**
	 * @param referencedSOPInstanceUIDs the referencedSOPInstanceUIDs to set
	 */
	public void setReferencedSOPInstanceUIDs(String referencedSOPInstanceUIDs) {
		this.referencedSOPInstanceUIDs = referencedSOPInstanceUIDs;
	}
	/**
	 * @return the seriesDescription
	 */
	public String getSeriesDescription() {
		return seriesDescription;
	}
	/**
	 * @param seriesDescription the seriesDescription to set
	 */
	public void setSeriesDescription(String seriesDescription) {
		this.seriesDescription = seriesDescription;
	}
	/**
	 * @return the performingPhysicianName
	 */
	public String getPerformingPhysicianName() {
		return performingPhysicianName;
	}
	/**
	 * @param performingPhysicianName the performingPhysicianName to set
	 */
	public void setPerformingPhysicianName(String performingPhysicianName) {
		this.performingPhysicianName = performingPhysicianName;
	}
	/**
	 * @return the protocolName
	 */
	public String getProtocolName() {
		return protocolName;
	}
	/**
	 * @param protocolName the protocolName to set
	 */
	public void setProtocolName(String protocolName) {
		this.protocolName = protocolName;
	}
	/**
	 * @return the operatorsName
	 */
	public String getOperatorsName() {
		return operatorsName;
	}
	/**
	 * @param operatorsName the operatorsName to set
	 */
	public void setOperatorsName(String operatorsName) {
		this.operatorsName = operatorsName;
	}
	/**
	 * @return the seriesInstanceUID
	 */
	public String getSeriesInstanceUID() {
		return seriesInstanceUID;
	}
	/**
	 * @param seriesInstanceUID the seriesInstanceUID to set
	 */
	public void setSeriesInstanceUID(String seriesInstanceUID) {
		this.seriesInstanceUID = seriesInstanceUID;
	}
	/**
	 * @return the createTimestamp
	 */
	public Timestamp getCreateTimestamp() {
		return createTimestamp;
	}
	/**
	 * @param createTimestamp the createTimestamp to set
	 */
	public void setCreateTimestamp(Timestamp createTimestamp) {
		this.createTimestamp = createTimestamp;
	}
	/**
	 * @return the updateTimestamp
	 */
	public Timestamp getUpdateTimestamp() {
		return updateTimestamp;
	}
	/**
	 * @param updateTimestamp the updateTimestamp to set
	 */
	public void setUpdateTimestamp(Timestamp updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

}
