/**
 * 
 */
package com.idexx.dicom.sendimage.impl;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.util.StringUtils;

import com.idexx.dicom.DicomObjectBuilder;
import com.idexx.dicom.ae.entities.BaseDicomImPluginConfig;
import com.idexx.dicom.conversion.ImagePropertiesProvider;
import com.idexx.dicom.conversion.impl.DicomObjectBuilderImpl;
import com.idexx.dicom.conversion.impl.ImageProperties;
import com.idexx.dicom.conversion.impl.ImagePropertiesProviderImpl;
import com.idexx.dicom.dao.ws.DicomConfigDao;
import com.idexx.dicom.sendimage.ImagePresignedUrlProvider;
import com.idexx.dicom.sendimage.SendImage;
import com.idexx.dicom.sendimage.SendImageJobConstants;
import com.idexx.dicom.sendimage.SendImageJobUpdateService;
import com.idexx.dicom.sendimage.TimedImageDownloader;
import com.idexx.dicom.sendimage.exceptions.SendRetryCountExceedException;
import com.idexx.dicom.services.IdexxDicomServiceConstants;
import com.idexx.dicom.services.sendimage.dto.SendImagePendingJobDTO;
import com.idexx.dicom.util.CommonUtil;
import com.idexx.imaging.imagemanager.soap.ImageDTO;
import com.idexx.imaging.imagemanager.soap.PatientDTO;
import com.idexx.imaging.imagemanager.soap.SeriesDTO;
import com.idexx.imaging.imagemanager.soap.StudyDTO;

/**
 * @author vkandagatla
 * 
 */
public class SendImageProcessorImpl implements Runnable {
	
	private static final Logger LOG = Logger.getLogger(SendImageProcessorImpl.class);

    private SendImageJobUpdateService jobUpdateService;

    private ImagePresignedUrlProvider presignedUrlProvider;

    private TimedImageDownloader imageDownloader;

    private DicomConfigDao configDao;

    private int defaultRetryCount = SendImageJobConstants.DEFAULT_JOB_RETRY_COUNT;

    private SendImage sendImageService;

    private SendImagePendingJobDTO job;

    private PatientDTO patientDTO;
    private StudyDTO studyDTO;
    private SeriesDTO seriesDTO;
    private ImageDTO imageDTO;
    private String presignedUrl;
    private String fileNameExtension = IdexxDicomServiceConstants.DICOM_FILE_EXTENSION1;
    private String sendImageBaseDir;

    /**
     * Default Processor
     */
    public SendImageProcessorImpl(final SendImagePendingJobDTO job, final SendImageJobUpdateService jobUpdateService,
            final ImagePresignedUrlProvider presignedUrlProvider, final TimedImageDownloader imageDownloader,
            final DicomConfigDao configDao, final SendImage sendImageService) {
        this.sendImageService = sendImageService;
        this.configDao = configDao;
        this.imageDownloader = imageDownloader;
        this.presignedUrlProvider = presignedUrlProvider;
        this.job = job;
        this.jobUpdateService = jobUpdateService;

    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Runnable#run()
     */
    public final void run() {
        try {
            this.process();
        } catch (SendRetryCountExceedException e1) {
            LOG.error(e1.getLocalizedMessage(), e1);
        } catch (SendImageException e1) {
            LOG.error(e1.getLocalizedMessage(), e1);
        }

    }

    /**
     * @throws SendRetryCountExceedException
     * @throws SendImageException
     */
    public final void process() throws SendRetryCountExceedException, SendImageException {
        LOG.info("Started JOB PROCESSING...");
        this.sendImageBaseDir = this.getSendImageBaseDir();
        // Step 1: get configured retry count
        this.defaultRetryCount = this.getRetryCount();
        // Step 2: Is the count exceeded?
        if (this.isRetryCountExceeded(job.getRetriesCount())) {
            LOG.info( "RETRY COUNT EXCEEDED");
            this.updateJobStatus(job.getJobId(), job.getRetriesCount(), "RETRY COUNT EXCEEDED");
            throw new SendRetryCountExceedException("Retry Count Exceed for job:" + job.getJobId()
                    + ":: Retry count is: " + job.getRetriesCount());
        }
        // Step 3: increase job's retry count
        LOG.info( "INCREASING RETRY COUNT");
        this.jobUpdateService.increaseRetryCount(job.getJobId());
        // Step 4: update job to progress status
        this.updateInProgressStatus(job.getJobId(), SendImageJobConstants.JOB_STATUS_DESC_PROGRESS);
        if (!isFileDownloaded(job)) {

            // Step 5: get presigned url for image with image asset id

            try {

                getPatientPropertiesForPresignedURL();
            } catch (Exception exp) {
                LOG.error(exp.getLocalizedMessage(), exp);
                this.updateJobStatus(job.getJobId(), job.getRetriesCount(), exp.getLocalizedMessage());
                throw new SendImageException("Unable to get Image Presigned URL for job:" + job.getJobId());
            }
            // Step 6: update presigned url to db
            LOG.info( "UPDATING IMAGE PRESIGNED URL to DB");
            this.jobUpdateService.updateImageUrl(job.getJobId(), presignedUrl);
            // Step 7: download Image with presigned URL
            File file = null;
            try {
                file = this.downloadImage();

            } catch (Exception exp) {
                LOG.error(exp.getLocalizedMessage(), exp);
                this.updateJobStatus(job.getJobId(), job.getRetriesCount(), exp.getLocalizedMessage());
                throw new SendImageException("Unable to Download URL for job:" + job.getJobId());
            }
            // Step 8: update image file path to job
            this.updateImageFilePathToJob(file);
        }
        // Step 9: send image
        this.sendImage(job);
    }

    /**
     * @param file
     *            Step 8
     */
    private void updateImageFilePathToJob(final File file) {
        if (null != file) {
            LOG.info( "Updating Image File Path to DB ");
            this.jobUpdateService.updateImageFilePath(job.getJobId(), file.getAbsolutePath());
            job.setDownloadedIMFilePath(file.getAbsolutePath());
        }
    }

    /**
     * @return
     * @throws  IOException
     * @throws Exception
     *             Step 7
     */
    private File downloadImage() throws SendImageException, IOException  {
        File file = null;
        LOG.info( "DOWNLOADING IMAGE for " + presignedUrl);
        File tmpFile = this.imageDownloader.downloadImage(presignedUrl, fileNameExtension, sendImageBaseDir);
        LOG.info( "Downloaded file: " + tmpFile.getAbsolutePath());
        String imageFileType = CommonUtil.removeDotCharInFileExtension(imageDTO.getFileType());
        LOG.info( "Image File Type: " + imageFileType);
        if (!IdexxDicomServiceConstants.DICOM_FILE_EXTENSION1.equalsIgnoreCase(imageFileType)
                ) {
            LOG.info( "Converting Downloaded File");
            ImageProperties properties = this.getImageProperties(tmpFile.getAbsolutePath(),
                    CommonUtil.getFileNameExtension(imageDTO.getFileType(), "jpg"));
            File convertedFile = this.createDcmFile(tmpFile.getName());
            DicomObjectBuilder dcmObjectBuilder = new DicomObjectBuilderImpl(properties, patientDTO, studyDTO,
                    seriesDTO, imageDTO, convertedFile);
            dcmObjectBuilder.build();
            LOG.info( "Converted Downloaded file: " + convertedFile.getAbsolutePath());
            file = convertedFile;
        } else {
            file = tmpFile;
        }
        return file;
    }

    /**
     * @throws SendImageException 
     * @throws Exception
     *             Step 5 in Send Image JOB
     */
    private void getPatientPropertiesForPresignedURL() throws SendImageException  {
        LOG.info( "Getting PRESIGNED URL for JOB: " + job.getImageAssetId());
        LOG.info("Getting patientDTO");
        patientDTO = this.presignedUrlProvider.getPresignedUrl(job.getImageAssetId());
        if (null == patientDTO) {
            throw new SendImageException("Unable to get Presigned URL for JOB: " + job.getJobId() + " for asset id:"
                    + job.getImageAssetId());
        }

        List<StudyDTO> studies = patientDTO.getStudies();
        // Get a Study
        if (null != studies && studies.size() > 0) {
            LOG.info("Getting study");
            studyDTO = studies.get(0);
        } else {
            throw new SendImageException("Unable to get Patient Details for JOB: " + job.getJobId() + " for asset id:"
                    + job.getImageAssetId());
        }
        // get Series
        List<SeriesDTO> seriesList = null;
        if (null != studyDTO) {
            LOG.info("Getting Serieses");
            seriesList = studyDTO.getSeries();
        } else {
            throw new SendImageException("Unable to get Study Details for JOB: " + job.getJobId() + " for asset id:"
                    + job.getImageAssetId());
        }
        if (null != seriesList && !seriesList.isEmpty()) {
            LOG.info("Getting seriesDTO");
            seriesDTO = seriesList.get(0);
        } else {
            throw new SendImageException("Unable to get Series Details for JOB: " + job.getJobId() + " for asset id:"
                    + job.getImageAssetId());
        }
        // get ImageDto
        List<ImageDTO> imageDTOs = null;
        if (null != seriesDTO) {
            imageDTOs = seriesDTO.getImages();
        } else {
            throw new SendImageException("Unable to get Series Details for JOB: " + job.getJobId() + " for asset id:"
                    + job.getImageAssetId());
        }
        if (null != imageDTOs && !imageDTOs.isEmpty()) {
            imageDTO = imageDTOs.get(0);
        }
        // Get Image URL
        if (null != imageDTO) {
            presignedUrl = imageDTO.getPreSignedUrl();
            LOG.info( "Image File Type: " + imageDTO.getFileType());
            fileNameExtension = CommonUtil.getFileNameExtension(imageDTO.getFileType(), fileNameExtension);
        } else {
            throw new SendImageException("Unable to get Image Details for JOB: " + job.getJobId() + " for asset id:"
                    + job.getImageAssetId());
        }
        LOG.info( "PRESIGNED URL: " + presignedUrl);
        if (StringUtils.isEmpty(presignedUrl)) {
            throw new SendImageException("Unable to get Presigned URL for JOB: " + job.getJobId() + " for asset id:"
                    + job.getImageAssetId());
        }
    }

    /**
     * @param imageFileName
     * @return
     * @throws IOException
     */
    private File createDcmFile(final String imageFileName) throws IOException {

        String dir = this.sendImageBaseDir + "/" + IdexxDicomServiceConstants.CONVERTED_IMAGES_DIR;
        CommonUtil.createDir(dir);

        File dcmFile = CommonUtil.createFile(dir,
                CommonUtil.getFileNameWithOutExtension(imageFileName) + "."
                        + IdexxDicomServiceConstants.DICOM_FILE_EXTENSION1);
        return dcmFile;
    }

    /**
     * @param imageFile
     * @return
     * @throws IOException 
     * 
     */
    private ImageProperties getImageProperties(final String imageFile, final String imageFileType) throws IOException  {
        ImagePropertiesProvider provider = new ImagePropertiesProviderImpl(imageFile, imageFileType);
        return provider.getImageProperties();
    }

    /**
     * @param job
     * @return If the DownloadedIMFilePath is not empty then the file is
     *         downloaed
     */
    private boolean isFileDownloaded(final SendImagePendingJobDTO job) {
        return !StringUtils.isEmpty(job.getDownloadedIMFilePath());
    }

    /**
     * @param job
     */
    private void sendImage(final SendImagePendingJobDTO job) throws SendImageException {
        try {
            LOG.info( "Sending Image: " + job.getDownloadedIMFilePath());
            this.sendImageService.sendImage(job);
            LOG.info( "Updating JOBS Status to Success for JOB:" + job.getJobId());
            this.jobUpdateService.updateJobStatusToSuccess(job.getJobId());
        } catch (SendImageException exp) {
            LOG.info( "Unable to send image.");
            LOG.error(exp.getLocalizedMessage(), exp);
            this.updateJobStatus(job.getJobId(), job.getRetriesCount(), exp.getLocalizedMessage());
            throw new SendImageException("Unable to Send ImageL for job:" + job.getJobId());
        }
    }

    /**
     * @param jobId
     * @param retryCount
     * @param message
     */
    private void updateJobStatus(final String jobId, final int retryCount, final String message) {
        if (this.canRetryTheJob(retryCount)) {
            this.jobUpdateService.updateJobStatusToPending(jobId, message);
        } else {
            this.jobUpdateService.updateJobStatusToFailed(jobId);
        }
    }

    /**
     * @param retryCount
     * @return
     */
    private boolean canRetryTheJob(final int retryCount) {
        return retryCount + 1 <= this.defaultRetryCount;
    }

    /**
     * @param jobRetryCount
     * @return
     */
    private boolean isRetryCountExceeded(final int jobRetryCount) {
        return jobRetryCount >= defaultRetryCount;

    }

    /**
     * @return
     */
    private int getRetryCount() {
        LOG.info( "Getting RETRY COUNT CONFIG VALUE");
        int defaultCount = SendImageJobConstants.DEFAULT_JOB_RETRY_COUNT;
        BaseDicomImPluginConfig config = configDao.getConfig(SendImageJobConstants.JOB_RETRY_COUNT_CONFIG_VALUE);

        String configValue = config.getConfigValue();
        if (!StringUtils.isEmpty(configValue)) {
            try {
                defaultCount = Integer.valueOf(configValue);
            } catch (NumberFormatException nfe) {
                defaultCount = SendImageJobConstants.DEFAULT_JOB_RETRY_COUNT;
            }
        }
        LOG.info( "RETRY COUNT CONFIG VALUE IS: " + defaultCount);
        return defaultCount;
    }
    
    private String getSendImageBaseDir() {
        LOG.info( "Getting Send Image Base CONFIG VALUE");
        String baseDir = SendImageJobConstants.SEND_IMAGE_DEFAULT_BASE_DIR;
        
        BaseDicomImPluginConfig config = configDao.getConfig(SendImageJobConstants.SEND_IMAGE_BASE_DIR_CONFIG_NAME);
        String configValue = config.getConfigValue();
        if (!StringUtils.isEmpty(configValue)) {
            baseDir = configValue;
        }
        return baseDir;
    }

    /**
     * @param jobId
     * @param reason
     */
    private void updateInProgressStatus(final String jobId, final String reason) {
        LOG.info( "UPDATING IN-PROGRESS STATUS");
        this.jobUpdateService.updateJobStatusToInProgress(jobId, reason);
    }

}
