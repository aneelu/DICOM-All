/**
 * 
 */
package com.idexx.dicom.conversion.impl;

import java.io.DataInputStream;

import javax.imageio.stream.ImageInputStream;

/**
 * @author vkandagatla
 * 
 */
public class ImageProperties {
    
    private int samplesPerPixel;
    private int height;
    private int width;
    private int bitsAllocated;
    private int imageLength;
    private DataInputStream imagePixelData;
    private ImageInputStream imageInputStream;
    
    /**
     * @param samplesPerPixel
     * @param height
     * @param width
     * @param bitsAllocated
     * @param imageLength
     * @param imagePixelData
     */
    public ImageProperties(final int samplesPerPixel, final int height, final int width, final int bitsAllocated, final int imageLength,
            final DataInputStream imagePixelData, final ImageInputStream imageInputStream) {
        super();
        this.samplesPerPixel = samplesPerPixel;
        this.height = height;
        this.width = width;
        this.bitsAllocated = bitsAllocated;
        this.imageLength = imageLength;
        this.imagePixelData = imagePixelData;
        this.imageInputStream = imageInputStream;
    }
    
    /**
     * @return the samplesPerPixel
     */
    public final int getSamplesPerPixel() {
        return samplesPerPixel;
    }
    
    /**
     * @return the hieght
     */
    public final int getHeight() {
        return height;
    }
    
    /**
     * @return the width
     */
    public final int getWidth() {
        return width;
    }
    
    /**
     * @return the bitsAllocated
     */
    public final int getBitsAllocated() {
        return bitsAllocated;
    }
    
    /**
     * @return the imageLength
     */
    public final int getImageLength() {
        return imageLength;
    }
    
    /**
     * @return the imagePixelData
     */
    public final DataInputStream getImagePixelData() {
        return imagePixelData;
    }

    /**
     * @return the imageInputStream
     */
    public final ImageInputStream getImageInputStream() {
        return imageInputStream;
    }

    /*
     * @see java.lang.Object#toString()
     */
    @Override
    public final String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("ImageProperties [getSamplesPerPixel()=");
        builder.append(getSamplesPerPixel());
        builder.append(", getHeight()=");
        builder.append(getHeight());
        builder.append(", getWidth()=");
        builder.append(getWidth());
        builder.append(", getBitsAllocated()=");
        builder.append(getBitsAllocated());
        builder.append(", getImageLength()=");
        builder.append(getImageLength());
        builder.append("]");
        return builder.toString();
    }
}
