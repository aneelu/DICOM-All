/**
 *
 */
package com.idexx.dicom.services.requestservice.dto;

import java.util.List;

import com.idexx.imaging.imagemanager.soap.ClientDTO;
import com.idexx.imaging.imagemanager.soap.ExternalPatientIdDTO;

/**
 * @author smallela
 * @version 1.3
 */
public class GetOpenRequestDTO {

	private String modality;
	private String requestingDoctor;
	private String requestNotes;
	private String accessionNumber;
	private String studyInstanceUID;;
	private String status;
	private String id;
	private String patientName;
	private String applicationPatientId;
	private String clientFirstName;
	private String clientLastName;
	private String breed;
	private String species;
	private String dob;
	private String clinicId;
	private Integer activeFlag;
	private String edhdNumber;
	private String gender;
	private List<String> studies;
	private List<ExternalPatientIdDTO> externalPatientIds;
	private Integer weight;
	private String weightUnit;
	private List<ClientDTO> owners;
	private String lastModifiedDate;

	/**
	 * @return the modality
	 */
	public String getModality() {
		return modality;
	}

	/**
	 * @param modality
	 *            the modality to set
	 */
	public void setModality(String modality) {
		this.modality = modality;
	}

	/**
	 * @return the requestingDoctor
	 */
	public String getRequestingDoctor() {
		return requestingDoctor;
	}

	/**
	 * @param requestingDoctor
	 *            the requestingDoctor to set
	 */
	public void setRequestingDoctor(String requestingDoctor) {
		this.requestingDoctor = requestingDoctor;
	}

	/**
	 * @return the requestNotes
	 */
	public String getRequestNotes() {
		return requestNotes;
	}

	/**
	 * @param requestNotes
	 *            the requestNotes to set
	 */
	public void setRequestNotes(String requestNotes) {
		this.requestNotes = requestNotes;
	}

	/**
	 * @return the accessionNumber
	 */
	public String getAccessionNumber() {
		return accessionNumber;
	}

	/**
	 * @param accessionNumber
	 *            the accessionNumber to set
	 */
	public void setAccessionNumber(String accessionNumber) {
		this.accessionNumber = accessionNumber;
	}

	/**
	 * @return the studyInstanceUID
	 */
	public String getStudyInstanceUID() {
		return studyInstanceUID;
	}

	/**
	 * @param studyInstanceUID
	 *            the studyInstanceUID to set
	 */
	public void setStudyInstanceUID(String studyInstanceUID) {
		this.studyInstanceUID = studyInstanceUID;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the patientName
	 */
	public String getPatientName() {
		return patientName;
	}

	/**
	 * @param patientName
	 *            the patientName to set
	 */
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	/**
	 * @return the applicationPatientId
	 */
	public String getApplicationPatientId() {
		return applicationPatientId;
	}

	/**
	 * @param applicationPatientId
	 *            the applicationPatientId to set
	 */
	public void setApplicationPatientId(String applicationPatientId) {
		this.applicationPatientId = applicationPatientId;
	}

	/**
	 * @return the clientFirstName
	 */
	public String getClientFirstName() {
		return clientFirstName;
	}

	/**
	 * @param clientFirstName
	 *            the clientFirstName to set
	 */
	public void setClientFirstName(String clientFirstName) {
		this.clientFirstName = clientFirstName;
	}

	/**
	 * @return the clientLastName
	 */
	public String getClientLastName() {
		return clientLastName;
	}

	/**
	 * @param clientLastName
	 *            the clientLastName to set
	 */
	public void setClientLastName(String clientLastName) {
		this.clientLastName = clientLastName;
	}

	/**
	 * @return the breed
	 */
	public String getBreed() {
		return breed;
	}

	/**
	 * @param breed
	 *            the breed to set
	 */
	public void setBreed(String breed) {
		this.breed = breed;
	}

	/**
	 * @return the species
	 */
	public String getSpecies() {
		return species;
	}

	/**
	 * @param species
	 *            the species to set
	 */
	public void setSpecies(String species) {
		this.species = species;
	}

	/**
	 * @return the dob
	 */
	public String getDob() {
		return dob;
	}

	/**
	 * @param dob
	 *            the dob to set
	 */
	public void setDob(String dob) {
		this.dob = dob;
	}

	/**
	 * @return the clinicId
	 */
	public String getClinicId() {
		return clinicId;
	}

	/**
	 * @param clinicId
	 *            the clinicId to set
	 */
	public void setClinicId(String clinicId) {
		this.clinicId = clinicId;
	}

	/**
	 * @return the activeFlag
	 */
	public Integer getActiveFlag() {
		return activeFlag;
	}

	/**
	 * @param activeFlag
	 *            the activeFlag to set
	 */
	public void setActiveFlag(Integer activeFlag) {
		this.activeFlag = activeFlag;
	}

	/**
	 * @return the edhdNumber
	 */
	public String getEdhdNumber() {
		return edhdNumber;
	}

	/**
	 * @param edhdNumber
	 *            the edhdNumber to set
	 */
	public void setEdhdNumber(String edhdNumber) {
		this.edhdNumber = edhdNumber;
	}

	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * @param gender
	 *            the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * @return the studies
	 */
	public List<String> getStudies() {
		return studies;
	}

	/**
	 * @param studies
	 *            the studies to set
	 */
	public void setStudies(List<String> studies) {
		this.studies = studies;
	}

	/**
	 * @return the externalPatientIds
	 */
	public List<ExternalPatientIdDTO> getExternalPatientIds() {
		return externalPatientIds;
	}

	/**
	 * @param externalPatientIds
	 *            the externalPatientIds to set
	 */
	public void setExternalPatientIds(List<ExternalPatientIdDTO> externalPatientIds) {
		this.externalPatientIds = externalPatientIds;
	}

	/**
	 * @return the weight
	 */
	public Integer getWeight() {
		return weight;
	}

	/**
	 * @param weight
	 *            the weight to set
	 */
	public void setWeight(Integer weight) {
		this.weight = weight;
	}

	/**
	 * @return the weightUnit
	 */
	public String getWeightUnit() {
		return weightUnit;
	}

	/**
	 * @param weightUnit
	 *            the weightUnit to set
	 */
	public void setWeightUnit(String weightUnit) {
		this.weightUnit = weightUnit;
	}

	/**
	 * @return the owners
	 */
	public List<ClientDTO> getOwners() {
		return owners;
	}

	/**
	 * @param owners
	 *            the owners to set
	 */
	public void setOwners(List<ClientDTO> owners) {
		this.owners = owners;
	}

	/**
	 * @return the lastModifiedDate
	 */
	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	/**
	 * @param lastModifiedDate
	 *            the lastModifiedDate to set
	 */
	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

}
