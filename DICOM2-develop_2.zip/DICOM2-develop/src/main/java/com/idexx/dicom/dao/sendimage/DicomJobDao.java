/**
 * Provides Jobs from Database for Dicom Send
 */
package com.idexx.dicom.dao.sendimage;

import java.util.List;

import com.idexx.dicom.ae.entities.IdexxSendImageJob;

/**
 * @author vkandagatla
 * 
 */
public interface DicomJobDao {
    String PENDING_STATUS_PARAM_NAME = "PENDING_STATUS";
    String PENDING_STATUS_PARAM_NAME1 = "PENDING_STATUS1";
    String PENDING_JOB_STATUS = "PENDING";
    String PENDING_JOB_STATUS1 = "IN PROGRESS";
    String JOB_ID_PARAM = "JOB_ID";
    String PENDING_JOB_QUERY = "SELECT JOB FROM IdexxSendImageJob JOB WHERE JOB.jobStatus=:"
            + PENDING_STATUS_PARAM_NAME;

    String INPROGRESS_JOB_QUERY = "SELECT JOB FROM IdexxSendImageJob JOB WHERE JOB.jobStatus='" + PENDING_JOB_STATUS1
            + "'";
    String JOB_QUERY_BY_JOB_ID = "SELECT JOB FROM IdexxSendImageJob JOB WHERE JOB.jobId = :" + JOB_ID_PARAM;

    String JOB_UPDATE_QUERY = "update IdexxSendImageJob JOB set JOB.jobStatus=:" + PENDING_STATUS_PARAM_NAME
            + " where JOB.jobStatus=:" + PENDING_STATUS_PARAM_NAME1;

    /**
     * @return Retrieves only Pending Jobs
     */
    List<IdexxSendImageJob> getPendingJobs();

    /**
     * @param jobId
     * @return Get the IdexxSendImageJob from DB with jobId
     */
    IdexxSendImageJob getJobByJobId(String jobId);

    /**
     * @param job
     *            Update any IdexxSendImageJob
     */
    void updateJob(IdexxSendImageJob job);

    /**
     * updates all Inprogress jobs to pending status
     */
    void updateAllInProgressJobs();
}
