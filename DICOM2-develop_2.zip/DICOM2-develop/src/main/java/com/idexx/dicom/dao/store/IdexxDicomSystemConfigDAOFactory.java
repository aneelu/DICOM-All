/**
 * 
 */
package com.idexx.dicom.dao.store;

/**
 * @author vkandagatla
 *
 */
public interface IdexxDicomSystemConfigDAOFactory {
    SystemConfigDao create();
    SystemConfigDao create(String context);
}
