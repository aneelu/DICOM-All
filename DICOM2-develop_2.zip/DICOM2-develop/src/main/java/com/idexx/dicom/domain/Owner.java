package com.idexx.dicom.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@Table(name = "OWNER")
@IdClass(OwnerPK.class)
public class Owner {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

    @Id
	@Column(name="PATIENT_ID")
	private String patientID;

    @Id
	@Column(name="CLIENT_ID")
	private String clientID;

	@Column(name="PRIMARY_OWNER")
	private String primaryOwner;

	/**
	 * @return the patientId
	 */
	public String getPatientID() {
		return patientID;
	}

	/**
	 * @param patientId the patientId to set
	 */
	public void setPatientID(String patientID) {
		this.patientID = patientID;
	}

	/**
	 * @return the clientId
	 */
	public String getClientID() {
		return clientID;
	}

	/**
	 * @param clientId the clientId to set
	 */
	public void setClientID(String clientID) {
		this.clientID = clientID;
	}

	/**
	 * @return the primaryOwner
	 */
	public String getPrimaryOwner() {
		return primaryOwner;
	}

	/**
	 * @param primaryOwner the primaryOwner to set
	 */
	public void setPrimaryOwner(String primaryOwner) {
		this.primaryOwner = primaryOwner;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
