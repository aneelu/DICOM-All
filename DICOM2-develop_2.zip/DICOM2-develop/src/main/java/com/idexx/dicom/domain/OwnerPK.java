package com.idexx.dicom.domain;

import java.io.Serializable;

public class OwnerPK implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8309348941044119762L;
	protected String patientID;
    protected String clientID;
    public OwnerPK() {}
    public OwnerPK(String patientID, String clientID) {
    	this.patientID = patientID;
    	this.clientID = clientID;
    }
}
