/**
 * Code Re factored as per the comments from the client. 12-Jun-2013
 */
package com.idexx.dicom.sendimage.impl;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.idexx.dicom.sendimage.SendImage;
import com.idexx.dicom.services.sendimage.dto.SendImagePendingJobDTO;

/**
 * @author rmalla
 * 
 */
@Service
public final class SendImageImpl implements SendImage {
    private Logger logger = Logger.getLogger(SendImageImpl.class);

    /**
     * Send Image to the Destination AE
     * 
     * @param SendImagePendingJobDTO
     *            Pending Job
     */
    public void sendImage(final SendImagePendingJobDTO dto) throws SendImageException {
    	
    }

}
