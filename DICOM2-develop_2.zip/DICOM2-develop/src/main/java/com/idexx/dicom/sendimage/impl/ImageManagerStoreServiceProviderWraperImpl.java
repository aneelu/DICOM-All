/**
 * 
 */
package com.idexx.dicom.sendimage.impl;

import static com.idexx.dicom.sendimage.SendImageJobConstants.DEFAULT_IMG_MGR_URL;
import static com.idexx.dicom.sendimage.SendImageJobConstants.IMAGE_MGR_CONFIG_NAME;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ImageManagerStoreServiceProvider;
import com.idexx.dicom.ImageManagerStoreServiceProviderImpl;
import com.idexx.dicom.ae.entities.BaseDicomImPluginConfig;
import com.idexx.dicom.dao.ws.DicomConfigDao;
import com.idexx.dicom.sendimage.ImageManagerStoreServiceProviderWraper;
import com.idexx.dicom.sendimage.SendImageJobConstants;
import com.idexx.imaging.imagemanager.soap.IDEXXImageManagerServices;

/**
 * @author vkandagatla
 * 
 */
@Service
public class ImageManagerStoreServiceProviderWraperImpl implements ImageManagerStoreServiceProviderWraper {
	
	private static final Logger LOG = Logger.getLogger(ImageManagerStoreServiceProviderWraperImpl.class);
	
    @Autowired
    private DicomConfigDao configDao;

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.sendimage.ImageManageStoreServiceProviderWraper#getService
     * ()
     */
    @Override
    public IDEXXImageManagerServices getService()  {
        String imageManagerStoreURL = getDefaultStringConfigValue(IMAGE_MGR_CONFIG_NAME, DEFAULT_IMG_MGR_URL);
        ImageManagerStoreServiceProvider storeProvider = new ImageManagerStoreServiceProviderImpl(imageManagerStoreURL,
                SendImageJobConstants.STORE_CONNECTION_TIME_OUT);
        return storeProvider.getService();
    }

    /**
     * @return
     */
    private String getDefaultStringConfigValue(final String key, final String defaultValue) {
        LOG.info( "Getting " + key + " CONFIG VALUE");
        String defaultVal = defaultValue;
        BaseDicomImPluginConfig config = configDao.getConfig(key);

        String configValue = config.getConfigValue();
        if (!StringUtils.isEmpty(configValue)) {
            defaultVal = configValue;
        }
        LOG.info( "RESULT CONFIG VALUE FOR KEY: " + key + " IS: " + defaultVal);
        return defaultVal;
    }
}
