package com.idexx.dicom.store;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.idexx.dicom.ae.entities.AssumedIssuer;
import com.idexx.dicom.dao.ws.AssumedIssuerDao;
import com.idexx.dicom.dto.IdexxAuthorizationObject;
import com.idexx.dicom.store.authorization.IdexxAuthorization;
import com.idexx.dicom.store.authorization.impl.IdexxDicomAuthorizationHandlerImpl;
import com.idexx.dicom.store.authorization.impl.IdexxDicomErrorHandlerImpl;
import com.idexx.dicom.util.CommonUtil;
import com.idexx.imaging.imagemanager.soap.Exception_Exception;
import com.idexx.imaging.imagemanager.soap.ExternalPatientIdDTO;
import com.idexx.imaging.imagemanager.soap.IDEXXImageManagerServices;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;
import com.idexx.imaging.imagemanager.soap.ImageDTO;
import com.idexx.imaging.imagemanager.soap.PatientDTO;
import com.idexx.imaging.imagemanager.soap.SeriesDTO;
import com.idexx.imaging.imagemanager.soap.StoreImageMetaDataDTO;
import com.idexx.imaging.imagemanager.soap.StudyDTO;
import com.idexx.imaging.imagemanager.soap.UploadImageDTO;

@Service
public class DicomStoreServiceWithMetadataExtraction {
	
	private static Logger LOG = Logger.getLogger(DicomStoreServiceWithMetadataExtraction.class);
    
    @Autowired
    IdexxDicomAuthorizationHandlerImpl idexxDicomAuthorizationHandler;
    
    @Autowired
    AtributeExtractorIntegrator integrator;
    
    @Autowired
    AssumedIssuerDao assumedIssuerDao;
     
    @Autowired
    IdexxDicomErrorHandlerImpl idexxDicomErrorHandlerImpl;

    private final String contentType;
    private final String fileType;
    private final String genThumbNail;
    private String hostAddress;
    private String hostName;
    private String manufacturer;
    private String manufacturerModelName;
    private String modality;
    private String patientName;
    private String responsiblePerson;

    private final String defaultSOPInstanceId = "1.2.826.0.1.300003.2.950.9X999.20100923094143.14.1";
    private final String unKnownValue = "Unknown";
    
    private ImageDTO imageDTO;

    private IDEXXImageManagerServices imageManagerServices;
  
    public DicomStoreServiceWithMetadataExtraction(final String contentType, final String fileType,
            final String genThumbNail, final IDEXXImageManagerServices imageManagerServiceStoreHandler) {
        this.contentType = contentType;
        this.fileType = fileType;
        this.genThumbNail = genThumbNail;
        this.imageManagerServices = imageManagerServiceStoreHandler;
        
    }
    
    public DicomStoreServiceWithMetadataExtraction(){
	    this.contentType = "";
	    this.fileType = "";
	    this.genThumbNail = "";
    }

    public IdexxAuthorization getAuthorization(final Attributes ds, final String callingAet, final String hostAddr,
            final String hostName) {

        IdexxAuthorization authorization = authorizeAE(ds, callingAet, hostName, hostAddr);
        this.hostAddress = hostAddr;
        this.hostName = hostName;
        return authorization;

    }

   
    public IdexxAuthorization authorizeAE(final Attributes ds, final String callingAet, final String hostName,
            final String hostAddr) {
        LOG.info("Performing Authorization. Getting dataset values for Authorization");
        
        String aeTitle = callingAet;        
        String instituteName = ds.getString(Tag.InstitutionName);
        String manufacturer = ds.getString(Tag.Manufacturer);
        String manufacturerModelName = ds.getString(Tag.ManufacturerModelName);
        String modality = ds.getString(Tag.Modality);
        String patientName = ds.getString(Tag.PatientName);
        
        LOG.info("aeTitle: " + aeTitle);
        LOG.info("instituteName: " + instituteName);
        LOG.info("manufacturer: " + manufacturer);
        LOG.info("manufacturerModelName: " + manufacturerModelName);
        LOG.info("modality: " + modality);
        LOG.info("patientName: " + patientName);
        

        IdexxAuthorization idexxAutorization = idexxDicomAuthorizationHandler.performaAuthorization(aeTitle, instituteName,
                hostAddr, hostName, manufacturer, manufacturerModelName, modality, patientName, "  ");
        return idexxAutorization;

    }
    
    
    public String callStoreImgMetaDataService(final Attributes ds,
            final IdexxAuthorizationObject idexxAuthorizationObject, final String callingAet,  Map<String, Object> props)
            throws IdexxServiceException_Exception {

        String imageAssetId = "";
        try {
            Map<String, String> imageManagerAttributes = integrator.createExtractor().extractDcmElements(ds);
            StoreImageMetaDataDTO imageStoreReqDTO = new StoreImageMetaDataDTO();
            imageDTO = CommonUtil.createImageDTO(imageManagerAttributes, contentType, fileType, defaultSOPInstanceId);
            this.manufacturer = ds.getString(Tag.Manufacturer);
            this.manufacturerModelName = ds.getString(Tag.ManufacturerModelName);
            this.modality = ds.getString(Tag.Modality);
            this.patientName = ds.getString(Tag.PatientName);
            this.responsiblePerson = ds.getString(Tag.ResponsiblePerson);            
            /*imageDTO.setModality(modality);
            imageDTO.setManufacturerModel(manufacturerModelName);
            imageDTO.setManufacturer(manufacturer);*/
            imageDTO.setFileType((String) props.get("fileType"));
            imageStoreReqDTO.setImage(imageDTO);
            imageStoreReqDTO.setApiKey(idexxAuthorizationObject.getApiKey());
            
            imageStoreReqDTO.setClinicId(idexxAuthorizationObject.getSapId());
            PatientDTO patientDTO = createPatientDTOAndUpdateMetadata(ds, imageManagerAttributes);
            
            boolean useDicomServicesAssumedIssuer = true;
            Attributes dcmElement = ds.getNestedDataset(Tag.OtherPatientIDsSequence);
            if (null != dcmElement && dcmElement.size() > 0) {
                for(int i =0 ; i < dcmElement.size(); i++) {
                    useDicomServicesAssumedIssuer = false;
                    ExternalPatientIdDTO epiDto = new ExternalPatientIdDTO();                    
                    epiDto.setPimsPatientId(ds.getString(Tag.PatientID));
                    epiDto.setIssuerOfPatientId(ds.getString(Tag.IssuerOfPatientID));
                    patientDTO.getExternalPatientIds().add(epiDto);
                    LOG.info("Tags.OtherPatientIDSeq Patient ID: " + epiDto.getPimsPatientId()
                              + "  -  Issuer Of Patient ID: " + epiDto.getIssuerOfPatientId());
                }
            }
            if (useDicomServicesAssumedIssuer) {
                String assumedIssuer = getAssumedIssuer(idexxAuthorizationObject.getSapId());
                if (!StringUtils.isEmpty(assumedIssuer)) {
                    ExternalPatientIdDTO epiDto = new ExternalPatientIdDTO();
                    epiDto.setPimsPatientId(ds.getString(Tag.PatientID));
                    epiDto.setIssuerOfPatientId(assumedIssuer);
                    patientDTO.getExternalPatientIds().add(epiDto);
                    LOG.info("Assumed Issuer Patient ID: " + epiDto.getPimsPatientId()
                            + "  -  Assumed Issuer: " + epiDto.getIssuerOfPatientId());
                }
            }
            imageStoreReqDTO.setPatient(patientDTO);

            StudyDTO studyDTO = createStudyDTOAndUpdateMetadata(ds, imageManagerAttributes);
            imageStoreReqDTO.setStudy(studyDTO);

            SeriesDTO seriesDTO = createSeriesDTOAndUpdateMetadata(ds, imageManagerAttributes);
            imageStoreReqDTO.setSeries(seriesDTO);
            long startTime = System.currentTimeMillis();
            imageManagerServices = (IDEXXImageManagerServices) props.get("imageManagerServiceStoreHandler");
            imageAssetId = imageManagerServices.storeImageMetaData(imageStoreReqDTO);
            LOG.info("callStoreImgMetaDataService ->Start Time Millis:  " + startTime
                    + "  total time " + (System.currentTimeMillis() - startTime));

            LOG.info("Store Image Meta Data Response imageAssetId : " + imageAssetId);            
        } catch (IdexxServiceException_Exception exp) {
            LOG.error("DicomStoreServiceWithMetadataExtractionImpl : Image Manager Response Exception : "
                    + exp.getMessage());                     

            idexxDicomErrorHandlerImpl.storeErrorLogs(idexxAuthorizationObject.getAeTitle(),
                    idexxAuthorizationObject.getInstituteName(),
                    hostAddress, hostName, this.manufacturer,this.manufacturerModelName, 
                    this.modality, this.patientName, this.responsiblePerson);
            throw exp;

        }
        return imageAssetId;           
    }

    private String getAssumedIssuer(final String sapId) {
        String assumedIssuerValue = "";
        List<AssumedIssuer> assumedIssuerList = assumedIssuerDao.findAssumedIssuerBySapId(sapId);
        if (null != assumedIssuerList && assumedIssuerList.size() > 0) {
            AssumedIssuer assumedIssuer = assumedIssuerList.get(0);
            if (assumedIssuer != null) {
                assumedIssuerValue = assumedIssuer.getAssumedIssuerValue();
            }
        }
        return assumedIssuerValue;
    }
    
    /**
     * 
     * @param ds
     * @param imageManagerAttributes
     * @return PatientDTO after setting metadata attributes
     * @throws java.text.ParseException 
     */
    protected PatientDTO createPatientDTOAndUpdateMetadata(final Attributes ds,
            final Map<String, String> imageManagerAttributes) {

        PatientDTO patientDTO = new PatientDTO();

        String perName = imageManagerAttributes.get("PatientDTO.clientFirstName");
        String tempValue = imageManagerAttributes.get("PatientDTO.patientName");
        LOG.info("perName: " + perName);
        String firstName = CommonUtil.extractPatientFirstName(perName, this.unKnownValue), lastName = CommonUtil
                .extractPatientLastName(perName, tempValue, this.unKnownValue);

        patientDTO.setClientFirstName(firstName);
        patientDTO.setClientLastName(lastName);

        tempValue = CommonUtil.extractPatientFirstName(tempValue, this.unKnownValue);
        LOG.info("ClientFirstName: " + firstName + " ClientLastName " + lastName + " tempValue " + tempValue);

        patientDTO.setPatientName(tempValue);

        // Last name LOGic

        tempValue = imageManagerAttributes.get("PatientDTO.patientId");
        if (tempValue != null && !tempValue.trim().equals("")) {
            patientDTO.setApplicationPatientId(tempValue);
            LOG.info("PatientID: " + tempValue);
        }

        tempValue = imageManagerAttributes.get("PatientDTO.gender");
        if (tempValue != null) {
            patientDTO.setGender(tempValue);
            LOG.info("patientGender: " + tempValue);

        }

        tempValue = imageManagerAttributes.get("PatientDTO.species");
        if (tempValue != null) {
            patientDTO.setSpecies(tempValue);
            LOG.info("patientSpecies : " + tempValue);

        }
        tempValue = imageManagerAttributes.get("PatientDTO.breed");
        if (tempValue != null) {
            patientDTO.setBreed(tempValue);
            LOG.info("patientBreed: " + tempValue);

        }
        // patientBirthDate
        SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyyMMdd HHmmss");
        GregorianCalendar gc = new GregorianCalendar();
        sDateFormat.setCalendar(gc);
        try {
            tempValue = imageManagerAttributes.get("PatientDTO.dob");
            if (tempValue != null && !tempValue.trim().equals("") && !tempValue.startsWith("null")) {
                try {
                    Date nDate = sDateFormat.parse(tempValue);
                    gc.setTime(nDate);
                    patientDTO.setDob(DatatypeFactory.newInstance().newXMLGregorianCalendar(gc));
                    LOG.info("PatientDTO.dob: " + tempValue);
                } catch (ParseException pe) {
                    gc.setTime(new Date());
                    LOG.error(" PatientDTO.dob : ParseException " + pe.getMessage(), pe);
                    patientDTO.setDob(DatatypeFactory.newInstance().newXMLGregorianCalendar(gc));
                }
            } else {
                patientDTO.setDob(DatatypeFactory.newInstance().newXMLGregorianCalendar(gc));

            }
        } catch (DatatypeConfigurationException dce) {
            LOG.error(" DatatypeConfigurationException " + dce.getMessage(), dce);
        }

        return patientDTO;

    }
    
    /**
     * 
     * @param ds
     * @param imageManagerAttributes
     * @return
     */
    private SeriesDTO createSeriesDTOAndUpdateMetadata(final Attributes ds,
            final Map<String, String> imageManagerAttributes) {
        SeriesDTO seriesDTO = new SeriesDTO();
        String seriesTempVal = imageManagerAttributes.get("SeriesDTO.dicomModality");
        if (seriesTempVal != null) {
            seriesDTO.setDicomModality(seriesTempVal);
            LOG.info("modality: " + seriesTempVal);
        }       

        seriesTempVal = imageManagerAttributes.get("SeriesDTO.seriesInstanceUID");
        if (seriesTempVal != null) {
            seriesDTO.setSeriesInstanceUid(seriesTempVal);
            LOG.info("SeriesInstanceUID: " + seriesTempVal);
        }
        
        seriesTempVal = imageManagerAttributes.get("SeriesDTO.SeriesDescription");
        LOG.info("SeriesTitle: " + seriesTempVal);
        if (seriesTempVal != null) {
            seriesDTO.setSeriesTitle(seriesTempVal);
            LOG.info("SeriesDescription: " + seriesTempVal);
        }
        

        return seriesDTO;

    }
    
    /**
     * 
     * @param ds
     * @param imageManagerAttributes
     * @return
     */

    private StudyDTO createStudyDTOAndUpdateMetadata(final Attributes ds, final Map<String, String> imageManagerAttributes) {

        SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyyMMdd HHmmss");
        GregorianCalendar gc = new GregorianCalendar();
        sDateFormat.setCalendar(gc);
        String studyTempValue = "";
        StudyDTO studyDTO = new StudyDTO();
        try {
            studyTempValue = imageManagerAttributes.get("StudyDTO.studyDate");
            LOG.info("studyDate: " + studyTempValue);
            if (studyTempValue != null && !studyTempValue.trim().equals("")) {
                try {
                    Date nDate = sDateFormat.parse(studyTempValue);
                    gc.setTime(nDate);
                    studyDTO.setStudyDate(DatatypeFactory.newInstance().newXMLGregorianCalendar(gc));
                } catch (ParseException pe) {
                    LOG.error(" StudyDTO.studyDate : ParseException " + pe.getMessage(), pe);
                    gc.setTime(new Date());
                    studyDTO.setStudyDate(DatatypeFactory.newInstance().newXMLGregorianCalendar(gc));
                }
            } else {
                studyDTO.setStudyDate(DatatypeFactory.newInstance().newXMLGregorianCalendar(
                        (GregorianCalendar) sDateFormat.getCalendar()));

            }
        } catch (DatatypeConfigurationException dce) {
            LOG.error(" DatatypeConfigurationException " + dce.getMessage(), dce);
        }

        studyTempValue = imageManagerAttributes.get("StudyDTO.studyId");
        LOG.info("StudyDTO.studyId: " + studyTempValue);
        if (studyTempValue != null) {
            studyDTO.setStudyInstanceUid(studyTempValue);
            LOG.info("studyInstanceUID: " + studyTempValue);
        }

        studyTempValue = imageManagerAttributes.get("StudyDTO.ascessionNumber");
        if (studyTempValue != null) {
            studyDTO.setAscessionNumber(studyTempValue);
            LOG.info("accessionNumber: " + studyTempValue);
        }

        studyTempValue = imageManagerAttributes.get("StudyDTO.description");
        LOG.info("Study Title: " + studyTempValue);
        if (studyTempValue != null) {
            studyDTO.setDescription(studyTempValue);
            studyDTO.setStudyTitle(studyTempValue);
            LOG.info("studyDesc: " + studyTempValue);
        }       

        return studyDTO;
    }
    
    public String callStoreUploadImgService(final File file, final IdexxAuthorizationObject idexxAuthorizationObject,
            final String imageAssetId, final String fileName, Map<String, Object> props) throws IdexxServiceException_Exception {

        String rtnMsg = "";

        boolean generateThumbnail = false;
        if (genThumbNail.equals("true")) {
            generateThumbnail = Boolean.TRUE;
        }
        UploadImageDTO uploadImgReqDTO = new UploadImageDTO();
        uploadImgReqDTO.setGenerateThumbnail(generateThumbnail);
        uploadImgReqDTO.setGenerateThumbnail(true);

        uploadImgReqDTO.setApiKey(idexxAuthorizationObject.getApiKey());
        uploadImgReqDTO.setClinicId(idexxAuthorizationObject.getSapId());
        uploadImgReqDTO.setImageAssetId(imageAssetId);

        try {
            byte[] buffer = CommonUtil.readBytesFromFile(file);
            uploadImgReqDTO.setMd5Checksum(DigestUtils.md5Hex(buffer));
            imageDTO.setAssetSize(buffer.length);            
            imageDTO.setOriginalFileName(file.getName());            
            /*FileDataSource fileDataSource = new FileDataSource(file);
            DataHandler dataHandler = new DataHandler(fileDataSource);*/
            
            uploadImgReqDTO.setUploadfile(buffer);

        } catch (IOException exp) {
            LOG.error("File Reading failed: " + exp.getMessage(), exp);
            
            idexxDicomErrorHandlerImpl.uploadErrorLogs(idexxAuthorizationObject.getAeTitle(),
                    idexxAuthorizationObject.getInstituteName(),
                    hostAddress, hostName, this.manufacturer,this.manufacturerModelName, 
                    this.modality, this.patientName, this.responsiblePerson);
            throw new IdexxServiceException_Exception(exp.getMessage(), null);
        }
        try {
            long startTime = System.currentTimeMillis();
            imageManagerServices = (IDEXXImageManagerServices) props.get("imageManagerServiceStoreHandler");
            rtnMsg = imageManagerServices.uploadImage(uploadImgReqDTO);
            LOG.info("callStoreUploadImgService->Start Time Millis:  " + startTime
                    + "  total time " + (System.currentTimeMillis() - startTime));
            LOG.info("Dicom Store Service Upload Image Response : " + rtnMsg);

        } catch (Exception_Exception e) {
            LOG.error("Image Manager Response Exception : " + e.getMessage(), e);
            throw new IdexxServiceException_Exception(e.getMessage(), null);
	}
        return rtnMsg;

    }

}
