/**
 * IDEXX DICOM Web services.
 * This Implementation provides following services:
 * 1. Create AE Title - Creates new AE Title with given parameters
 * 2. Delete AE Title - delete given AE Title
 * 3. Read AE Title - read list of AE Titles for given AE Title name, inistitute name and with other params
 * 4. Set Enable AE Title - update AE Title, as enable/disable
 * 5. Details of the authorization failure instances for Store image.
 * 6. Send Image to third party AE
 * 7. Get the status of the C-move job requested through SendImage service
 */
package com.idexx.dicom.services;

import java.util.List;

import javax.annotation.Resource;
import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.ws.BindingType;
import javax.xml.ws.WebServiceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.idexx.dicom.aeservices.impl.v13.AbstractAEServiceImpl;
import com.idexx.dicom.aeservices.impl.v13.AssumedIssuerServiceImpl;
import com.idexx.dicom.aeservices.impl.v13.CancelSendJobServiceImpl;
import com.idexx.dicom.aeservices.impl.v13.GetStoreFailuresService;
import com.idexx.dicom.aeservices.impl.v13.SendImageJobServiceImpl;
import com.idexx.dicom.aeservices.impl.v13.SendImageStatusServiceImpl;
import com.idexx.dicom.aeservices.impl.v13.StoreErrorLogServiceImpl;
import com.idexx.dicom.echo.v13.DicomEchoServiceImpl;
import com.idexx.dicom.services.dto.v13.AETitleDTO;
import com.idexx.dicom.services.dto.v13.AssumedIssuerEntityDTO;
import com.idexx.dicom.services.dto.v13.CreateAETitleDTO;
import com.idexx.dicom.services.dto.v13.EchoDTO;
import com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO;
import com.idexx.dicom.services.dto.v13.IdexxErrorLogParamDTO;
import com.idexx.dicom.services.dto.v13.IdexxFailureLogDTO;
import com.idexx.dicom.services.dto.v13.IdexxFailureLogParamDTO;
import com.idexx.dicom.services.dto.v13.ReadAETitleDTO;
import com.idexx.dicom.services.dto.v13.ReadAssumedIssuerDTO;
import com.idexx.dicom.services.dto.v13.SetAssumedIssuerDTO;
import com.idexx.dicom.services.dto.v13.SetEnabledAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v13.CancelSendJobParamDTO;
import com.idexx.dicom.services.sendimage.dto.v13.IdexxSendImageJobStatusDTO;
import com.idexx.dicom.services.sendimage.dto.v13.SendImageJobParamDTO;
import com.idexx.dicom.services.sendimage.dto.v13.SendImageStatusParamDTO;

/**
 * Dicom services soap interface for version 3
 * @author smallela
 * @version 1.3
 */
@WebService(targetNamespace = "http://idexx.services.dicom.idexx.com/", portName = "IdexxDicomAEConfigServiceImplPortV1_3", serviceName = "IdexxDicomAEConfigServicesV1_3")
// @BindingType(value = "http://schemas.xmlsoap.org/wsdl/soap/http?mtom=true")
@BindingType(javax.xml.ws.soap.SOAPBinding.SOAP12HTTP_BINDING)
@Service("IdexxDicomAEConfigServicesV1_3")
public class IdexxDicomAEConfigServicesV1_3 extends SpringBeanAutowiringSupport {

    @Resource
    private WebServiceContext wsContext;
    
    @Autowired
    @Qualifier("dicomEchoServiceImplV13")
    private DicomEchoServiceImpl dicomEchoService;

    @Autowired
    @Qualifier("assumedIssuerServiceV13")
    private AssumedIssuerServiceImpl assumedIssuerService;
    
    @Autowired
	@Qualifier("createAETitleServiceV13")
	private AbstractAEServiceImpl createService;

	@Autowired
	@Qualifier("deleteAETitleServiceV13")
	private AbstractAEServiceImpl deleteService;

	@Autowired
	@Qualifier("readAETitleServiceV13")
	private AbstractAEServiceImpl readService;

	@Autowired
	@Qualifier("setAETitleStatusServiceV13")
	private AbstractAEServiceImpl setEnabledAEService;
	
	@Autowired
    @Qualifier("cancelSendJobServiceImplV13")
    private CancelSendJobServiceImpl cancelSendJobService;
 
    @Autowired
	@Qualifier("getSendImageStatusServiceV13")
	private SendImageStatusServiceImpl sendImageStatusService;
    
    @Autowired
	@Qualifier("getStoreFailuresServiceV13")
	private GetStoreFailuresService getStoreFailuresService;
	
	@Autowired
	@Qualifier("storeErrorLogServiceV13")
	private StoreErrorLogServiceImpl getStoreErrorLog;
	
	@Autowired
	@Qualifier("getIdexxSendImageValidatorV13")
	private SendImageJobServiceImpl sendImageJobService;
	

    
    @WebMethod
    public String setAssumedIssuer(final SetAssumedIssuerDTO aiDTO) throws IdexxDicomAEConfigServiceException {
	return assumedIssuerService.setAssumedIssuer(aiDTO);
    }

    @WebMethod
    public AssumedIssuerEntityDTO readAssumedIssuer(final ReadAssumedIssuerDTO dto)
	    throws IdexxDicomAEConfigServiceException {
	return assumedIssuerService.readAssumedIssuer(dto);
    }
    
    
    /**
     * 
     * @param echoDTO
     * @return boolean
     * @throws IdexxDicomAEConfigServiceException
     * 
     */
    @WebMethod
    public boolean echo(final EchoDTO echoDTO) throws IdexxDicomAEConfigServiceException {
        boolean isEcho = Boolean.FALSE;
        try {
            if (!echoDTO.isEmpty()) 
            {
                isEcho = dicomEchoService.echo(echoDTO.getAeTitle(), echoDTO.getCalledAeTitle(), echoDTO.getHostName(), echoDTO.getPortNumber());    
            } 
            else 
            {
                isEcho = dicomEchoService.echo(echoDTO.getAeTitle(), echoDTO.getHostName(), echoDTO.getPortNumber());
            }            
        } catch (NumberFormatException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return isEcho;
    }
    
    /**
	 * <pre>Register the AE or Add DVMSpecialist to AE list</pre>
	 * @param aeDTO
	 * @throws IdexxDicomAEConfigServiceException
	 * 
	 */
	@WebMethod
	public void createAETitle(CreateAETitleDTO aeDTO)
			throws IdexxDicomAEConfigServiceException {
	    
		createService.performService(aeDTO);
	}

	
	/**
	 * <pre>Read the details of the registered AE</pre>
	 * @param aeTitle
	 * @return List<IdexxDicomApplicationEntityDTO>
	 * @throws IdexxDicomAEConfigServiceException
	 * 
	 */
	@WebMethod
	@Transactional
	public List<IdexxDicomApplicationEntityDTO> readAETitle(
			ReadAETitleDTO aeTitle)
			throws IdexxDicomAEConfigServiceException {
		readService.performService(aeTitle);		
		@SuppressWarnings("unchecked")
		List<IdexxDicomApplicationEntityDTO> dtos = (List<IdexxDicomApplicationEntityDTO>) readService.sendResponse();
		return dtos;
	}

	
	/**
	 * <pre>Delete the registered AE title</pre>
	 * @param aeTitle
	 * @throws IdexxDicomAEConfigServiceException
	 * 
	 */
	@WebMethod
	public void deleteAETitle(AETitleDTO aeTitle)
			throws IdexxDicomAEConfigServiceException {
		deleteService.performService(aeTitle);
	}

	/**
	 * <pre>Enable/Disable the registered AE</pre>
	 * @param aeTitle
	 * @throws IdexxDicomAEConfigServiceException
	 * 
	 */
	@WebMethod
	public void setEnableAETitle(SetEnabledAETitleDTO aeTitle)
			throws IdexxDicomAEConfigServiceException {
		setEnabledAEService.performService(aeTitle);
	}
	
	/**
	  * 
	  * @param dto
	  * @return
	  * @throws IdexxDicomAEConfigServiceException
	  */
	 @WebMethod
	 public String cancelSendJob(final CancelSendJobParamDTO dto) throws IdexxDicomAEConfigServiceException {
	        return cancelSendJobService.performService(dto);
	    }
	 
	 /**
	  * Get the status of the C-move job requested through SendImage service
	  * @param dto
	  * @return
	  * @throws IdexxDicomAEConfigServiceException
	  */
	 @WebMethod
	 public List<IdexxSendImageJobStatusDTO> getCMoveJobStatus(
				final SendImageStatusParamDTO dto)
				throws IdexxDicomAEConfigServiceException {
			List<IdexxSendImageJobStatusDTO> aeResponse = (List<IdexxSendImageJobStatusDTO>) sendImageStatusService
					.performService(dto);
			return aeResponse;
		}
	 
	 @WebMethod
		public List<IdexxFailureLogDTO> getFailures(
				final IdexxFailureLogParamDTO dto)
				throws IdexxDicomAEConfigServiceException {
			return getStoreFailuresService.performService(dto);
		}
		
		@WebMethod
		public List<IdexxFailureLogDTO> getFailureErrorLogs(
				final IdexxErrorLogParamDTO dto)
				throws IdexxDicomAEConfigServiceException {
			return getStoreErrorLog.performService(dto);
		}
		
		/**
		  * Request to send Image to third party AE 
		  * 
		  * @param dto
		  * @return
		  * @throws IdexxDicomAEConfigServiceException
		  */
		 @WebMethod
		 public String sendImage(final SendImageJobParamDTO dto)
				throws IdexxDicomAEConfigServiceException {
			return sendImageJobService.performService(dto);
		 } 
	
    
 }
