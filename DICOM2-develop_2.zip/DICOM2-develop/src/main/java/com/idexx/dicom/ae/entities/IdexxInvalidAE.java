/**
 * Entity for IDEXX Invalid AEs
 */
package com.idexx.dicom.ae.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author vkandagatla
 * 
 */
@Entity
@Table(name = "idx_invalid_ae")
public class IdexxInvalidAE implements Serializable {
    /**
     * Eclipse Generated
     */
    private static final long serialVersionUID = -6234298088504999106L;
    private String aeTitle;
    
    /**
     * @return the aeTitle
     */
    @Id
    @Column(name = "AETITLE")
    public String getAeTitle() {
        return aeTitle;
    }
    
    /**
     * @param aeTitle
     *            the aeTitle to set
     */
    public void setAeTitle(final String aeTitle) {
        this.aeTitle = aeTitle;
    }
    
}
