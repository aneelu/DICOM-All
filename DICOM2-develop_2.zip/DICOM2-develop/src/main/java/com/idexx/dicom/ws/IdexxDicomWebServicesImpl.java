package com.idexx.dicom.ws;

import javax.jws.WebService;

import org.springframework.stereotype.Service;

@Service("idexxDicomWebServicesImpl")
@WebService(endpointInterface = "com.idexx.dicom.ws.IdexxDicomWebServices")
public class IdexxDicomWebServicesImpl implements IdexxDicomWebServices {
}
