/**
 * 
 */
package com.idexx.dicom.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.idexx.dicom.domain.RequestDetails;

/**
 * @author vvanjarana
 *
 */
public interface RequestDetailsRepository extends IdexxRepository<RequestDetails, String> {

    RequestDetails save(RequestDetails reqDetails);

    List<RequestDetails> findByStudyInstanceUID(String studyInstanceUID);

    List<RequestDetails> findByStatus(String status);

    List<RequestDetails> findBySapIdAndStatus(String sapId, String status);

    List<RequestDetails> findOneByStudyInstanceUIDAndSapId(String studyInstanceUID, String sapId);

    @Query("Select RD from RequestDetails RD where RD.patientId = ?1 and RD.sapId = ?2 and RD.status <> 'MPPS_CANCEL'")
    List<RequestDetails> findByPatientIdAndSapId(String patientId, String sapId);

    @Query("Select RD from RequestDetails RD where RD.pimsIssuer = ?1 and RD.sapId = ?2 and RD.status <> 'MPPS_CANCEL'")
    List<RequestDetails> findByIssuerOfPatientIdAndSapId(String issuerOfPatientId, String sapId);

    @Query("Select RD from RequestDetails RD where RD.patientId = ?1 and RD.pimsIssuer = ?2 and RD.sapId = ?3 and RD.status <> 'MPPS_CANCEL'")
    List<RequestDetails> findByPatientIdIssuerOfPatientIdAndSapId(String patientId, String issuerOfPatientId,
	    String sapId);

    @Query("Select RD from RequestDetails RD where RD.sapId = ?1 and RD.status <> 'MPPS_CANCEL'")
    List<RequestDetails> findBySapId(String sapId);

}
