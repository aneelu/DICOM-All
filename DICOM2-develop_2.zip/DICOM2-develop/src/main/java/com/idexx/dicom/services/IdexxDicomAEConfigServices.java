package com.idexx.dicom.services;

import java.util.List;

import javax.annotation.Resource;
import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.ws.BindingType;
import javax.xml.ws.WebServiceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.idexx.dicom.aeservices.AEService;
import com.idexx.dicom.aeservices.GetStoreFailuresServiceIntf;
import com.idexx.dicom.aeservices.SendImageJobService;
import com.idexx.dicom.aeservices.SendImageStatusService;
import com.idexx.dicom.services.dto.AETitleDTO;
import com.idexx.dicom.services.dto.CreateAETitleDTO;
import com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO;
import com.idexx.dicom.services.dto.IdexxFailureLogDTO;
import com.idexx.dicom.services.dto.IdexxFailureLogParamDTO;
import com.idexx.dicom.services.dto.ReadAETitleDTO;
import com.idexx.dicom.services.dto.SetEnabledAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.IdexxSendImageJobStatusDTO;
import com.idexx.dicom.services.sendimage.dto.SendImageJobParamDTO;
import com.idexx.dicom.services.sendimage.dto.SendImageStatusParamDTO;

@WebService(targetNamespace = "http://idexx.services.dicom.idexx.com/", 
portName = "IdexxDicomAEConfigServiceImplPort", serviceName = "IdexxDicomAEConfigServices")
//@BindingType(value = "http://schemas.xmlsoap.org/wsdl/soap/http?mtom=true")
@BindingType(javax.xml.ws.soap.SOAPBinding.SOAP12HTTP_BINDING)
@Service("IdexxDicomAEConfigServices")
public class IdexxDicomAEConfigServices {

    @Resource
    private WebServiceContext wsContext;
    @Autowired
    @Qualifier("createAETitleService")
    private AEService createService;

    @Autowired
    @Qualifier("deleteAETitleService")
    private AEService deleteService;

    @Autowired
    @Qualifier("readAETitleService")
    private AEService readService;

    @Autowired
    @Qualifier("setAETitleStatusService")
    private AEService setEnabledAEService;

    @Autowired
    @Qualifier("getStoreFailuresService")
    private GetStoreFailuresServiceIntf getStoreFailuresService;

    @Autowired
    @Qualifier("getIdexxSendImageValidator")
    private SendImageJobService sendImageJobService;

    @Autowired
    @Qualifier("getSendImageStatusService")
    private SendImageStatusService sendImageStatusService;

    /**
     * Register the AE or Add DVMSpecialist to AE list
     * 
     * @param aeDTO
     * @throws IdexxDicomAEConfigServiceException
     */
    @WebMethod
    public final void createAETitle(final CreateAETitleDTO aeDTO) throws IdexxDicomAEConfigServiceException {

        createService.performService(aeDTO);
    }

    /**
     * Read the details of the registered AE
     * 
     * @param aeTitle
     * @return
     * @throws IdexxDicomAEConfigServiceException
     */
    @WebMethod
    public final List<IdexxDicomApplicationEntityDTO> readAETitle(final ReadAETitleDTO aeTitle)
            throws IdexxDicomAEConfigServiceException {

        readService.performService(aeTitle);
        @SuppressWarnings("unchecked")
        List<IdexxDicomApplicationEntityDTO> dtos = (List<IdexxDicomApplicationEntityDTO>) readService.sendResponse();

        return dtos;
    }

    /**
     * Delete the registered AE title
     * 
     * @Param aeTitle
     */
    @WebMethod
    public final void deleteAETitle(final AETitleDTO aeTitle) throws IdexxDicomAEConfigServiceException {
        deleteService.performService(aeTitle);
    }

    /**
     * Enable/Disable the registered AE
     * 
     * @param aeTitle
     * @throws IdexxDicomAEConfigServiceException
     */
    @WebMethod
    public final void setEnableAETitle(final SetEnabledAETitleDTO aeTitle) throws IdexxDicomAEConfigServiceException {
        setEnabledAEService.performService(aeTitle);
    }

    /**
     * Details of the authorization failure instances for Store image.
     * 
     * @param String
     *            ipAddress
     * @param Calendar
     *            startDate
     * @param Calendar
     *            endDate
     * @return List of AEAuthorizationFailureLogDTO
     */
    @WebMethod
    public final List<IdexxFailureLogDTO> getFailures(final IdexxFailureLogParamDTO dto)
            throws IdexxDicomAEConfigServiceException {
        return getStoreFailuresService.performService(dto);

    }

    /**
     * Request to send Image to third party AE
     * 
     * @param dto
     * @return
     * @throws IdexxDicomAEConfigServiceException
     */
    @WebMethod
    public final String sendImage(final SendImageJobParamDTO dto) throws IdexxDicomAEConfigServiceException {
        return sendImageJobService.performService(dto);
    }

    /**
     * Get the status of the C-move job requested through SendImage service
     * 
     * @param dto
     * @return
     * @throws IdexxDicomAEConfigServiceException
     */
    @WebMethod
    public final List<IdexxSendImageJobStatusDTO> getCMoveJobStatus(final SendImageStatusParamDTO dto)
            throws IdexxDicomAEConfigServiceException {
        List<IdexxSendImageJobStatusDTO> aeResponse = (List<IdexxSendImageJobStatusDTO>) sendImageStatusService
                .performService(dto);
        return aeResponse;
    }
}
