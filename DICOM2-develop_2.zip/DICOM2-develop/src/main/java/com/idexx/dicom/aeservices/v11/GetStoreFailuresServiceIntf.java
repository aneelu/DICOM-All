/**
 * 
 */
package com.idexx.dicom.aeservices.v11;

import java.util.List;

import com.idexx.dicom.services.dto.v11.IdexxFailureLogDTO;
import com.idexx.dicom.services.dto.v11.IdexxFailureLogParamDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * @author vkandagatla
 * 
 */
public interface GetStoreFailuresServiceIntf {
    List<IdexxFailureLogDTO> performService(IdexxFailureLogParamDTO dto) throws IdexxDicomAEConfigServiceException;

}
