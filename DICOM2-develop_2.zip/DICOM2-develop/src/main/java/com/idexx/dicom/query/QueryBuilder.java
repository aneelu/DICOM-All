package com.idexx.dicom.query;

public interface QueryBuilder {
	String getSelectQuery(String aeTitle, String instituteName, String errorType);
}
