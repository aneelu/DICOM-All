package com.idexx.dicom.aeservices.impl.v13;

import static org.junit.Assert.assertNotNull;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.idexx.dicom.ae.entities.AssumedIssuer;
import com.idexx.dicom.dao.ws.AssumedIssuerDao;
import com.idexx.dicom.services.dto.v13.AssumedIssuerEntityDTO;
import com.idexx.dicom.services.dto.v13.ReadAssumedIssuerDTO;
import com.idexx.dicom.services.dto.v13.SetAssumedIssuerDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * Test for AssumedIssuerServiceImpl using JMock
 * @author vvanjarana
 * @version 1.3
 */
public class AssumedIssuerServiceImplTest extends AbstractTestConfig {

    AssumedIssuerServiceImpl classToTest;
    
    public Mockery context = new JUnit4Mockery() {{
        setImposteriser(ClassImposteriser.INSTANCE);
    }};
    
    IdexxDicomWSAthorizationServiceImpl idexxDicomWsAuthorizeServiceMock = context.mock(IdexxDicomWSAthorizationServiceImpl.class);    
    AssumedIssuerDao assumedIssuerDao = context.mock(AssumedIssuerDao.class);
    
    SetAssumedIssuerDTO setAssumedIssuerDTO = new SetAssumedIssuerDTO(); 
    
    ReadAssumedIssuerDTO readAssumedIssuerDTO = new ReadAssumedIssuerDTO();
    
    AssumedIssuer assumedIssuer = new AssumedIssuer();
    List<AssumedIssuer> listAssumedIssuerList = new ArrayList<AssumedIssuer>();
    Timestamp ts = new Timestamp(System.currentTimeMillis());
    
    public static final String APIKEY = "apiKey";
    public static final String SAPID = "sapID";
    public static final String ASSUMED_VALUE = "CS";

    
    @Before
    public void setUp() throws Exception {
	readAssumedIssuerDTO.setApiKey(APIKEY);
	readAssumedIssuerDTO.setSapId(SAPID);
	
	assumedIssuer.setAssumedIssuerValue(ASSUMED_VALUE);
	assumedIssuer.setSapId(SAPID);
	assumedIssuer.setCreatedDateTime(ts);
	assumedIssuer.setLastUpdatedDateTime(ts);
	listAssumedIssuerList.add(assumedIssuer);
	
	setAssumedIssuerDTO.setApiKey(APIKEY);
	setAssumedIssuerDTO.setAssumedIssuerValue(ASSUMED_VALUE);
	setAssumedIssuerDTO.setSapId(SAPID);
	
	context.checking(new Expectations() {
	    {
		oneOf(idexxDicomWsAuthorizeServiceMock).authorize(APIKEY);
		will(returnValue(true));
		oneOf(assumedIssuerDao).findAssumedIssuerBySapId(SAPID);
		will(returnValue(listAssumedIssuerList));
		oneOf(assumedIssuerDao).updateAssumedIssuer(assumedIssuer);
		oneOf(assumedIssuerDao).createAssumedIssuer(assumedIssuer);
		
	    }
	});
	classToTest = new AssumedIssuerServiceImpl();
	ReflectionTestUtils.setField(classToTest, "idexxDicomWsAuthorizeService", idexxDicomWsAuthorizeServiceMock);
	ReflectionTestUtils.setField(classToTest, "assumedIssuerDao", assumedIssuerDao);
    }    
    
    @Test
    public final void test_for_readAssumedIssuer() throws IdexxDicomAEConfigServiceException {
	
	AssumedIssuerEntityDTO originalReadAssumedIssuerDTO = classToTest.readAssumedIssuer(readAssumedIssuerDTO);	
	assertNotNull(originalReadAssumedIssuerDTO.getAssumedIssuerValue());
    }
    
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public final void test_for_isValidSapId() throws IdexxDicomAEConfigServiceException {
	classToTest.isValidSapId("");
    }
    
    @Test
    public final void test_for_saveAssumedIssuer() throws IdexxDicomAEConfigServiceException {	
	String originalReadAssumedIssuerDTO = classToTest.setAssumedIssuer(setAssumedIssuerDTO);	
	assertNotNull(originalReadAssumedIssuerDTO);
    }
}
