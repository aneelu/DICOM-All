/**
 * 
 */
package com.idexx.dicom.aeservices.impl.v13;

import static org.junit.Assert.assertTrue;

import org.jmock.Expectations;
import org.jmock.auto.Mock;
import org.jmock.integration.junit4.JUnitRuleMockery;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.springframework.test.util.ReflectionTestUtils;

import com.idexx.dicom.ae.entities.IdexxAPIKey;
import com.idexx.dicom.aeservices.IdexxDicomWSAthorizationService;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * <pre>Requirements to test:
 *             Verifies if the given API Key is valid. If valid returns true.
 *             Also if the API Key is empty/invalid throws IdexxDicomAEConfigServiceException.
 *             If API KEY is missing in the request , the exception should contain the error code as
 *             AETitleValidator.MISSING_MANDATORY. If API KEY is not valid,
 *             the exception should contain the error code as INVALID_API_KEY.
 *             The API KEY Validation should check from idx_api_keys DATABASE Table</pre>
 * @author smallela
 * @version 1.3
 */

@RunWith(JUnit4.class)
public class IdexxDicomWSAthorizationServiceImplTest {
    @Rule
    public JUnitRuleMockery context = new JUnitRuleMockery();
    
    private static final String TEST_VALID_API_KEY_1 = "TEST_API_KEY_ONE";
    private static final String TEST_INVALID_API_KEY_1 = "TEST_API_KEY_TWO";
    
    @Mock
    private AETitleDao mockDao;
    
    private IdexxDicomWSAthorizationServiceImpl service;
    
    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {
        service = new IdexxDicomWSAthorizationServiceImpl();
        ReflectionTestUtils.setField(service, "aeTitleDao", mockDao);
        
    }
    
    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.IdexxDicomWSAthorizationServiceImpl#authorize(java.lang.String)}
     * .
     */
    @Test
    public void testAuthorize1() throws IdexxDicomAEConfigServiceException {
        final IdexxAPIKey apiKey = new IdexxAPIKey();
        context.checking(new Expectations() {
            {
                // Valid API Key
                oneOf(mockDao).getIdexxAPIKey(TEST_VALID_API_KEY_1);
                will(returnValue(apiKey));
            }
        });
        assertTrue("WS Authorization Failed", service.authorize(TEST_VALID_API_KEY_1));
    }
    
    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.IdexxDicomWSAthorizationServiceImpl#authorize(java.lang.String)}
     * . Test For Invalid API Key
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public void testAuthorize2() throws IdexxDicomAEConfigServiceException {
        context.checking(new Expectations() {
            {
                // Invalid API KEY
                oneOf(mockDao).getIdexxAPIKey(TEST_INVALID_API_KEY_1);
                will(returnValue(null));
            }
        });
        String errorCode = null;
        try {
            service.authorize(TEST_INVALID_API_KEY_1);
        } catch (IdexxDicomAEConfigServiceException exp) {
            errorCode = exp.getErrorCode();
            throw exp;
        }
        assertTrue("WS Authorization Failed", IdexxDicomWSAthorizationService.INVALID_API_KEY.equals(errorCode));
    }
    
    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.IdexxDicomWSAthorizationServiceImpl#authorize(java.lang.String)}
     * . Test for Empty API KEY
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public void testAuthorize3() throws IdexxDicomAEConfigServiceException {
        String errorCode = null;
        try {
            service.authorize("");
        } catch (IdexxDicomAEConfigServiceException exp) {
            errorCode = exp.getErrorCode();
            throw exp;
        }
        assertTrue("WS Authorization Failed", IdexxDicomWSAthorizationService.MISSING_MANDATORY.equals(errorCode));
    }
    
}
