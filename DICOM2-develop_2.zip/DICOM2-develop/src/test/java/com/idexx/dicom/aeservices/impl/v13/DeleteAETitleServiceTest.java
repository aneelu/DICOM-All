/**
 * 
 */
package com.idexx.dicom.aeservices.impl.v13;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.action.VoidAction;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.validator.impl.v13.AbstractAETitleValidator;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.dto.v13.AETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;


/**
 * <pre>Test Cases Related DeleteAETitleService</pre>
 * @author smallela
 * @version 1.3
 */

public class DeleteAETitleServiceTest {

    private DeleteAETitleService service;

    public Mockery context = new JUnit4Mockery() {{
        setImposteriser(ClassImposteriser.INSTANCE);
    }};
    
    AbstractAETitleValidator mockValidator = context.mock(AbstractAETitleValidator.class);    
    AETitleDao mockDao = context.mock(AETitleDao.class);
    IdexxDicomWSAthorizationServiceImpl idexxDicomWsAuthorizeService = context.mock(IdexxDicomWSAthorizationServiceImpl.class);
    
    
    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.DeleteAETitleService#validate(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public final void testValidate() throws IdexxDicomAEConfigServiceException {
        AETitleDTO dto = new AETitleDTO();
        dto.setAeTitle("Test1");
        dto.setInstituteName("Testing");
        context.checking(new Expectations() {
            {
                oneOf(mockValidator).validate(with(any(AETitleDTO.class)));
                will(returnValue(1));

            }
        });
        service = new DeleteAETitleService();
        ReflectionTestUtils.setField(service, "validator", mockValidator);
        int val = service.validate(dto);
        assertTrue("Delete AE Failed#1", 1 == val);

    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.DeleteAETitleService#doService(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public final void testDoService() throws IdexxDicomAEConfigServiceException {

        final AETitle aeTitle = new AETitle();
        final List<AETitle> registeredAEList = new ArrayList<AETitle>();
        AETitleDTO dto = new AETitleDTO();
        dto.setAeTitle("Test1");
        dto.setInstituteName("TestIng");
        aeTitle.setAeTitle(dto.getAeTitle());
        aeTitle.setInstituteName(dto.getInstituteName());
        aeTitle.setIdentifiedByaeTitleOnly(false);
        registeredAEList.add(aeTitle);
        context.checking(new Expectations() {
            {
                oneOf(mockDao).findAETitle("Test1");
                will(returnValue(registeredAEList));
                oneOf(mockDao).findAETitle("Test1", "TestIng");
                will(returnValue(registeredAEList));
                oneOf(mockDao).deleteAETitle(aeTitle);
                will(VoidAction.INSTANCE);
            }
        });
        service = new DeleteAETitleService();
        ReflectionTestUtils.setField(service, "aeTitleDao", mockDao);
        int val = service.doService(dto);
        assertTrue("Delete AE Failed#1", 1 == val);
        assertTrue("Delete AE failed", null != registeredAEList);

    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.DeleteAETitleService#doService(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public final void testDoService2() throws IdexxDicomAEConfigServiceException {

        final AETitle aeTitle = new AETitle();
        final List<AETitle> registeredAEList = new ArrayList<AETitle>();
        final List<AETitle> registeredAEList2 = new ArrayList<AETitle>();
        AETitleDTO dto = new AETitleDTO();
        dto.setAeTitle("Test1");
        dto.setInstituteName("TestIng");
        aeTitle.setAeTitle(dto.getAeTitle());
        aeTitle.setInstituteName(dto.getInstituteName());
        aeTitle.setIdentifiedByaeTitleOnly(false);
        registeredAEList.add(aeTitle);
        context.checking(new Expectations() {
            {
                oneOf(mockDao).findAETitle("Test1");
                will(returnValue(registeredAEList));
                oneOf(mockDao).findAETitle("Test1", "TestIng");
                will(returnValue(registeredAEList2));
                oneOf(mockDao).deleteAETitle(aeTitle);
                will(VoidAction.INSTANCE);
            }
        });
        service = new DeleteAETitleService();
        ReflectionTestUtils.setField(service, "aeTitleDao", mockDao);

        int val = service.doService(dto);
        assertTrue("Delete AE Failed#1", 1 == val);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.DeleteAETitleService#doService(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public final void testDoService3() throws IdexxDicomAEConfigServiceException {

        final AETitle aeTitle = new AETitle();
        final List<AETitle> registeredAEList = new ArrayList<AETitle>();
        AETitleDTO dto = new AETitleDTO();
        dto.setAeTitle("Test1");
        dto.setInstituteName("TestIng");
        aeTitle.setAeTitle(dto.getAeTitle());
        aeTitle.setInstituteName(dto.getInstituteName());
        aeTitle.setIdentifiedByaeTitleOnly(false);
        registeredAEList.add(aeTitle);
        context.checking(new Expectations() {
            {
                oneOf(mockDao).findAETitle("Test1");
                will(throwException(new IdexxDicomAEConfigDbException()));
            }
        });
        service = new DeleteAETitleService();
        ReflectionTestUtils.setField(service, "aeTitleDao", mockDao);
        service.doService(dto);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.AETitleService#sendResponse(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * .
     */
    @Test
    public final void testSendResponse() {
        service = new DeleteAETitleService();
        Object val = service.sendResponse();
        assertTrue("Not yet implemented", val != null);
    }

}
