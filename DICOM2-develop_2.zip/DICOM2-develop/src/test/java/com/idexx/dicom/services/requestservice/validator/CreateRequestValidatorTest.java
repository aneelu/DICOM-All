/**
 * <h1>JUnit test cases for CreateRequestValidator class.</h1>
 */
package com.idexx.dicom.services.requestservice.validator;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.requestservice.dto.CreateRequestErrorCodesConstants;
import com.idexx.dicom.services.requestservice.dto.CreateRequestServiceResponseDTO;
import com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO;

/**
 * <pre>
 * JUnit test cases for CreateRequestValidator class.
 * </pre>
 * 
 * @author nayeemuddin
 * @version 1.3
 */
public class CreateRequestValidatorTest {
	public static final String APIKEY = "ApiKey";
	public static final String SAPID = "999531";
	public static final String ACCESSIONNUMBER = "AccessionNumber";
	public static final String BREED = "Breed";
	public static final String CLIENTFIRSTNAME = "ClientFirstName";
	public static final String CLIENTLASTNAME = "ClientLastName";
	public static final String MODALITY = "Modality";
	public static final String PATIENTDOB = "PatientDOB";
	public static final String PATIENTID = "PatientId";
	public static final String PATIENTNAME = "PatientName";
	public static final String PIMSISSUER = "PimsIssuer";
	public static final String REQUESTINGDOCTOR = "RequestingDoctor";
	public static final String SPECIES = "Species";
	public static final String SEX = "Sex";

	CreateRequestValidator createRequestValidator = new CreateRequestValidator();
	CreateRequestServiceResponseDTO expectedCreateRequestServiceResponseDTO;

	AETitleDao aeTitleDao;
	RequestDetailsDTO requestDTO;
	List<ErrorDTO> listOfErrors;

	/**
	 * 
	 * @throws java.lang.Exception
	 * 
	 */
	@Before
	public void setUp() throws Exception {
		expectedCreateRequestServiceResponseDTO = new CreateRequestServiceResponseDTO();

		aeTitleDao = mock(AETitleDao.class);
		listOfErrors = new ArrayList<ErrorDTO>();

		requestDTO = new RequestDetailsDTO();
		requestDTO.setApiKey(APIKEY);
		requestDTO.setAccessionNumber(ACCESSIONNUMBER);
		requestDTO.setBreed(BREED);
		requestDTO.setClientFirstName(CLIENTFIRSTNAME);
		requestDTO.setClientLastName(CLIENTLASTNAME);
		requestDTO.setModality(MODALITY);
		requestDTO.setPatientDOB("2015-01-12");
		requestDTO.setPatientId(PATIENTID);
		requestDTO.setPatientName(PATIENTNAME);
		requestDTO.setPimsIssuer(PIMSISSUER);
		requestDTO.setRequestingDoctor(REQUESTINGDOCTOR);
		requestDTO.setSapId(SAPID);
		requestDTO.setSpecies(SPECIES);
		requestDTO.setSex(SEX);

		MockitoAnnotations.initMocks(createRequestValidator);

	}

	/**
	 * Test method for all expected parameters
	 * {@link com.idexx.dicom.services.requestservice.validator.CreateRequestValidator#validate(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * 
	 * @throws IdexxDicomAEConfigServiceException
	 * 
	 */
	@Test
	public void testValidate() throws IdexxDicomAEConfigServiceException {
		List<ErrorDTO> expectedErrorResponse = new ArrayList<ErrorDTO>();
		List<ErrorDTO> actualErrorResponse = new ArrayList<ErrorDTO>();
		actualErrorResponse = createRequestValidator.validate(requestDTO);
		assertEquals(expectedErrorResponse.size(), actualErrorResponse.size());
		assertEquals(actualErrorResponse.size(),0);
	}

	/**
	 * Test method for missing Patient birth date.
	 * {@link com.idexx.dicom.services.requestservice.validator.CreateRequestValidator#validate(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * 
	 * @throws IdexxDicomAEConfigServiceException
	 * 
	 */
	@Test
	public void testValidate1() throws IdexxDicomAEConfigServiceException {
		List<ErrorDTO> expectedErrorResponse = new ArrayList<ErrorDTO>();
		ErrorDTO errorCodes = new ErrorDTO();
		errorCodes.setErrorCode(CreateRequestErrorCodesConstants.PATIENT_DOB_ERROR_CODE);
		errorCodes.setMessage(CreateRequestErrorCodesConstants.PATIENT_DOB_ERROR_CODE_MSG);

		expectedErrorResponse.add(errorCodes);
		expectedCreateRequestServiceResponseDTO.setErrors(expectedErrorResponse);

		requestDTO.setPatientDOB("");

		List<ErrorDTO> actualErrorResponse = new ArrayList<ErrorDTO>();
		actualErrorResponse = createRequestValidator.validate(requestDTO);

		assertEquals(actualErrorResponse.get(0).getErrorCode(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getErrorCode());
		assertEquals(actualErrorResponse.get(0).getMessage(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getMessage());
	}

	/**
	 * Test method for missing Patient ID.
	 * {@link com.idexx.dicom.services.requestservice.validator.CreateRequestValidator#validate(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * 
	 * @throws IdexxDicomAEConfigServiceException
	 * 
	 */
	@Test
	public void testValidate2() throws IdexxDicomAEConfigServiceException {
		List<ErrorDTO> expectedErrorResponse = new ArrayList<ErrorDTO>();
		ErrorDTO errorCodes = new ErrorDTO();
		errorCodes.setErrorCode(CreateRequestErrorCodesConstants.PATIENT_ID_ERROR_CODE);
		errorCodes.setMessage(CreateRequestErrorCodesConstants.PATIENT_ID_ERROR_CODE_MSG);

		expectedErrorResponse.add(errorCodes);
		expectedCreateRequestServiceResponseDTO.setErrors(expectedErrorResponse);

		requestDTO.setPatientId("");

		List<ErrorDTO> actualErrorResponse = new ArrayList<ErrorDTO>();
		actualErrorResponse = createRequestValidator.validate(requestDTO);

		assertEquals(actualErrorResponse.get(0).getErrorCode(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getErrorCode());
		assertEquals(actualErrorResponse.get(0).getMessage(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getMessage());
	}

	/**
	 * Test method for missing Patient Name.
	 * {@link com.idexx.dicom.services.requestservice.validator.CreateRequestValidator#validate(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * 
	 * @throws IdexxDicomAEConfigServiceException
	 */
	@Test
	public void testValidate3() throws IdexxDicomAEConfigServiceException {

		List<ErrorDTO> expectedErrorResponse = new ArrayList<ErrorDTO>();
		ErrorDTO errorCodes = new ErrorDTO();
		errorCodes.setErrorCode(CreateRequestErrorCodesConstants.PATIENT_NAME_ERROR_CODE);
		errorCodes.setMessage(CreateRequestErrorCodesConstants.PATIENT_NAME_ERROR_CODE_MSG);

		expectedErrorResponse.add(errorCodes);
		expectedCreateRequestServiceResponseDTO.setErrors(expectedErrorResponse);

		requestDTO.setPatientName("");

		List<ErrorDTO> actualErrorResponse = new ArrayList<ErrorDTO>();
		actualErrorResponse = createRequestValidator.validate(requestDTO);

		assertEquals(actualErrorResponse.get(0).getErrorCode(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getErrorCode());
		assertEquals(actualErrorResponse.get(0).getMessage(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getMessage());
	}

	/**
	 * Test method for missing Client's First Name.
	 * {@link com.idexx.dicom.services.requestservice.validator.CreateRequestValidator#validate(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * 
	 * @throws IdexxDicomAEConfigServiceException
	 */
	@Test
	public void testValidate4() throws IdexxDicomAEConfigServiceException {

		List<ErrorDTO> expectedErrorResponse = new ArrayList<ErrorDTO>();
		ErrorDTO errorCodes = new ErrorDTO();
		errorCodes.setErrorCode(CreateRequestErrorCodesConstants.CLIENT_FIRST_NAME_ERROR_CODE);
		errorCodes.setMessage(CreateRequestErrorCodesConstants.CLIENT_FIRST_NAME_ERROR_CODE_MSG);

		expectedErrorResponse.add(errorCodes);
		expectedCreateRequestServiceResponseDTO.setErrors(expectedErrorResponse);

		requestDTO.setClientFirstName("");

		List<ErrorDTO> actualErrorResponse = new ArrayList<ErrorDTO>();
		actualErrorResponse = createRequestValidator.validate(requestDTO);

		assertEquals(actualErrorResponse.get(0).getErrorCode(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getErrorCode());
		assertEquals(actualErrorResponse.get(0).getMessage(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getMessage());
	}

	/**
	 * Test method for missing Client's Last Name.
	 * {@link com.idexx.dicom.services.requestservice.validator.CreateRequestValidator#validate(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * 
	 * @throws IdexxDicomAEConfigServiceException
	 */
	@Test
	public void testValidate5() throws IdexxDicomAEConfigServiceException {
		List<ErrorDTO> expectedErrorResponse = new ArrayList<ErrorDTO>();
		ErrorDTO errorCodes = new ErrorDTO();
		errorCodes.setErrorCode(CreateRequestErrorCodesConstants.CLIENT_LAST_NAME_ERROR_CODE);
		errorCodes.setMessage(CreateRequestErrorCodesConstants.CLIENT_LAST_NAME_ERROR_CODE_MSG);
		expectedErrorResponse.add(errorCodes);
		expectedCreateRequestServiceResponseDTO.setErrors(expectedErrorResponse);

		requestDTO.setClientLastName("");

		List<ErrorDTO> actualErrorResponse = new ArrayList<ErrorDTO>();
		actualErrorResponse = createRequestValidator.validate(requestDTO);

		assertEquals(actualErrorResponse.get(0).getErrorCode(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getErrorCode());
		assertEquals(actualErrorResponse.get(0).getMessage(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getMessage());
	}

	/**
	 * Test method for missing Patient's Sex
	 * {@link com.idexx.dicom.services.requestservice.validator.CreateRequestValidator#validate(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * 
	 * @throws IdexxDicomAEConfigServiceException
	 */
	@Test
	public void testValidate6() throws IdexxDicomAEConfigServiceException {

		List<ErrorDTO> expectedErrorResponse = new ArrayList<ErrorDTO>();
		ErrorDTO errorCodes = new ErrorDTO();
		errorCodes.setErrorCode(CreateRequestErrorCodesConstants.SEX_ERROR_CODE);
		errorCodes.setMessage(CreateRequestErrorCodesConstants.SEX_ERROR_CODE_MSG);

		expectedErrorResponse.add(errorCodes);
		expectedCreateRequestServiceResponseDTO.setErrors(expectedErrorResponse);

		requestDTO.setSex("");

		List<ErrorDTO> actualErrorResponse = new ArrayList<ErrorDTO>();
		actualErrorResponse = createRequestValidator.validate(requestDTO);

		assertEquals(actualErrorResponse.get(0).getErrorCode(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getErrorCode());
		assertEquals(actualErrorResponse.get(0).getMessage(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getMessage());
	}

	/**
	 * Test method for missing Patient's Breed.
	 * {@link com.idexx.dicom.services.requestservice.validator.CreateRequestValidator#validate(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * 
	 * @throws IdexxDicomAEConfigServiceException
	 */
	@Test
	public void testValidate7() throws IdexxDicomAEConfigServiceException {
		List<ErrorDTO> expectedErrorResponse = new ArrayList<ErrorDTO>();
		ErrorDTO errorCodes = new ErrorDTO();
		errorCodes.setErrorCode(CreateRequestErrorCodesConstants.BREED_ERROR_CODE);
		errorCodes.setMessage(CreateRequestErrorCodesConstants.BREED_ERROR_CODE_MSG);

		expectedErrorResponse.add(errorCodes);
		expectedCreateRequestServiceResponseDTO.setErrors(expectedErrorResponse);

		requestDTO.setBreed("");

		List<ErrorDTO> actualErrorResponse = new ArrayList<ErrorDTO>();
		actualErrorResponse = createRequestValidator.validate(requestDTO);

		assertEquals(actualErrorResponse.get(0).getErrorCode(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getErrorCode());
		assertEquals(actualErrorResponse.get(0).getMessage(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getMessage());
	}

	/**
	 * Test method for missing Patient's Species.
	 * {@link com.idexx.dicom.services.requestservice.validator.CreateRequestValidator#validate(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * 
	 * @throws IdexxDicomAEConfigServiceException
	 */
	@Test
	public void testValidate8() throws IdexxDicomAEConfigServiceException {
		List<ErrorDTO> expectedErrorResponse = new ArrayList<ErrorDTO>();
		ErrorDTO errorCodes = new ErrorDTO();
		errorCodes.setErrorCode(CreateRequestErrorCodesConstants.SPECIES_ERROR_CODE);
		errorCodes.setMessage(CreateRequestErrorCodesConstants.SPECIES_ERROR_CODE_MSG);

		expectedErrorResponse.add(errorCodes);
		expectedCreateRequestServiceResponseDTO.setErrors(expectedErrorResponse);

		requestDTO.setSpecies("");

		List<ErrorDTO> actualErrorResponse = new ArrayList<ErrorDTO>();
		actualErrorResponse = createRequestValidator.validate(requestDTO);

		assertEquals(actualErrorResponse.get(0).getErrorCode(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getErrorCode());
		assertEquals(actualErrorResponse.get(0).getMessage(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getMessage());
	}

	/**
	 * Test method for missing Doctor.
	 * {@link com.idexx.dicom.services.requestservice.validator.CreateRequestValidator#validate(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * 
	 * @throws IdexxDicomAEConfigServiceException
	 */
	@Test
	public void testValidate9() throws IdexxDicomAEConfigServiceException {
		List<ErrorDTO> expectedErrorResponse = new ArrayList<ErrorDTO>();
		ErrorDTO errorCodes = new ErrorDTO();
		errorCodes.setErrorCode(CreateRequestErrorCodesConstants.DOCTOR_ERROR_CODE);
		errorCodes.setMessage(CreateRequestErrorCodesConstants.DOCTOR_ERROR_CODE_MSG);

		expectedErrorResponse.add(errorCodes);
		expectedCreateRequestServiceResponseDTO.setErrors(expectedErrorResponse);

		requestDTO.setRequestingDoctor("");

		List<ErrorDTO> actualErrorResponse = new ArrayList<ErrorDTO>();
		actualErrorResponse = createRequestValidator.validate(requestDTO);

		assertEquals(actualErrorResponse.get(0).getErrorCode(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getErrorCode());
		assertEquals(actualErrorResponse.get(0).getMessage(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getMessage());
	}

	/**
	 * Test method for missing Modality.
	 * {@link com.idexx.dicom.services.requestservice.validator.CreateRequestValidator#validate(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * 
	 * @throws IdexxDicomAEConfigServiceException
	 */
	@Test
	public void testValidate10() throws IdexxDicomAEConfigServiceException {
		List<ErrorDTO> expectedErrorResponse = new ArrayList<ErrorDTO>();
		ErrorDTO errorCodes = new ErrorDTO();
		errorCodes.setErrorCode(CreateRequestErrorCodesConstants.MODALITY_ERROR_CODE);
		errorCodes.setMessage(CreateRequestErrorCodesConstants.MODALITY_ERROR_CODE_MSG);

		expectedErrorResponse.add(errorCodes);
		expectedCreateRequestServiceResponseDTO.setErrors(expectedErrorResponse);

		requestDTO.setModality("");

		List<ErrorDTO> actualErrorResponse = new ArrayList<ErrorDTO>();
		actualErrorResponse = createRequestValidator.validate(requestDTO);

		assertEquals(actualErrorResponse.get(0).getErrorCode(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getErrorCode());
		assertEquals(actualErrorResponse.get(0).getMessage(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getMessage());
	}

	/**
	 * Test method for missing PIMS Issuer.
	 * {@link com.idexx.dicom.services.requestservice.validator.CreateRequestValidator#validate(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * 
	 * @throws IdexxDicomAEConfigServiceException
	 */
	@Test
	public void testValidate11() throws IdexxDicomAEConfigServiceException {
		List<ErrorDTO> expectedErrorResponse = new ArrayList<ErrorDTO>();
		ErrorDTO errorCodes = new ErrorDTO();
		errorCodes.setErrorCode(CreateRequestErrorCodesConstants.PIMS_ISSUER_ERROR_CODE);
		errorCodes.setMessage(CreateRequestErrorCodesConstants.PIMS_ISSUER_ERROR_CODE_MSG);

		expectedErrorResponse.add(errorCodes);
		expectedCreateRequestServiceResponseDTO.setErrors(expectedErrorResponse);

		requestDTO.setPimsIssuer("");

		List<ErrorDTO> actualErrorResponse = new ArrayList<ErrorDTO>();
		actualErrorResponse = createRequestValidator.validate(requestDTO);

		assertEquals(actualErrorResponse.get(0).getErrorCode(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getErrorCode());
		assertEquals(actualErrorResponse.get(0).getMessage(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getMessage());
	}

	/**
	 * Test method for missing SAP ID.
	 * {@link com.idexx.dicom.services.requestservice.validator.CreateRequestValidator#validate(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * 
	 * @throws IdexxDicomAEConfigServiceException
	 */
	@Test
	public void testValidate12() throws IdexxDicomAEConfigServiceException {
		List<ErrorDTO> expectedErrorResponse = new ArrayList<ErrorDTO>();
		ErrorDTO errorCodes = new ErrorDTO();
		errorCodes.setErrorCode(CreateRequestErrorCodesConstants.SAP_ID_ERROR_CODE);
		errorCodes.setMessage(CreateRequestErrorCodesConstants.SAP_ID_ERROR_CODE_MSG);

		expectedErrorResponse.add(errorCodes);
		expectedCreateRequestServiceResponseDTO.setErrors(expectedErrorResponse);

		requestDTO.setSapId("");

		List<ErrorDTO> actualErrorResponse = new ArrayList<ErrorDTO>();
		actualErrorResponse = createRequestValidator.validate(requestDTO);

		assertEquals(actualErrorResponse.get(0).getErrorCode(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getErrorCode());
		assertEquals(actualErrorResponse.get(0).getMessage(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getMessage());
	}

	/**
	 * Test method for missing API KEY.
	 * {@link com.idexx.dicom.services.requestservice.validator.CreateRequestValidator#validate(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * 
	 * @throws IdexxDicomAEConfigServiceException
	 */
	@Test
	public void testValidate13() throws IdexxDicomAEConfigServiceException {
		List<ErrorDTO> expectedErrorResponse = new ArrayList<ErrorDTO>();
		ErrorDTO errorCodes = new ErrorDTO();
		errorCodes.setErrorCode(CreateRequestErrorCodesConstants.API_KEY_ERROR_CODE);
		errorCodes.setMessage(CreateRequestErrorCodesConstants.API_KEY_ERROR_CODE_MSG);

		expectedErrorResponse.add(errorCodes);
		expectedCreateRequestServiceResponseDTO.setErrors(expectedErrorResponse);

		requestDTO.setApiKey("");

		List<ErrorDTO> actualErrorResponse = new ArrayList<ErrorDTO>();
		actualErrorResponse = createRequestValidator.validate(requestDTO);

		assertEquals(actualErrorResponse.get(0).getErrorCode(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getErrorCode());
		assertEquals(actualErrorResponse.get(0).getMessage(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getMessage());
	}

	/**
	 * Test method for missing SAP ID must be Numeric.
	 * {@link com.idexx.dicom.services.requestservice.validator.CreateRequestValidator#validate(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * 
	 * @throws IdexxDicomAEConfigServiceException
	 */
	@Test
	public void testValidate14() throws IdexxDicomAEConfigServiceException {
		List<ErrorDTO> expectedErrorResponse = new ArrayList<ErrorDTO>();
		ErrorDTO errorCodes = new ErrorDTO();
		errorCodes.setErrorCode(CreateRequestErrorCodesConstants.SAP_ID_NUMERIC_ERROR_CODE);
		errorCodes.setMessage(CreateRequestErrorCodesConstants.SAP_ID_NUMERIC_ERROR_CODE_MSG);

		expectedErrorResponse.add(errorCodes);
		expectedCreateRequestServiceResponseDTO.setErrors(expectedErrorResponse);

		requestDTO.setSapId("12345A");

		List<ErrorDTO> actualErrorResponse = new ArrayList<ErrorDTO>();
		actualErrorResponse = createRequestValidator.validate(requestDTO);

		assertEquals(actualErrorResponse.get(0).getErrorCode(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getErrorCode());
		assertEquals(actualErrorResponse.get(0).getMessage(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getMessage());
	}

	/**
	 * Test method for Invalid Patient date of birth.
	 * {@link com.idexx.dicom.services.requestservice.validator.CreateRequestValidator#validate(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * 
	 * @throws IdexxDicomAEConfigServiceException
	 */
	@Test
	public void testValidate15() throws IdexxDicomAEConfigServiceException {
		List<ErrorDTO> expectedErrorResponse = new ArrayList<ErrorDTO>();
		ErrorDTO errorCodes = new ErrorDTO();
		errorCodes.setErrorCode(CreateRequestErrorCodesConstants.INVALID_PATIENT_DOB_ERROR_CODE);
		errorCodes.setMessage(CreateRequestErrorCodesConstants.INVALID_PATIENT_DOB_ERROR_CODE_MSG);

		expectedErrorResponse.add(errorCodes);
		expectedCreateRequestServiceResponseDTO.setErrors(expectedErrorResponse);

		requestDTO.setPatientDOB("2015-01-");

		List<ErrorDTO> actualErrorResponse = new ArrayList<ErrorDTO>();
		actualErrorResponse = createRequestValidator.validate(requestDTO);

		assertEquals(actualErrorResponse.get(0).getErrorCode(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getErrorCode());
		assertEquals(actualErrorResponse.get(0).getMessage(),
				expectedCreateRequestServiceResponseDTO.getErrors().get(0).getMessage());
	}

}
