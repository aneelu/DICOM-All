#!/bin/bash

case "${ENV^^}" in
  LOCAL)
    echo "local environment"
    touch ${_tomcatHomeDir}/${_tomcatVersion}/bin/local.properties
    ;;

  DEV)
    echo "dev"
    #Optional download environment specific config or credentials file from s3
    ;;

  QA)
    echo "qa"
     #Optional download environment specific config or credentials file from s3
    ;;

  PROD)
    echo "prod"
     #Optional download environment specific config or credentials file from s3
    ;;

  *)
    echo "invalid environment"
    exit 1
    ;;
esac

# Setup Tomcat
sed -i -e "s/<ENV>/${ENV,,}/" ${_tomcatHomeDir}/${_tomcatVersion}/bin/setenv.sh
sed -i -e "s,<TOMCAT_HOMEDIR>,${_tomcatHomeDir}," ${_tomcatHomeDir}/${_tomcatVersion}/bin/setenv.sh
sed -i -e "s/<TOMCAT_VERSION>/${_tomcatVersion}/" ${_tomcatHomeDir}/${_tomcatVersion}/bin/setenv.sh
sed -i -e "s/<ENV>/${_proxyNameEnv}/" ${_tomcatHomeDir}/${_tomcatVersion}/conf/server.xml
sed -i -e "s/<JVM_HEAP>/${jvmHeap}/" ${_tomcatHomeDir}/${_tomcatVersion}/bin/setenv.sh

# Setup sumo config
sed -i -e "s/ENV/${ENV,,}/" /opt/sumo_sources/sumo.conf
sed -i -e "s/ENV/${ENV,,}/" /opt/sumo_sources/sumo_sources.json
sed -i -e "s,<TOMCAT_HOMEDIR>,${_tomcatHomeDir}," /opt/sumo_sources/sumo_sources.json
sed -i -e "s/<TOMCAT_VERSION>/${_tomcatVersion}/" /opt/sumo_sources/sumo_sources.json
aws s3 cp s3://IDEXX-Digtal-Autodeploy/DICOM/config/sumo.credentials /tmp/sumo.credentials
source /tmp/sumo.credentials
sed -i -e "s/<SUMO_ACCESS_ID>/${sumoAccessID}/" /opt/sumo_sources/sumo.conf
sed -i -e "s/<SUMO_ACCESS_KEY>/${sumoAccessKey}/" /opt/sumo_sources/sumo.conf
rm -f /tmp/sumo.credentials
chmod 755 /opt/sumo_sources/sumologic_entrypoint.sh

if [[ "${sumologicEnabled}" = "yes" ]]; then
    sed -i -e "/<FILTERS>/d" /opt/sumo_sources/sumo_sources.json
else
    # Sumologic is disabled - we still run the container, but we just drop all data ingested
    sed -i -e 's/<FILTERS>/"filters": [{"name":"Disable Sumo","filterType":"Exclude","regexp":"(?s).*(?s)"}]/' /opt/sumo_sources/sumo_sources.json
fi

# Start Tomcat - Note this launches into foreground, and will keep container alive until Tomcat exits prematurely
${_tomcatHomeDir}/${_tomcatVersion}/bin/catalina.sh run >> "${_tomcatHomeDir}/${_tomcatVersion}/logs/catalina.out" 2>&1
