#!/bin/bash

cp /opt/sumo_sources/sumo.conf /etc/sumo.conf
cp /opt/sumo_sources/sumo_sources.json /etc/sumo_sources.json

# Call the default sumologic container entrypoint
sh run.sh