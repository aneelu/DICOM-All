package com.idexx.dicom.dao.ws;

import java.util.List;

import com.idexx.dicom.ae.entities.AssumedIssuer;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;

public interface AssumedIssuerDao {
    
    List<AssumedIssuer> findAssumedIssuerBySapId(String sapId);
    
    void createAssumedIssuer(AssumedIssuer assumedIssuer) throws IdexxDicomAEConfigDbException;
    
    void updateAssumedIssuer(AssumedIssuer assumedIssuer)throws IdexxDicomAEConfigDbException;
}
