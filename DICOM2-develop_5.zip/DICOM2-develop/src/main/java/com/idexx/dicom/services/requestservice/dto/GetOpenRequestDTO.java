/**
 *
 */
package com.idexx.dicom.services.requestservice.dto;

import java.sql.Timestamp;

import com.idexx.imaging.imagemanager.soap.PatientDTO;

/**
 * @author smallela
 * @version 1.3
 */
public class GetOpenRequestDTO {

	private String modality;
	private String requestingDoctor;
	private String requestNotes;
	private String accessionNumber;
	private String studyInstanceUID;;
	private String status;
	private Timestamp createTimestamp;
	private Timestamp updateTimestamp;
	
	private PatientDTO patientDTO;


	/**
	 * @return the modality
	 */
	public String getModality() {
		return modality;
	}

	/**
	 * @param modality
	 *            the modality to set
	 */
	public void setModality(String modality) {
		this.modality = modality;
	}

	/**
	 * @return the requestingDoctor
	 */
	public String getRequestingDoctor() {
		return requestingDoctor;
	}

	/**
	 * @param requestingDoctor
	 *            the requestingDoctor to set
	 */
	public void setRequestingDoctor(String requestingDoctor) {
		this.requestingDoctor = requestingDoctor;
	}

	/**
	 * @return the requestNotes
	 */
	public String getRequestNotes() {
		return requestNotes;
	}

	/**
	 * @param requestNotes
	 *            the requestNotes to set
	 */
	public void setRequestNotes(String requestNotes) {
		this.requestNotes = requestNotes;
	}

	/**
	 * @return the accessionNumber
	 */
	public String getAccessionNumber() {
		return accessionNumber;
	}

	/**
	 * @param accessionNumber
	 *            the accessionNumber to set
	 */
	public void setAccessionNumber(String accessionNumber) {
		this.accessionNumber = accessionNumber;
	}

	/**
	 * @return the studyInstanceUID
	 */
	public String getStudyInstanceUID() {
		return studyInstanceUID;
	}

	/**
	 * @param studyInstanceUID
	 *            the studyInstanceUID to set
	 */
	public void setStudyInstanceUID(String studyInstanceUID) {
		this.studyInstanceUID = studyInstanceUID;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getCreateTimestamp() {
		return createTimestamp;
	}

	public void setCreateTimestamp(Timestamp createTimestamp) {
		this.createTimestamp = createTimestamp;
	}

	public Timestamp getUpdateTimestamp() {
		return updateTimestamp;
	}

	public void setUpdateTimestamp(Timestamp updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

	public PatientDTO getPatientDTO() {
		return patientDTO;
	}

	public void setPatientDTO(PatientDTO patientDTO) {
		this.patientDTO = patientDTO;
	}
}
