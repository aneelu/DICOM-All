/**
 * <h1>Class to validate the Create Request mandatory parameters.</h1>
 */
package com.idexx.dicom.services.requestservice.validator;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.requestservice.dto.CreateRequestErrorCodesConstants;
import com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO;

/**
 * <pre>
 * Class to validate the Create Request mandatory parameters.
 * </pre>
 * 
 * @author nayeemuddin
 * @version 1.3
 */
@Service("requestServiceValidator")
public class CreateRequestValidator {
	
	private static final Logger LOG = Logger.getLogger(CreateRequestValidator.class);

    /**
     * 
     * <pre>
     * Method to validate create request mandatory parameters.
     * </pre>
     * 
     * @param dto
     * @return
     * @throws IdexxDicomAEConfigServiceException
     *
     */
    public List<ErrorDTO> validate(final RequestDetailsDTO dto) throws IdexxDicomAEConfigServiceException {

	List<ErrorDTO> listOfErrors = new ArrayList<ErrorDTO>();
	    
	    listOfErrors.add(checkInput(dto.getPatientDOB(),CreateRequestErrorCodesConstants.PATIENT_DOB_ERROR_CODE, CreateRequestErrorCodesConstants.PATIENT_DOB_ERROR_CODE_MSG));
	    listOfErrors.add(checkInput(dto.getPatientId(),CreateRequestErrorCodesConstants.PATIENT_ID_ERROR_CODE, CreateRequestErrorCodesConstants.PATIENT_ID_ERROR_CODE_MSG));
	    listOfErrors.add(checkInput(dto.getPatientName(),CreateRequestErrorCodesConstants.PATIENT_NAME_ERROR_CODE, CreateRequestErrorCodesConstants.PATIENT_NAME_ERROR_CODE_MSG));
	    listOfErrors.add(checkInput(dto.getModality(),CreateRequestErrorCodesConstants.MODALITY_ERROR_CODE, CreateRequestErrorCodesConstants.MODALITY_ERROR_CODE_MSG));
	    listOfErrors.add(checkInput(dto.getClientFirstName(),CreateRequestErrorCodesConstants.CLIENT_FIRST_NAME_ERROR_CODE, CreateRequestErrorCodesConstants.CLIENT_FIRST_NAME_ERROR_CODE_MSG));
	    listOfErrors.add(checkInput(dto.getClientLastName(),CreateRequestErrorCodesConstants.CLIENT_LAST_NAME_ERROR_CODE, CreateRequestErrorCodesConstants.CLIENT_LAST_NAME_ERROR_CODE_MSG));
	    listOfErrors.add(checkInput(dto.getSex(),CreateRequestErrorCodesConstants.SEX_ERROR_CODE, CreateRequestErrorCodesConstants.SEX_ERROR_CODE_MSG));
	    listOfErrors.add(checkInput(dto.getBreed(),CreateRequestErrorCodesConstants.BREED_ERROR_CODE, CreateRequestErrorCodesConstants.BREED_ERROR_CODE_MSG));
	    listOfErrors.add(checkInput(dto.getSpecies(),CreateRequestErrorCodesConstants.SPECIES_ERROR_CODE, CreateRequestErrorCodesConstants.SPECIES_ERROR_CODE_MSG));
	    listOfErrors.add(checkInput(dto.getRequestingDoctor(),CreateRequestErrorCodesConstants.DOCTOR_ERROR_CODE, CreateRequestErrorCodesConstants.DOCTOR_ERROR_CODE_MSG));
	    listOfErrors.add(checkInput(dto.getPimsIssuer(),CreateRequestErrorCodesConstants.PIMS_ISSUER_ERROR_CODE, CreateRequestErrorCodesConstants.PIMS_ISSUER_ERROR_CODE_MSG));
	    listOfErrors.add(checkInput(dto.getApiKey(),CreateRequestErrorCodesConstants.API_KEY_ERROR_CODE, CreateRequestErrorCodesConstants.API_KEY_ERROR_CODE_MSG));
	    listOfErrors.add(checkInput(dto.getSapId(),CreateRequestErrorCodesConstants.SAP_ID_ERROR_CODE, CreateRequestErrorCodesConstants.SAP_ID_ERROR_CODE_MSG));

	if (!StringUtils.isEmpty(dto.getPatientDOB())) {
	    XMLGregorianCalendar xmlGC = getFormatDOB(dto.getPatientDOB());
	    LOG.info("Patient date of birth: " + xmlGC);
	    if (null == xmlGC) {
		dto.setAllInputsAvailable(false);
		listOfErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.INVALID_PATIENT_DOB_ERROR_CODE, CreateRequestErrorCodesConstants.INVALID_PATIENT_DOB_ERROR_CODE_MSG));
	    }
	}

	if (!StringUtils.isEmpty(dto.getSapId()) && !NumberUtils.isNumber(dto.getSapId())) {
	    dto.setAllInputsAvailable(false);
	    listOfErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.SAP_ID_NUMERIC_ERROR_CODE, CreateRequestErrorCodesConstants.SAP_ID_NUMERIC_ERROR_CODE_MSG));
	}
	 List<ErrorDTO> filterListOfErrors = listOfErrors.stream().filter(p -> p != null).collect(Collectors.toList());
	return filterListOfErrors;
    }
    
    
    private ErrorDTO checkInput(String valueToCheck, String errorCode, String errorMsg) {	
	if (StringUtils.isEmpty(valueToCheck)) {
	    return new ErrorDTO(errorCode, errorMsg);
	    }
	return null;
    }



    /**
     * 
     * @param strDdate
     * @return
     *
     */
    protected XMLGregorianCalendar getFormatDOB(String strDdate) {
	String strPatientDOB = null;
	XMLGregorianCalendar xmlGC = null;
	SimpleDateFormat sdf = new SimpleDateFormat(CreateRequestErrorCodesConstants.PATIENT_DOB_FORMAT);

	try {
	    Date dobDate = sdf.parse(strDdate);
	    SimpleDateFormat sdf1 = new SimpleDateFormat(CreateRequestErrorCodesConstants.CREATE_PATIENT_DATE_FORMAT);
	    strPatientDOB = sdf1.format(dobDate);

	    xmlGC = DatatypeFactory.newInstance().newXMLGregorianCalendar(strPatientDOB);
	} catch (ParseException e) {
	    LOG.error(CreateRequestErrorCodesConstants.INVALID_PATIENT_DOB_ERROR_CODE, e);
	} catch (DatatypeConfigurationException e) {
	    LOG.error(CreateRequestErrorCodesConstants.INVALID_PATIENT_DOB_ERROR_CODE, e);
	}

	return xmlGC;
    }

}
