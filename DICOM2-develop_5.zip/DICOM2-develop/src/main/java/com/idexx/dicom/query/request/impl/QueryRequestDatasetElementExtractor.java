package com.idexx.dicom.query.request.impl;

import java.util.HashMap;
import java.util.Map;

import org.dcm4che3.data.Attributes;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.idexx.dicom.query.common.TagsElementMappingService;
import com.idexx.dicom.query.request.QueryRequestDatasetElementExtractorInterface;

/**
 * class helper class that extracts data from Dataset
 * 
 * @author apinninti
 * 
 */

@Component
public class QueryRequestDatasetElementExtractor implements QueryRequestDatasetElementExtractorInterface, InitializingBean {
    
    private Map<String, Integer> elementsFromRequestMap;
    
    @Autowired
    private TagsElementMappingService tagsElementMappingService;
    
    /**
     * this method extracts information from dataset
     * @param dataset
     * @return Map<String, String>
     */
    public final Map<String, String> getElementsExtractedFromDataset(final Attributes dataset) {
        
        Map<String, String> responseMap = new HashMap<String, String>();
        if (null == elementsFromRequestMap) {
            return responseMap;
        }
        Object[] elementsFromRequest1 = elementsFromRequestMap.keySet().toArray();
        for (int i = 0; i < elementsFromRequest1.length; i++) {
            
            int tagName = Integer.parseInt("" + elementsFromRequestMap.get(elementsFromRequest1[i]));
            String value = dataset.getString(tagName);
            responseMap.put("" + elementsFromRequest1[i], value);
        }
        return responseMap;
    }

	@Override
	public void afterPropertiesSet() throws Exception {
        elementsFromRequestMap = tagsElementMappingService.getMappings();
	}
}
