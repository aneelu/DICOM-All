/**
 * 
 */
package com.idexx.dicom.store;

import java.util.List;

import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;

import com.idexx.dicom.entities.store.DicomImageManagerMapping;

/**
 * @author vkandagatla
 * 
 */
public class AquisitionDateExtractor extends AbstractExtractor {

    public AquisitionDateExtractor(final List<DicomImageManagerMapping> mapping) {
        super(mapping);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.store.ImageManagerAttributeExtractorFromDicomElement#
     * exractAtribute(org.dcm4che.data.Dataset)
     */
    @Override
    public final String exractAtribute(final Attributes dataset) {
        String value1 = this.getTagValueAsString(Tag.AcquisitionDate, dataset);
        String value2 = this.getTagValueAsString(Tag.AcquisitionTime, dataset);
        if (value1 != null && value1.trim().equals("00000000") && value1.equalsIgnoreCase("null"))  {
            return null;
        }
        else if ((value1 != null && !value1.trim().equals("")) && (value2 == null || value2.trim().equals(""))) {
            value2 = "000000";
        } else if(value1 == null) {
            return null;
        }
        return value1 + value2;
    }

}
