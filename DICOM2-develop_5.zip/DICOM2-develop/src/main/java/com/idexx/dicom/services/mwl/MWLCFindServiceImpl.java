/**
 * <h1>MWL C-Find Service Implementation Class</h1>
 */
package com.idexx.dicom.services.mwl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.idexx.dcm4che3.tool.dcmqrscp.PatientQueryBuilder;
import com.idexx.dicom.domain.ExternalPatient;
import com.idexx.dicom.domain.MPPSNCreate;
import com.idexx.dicom.domain.RequestDetails;
import com.idexx.dicom.mapper.EntityMapper;
import com.idexx.dicom.repo.AETitleRepository;
import com.idexx.dicom.repo.MPPSNCreateRepository;
import com.idexx.dicom.services.requestservice.dto.SearchDetailsDTO;
import com.idexx.imaging.imagemanager.soap.ExternalPatientIdDTO;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;

/**
 * <pre>
 * Description of the class
 * </pre>
 * 
 * @author rkaranam
 * @version 1.3
 */
@Service("mwlCFindService")
public class MWLCFindServiceImpl {

    @Autowired
    private MPPSNCreateRepository mppsNCreateRepository;

    @Autowired
    private AETitleRepository aeTitleRespository;

    @Autowired
    private PatientQueryBuilder patientQueryBuilder;

    @Autowired
    @Qualifier("entityMapper")
    private EntityMapper entityMapper;

    /**
     * <pre>
     * Returns a sequence for the given studyInstanceUID
     * </pre>
     * 
     * @param studyInstanceUID
     * @return
     * 
     */
    public List<MPPSNCreate> findSequence(String studyInstanceUID) {
	return mppsNCreateRepository.findByStudyInstanceUID(studyInstanceUID);
    }

    /**
     * <pre>
     * Returns a distinct sapId
     * </pre>
     * 
     * @param studyInstanceUID
     * @return
     * 
     */
    public List<String> findDistinctAeTitleBySapId(String aeTitle) {
	return aeTitleRespository.findDistinctAeTitleBySapId(aeTitle);
    }

    /**
     * <pre>
     * Method returns List<RequestDetails>
     * </pre>
     * 
     * @param requestDetails
     * @return
     * 
     */
    public List<RequestDetails> findRequestDetails(final SearchDetailsDTO searchDetails)
	    throws IdexxServiceException_Exception {
	return patientQueryBuilder.buildSearchPatientQuery(searchDetails);
    }

    /**
     * <pre>
     * Method returns List<ExternalPatientIdDTO>
     * </pre>
     * 
     * @param extPatients
     * @return
     * 
     */
    public List<ExternalPatientIdDTO> getExternalPatientIdList(final List<ExternalPatient> extPatients) {
	return entityMapper.convertExternalPatientsListToDto(extPatients);
    }

}
