/**
 * 
 */
package com.idexx.dicom.aeservices.impl.v12;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.ae.validator.v12.IdexxSendImageStatusValidator;
import com.idexx.dicom.aeservices.v12.IdexxDicomWSAthorizationService;
import com.idexx.dicom.aeservices.v12.SendImageStatusService;
import com.idexx.dicom.dao.ws.IdexxSendImageJobDao;
import com.idexx.dicom.services.IdexxDicomServiceConstants;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v12.IdexxSendImageJobStatusDTO;
import com.idexx.dicom.services.sendimage.dto.v12.SendImageStatusParamDTO;

/**
 * @author mdindukurthi
 * 
 */
@Service("getSendImageStatusServiceV12")
public class SendImageStatusServiceImpl implements SendImageStatusService {

	private static final Logger LOG = Logger.getLogger(SendImageStatusServiceImpl.class);
	
    @Autowired
    @Qualifier("idexxSendImageStatusValidatorV12")
    private IdexxSendImageStatusValidator validator;

    @Autowired
    private IdexxSendImageJobDao sendImageJobDao;

    private List<IdexxSendImageJobStatusDTO> dtos;

    private List<String> cloneList;

    @Autowired
    private IdexxDicomWSAthorizationService idexxDicomWsAuthorizeService;

    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.aeservices.AEService#performService()
     */
    @Transactional
    public final List<IdexxSendImageJobStatusDTO> performService(final SendImageStatusParamDTO dto)
            throws IdexxDicomAEConfigServiceException {
        boolean authorized = false;
        authorized = idexxDicomWsAuthorizeService.authorize(dto.getApiKey());
        if (authorized) {
            this.validate(dto);
            this.doService(dto);
        }

        return dtos;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.aeservices.impl.AbstractAEServiceImpl#validate(com.idexx
     * .dicom.services.dto.IdexxDicomApplicationEntityDTO)
     */

    protected final int validate(final SendImageStatusParamDTO dto) throws IdexxDicomAEConfigServiceException {
        SendImageStatusParamDTO failureParamDTO = (SendImageStatusParamDTO) dto;
        return validator.validate(failureParamDTO);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.aeservices.impl.AbstractAEServiceImpl#doService(com.idexx
     * .dicom.services.dto.IdexxDicomApplicationEntityDTO)
     */

    protected final int doService(final SendImageStatusParamDTO dto) throws IdexxDicomAEConfigServiceException {

        List<IdexxSendImageJob> jobIdList = sendImageJobDao.getJob(dto.getJobId());
        setDTOList(jobIdList, dto.getJobId());

        return 1;
    }

    /**
     * This method set the AETitles to IdexxDicomApplicationEntityDTO list
     * 
     * @param aeTitleList
     */
    private void setDTOList(final List<IdexxSendImageJob> sendImageStatus, final List<String> jobIds) {
        dtos = new ArrayList<IdexxSendImageJobStatusDTO>();

        if (null == sendImageStatus || (null != sendImageStatus && sendImageStatus.isEmpty())) {
            LOG.info( "Empty IdexxSendImageJob ");
            IdexxSendImageJobStatusDTO dto = null;
            dto = this.createEmptyJobDTO("");
            dto.setJobStatusDescription(IdexxDicomServiceConstants.NO_JOBS_EXISTS);
            dto.setJobStatusCode(IdexxDicomServiceConstants.NO_JOBS_EXISTS);
            dtos.add(dto);
        } else {
            LOG.info( "Size of Entities" + sendImageStatus.size());
            cloneList = new ArrayList<String>();
            cloneList.addAll(jobIds);
            createJobDto(sendImageStatus);
            this.setEmptyDTOs();
        }
    }

    private void setEmptyDTOs() {
        for (String jobIds : cloneList) {
            dtos.add(createEmptyJobDTO(jobIds));
        }
    }

    /**
     * @param jobId
     * @return
     */
    private IdexxSendImageJobStatusDTO createEmptyJobDTO(final String jobId) {
        IdexxSendImageJobStatusDTO dto = new IdexxSendImageJobStatusDTO();
        dto.setJobId(jobId);
        dto.setJobStatusCode(IdexxDicomServiceConstants.JOB_ID_DOES_NOT_EXIST);
        dto.setJobStatusDescription(IdexxDicomServiceConstants.JOB_ID_DOES_NOT_EXIST);
        dto.setRetriedCount(0);
        return dto;
    }

    private void createJobDto(final List<IdexxSendImageJob> sendImageStatus) {

        for (IdexxSendImageJob job : sendImageStatus) {
            IdexxSendImageJobStatusDTO dto = new IdexxSendImageJobStatusDTO();
            dto.setJobId(job.getJobId());
            dto.setJobStatusCode(job.getJobStatus());
            dto.setJobStatusDescription(job.getJobStatusDescription());
            dto.setRetriedCount(job.getRetriesCount());
            dtos.add(dto);
            cloneList.remove(job.getJobId());
        }

    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.aeservices.impl.AbstractAEServiceImpl#sendResponse(com
     * .idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)
     */
    protected final List<IdexxSendImageJobStatusDTO> sendResponse() {
        return dtos;
    }
}
