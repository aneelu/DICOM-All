/**
 * 
 */
package com.idexx.dicom.sendimage.impl;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.log4j.Logger;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.entities.BaseDicomImPluginConfig;
import com.idexx.dicom.dao.ws.DicomConfigDao;
import com.idexx.dicom.sendimage.SendImageJobConstants;
import com.idexx.dicom.sendimage.ThreadController;

/**
 * @author vkandagatla
 * 
 */
public class ThreadControllerImpl implements ThreadController {
	
	private static final Logger LOG = Logger.getLogger(ThreadControllerImpl.class);
	
    /**
     * @param sendImageQue
     */
    public ThreadControllerImpl(final ConcurrentLinkedQueue<Runnable> sendImageQue, final DicomConfigDao configDao) {
        super();
        this.sendImageQue = sendImageQue;
        this.configDao = configDao;
    }

    ConcurrentLinkedQueue<Runnable> sendImageQue;

    /*
     * @see com.idexx.dicom.sendimage.ThreadController#isThreadAvailable()
     */
    @Override
    public final boolean isThreadAvailable() {
        return this.sendImageQue.size() > 0;
    }

    /*
     * @see
     * com.idexx.dicom.sendimage.ThreadController#createThread(com.idexx.dicom
     * .sendimage.impl.SendImageJobRunner)
     */
    @Override
    public final void start() {
        this.createNextPool();
    }

    /**
     * Create next set of jobs for pooling
     */
    private void createNextPool() {

        if (isThreadAvailable()) {
            ExecutorService pool = this.createPool();
            if (pool.isTerminated()) {
                LOG.info( "Pool is terminated...Creating next pool");
                createNextPool();
            } else {
                LOG.info( "Waiting All Thread to complete");
                while (!pool.isTerminated()) {
                    try {
                        Thread.sleep(SendImageJobConstants.SEND_IMAGE_JOB_PAUSE_TIME);
                    } catch (InterruptedException e) {
                        LOG.error(e.getMessage());
                    }
                }
            }
        }
    }

    private ExecutorService createPool() {
        int poolsize = this.computeExecutorCount();
        LOG.info( "Creating Executor Pool: " + poolsize);
        ExecutorService pool = Executors.newFixedThreadPool(poolsize);
        for (int start = 0; start < poolsize; start++) {
            Runnable processor = this.sendImageQue.poll();
            pool.execute(processor);
        }
        pool.shutdown();

        return pool;
    }

    /**
     * @return Determines how many thread executor objects should be created
     */
    private int computeExecutorCount() {
        int defaultThreadCount = this.getThreadCount();
        int queueLength = this.sendImageQue.size();
        int count = defaultThreadCount;
        if (queueLength < defaultThreadCount) {
            count = queueLength;
        }
        LOG.info( "Processing for " + count + " number of jobs");
        return count;
    }

    private DicomConfigDao configDao;

    /**
     * @return
     */
    private int getThreadCount() {
        LOG.info( "Getting THREAD COUNT COUNT CONFIG VALUE");
        int defaultCount = SendImageJobConstants.DEFAULT_QUARTZ_THREAD_COUNT;
        BaseDicomImPluginConfig config = configDao.getConfig(SendImageJobConstants.QUARTZ_THREAD_COUNT_CONFIG_NAME);

        String configValue = config.getConfigValue();
        if (!StringUtils.isEmpty(configValue)) {
            try {
                defaultCount = Integer.valueOf(configValue);
            } catch (NumberFormatException nfe) {
                defaultCount = SendImageJobConstants.DEFAULT_QUARTZ_THREAD_COUNT;
            }
        }
        LOG.info( "THREAD COUNT CONFIG VALUE IS: " + defaultCount);
        return defaultCount;
    }

}
