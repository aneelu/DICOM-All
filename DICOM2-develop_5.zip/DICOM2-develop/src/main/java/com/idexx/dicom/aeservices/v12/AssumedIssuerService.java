package com.idexx.dicom.aeservices.v12;

import com.idexx.dicom.services.dto.v12.AssumedIssuerEntityDTO;
import com.idexx.dicom.services.dto.v12.ReadAssumedIssuerDTO;
import com.idexx.dicom.services.dto.v12.SetAssumedIssuerDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

public interface AssumedIssuerService {
    
    String setAssumedIssuer(SetAssumedIssuerDTO dto) throws IdexxDicomAEConfigServiceException;
    AssumedIssuerEntityDTO readAssumedIssuer(ReadAssumedIssuerDTO dto) throws IdexxDicomAEConfigServiceException;
    boolean isAPIKeyValid(String apiKey) throws IdexxDicomAEConfigServiceException;
    boolean isValidSapId(String sapId) throws IdexxDicomAEConfigServiceException;
}
