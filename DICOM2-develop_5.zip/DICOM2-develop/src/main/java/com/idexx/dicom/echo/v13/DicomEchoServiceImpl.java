package com.idexx.dicom.echo.v13;

import java.io.IOException;

import org.dcm4che3.data.Attributes;
import org.dcm4che3.net.ApplicationEntity;
import org.dcm4che3.net.Connection;
import org.dcm4che3.net.Device;
import org.dcm4che3.tool.storescu.StoreSCU;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

// TODO: Auto-generated Javadoc
/**
 * The Class DicomEchoServiceImpl.
 *
 * @author lamarawadi
 * @version 1.3
 */
@Service("dicomEchoServiceImplV13")
public class DicomEchoServiceImpl {

	/** The remote hostname. */
	String remoteHostname = "aws-dico-jboss-dev01.dicom.idexxi.com";

	/** The remote port number. */
	int remotePortNumber = 11112;

	/** The default called aet. */
	String defaultCalledAET = "DCM4CHEE_MAIN";

	/** The device. */
	Device device = null;

	/** The ae. */
	ApplicationEntity ae = null;

	/** The conn. */
	Connection conn = null;

	/**
	 * Inits the.
	 *
	 * @param device
	 *            the device
	 * @param ae
	 *            the ae
	 * @param conn
	 *            the conn
	 */
	public void init(Device device, ApplicationEntity ae, Connection conn) {
		this.device = device;
		this.ae = ae;
		this.conn = conn;
	}

	/** The Constant log. */
	private static final Logger LOG = LoggerFactory.getLogger(DicomEchoServiceImpl.class);

	/**
	 * Echo.
	 *
	 * @param callingAET
	 *            the calling aet
	 * @return true, if successful
	 * @throws InterruptedException
	 *             the interrupted exception
	 * @throws IOException 
	 */
	public boolean echo(final String callingAET) throws InterruptedException, IOException {
		return echo(callingAET, remoteHostname, remotePortNumber);
	}

	/**
	 * Echo.
	 *
	 * @param callingAET
	 *            the calling aet
	 * @param calledAET
	 *            the called aet
	 * @return true, if successful
	 * @throws InterruptedException
	 *             the interrupted exception
	 * @throws IOException 
	 */
	public boolean echo(final String callingAET, final String calledAET) throws InterruptedException, IOException {
		return echo(callingAET, calledAET, remoteHostname, remotePortNumber);
	}

	/**
	 * Echo.
	 *
	 * @param callingAET
	 *            the calling aet
	 * @param hostName
	 *            the host name
	 * @param port
	 *            the port
	 * @return true, if successful
	 * @throws InterruptedException
	 *             the interrupted exception
	 * @throws IOException 
	 */
	public boolean echo(final String callingAET, final String hostName, final int port) throws InterruptedException, IOException {
		return echo(callingAET, "DCM4CHEE_MAIN", hostName, port);
	}

	/**
	 * Echo.
	 *
	 * @param callingAET
	 *            the calling aet
	 * @param calledAET
	 *            the called aet
	 * @param hostName
	 *            the host name
	 * @param port
	 *            the port
	 * @return true, if successful
	 * @throws InterruptedException
	 *             the interrupted exception
	 * @throws IOException 
	 */
	public boolean echo(final String callingAET, final String calledAET, final String hostName, final int port)
			throws InterruptedException, IOException {
		boolean returnValue = true;
		StoreSCU main = null;
		try {
			main = new StoreSCU(ae);
		} catch (IOException e) {
			LOG.error("Unable to echo the dicom server: " + e);
			throw e;
		}

		main.getAAssociateRQ().setCalledAET(calledAET);
		main.getRemoteConnection().setHostname(hostName);
		main.getRemoteConnection().setPort(port);
		main.getRemoteConnection().setTlsCipherSuites(conn.getTlsCipherSuites());
		main.getRemoteConnection().setTlsProtocols(conn.getTlsProtocols());
		main.setAttributes(new Attributes());

		try {
			main.open();
			main.echo();
		} catch (Exception exc) {
			LOG.error("Unable to echo the dicom server: " + exc);
			returnValue = false;
		} finally {
			try {
				main.close();
			} catch (IOException e) {
				LOG.error("Unable to echo the dicom server: " + e);
				returnValue = false;
			}
		}
		return returnValue;
	}
}