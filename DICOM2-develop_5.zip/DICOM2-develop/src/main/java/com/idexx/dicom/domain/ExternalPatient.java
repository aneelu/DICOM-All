package com.idexx.dicom.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "EXTERNAL_PATIENT_LINK")
@IdClass(ExternalPatientPK.class)
public class ExternalPatient implements Serializable {

    private String issuerOfPatientID;

    private String pimsPatientId;

    private String patientID;

    private Patient patient;

    /**
     * @return the issuerOfPatientID
     */
    @Id
    @Column(name = "ISSUER_OF_PATIENT_ID")
    public String getIssuerOfPatientID() {
	return issuerOfPatientID;
    }

    /**
     * @param issuerOfPatientID
     *            the issuerOfPatientID to set
     */
    public void setIssuerOfPatientID(String issuerOfPatientID) {
	this.issuerOfPatientID = issuerOfPatientID;
    }

    @Column(name = "PIMS_PATIENT_ID")
    public String getPimsPatientId() {
	return pimsPatientId;
    }

    public void setPimsPatientID(String pimsPatientId) {
	this.pimsPatientId = pimsPatientId;
    }


    /**
     * @return the patientID
     */
    @Id
    @Column(name = "PATIENT_ID")
    public String getPatientID() {
        return patientID;
    }

    /**
     * @param patientID the patientID to set
     */
    public void setPatientID(String patientID) {
        this.patientID = patientID;
    }

    /**
     * @param pimsPatientId the pimsPatientId to set
     */
    public void setPimsPatientId(String pimsPatientId) {
        this.pimsPatientId = pimsPatientId;
    }

    @ManyToOne(targetEntity = Patient.class)
    @JoinColumn(name = "PATIENT_ID", insertable=false, updatable=false)
    public Patient getPatient() {
	return patient;
    }

    public void setPatient(Patient patient) {
	this.patient = patient;
    }
}
