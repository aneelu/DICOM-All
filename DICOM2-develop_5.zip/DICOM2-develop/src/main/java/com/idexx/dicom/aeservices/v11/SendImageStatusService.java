/**
 * 
 */
package com.idexx.dicom.aeservices.v11;

import java.util.List;

import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v11.IdexxSendImageJobStatusDTO;
import com.idexx.dicom.services.sendimage.dto.v11.SendImageStatusParamDTO;

/**
 * @author mdindukurthi
 * 
 */
public interface SendImageStatusService {
    List<IdexxSendImageJobStatusDTO> performService(SendImageStatusParamDTO dto)
            throws IdexxDicomAEConfigServiceException;
}
