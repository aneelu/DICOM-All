/**
 * Validator for Send Image Params
 */
package com.idexx.dicom.ae.validator;

import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.SendImageJobParamDTO;

/**
 * @author vkandagatla
 *
 */
public interface IdexxSendImageValidator extends IdexxValidator {
    int validate(SendImageJobParamDTO dto) throws IdexxDicomAEConfigServiceException;
}
