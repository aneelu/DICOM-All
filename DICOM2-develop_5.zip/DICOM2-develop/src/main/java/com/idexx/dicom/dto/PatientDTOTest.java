/**
 * 
 */
package com.idexx.dicom.dto;

import java.util.List;

import com.idexx.imaging.imagemanager.soap.PatientDTO;
import com.idexx.imaging.imagemanager.soap.StudyDTO;

/**
 * @author vkandagatla
 *
 */
public class PatientDTOTest extends PatientDTO {
    private List<StudyDTO> studies;

    /**
     * @return the studies
     */
    public final List<StudyDTO> getStudies() {
        return studies;
    }

    /**
     * @param studies
     *            the studies to set
     */
    public final void setStudies(final List<StudyDTO> studies) {
        this.studies = studies;
    }

}
