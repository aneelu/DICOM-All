/**
 * 
 */
package com.idexx.dicom.store.authorization;

import com.idexx.dicom.exceptions.IdexxDicomAuthorizationException;

/**
 * @author vkandagatla
 * 
 */
public interface IdexxAuthorizationService {
    IdexxAuthorization authorize(final String aeTitle, final String instituteName) 
            throws IdexxDicomAuthorizationException;
}
