package com.idexx.dicom;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

import javax.annotation.PreDestroy;

import org.apache.commons.cli.ParseException;
import org.apache.log4j.Logger;
import org.dcm4che3.net.ApplicationEntity;
import org.dcm4che3.net.Connection;
import org.dcm4che3.net.Device;
import org.dcm4che3.net.service.DicomServiceRegistry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.idexx.dicom.proxy.dcmqrscp.DcmQRSCPProxy;

// TODO: Auto-generated Javadoc
/**
 * The Class IdexxDicomProxyServiceRegistry.
 */
@Component
@Scope("prototype")
public class IdexxDicomProxyServiceRegistry {

	/** The log. */
	private static Logger LOG = Logger.getLogger(IdexxDicomProxyServiceRegistry.class);

	/** The device. */
	private Device device = new Device("IDEXXDICOM_PROXY");

	/** The application entity. */
	private ApplicationEntity applicationEntity = new ApplicationEntity("*");

	/** The conn. */
	private final Connection conn = new Connection();

	/** The started. */
	protected boolean started = false;

	/** The input stream. */
	InputStream inputStream;

	/** The dcm qrscp. */
	@Autowired
	private DcmQRSCPProxy dcmQRSCP;

	/**
	 * Instantiates a new idexx dicom proxy service registry.
	 */
	public IdexxDicomProxyServiceRegistry() {
	}

	/**
	 * Inits the.
	 *
	 * @param instance
	 *            the instance
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 * @throws GeneralSecurityException
	 *             the general security exception
	 * @throws ParseException
	 *             the parse exception
	 */
	public void init(int instance) throws IOException, GeneralSecurityException, ParseException {
		LOG.info("Registering Idexx Dicom Proxy Services");
		Properties prop = getProperties();
		String hostName = prop.getProperty("LocalHostName");
		String port = "11120";
		if (instance == 1) {
			port = prop.getProperty("PROXY_PORT1");
		} else {
			port = prop.getProperty("PROXY_PORT2");
		}
		String aeTitle = prop.getProperty("PROXY_AE_TITLE");
		conn.setHostname(hostName);
		conn.setPort(Integer.valueOf(port));
		conn.setConnectionInstalled(true);
		device.setInstalled(true);

		applicationEntity.setAssociationAcceptor(true);
		applicationEntity.setAeInstalled(true);
		applicationEntity.setAETitle(aeTitle);
		applicationEntity.addConnection(conn);
		device.addConnection(conn);
		device.addApplicationEntity(applicationEntity);
		applicationEntity.setAssociationAcceptor(true);
		applicationEntity.addConnection(conn);

		DicomServiceRegistry serviceRegistry = new DicomServiceRegistry();
		started = true;

		String[] args1 = { "-b", aeTitle + ":" + port };
		dcmQRSCP.init(args1, device, applicationEntity, conn, serviceRegistry);

		ExecutorService executorService = Executors.newCachedThreadPool();
		ScheduledExecutorService scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
		device.setScheduledExecutor(scheduledExecutorService);
		device.setExecutor(executorService);
		device.bindConnections();
	}

	/**
	 * Gets the device.
	 *
	 * @return the device
	 */
	public final Device getDevice() {
		return device;
	}

	/**
	 * Sets the device.
	 *
	 * @param device
	 *            the new device
	 */
	public void setDevice(Device device) {
		this.device = device;
	}

	/**
	 * Gets the application entity.
	 *
	 * @return the application entity
	 */
	public ApplicationEntity getApplicationEntity() {
		return applicationEntity;
	}

	/**
	 * Sets the application entity.
	 *
	 * @param applicationEntity the new application entity
	 */
	public void setApplicationEntity(ApplicationEntity applicationEntity) {
		this.applicationEntity = applicationEntity;
	}

	/**
	 * Gets the properties.
	 *
	 * @return the properties
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 * @throws FileNotFoundException
	 *             the file not found exception
	 */
	private Properties getProperties() throws IOException, FileNotFoundException {
		Properties prop = new Properties();
		String propFileName = "storescpConfig.properties";

		inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(propFileName);

		if (inputStream != null) {
			prop.load(inputStream);
		} else {
			throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
		}
		return prop;
	}

	/**
	 * Destroy.
	 *
	 * @throws Exception
	 *             the exception
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.beans.factory.DisposableBean#destroy()
	 */
	@PreDestroy
	public void destroy() throws Exception {
		LOG.info("DESTROY METHOD CALLED: Closing all opened TCP Ports");

		if (!started)
			return;

		started = false;

		device.unbindConnections();
		((ExecutorService) device.getExecutor()).shutdown();
		device.getScheduledExecutor().shutdown();

		while (device.getConnections().get(0).isListening()) {
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				LOG.error("UnBinding TCP/IP Ports : " + e);
			}
		}

	}
}
