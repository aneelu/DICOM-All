package com.idexx.dcm4che3.tool.dcmqrscp;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Root;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.domain.Patient;
import com.idexx.dicom.domain.RequestDetails;
import com.idexx.dicom.domain.RequestDetails_;
import com.idexx.dicom.services.requestservice.dto.SearchDetailsDTO;

// TODO: Auto-generated Javadoc
/**
 * The Class PatientQueryBuilderTest.
 *
 * @author rkaranam
 * @version 1.3
 */
public class PatientQueryBuilderTest {
	
	/** The object under test. */
	@InjectMocks
	PatientQueryBuilder objectUnderTest = new PatientQueryBuilder();

	/** The entity manager mock. */
	@Mock
	private EntityManager entityManagerMock;
	
	/** The builder. */
	@Mock
	private CriteriaBuilder builder;
	
	/** The criteria query. */
	@Mock
	private CriteriaQuery<RequestDetails> criteriaQuery;
	
	/** The request details. */
	@Mock
	private Root<RequestDetails> requestDetails;
	
	/** The patient join. */
	@Mock
	private Join<RequestDetails, Patient> patientJoin;
	
	/** The condition object. */
	@Mock
	private Path<Object> conditionObject;
	
	/** The query. */
	@Mock
	private TypedQuery<RequestDetails> query;
	
	/**
	 * Setup.
	 */
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);			
		when(entityManagerMock.getCriteriaBuilder()).thenReturn(builder);	
		when(builder.createQuery(RequestDetails.class)).thenReturn(criteriaQuery);
		when(criteriaQuery.from(RequestDetails.class)).thenReturn(requestDetails);
		when(requestDetails.join(RequestDetails_.patient, JoinType.LEFT)).thenReturn(patientJoin);
		when(criteriaQuery.select(requestDetails)).thenReturn(criteriaQuery);
		when(entityManagerMock.createQuery(criteriaQuery)).thenReturn(query);
		when(requestDetails.get(anyString())).thenReturn(conditionObject);
	}

	/**
	 * Builds the search patient query test.
	 */
	@Test
	public void buildSearchPatientQueryTest() {
		
		List<RequestDetails> expectedRequestDetailsList = new ArrayList<RequestDetails>();
		
		List<String> modalities = new ArrayList<String>();
		modalities.add("MODALITY1");
		modalities.add("MODALITY2");
		
		List<String> status = new ArrayList<String>(0);
		
		SearchDetailsDTO searchObject = new SearchDetailsDTO();
		searchObject.setPatientId("PATIENTID");		
		searchObject.setModalities(modalities);
		searchObject.setPatientName("PATIENTNAME");
		searchObject.setSapId("SAPID");
		searchObject.setStartDate(new Date());
		searchObject.setEndDate(new Date());
		searchObject.setStatus(status);
		
		
		when(objectUnderTest.buildSearchPatientQuery(searchObject)).thenReturn(expectedRequestDetailsList);
		
		
		List<RequestDetails> actualRequestDetailsList = objectUnderTest.buildSearchPatientQuery(searchObject);
		
		assertEquals(expectedRequestDetailsList, actualRequestDetailsList);
		
	}
	
	/**
	 * Check status filter test.
	 */
	@Test
	public void checkStatusFilterTest() {
		
		List<RequestDetails> expectedRequestDetailsList = new ArrayList<RequestDetails>();		
		
		List<String> modalities = new ArrayList<String>();
		modalities.add("MODALITY1");
		modalities.add("MODALITY2");
		
		List<String> status = new ArrayList<String>();
		status.add("STATUS");
	
		SearchDetailsDTO searchObject = new SearchDetailsDTO();
		searchObject.setPatientId("PATIENTID");		
		searchObject.setModalities(modalities);
		searchObject.setPatientName("PATIENTNAME");
		searchObject.setSapId("SAPID");
		searchObject.setStartDate(new Date());
		searchObject.setEndDate(new Date());
		searchObject.setStatus(status);
		
		when(objectUnderTest.buildSearchPatientQuery(searchObject)).thenReturn(expectedRequestDetailsList);
		
	}


}
