/**
 * 
 */
package com.idexx.dao.sendimage;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.ImageManagerConfigurationProvider;
import com.idexx.dicom.sendimage.ImageManagerStoreServiceProviderWraper;
import com.idexx.dicom.store.DicomStoreServiceWithMetadataExtraction;
import com.idexx.dicom.store.impl.DicomStoreIMPluginService;
// TODO: Auto-generated Javadoc

/**
 * Test class from SendImageJobProviderImpl.
 *
 * @author vvanjarana
 * @version 1.3
 */
public class DicomStoreIMPluginServiceTest {

	/** The config values. */
	Map<String, String> configValues = new HashMap<String, String>();

	/** The config obj. */
	Map<String, Object> configObj = new HashMap<String, Object>();

	/** The obj in test. */
	@InjectMocks
	private DicomStoreIMPluginService objInTest = new DicomStoreIMPluginService();

	/** The image manager configuration provider. */
	@Mock
	private ImageManagerConfigurationProvider imageManagerConfigurationProvider;

	/** The image manager store service provider wraper. */
	@Mock
	private ImageManagerStoreServiceProviderWraper imageManagerStoreServiceProviderWraper;

	/**
	 * Sets the up.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Before
	public void setUp() throws Exception {

		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test_build service.
	 */
	@Test
	public void test_buildService() {

		when(imageManagerConfigurationProvider.geCofingurationValues()).thenReturn(configValues);
		objInTest.buildService();
		verify(imageManagerConfigurationProvider, times(1)).geCofingurationValues();
	}

	/**
	 * Test_dicom_store_service_metadataextraction.
	 */
	@Test
	public void test_dicom_store_service_metadataextraction() {

		when(imageManagerConfigurationProvider.geCofingurationValues()).thenReturn(configValues);
		DicomStoreServiceWithMetadataExtraction returnObj = objInTest
				.getDicomStoreServiceWithMetadataExtractionInstance(configObj);
		assertNotNull(returnObj);
	}

}
