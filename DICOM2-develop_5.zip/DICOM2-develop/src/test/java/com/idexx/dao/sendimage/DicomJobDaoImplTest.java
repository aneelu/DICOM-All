/**
 * 
 */
package com.idexx.dao.sendimage;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import javax.persistence.Query;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.dao.sendimage.DicomJobDao;
import com.idexx.dicom.dao.sendimage.impl.DicomJobDaoImpl;

// TODO: Auto-generated Javadoc
/**
 * Test class from DicomJobDaoImpl.
 *
 * @author vvanjarana
 * @version 1.3
 */
public class DicomJobDaoImplTest {

	/** The Constant TESTJOBID. */
	private static final String TESTJOBID = "Test Job Id";

	/** The Constant TESTDESTINATIONAETITLE. */
	private static final String TESTDESTINATIONAETITLE = "Destination AE Title";

	/** The Constant DESTINATIONHOSTNAME. */
	private static final String DESTINATIONHOSTNAME = "DESTINATIONHOSTNAME";

	/** The Constant DESTINATIONPORT. */
	private static final int DESTINATIONPORT = 123;

	/** The Constant JOBSTATUS. */
	private static final String JOBSTATUS = "JOBSTATUS";

	/** The Constant JOBSTATUSDESCRIPTION. */
	private static final String JOBSTATUSDESCRIPTION = "JOBSTATUSDESCRIPTION";

	/** The Constant IMAGEASSETID. */
	private static final String IMAGEASSETID = "IMAGEASSETID";

	/** The Constant RETRIESCOUNT. */
	private static final int RETRIESCOUNT = 123;

	/** The Constant CREATEDDATETIME. */
	private static final Timestamp CREATEDDATETIME = new Timestamp(System.currentTimeMillis() - (60 * 60 * 1000));;

	/** The Constant DOWNLOADEDIMFILEPATH. */
	private static final String DOWNLOADEDIMFILEPATH = "DOWNLOADEDIMFILEPATH";

	/** The Constant SENDINGAETITLE. */
	private static final String SENDINGAETITLE = "SENDINGAETITLE";

	/** The Constant UPDATEDDATETIME. */
	private static final Timestamp UPDATEDDATETIME = new Timestamp(System.currentTimeMillis());;

	/** The Constant S3IMAGEURL. */
	private static final String S3IMAGEURL = "S3IMAGEURL";

	/** The Constant SCHEDULETIMESTAMP. */
	private static final Date SCHEDULETIMESTAMP = new Date(System.currentTimeMillis());

	/** The obj in test. */
	@InjectMocks
	private DicomJobDao objInTest = new DicomJobDaoImpl();

	/** The entity manager. */
	private EntityManager entityManager;

	/** The query. */
	private Query query;

	/** The result list. */
	List<IdexxSendImageJob> resultList = new ArrayList<IdexxSendImageJob>();

	/** The idexxjob. */
	IdexxSendImageJob idexxjob = new IdexxSendImageJob();

	/**
	 * Sets the up.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Before
	public void setUp() throws Exception {

		idexxjob.setJobId(TESTJOBID);
		idexxjob.setCreatedDateTime(CREATEDDATETIME);
		idexxjob.setDestinationAETitle(TESTDESTINATIONAETITLE);
		idexxjob.setDestinationHostName(DESTINATIONHOSTNAME);
		idexxjob.setDestinationPort(DESTINATIONPORT);
		idexxjob.setDownloadedIMFilePath(DOWNLOADEDIMFILEPATH);
		idexxjob.setImageAssetId(IMAGEASSETID);
		idexxjob.setJobStatus(JOBSTATUS);
		idexxjob.setJobStatusDescription(JOBSTATUSDESCRIPTION);
		idexxjob.setRetriesCount(RETRIESCOUNT);
		idexxjob.setS3ImageUrl(S3IMAGEURL);
		idexxjob.setScheduleTimestamp(SCHEDULETIMESTAMP);
		idexxjob.setUpdatedDateTime(UPDATEDDATETIME);
		idexxjob.getScheduleTimestamp();
		idexxjob.getSendingAETitle();
		resultList.add(idexxjob);

		entityManager = mock(EntityManager.class);
		query = mock(Query.class);

		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test_get pending jobs.
	 */
	@Test
	public void test_getPendingJobs() {

		when(entityManager.createQuery(anyString())).thenReturn(query);
		when(query.setParameter(anyString(), anyString())).thenReturn(query);
		when(query.setMaxResults(1)).thenReturn(query);
		when(query.setLockMode(LockModeType.PESSIMISTIC_WRITE)).thenReturn(query);
		when(query.getResultList()).thenReturn(resultList);
		List<IdexxSendImageJob> originalList = objInTest.getPendingJobs("1");
		verify(entityManager, atLeast(1)).createQuery(anyString());
		assertEquals(originalList, resultList);
	}

	/**
	 * Test_update all_ inprogress_ jobs.
	 */
	@Test
	public void test_updateAll_Inprogress_Jobs() {

		when(entityManager.createQuery(anyString())).thenReturn(query);
		when(query.setParameter(anyString(), anyString())).thenReturn(query);
		when(query.getResultList()).thenReturn(resultList);
		objInTest.updateAllInProgressJobs("1");
		verify(entityManager, atLeast(1)).createQuery(anyString());
		verify(entityManager, atLeast(1)).persist(anyObject());
	}

	/**
	 * Test_get job_by_ id.
	 */
	@Test
	public void test_getJob_by_Id() {

		when(entityManager.createQuery(anyString())).thenReturn(query);
		when(query.setParameter(anyString(), anyString())).thenReturn(query);
		when(query.getSingleResult()).thenReturn(idexxjob);
		objInTest.getJobByJobId(TESTJOBID);
		verify(entityManager, atLeast(1)).createQuery(anyString());
	}

	/**
	 * Test_update_jobs_to_ inprogress.
	 */
	@Test
	public void test_update_jobs_to_Inprogress() {

		when(entityManager.createQuery(anyString())).thenReturn(query);
		when(query.setParameter(anyString(), anyString())).thenReturn(query);
		when(query.getResultList()).thenReturn(resultList);
		objInTest.updateJobsToInProgressStatus();
		verify(entityManager, atLeast(1)).createQuery(anyString());
		verify(entityManager, atLeast(1)).persist(anyObject());
	}

	/**
	 * Test_update_list_of_jobs_to_ inprogress.
	 */
	@Test
	public void test_update_list_of_jobs_to_Inprogress() {

		objInTest.updateJobsToInProgressStatus(resultList);
		verify(entityManager, atLeast(1)).persist(anyObject());
	}

	/**
	 * Test_update_job.
	 */
	@Test
	public void test_update_job() {

		when(entityManager.createQuery(anyString())).thenReturn(query);
		when(query.setParameter(anyString(), anyString())).thenReturn(query);
		when(query.getSingleResult()).thenReturn(idexxjob);
		objInTest.updateJob(idexxjob);
		verify(entityManager, atLeast(1)).persist(anyObject());
	}
}
