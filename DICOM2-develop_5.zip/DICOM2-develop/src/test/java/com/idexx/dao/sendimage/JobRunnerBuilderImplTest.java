/**
 * 
 */
package com.idexx.dao.sendimage;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.ae.entities.BaseDicomImPluginConfig;
import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.dao.ws.DicomConfigDao;
import com.idexx.dicom.mapper.EntityMapper;
import com.idexx.dicom.sendimage.ImagePresignedUrlProvider;
import com.idexx.dicom.sendimage.SendImage;
import com.idexx.dicom.sendimage.SendImageJobProvider;
import com.idexx.dicom.sendimage.SendImageJobUpdateService;
import com.idexx.dicom.sendimage.TimedImageDownloader;
import com.idexx.dicom.sendimage.impl.JobRunnerBuilderImpl;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.SendImagePendingJobDTO;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;

// TODO: Auto-generated Javadoc
/**
 * Test Cases Related CancelRequestServiceImpl.
 *
 * @author vvanjarana
 * @version 1.3
 */
public class JobRunnerBuilderImplTest {

	/** The Constant TEST_CONFIG_NAME. */
	private static final String TEST_CONFIG_NAME = "Test Config name";

	/** The Constant TEST_CONFIG_VALUE. */
	private static final String TEST_CONFIG_VALUE = "Test config value";

	/** The Constant JOB_ID. */
	private static final String JOB_ID = "TestJobId";

	/** The obj in test. */
	@InjectMocks
	private JobRunnerBuilderImpl objInTest = new JobRunnerBuilderImpl();

	/** The job provider. */
	@Mock
	private SendImageJobProvider jobProvider;

	/** The job update service. */
	@Mock
	private SendImageJobUpdateService jobUpdateService;

	/** The presigned url provider. */
	@Mock
	private ImagePresignedUrlProvider presignedUrlProvider;

	/** The image downloader. */
	@Mock
	private TimedImageDownloader imageDownloader;

	/** The config dao. */
	@Mock
	private DicomConfigDao configDao;

	/** The send image service. */
	@Mock
	private SendImage sendImageService;

	/** The entity mapper. */
	@Mock
	private EntityMapper entityMapper;

	/** The base dicom im plugin config. */
	private BaseDicomImPluginConfig baseDicomImPluginConfig;

	/** The jobs. */
	List<IdexxSendImageJob> jobs = new ArrayList<IdexxSendImageJob>();

	/** The send image dtos. */
	List<SendImagePendingJobDTO> sendImageDtos = new ArrayList<SendImagePendingJobDTO>();

	/**
	 * Sets the up.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Before
	public void setUp() throws Exception {

		baseDicomImPluginConfig = new BaseDicomImPluginConfig();
		baseDicomImPluginConfig.setConfigName(TEST_CONFIG_NAME);
		baseDicomImPluginConfig.setConfigValue(TEST_CONFIG_VALUE);

		IdexxSendImageJob job = new IdexxSendImageJob();
		job.setJobId(JOB_ID);
		jobs.add(job);

		SendImagePendingJobDTO sendJob = new SendImagePendingJobDTO();
		sendJob.setJobId(JOB_ID);
		sendImageDtos.add(sendJob);

		MockitoAnnotations.initMocks(this);

	}

	/**
	 * Test_update_inprogress_jobs.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 * @throws IdexxServiceException_Exception
	 *             the idexx service exception_ exception
	 */
	@Test
	public void test_update_inprogress_jobs()
			throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {

		when(configDao.getConfig(anyString())).thenReturn(baseDicomImPluginConfig);
		objInTest.patchInProgresstoPending();
		verify(jobProvider, times(1)).updateInProgressJobs(anyString());
	}

	/**
	 * Test_build.
	 */
	@Test
	public void test_build() {

		when(jobProvider.getPendingJobs(anyString())).thenReturn(jobs);
		doNothing().when(jobProvider).updateJobsToInProgressStatus(jobs);
		when(entityMapper.createPendingJobDto(jobs)).thenReturn(sendImageDtos);
		when(configDao.getConfig(anyString())).thenReturn(baseDicomImPluginConfig);
		objInTest.build();
	}

}
