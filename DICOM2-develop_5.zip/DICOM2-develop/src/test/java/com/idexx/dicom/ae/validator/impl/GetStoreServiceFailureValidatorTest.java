package com.idexx.dicom.ae.validator.impl;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;

import com.idexx.dicom.services.dto.IdexxFailureLogParamDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

// TODO: Auto-generated Javadoc
/**
 * The Class GetStoreServiceFailureValidatorTest.
 *
 * @author smallela
 * @version 1.3
 */
public class GetStoreServiceFailureValidatorTest {

	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(GetStoreServiceFailureValidatorTest.class);

	/** The Constant STARTDATE. */
	private static final String STARTDATE = "StartDate";

	/** The Constant ENDDATE. */
	private static final String ENDDATE = "EndDate";

	/** The validator. */
	@InjectMocks
	private GetStoreFailuresValidator validator = new GetStoreFailuresValidator();

	/**
	 * Sets the up.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * Test validate.
	 */
	@Test
	public final void testValidate() {
		
		IdexxFailureLogParamDTO idexxFailureLogParamDTO = new IdexxFailureLogParamDTO();
		idexxFailureLogParamDTO.setEndDate(ENDDATE);
		idexxFailureLogParamDTO.setStartDate(STARTDATE);
		int val = 0;
		try {
			val = validator.validateInputFields(idexxFailureLogParamDTO);
			fail("validation failed.");
		} catch (IdexxDicomAEConfigServiceException exp) {
			LOG.error(exp.getLocalizedMessage());

		}
		idexxFailureLogParamDTO.setEndDate("1997-12-31T23:59:59.1+05:30");
		idexxFailureLogParamDTO.setStartDate("1997-12-31T25:59:59.1+05:30");
		try {
			val = validator.validateInputFields(idexxFailureLogParamDTO);
			fail("validation failed.");
		} catch (IdexxDicomAEConfigServiceException exp) {
			LOG.error(exp.getLocalizedMessage());
		}
		idexxFailureLogParamDTO.setEndDate("1997-12-31T25:59:59.1+05:30");
		idexxFailureLogParamDTO.setStartDate("1997-12-31T23:59:59.1+05:30");
		try {
			val = validator.validateInputFields(idexxFailureLogParamDTO);
			fail("validation failed.");
		} catch (IdexxDicomAEConfigServiceException exp) {
			LOG.error(exp.getLocalizedMessage());
		}

		idexxFailureLogParamDTO.setEndDate("1997-12-31T22:59:59.1+05:30");
		idexxFailureLogParamDTO.setStartDate("1997-12-31T23:59:59.1+05:30");
		try {
			val = validator.validateInputFields(idexxFailureLogParamDTO);
			fail("validation failed.");
		} catch (IdexxDicomAEConfigServiceException exp) {
			LOG.error(exp.getLocalizedMessage());
		}
		idexxFailureLogParamDTO.setEndDate("1997-12-31T23:59:59.1+05:30");
		idexxFailureLogParamDTO.setStartDate("1997-12-31T23:59:59.1+05:30");
		try {
			val = validator.validateInputFields(idexxFailureLogParamDTO);
			assertTrue("Date Validation Failed", val == 1);
		} catch (IdexxDicomAEConfigServiceException exp) {
			LOG.error(exp.getLocalizedMessage());
			fail("validation failed.");
		}
	}

}
