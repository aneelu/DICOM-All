/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dicom.aeservices.impl;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.ae.entities.AEEntity;
import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.validator.impl.AbstractAETitleValidator;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.dto.AETitleDTO;
import com.idexx.dicom.services.dto.CreateAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

// TODO: Auto-generated Javadoc
/**
 * The Class CreateAETitleServiceTest.
 *
 * @author smallela
 * @version 1.3
 */
public class CreateAETitleServiceTest {

	/** The Constant AETITLE. */
	private static final String AETITLE = "aeTitle";

	/** The Constant INSTITUTENAME. */
	private static final String INSTITUTENAME = "instituteName";

	/** The Constant SAPID. */
	private static final String SAPID = "sapId";

	/** The Constant APIKEY. */
	private static final String APIKEY = "apiKey";

	/** The Constant HOSTNAME. */
	private static final String HOSTNAME = "hostName";

	/** The Constant GENERAL_DB_FAILURE. */
	private static final String GENERAL_DB_FAILURE = "ERR_general_db_fail";

	/** The service. */
	@InjectMocks
	private CreateAETitleService service = new CreateAETitleService();

	/** The validator. */
	@Mock
	private AbstractAETitleValidator validator;

	/** The ae title dao. */
	@Mock
	private AETitleDao aeTitleDao;

	/** The idexx dicom ws authorize service. */
	@Mock
	private IdexxDicomWSAthorizationServiceImpl idexxDicomWsAuthorizeService;

	/** The ae title dto. */
	AETitleDTO aeTitleDTO = new AETitleDTO();

	/** The create ae title dto. */
	CreateAETitleDTO createAETitleDTO = new CreateAETitleDTO();

	/** The ae entity. */
	AEEntity aeEntity = new AEEntity();

	/** The ae title. */
	AETitle aeTitle = new AETitle();

	/**
	 * Sets the up.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Before
	public void setUp() throws Exception {

		createAETitleDTO.setAeTitle(AETITLE);
		createAETitleDTO.setInstituteName(INSTITUTENAME);
		createAETitleDTO.setSapId(SAPID);
		createAETitleDTO.setApiKey(APIKEY);
		createAETitleDTO.setHostName(HOSTNAME);
		createAETitleDTO.setIdentifiedByAeTitleOnly(false);

		aeEntity.setAeTitle(createAETitleDTO.getAeTitle());
		aeEntity.setHostName(createAETitleDTO.getHostName());
		aeEntity.setPort(createAETitleDTO.getPort());

		aeTitle.setAeTitle(createAETitleDTO.getAeTitle());
		aeTitle.setApiKey(createAETitleDTO.getApiKey());
		aeTitle.setSapId(createAETitleDTO.getSapId());
		aeTitle.setEnabled(true);
		aeTitle.setIdentifiedByaeTitleOnly(createAETitleDTO.isIdentifiedByAeTitleOnly());

		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test validate.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public final void testValidate() throws IdexxDicomAEConfigServiceException {

		when(validator.validate(any(AETitleDTO.class))).thenReturn(1);
		int val = service.validate(aeTitleDTO);
		assertTrue("Create AE Failed#1", 1 == val);
	}

	/**
	 * Test do service.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public void testDoService() throws IdexxDicomAEConfigServiceException {

		createAETitleDTO.setDvmSpecialist(true);
		doNothing().when(aeTitleDao).createAE(aeEntity);
		int val = service.doService(createAETitleDTO);
		assertTrue("Set AE statusFailed#1", 1 == val);
	}

	/**
	 * Test do service2.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public void testDoService2() throws IdexxDicomAEConfigServiceException {

		createAETitleDTO.setDvmSpecialist(false);
		String instituteName = null;
		createAETitleDTO.setInstituteName(instituteName);
		aeTitle.setInstituteName(instituteName);
		doNothing().when(aeTitleDao).createAETitle(aeTitle);
		int val = service.doService(createAETitleDTO);
		assertTrue("Set AE statusFailed#1", 1 == val);
	}

	/**
	 * Exception test2.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = Exception.class)
	public void exceptionTest2() throws IdexxDicomAEConfigServiceException {

		doThrow(new IdexxDicomAEConfigServiceException(GENERAL_DB_FAILURE, GENERAL_DB_FAILURE)).when(aeTitleDao)
				.createAE(aeEntity);
		service.doService(createAETitleDTO);
	}

}
