/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dicom.ae.validator.impl.v13;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.dto.v13.AETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

// TODO: Auto-generated Javadoc
/**
 * The Class DeleteAETitleValidatorTest.
 *
 * @author smallela
 * @version 1.3
 */
public class DeleteAETitleValidatorTest {

	/** The Constant AETITLE. */
	private static final String AETITLE = "AeTitle";

	/** The Constant INSTITUTENAME. */
	private static final String INSTITUTENAME = "InstituteName";

	/** The validator. */
	@InjectMocks
	private DeleteAETitleValidator validator = new DeleteAETitleValidator();

	/** The ae title dao. */
	@Mock
	private AETitleDao aeTitleDao;

	/** The ae title dto. */
	AETitleDTO aeTitleDTO = new AETitleDTO();

	/**
	 * Sets the up.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test validate input fields.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public final void testValidateInputFields() throws IdexxDicomAEConfigServiceException {

		int val = validator.validateInputFields(aeTitleDTO);
		assertTrue("Validation Failing#1", val == 1);
		verify(validator, times(1)).validateInputFields(aeTitleDTO);
	}

	/**
	 * Test validate input fields2.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public final void testValidateInputFields2() throws IdexxDicomAEConfigServiceException {

		aeTitleDTO.setAeTitle(AETITLE);
		int val = validator.validateInputFields(aeTitleDTO);
		assertTrue("Validation Failing#1", val == 1);

	}

	/**
	 * Test validate db fields.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public final void testValidateDBFields() throws IdexxDicomAEConfigServiceException {

		when(aeTitleDao.findAETitle(AETITLE)).thenThrow(new IdexxDicomAEConfigDbException());
		aeTitleDTO.setAeTitle(AETITLE);
		int val = validator.validateDBFields(aeTitleDTO);
		assertTrue("DB Validating Failed#1", 1 == val);
		verify(validator, times(1)).validateDBFields(aeTitleDTO);
	}

	/**
	 * Test validate db fields2.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public final void testValidateDBFields2() throws IdexxDicomAEConfigServiceException {

		List<AETitle> registeredAEList = new ArrayList<AETitle>();
		AETitleDTO aeTitleDTO = new AETitleDTO();
		aeTitleDTO.setAeTitle(AETITLE);
		when(aeTitleDao.findAETitle(AETITLE)).thenReturn(registeredAEList);
		int val = validator.validateDBFields(aeTitleDTO);
		assertTrue("DB Validating Failed#2", 1 == val);
		verify(validator, times(1)).validateDBFields(aeTitleDTO);
	}

	/**
	 * Test validate db fields3.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public final void testValidateDBFields3() throws IdexxDicomAEConfigServiceException {

		final List<AETitle> registeredAEList = new ArrayList<AETitle>();
		AETitle aeTitle = new AETitle();
		aeTitle.setAeTitle(AETITLE);
		aeTitle.setIdentifiedByaeTitleOnly(true);
		registeredAEList.add(aeTitle);
		AETitleDTO aeTitleDTO = new AETitleDTO();
		aeTitleDTO.setAeTitle(AETITLE);
		when(aeTitleDao.findAETitle(AETITLE)).thenReturn(registeredAEList);
		int val = validator.validateDBFields(aeTitleDTO);
		assertTrue("DB Validating Failed#3", 1 == val);
	}

	/**
	 * Test validate db fields4.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public final void testValidateDBFields4() throws IdexxDicomAEConfigServiceException {

		final List<AETitle> registeredAEList = new ArrayList<AETitle>();
		AETitle aeTitle = new AETitle();
		aeTitle.setAeTitle(AETITLE);
		aeTitle.setIdentifiedByaeTitleOnly(false);
		registeredAEList.add(aeTitle);
		AETitleDTO aeTitleDTO = new AETitleDTO();
		aeTitleDTO.setAeTitle(AETITLE);
		when(aeTitleDao.findAETitle(AETITLE)).thenReturn(registeredAEList);
		int val = validator.validateDBFields(aeTitleDTO);
		assertTrue("DB Validating Failed#3", 1 == val);
	}

	/**
	 * Test validate db fields5.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public final void testValidateDBFields5() throws IdexxDicomAEConfigServiceException {

		final List<AETitle> registeredAEList = new ArrayList<AETitle>();
		final List<AETitle> registeredAEListOther = new ArrayList<AETitle>();
		AETitle aeTitle = new AETitle();
		aeTitle.setAeTitle(AETITLE);
		aeTitle.setInstituteName(INSTITUTENAME);
		aeTitle.setIdentifiedByaeTitleOnly(false);
		registeredAEList.add(aeTitle);
		AETitleDTO aeTitleDTO = new AETitleDTO();
		aeTitleDTO.setAeTitle(AETITLE);
		aeTitleDTO.setInstituteName(INSTITUTENAME);
		when(aeTitleDao.findAETitle(AETITLE)).thenReturn(registeredAEList);
		when(aeTitleDao.findAETitle(AETITLE, INSTITUTENAME)).thenReturn(registeredAEListOther);
		int val = validator.validateDBFields(aeTitleDTO);
		assertTrue("DB Validating Failed#3", 1 == val);
		verify(validator, times(1)).validateDBFields(aeTitleDTO);
	}

	/**
	 * Test validate db fields6.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public final void testValidateDBFields6() throws IdexxDicomAEConfigServiceException {

		final List<AETitle> registeredAEList = new ArrayList<AETitle>();
		AETitle aeTitle = new AETitle();
		aeTitle.setAeTitle(AETITLE);
		aeTitle.setInstituteName(INSTITUTENAME);
		aeTitle.setIdentifiedByaeTitleOnly(false);
		registeredAEList.add(aeTitle);
		AETitleDTO aeTitleDTO = new AETitleDTO();
		aeTitleDTO.setAeTitle(AETITLE);
		aeTitleDTO.setInstituteName(INSTITUTENAME);
		when(aeTitleDao.findAETitle(AETITLE)).thenReturn(registeredAEList);
		when(aeTitleDao.findAETitle(AETITLE, INSTITUTENAME)).thenReturn(registeredAEList);
		int val = validator.validateDBFields(aeTitleDTO);
		assertTrue("DB Validating Failed#3", 1 == val);
	}

}
