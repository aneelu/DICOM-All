package com.idexx.dicom.ae.validator.impl;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;

import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.SendImageStatusParamDTO;

// TODO: Auto-generated Javadoc
/**
 * The Class IdexxSendImageStatusValidatorImplTest.
 *
 * @author smallela
 * @version 1.3
 */
public class IdexxSendImageStatusValidatorImplTest {

	/** The Constant APIKEY. */
	private static final String APIKEY = "ApiKey";

	/** The Constant JOBID. */
	private static final String JOBID = "JobId";

	/** The validator. */
	@InjectMocks
	private IdexxSendImageStatusValidatorImpl validator = new IdexxSendImageStatusValidatorImpl();

	/** The send image status param dto. */
	SendImageStatusParamDTO sendImageStatusParamDTO;

	/**
	 * Sets the up.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Before
	public void setUp() throws Exception {
		
		sendImageStatusParamDTO = new SendImageStatusParamDTO();
	}

	/**
	 * Test validate.
	 */
	@Test
	public void testValidate() {

		sendImageStatusParamDTO.setApiKey("");
		try {
			validator.validate(sendImageStatusParamDTO);
			fail("IdexxSendImageStatusValidatorImpl Failed to validate 1.0 ");
		} catch (IdexxDicomAEConfigServiceException exp) {
			assertTrue("IdexxSendImageStatusValidatorImpl Failed to validate 1.1 ",
					IdexxSendImageStatusValidatorImpl.MISSING_MANDATORY.equalsIgnoreCase(exp.getErrorCode()));
		}
		sendImageStatusParamDTO.setApiKey(null);
		try {
			validator.validate(sendImageStatusParamDTO);
			fail("IdexxSendImageStatusValidatorImpl Failed to validate 2.0 ");
		} catch (IdexxDicomAEConfigServiceException exp) {
			assertTrue("IdexxSendImageStatusValidatorImpl Failed to validate 2.1 ",
					IdexxSendImageStatusValidatorImpl.MISSING_MANDATORY.equalsIgnoreCase(exp.getErrorCode()));
		}
	}

	/**
	 * Test validate1.
	 */
	@Test
	public void testValidate1() {

		sendImageStatusParamDTO.setApiKey(APIKEY);
		sendImageStatusParamDTO.setJobId(null);
		try {
			validator.validate(sendImageStatusParamDTO);
			fail("IdexxSendImageStatusValidatorImpl Failed to validate 1.0 ");
		} catch (IdexxDicomAEConfigServiceException exp) {
			assertTrue("IdexxSendImageStatusValidatorImpl Failed to validate 1.1 ",
					IdexxSendImageStatusValidatorImpl.MISSING_MANDATORY.equalsIgnoreCase(exp.getErrorCode()));
		}
		List<String> listofjobs = new ArrayList<String>();
		listofjobs.add(JOBID);
		sendImageStatusParamDTO.setJobId(listofjobs);
		sendImageStatusParamDTO.setApiKey(APIKEY);
		try {
			int val = validator.validate(sendImageStatusParamDTO);
			assertTrue("IdexxSendImageStatusValidatorImpl Failed to validate 3.0 ", 1 == val);

		} catch (IdexxDicomAEConfigServiceException exp) {
			fail("IdexxSendImageStatusValidatorImpl Failed to validate 3.1 ");
		}

	}

}
