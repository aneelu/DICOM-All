package com.idexx.dicom.aeservices.impl;

import org.junit.Test;

// TODO: Auto-generated Javadoc
/**
 * Abstract class will start up spring boot application context for unit tests .
 *
 * @author vvanjarana
 * @version 1.3
 */
public abstract class AbstractTestConfig {

	/**
	 * Context loads.
	 */
	@Test
	public void contextLoads() {
	}
}
