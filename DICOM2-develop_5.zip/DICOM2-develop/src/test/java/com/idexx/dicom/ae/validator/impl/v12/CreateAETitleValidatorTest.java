/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dicom.ae.validator.impl.v12;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.ae.entities.AEEntity;
import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.entities.IdexxInvalidAE;
import com.idexx.dicom.aeservices.impl.v13.AbstractTestConfig;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.dto.v12.AETitleDTO;
import com.idexx.dicom.services.dto.v12.CreateAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

// TODO: Auto-generated Javadoc
/**
 * The Class CreateAETitleValidatorTest.
 *
 * @author smallela
 * @version 1.3
 */
public class CreateAETitleValidatorTest extends AbstractTestConfig {

	/** The Constant DEFAULT_DCM_PORT. */
	private static final int DEFAULT_DCM_PORT = 11112;

	/** The Constant DEFAULT_PORT. */
	private static final int DEFAULT_PORT = 8080;

	/** The Constant AETITLE. */
	private static final String AETITLE = "AeTitle";

	/** The Constant HOSTNAME. */
	private static final String HOSTNAME = "127.0.0.1";

	/** The Constant APIKEY. */
	private static final String APIKEY = "ApiKey";

	/** The Constant INSTITUTENAME. */
	private static final String INSTITUTENAME = "InstituteName";

	/** The Constant SAPID. */
	private static final String SAPID = "SapId";

	/** The validator. */
	@InjectMocks
	private AbstractAETitleValidator validator = new CreateAETitleValidator();

	/** The ae title dao. */
	@Mock
	private AETitleDao aeTitleDao;

	/** The ae title dto. */
	AETitleDTO aeTitleDTO = new CreateAETitleDTO();

	/**
	 * Sets the up.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Before
	public void setUp() throws Exception {
		
		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test validate input fields.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public final void testValidateInputFields() throws IdexxDicomAEConfigServiceException {

		int val = validator.validateInputFields(aeTitleDTO);
		verify(validator, times(1)).validateInputFields(aeTitleDTO);
		assertTrue("Validation Failing#1", val == 1);
	}

	/**
	 * Test validate input fields no host.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public final void testValidateInputFieldsNoHost() throws IdexxDicomAEConfigServiceException {

		CreateAETitleDTO createAETitleDTO = new CreateAETitleDTO();
		createAETitleDTO.setDvmSpecialist(true);
		createAETitleDTO.setAeTitle(AETITLE);
		int val = validator.validateInputFields(createAETitleDTO);
		verify(validator, times(1)).validateInputFields(createAETitleDTO);
		assertTrue("Validation Failing#1", val == 1);
	}

	/**
	 * Test validate input fields no port.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public final void testValidateInputFieldsNoPort() throws IdexxDicomAEConfigServiceException {

		CreateAETitleDTO createAETitleDTO = new CreateAETitleDTO();
		createAETitleDTO.setDvmSpecialist(true);
		createAETitleDTO.setAeTitle(AETITLE);
		createAETitleDTO.setHostName(HOSTNAME);
		int val = validator.validateInputFields(createAETitleDTO);
		verify(validator, times(1)).validateInputFields(createAETitleDTO);
		assertTrue("Validation Failing#1", val == 1);
	}

	/**
	 * Test validate input fields no api key.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public final void testValidateInputFieldsNoAPIKey() throws IdexxDicomAEConfigServiceException {

		CreateAETitleDTO createAETitleDTO = new CreateAETitleDTO();
		createAETitleDTO.setDvmSpecialist(false);
		createAETitleDTO.setAeTitle(AETITLE);
		int val = validator.validateInputFields(createAETitleDTO);
		verify(validator, times(1)).validateInputFields(createAETitleDTO);
		assertTrue("Validation Failing#1", val == 1);
	}

	/**
	 * Test validate input fields no sapid.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public final void testValidateInputFieldsNoSAPID() throws IdexxDicomAEConfigServiceException {

		CreateAETitleDTO createAETitleDTO = new CreateAETitleDTO();
		createAETitleDTO.setDvmSpecialist(false);
		createAETitleDTO.setAeTitle(AETITLE);
		createAETitleDTO.setApiKey(APIKEY);
		int val = validator.validateInputFields(createAETitleDTO);
		assertTrue("Validation Failing#1", val == 1);
		verify(validator, times(1)).validateInputFields(createAETitleDTO);

	}

	/**
	 * Test validate input fields2.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public final void testValidateInputFields2() throws IdexxDicomAEConfigServiceException {

		CreateAETitleDTO createAETitleDTO = new CreateAETitleDTO();
		createAETitleDTO.setDvmSpecialist(true);
		createAETitleDTO.setHostName(HOSTNAME);
		createAETitleDTO.setPort(DEFAULT_PORT);
		createAETitleDTO.setAeTitle(AETITLE);
		createAETitleDTO.setSapId(SAPID);
		createAETitleDTO.setInstituteName(INSTITUTENAME);
		createAETitleDTO.setApiKey(APIKEY);
		int val = validator.validateInputFields(createAETitleDTO);
		assertTrue("Validation Faled#2", 1 == val);
	}

	/**
	 * Test validate input fields3.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public final void testValidateInputFields3() throws IdexxDicomAEConfigServiceException {

		CreateAETitleDTO createAETitleDTO = new CreateAETitleDTO();
		createAETitleDTO.setDvmSpecialist(false);
		createAETitleDTO.setHostName(HOSTNAME);
		createAETitleDTO.setPort(DEFAULT_PORT);
		createAETitleDTO.setAeTitle(AETITLE);
		createAETitleDTO.setSapId(SAPID);
		createAETitleDTO.setIdentifiedByAeTitleOnly(true);
		createAETitleDTO.setApiKey(APIKEY);
		int val = validator.validateInputFields(createAETitleDTO);
		assertTrue("Validation Faled#2", 1 == val);

	}

	/**
	 * Test validate input fields4.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public final void testValidateInputFields4() throws IdexxDicomAEConfigServiceException {

		CreateAETitleDTO createAETitleDTO = new CreateAETitleDTO();
		createAETitleDTO.setAeTitle(AETITLE);
		createAETitleDTO.setSapId(SAPID);
		createAETitleDTO.setApiKey(APIKEY);
		int val = validator.validateInputFields(createAETitleDTO);
		assertTrue("Validation Faled#2", 1 == val);
		verify(validator, times(1)).validateInputFields(createAETitleDTO);

	}

	/**
	 * Test validate db fields.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public final void testValidateDBFields() throws IdexxDicomAEConfigServiceException {

		CreateAETitleDTO createAETitleDTO = new CreateAETitleDTO();
		createAETitleDTO.setAeTitle(AETITLE);
		createAETitleDTO.setSapId(SAPID);
		createAETitleDTO.setInstituteName(INSTITUTENAME);
		createAETitleDTO.setApiKey(APIKEY);
		createAETitleDTO.setDvmSpecialist(false);
		createAETitleDTO.setIdentifiedByAeTitleOnly(false);
		when(aeTitleDao.getInvalidAETitle(AETITLE)).thenThrow(new IdexxDicomAEConfigDbException());
		int val = validator.validateDBFields(createAETitleDTO);
		assertTrue("DB Validating Failed#1", 1 == val);
		verify(validator, times(1)).validateDBFields(createAETitleDTO);

	}

	/**
	 * Test validate db fields2.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public final void testValidateDBFields2() throws IdexxDicomAEConfigServiceException {

		final IdexxInvalidAE ae = new IdexxInvalidAE();
		ae.setAeTitle(AETITLE);
		CreateAETitleDTO createAETitleDTO = new CreateAETitleDTO();
		createAETitleDTO.setAeTitle(AETITLE);
		createAETitleDTO.setSapId(SAPID);
		createAETitleDTO.setInstituteName(INSTITUTENAME);
		createAETitleDTO.setApiKey(APIKEY);
		createAETitleDTO.setIdentifiedByAeTitleOnly(false);
		when(aeTitleDao.getInvalidAETitle(AETITLE)).thenReturn(ae);
		int val = validator.validateDBFields(createAETitleDTO);
		assertTrue("DB Validating Failed#2", 1 == val);
		verify(validator, times(1)).validateDBFields(createAETitleDTO);
	}

	/**
	 * Test validate db fields3.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public final void testValidateDBFields3() throws IdexxDicomAEConfigServiceException {

		final IdexxInvalidAE ae = null;
		final List<AETitle> registeredAEList = new ArrayList<AETitle>();
		CreateAETitleDTO createAETitleDTO = new CreateAETitleDTO();
		createAETitleDTO.setAeTitle(AETITLE);
		createAETitleDTO.setSapId(SAPID);
		createAETitleDTO.setInstituteName(INSTITUTENAME);
		createAETitleDTO.setApiKey(APIKEY);
		createAETitleDTO.setIdentifiedByAeTitleOnly(true);
		when(aeTitleDao.getInvalidAETitle(AETITLE)).thenReturn(ae);
		when(aeTitleDao.findAETitle(AETITLE)).thenReturn(registeredAEList);
		int val = validator.validateDBFields(createAETitleDTO);
		assertTrue("DB Validating Failed#1", 1 == val);

	}

	/**
	 * Test validate db fields ae.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public final void testValidateDBFieldsAe() throws IdexxDicomAEConfigServiceException {

		final List<AEEntity> registeredAEList = new ArrayList<AEEntity>();
		CreateAETitleDTO createAETitleDTO = new CreateAETitleDTO();
		createAETitleDTO.setAeTitle(AETITLE);
		createAETitleDTO.setDvmSpecialist(true);
		createAETitleDTO.setHostName(HOSTNAME);
		createAETitleDTO.setPort(DEFAULT_DCM_PORT);
		when(aeTitleDao.findAE(AETITLE)).thenReturn(registeredAEList);
		int val = validator.validateDBFields(createAETitleDTO);
		assertTrue("DB Validating Failed#1", 1 == val);
	}

	/**
	 * Test validate db fields ae exists.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public final void testValidateDBFieldsAeExists() throws IdexxDicomAEConfigServiceException {

		AEEntity ae = new AEEntity();
		ae.setAeTitle(AETITLE);
		final List<AEEntity> registeredAEList = new ArrayList<AEEntity>();
		registeredAEList.add(ae);
		CreateAETitleDTO createAETitleDTO = new CreateAETitleDTO();
		createAETitleDTO.setAeTitle(AETITLE);
		createAETitleDTO.setDvmSpecialist(true);
		createAETitleDTO.setHostName(HOSTNAME);
		createAETitleDTO.setPort(DEFAULT_DCM_PORT);
		when(aeTitleDao.findAE(AETITLE)).thenReturn(registeredAEList);
		int val = validator.validateDBFields(createAETitleDTO);
		assertTrue("DB Validating Failed#1", 1 == val);
		verify(validator, times(1)).validateDBFields(createAETitleDTO);
	}

	/**
	 * Test validate db fields4.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public final void testValidateDBFields4() throws IdexxDicomAEConfigServiceException {

		final IdexxInvalidAE ae = null;
		final List<AETitle> registeredAEList = new ArrayList<AETitle>();
		AETitle aeTitle = new AETitle();
		aeTitle.setAeTitle(AETITLE);
		aeTitle.setIdentifiedByaeTitleOnly(true);
		registeredAEList.add(aeTitle);
		CreateAETitleDTO createAETitleDTO = new CreateAETitleDTO();
		createAETitleDTO.setAeTitle(AETITLE);
		createAETitleDTO.setSapId(SAPID);
		createAETitleDTO.setInstituteName(INSTITUTENAME);
		createAETitleDTO.setApiKey(APIKEY);
		createAETitleDTO.setIdentifiedByAeTitleOnly(true);
		when(aeTitleDao.getInvalidAETitle(AETITLE)).thenReturn(ae);
		when(aeTitleDao.findAETitle(AETITLE)).thenReturn(registeredAEList);
		int val = validator.validateDBFields(createAETitleDTO);
		assertTrue("DB Validating Failed#2", 1 == val);
		verify(validator, times(1)).validateDBFields(createAETitleDTO);
	}

	/**
	 * Test validate db fields5.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public final void testValidateDBFields5() throws IdexxDicomAEConfigServiceException {

		final IdexxInvalidAE ae = null;
		final List<AETitle> registeredAEList = new ArrayList<AETitle>();
		AETitle aeTitle = new AETitle();
		aeTitle.setAeTitle(AETITLE);
		aeTitle.setIdentifiedByaeTitleOnly(false);
		aeTitle.setInstituteName(INSTITUTENAME);
		registeredAEList.add(aeTitle);
		CreateAETitleDTO createAETitleDTO = new CreateAETitleDTO();
		createAETitleDTO.setAeTitle(AETITLE);
		createAETitleDTO.setSapId(SAPID);
		createAETitleDTO.setInstituteName(INSTITUTENAME);
		createAETitleDTO.setApiKey(APIKEY);
		createAETitleDTO.setIdentifiedByAeTitleOnly(false);
		when(aeTitleDao.getInvalidAETitle(AETITLE)).thenReturn(ae);
		when(aeTitleDao.findAETitle(AETITLE)).thenReturn(registeredAEList);
		when(aeTitleDao.findAETitle(AETITLE, INSTITUTENAME)).thenReturn(registeredAEList);
		int val = validator.validateDBFields(createAETitleDTO);
		assertTrue("DB Validating Failed#2", 1 == val);
		verify(validator, times(1)).validateDBFields(createAETitleDTO);
	}

	/**
	 * Test validate db fields6.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public final void testValidateDBFields6() throws IdexxDicomAEConfigServiceException {

		final IdexxInvalidAE ae = null;
		final List<AETitle> registeredAEList = new ArrayList<AETitle>();
		final List<AETitle> registeredAEListEmpty = new ArrayList<AETitle>();
		AETitle aeTitle = new AETitle();
		aeTitle.setAeTitle(AETITLE);
		aeTitle.setIdentifiedByaeTitleOnly(false);
		aeTitle.setInstituteName(INSTITUTENAME);
		registeredAEList.add(aeTitle);
		CreateAETitleDTO createAETitleDTO = new CreateAETitleDTO();
		createAETitleDTO.setAeTitle(AETITLE);
		createAETitleDTO.setSapId(SAPID);
		createAETitleDTO.setInstituteName(INSTITUTENAME);
		createAETitleDTO.setApiKey(APIKEY);
		createAETitleDTO.setIdentifiedByAeTitleOnly(false);
		when(aeTitleDao.getInvalidAETitle(AETITLE)).thenReturn(ae);
		when(aeTitleDao.findAETitle(AETITLE)).thenReturn(registeredAEList);
		when(aeTitleDao.findAETitle(AETITLE, INSTITUTENAME)).thenReturn(registeredAEListEmpty);
		int val = validator.validateDBFields(createAETitleDTO);
		assertTrue("DB Validating Failed#2", 1 == val);

	}

	/**
	 * Test validate.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public final void testValidate() throws IdexxDicomAEConfigServiceException {

		final IdexxInvalidAE ae = null;
		final List<AETitle> registeredAEList = new ArrayList<AETitle>();
		final List<AETitle> registeredAEListEmpty = new ArrayList<AETitle>();
		AETitle aeTitle = new AETitle();
		aeTitle.setAeTitle(AETITLE);
		aeTitle.setIdentifiedByaeTitleOnly(false);
		aeTitle.setInstituteName(INSTITUTENAME);
		registeredAEList.add(aeTitle);
		CreateAETitleDTO createAETitleDTO = new CreateAETitleDTO();
		createAETitleDTO.setAeTitle(AETITLE);
		createAETitleDTO.setSapId(SAPID);
		createAETitleDTO.setInstituteName(INSTITUTENAME);
		createAETitleDTO.setApiKey(APIKEY);
		createAETitleDTO.setIdentifiedByAeTitleOnly(false);
		when(aeTitleDao.getInvalidAETitle(AETITLE)).thenReturn(ae);
		when(aeTitleDao.findAETitle(AETITLE)).thenReturn(registeredAEList);
		when(aeTitleDao.findAETitle(AETITLE, INSTITUTENAME)).thenReturn(registeredAEListEmpty);
		int val = validator.validate(createAETitleDTO);
		assertTrue("DB Validating Failed#2", 1 == val);
	}
}
