/**
 * 
 */
package com.idexx.dicom.aeservices.impl;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.validator.impl.AbstractAETitleValidator;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.dto.AETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

// TODO: Auto-generated Javadoc
/**
 * The Class DeleteAETitleServiceTest.
 *
 * @author smallela
 * @version 1.3
 */
public class DeleteAETitleServiceTest {

	/** The Constant AETITLE. */
	private static final String AETITLE = "aeTitle";

	/** The Constant INSTITUTENAME. */
	private static final String INSTITUTENAME = "instituteName";

	/** The service. */
	@InjectMocks
	private DeleteAETitleService service = new DeleteAETitleService();

	/** The validator. */
	@Mock
	private AbstractAETitleValidator validator;

	/** The ae title dao. */
	@Mock
	private AETitleDao aeTitleDao;

	/** The ae title dto. */
	AETitleDTO aeTitleDTO = new AETitleDTO();

	/** The ae title. */
	AETitle aeTitle = new AETitle();

	/** The registered ae list. */
	List<AETitle> registeredAEList = new ArrayList<AETitle>();

	/** The registered ae list2. */
	List<AETitle> registeredAEList2 = new ArrayList<AETitle>();

	/**
	 * Sets the up.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Before
	public void setUp() throws Exception {

		aeTitleDTO.setAeTitle(AETITLE);
		aeTitleDTO.setInstituteName(INSTITUTENAME);
		aeTitle.setAeTitle(aeTitleDTO.getAeTitle());
		aeTitle.setInstituteName(aeTitleDTO.getInstituteName());
		aeTitle.setIdentifiedByaeTitleOnly(false);
		registeredAEList.add(aeTitle);

		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test validate.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public final void testValidate() throws IdexxDicomAEConfigServiceException {

		when(validator.validate(any(AETitleDTO.class))).thenReturn(1);
		int val = service.validate(aeTitleDTO);
		assertTrue("Delete AE Failed#1", 1 == val);
	}

	/**
	 * Test do service.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public final void testDoService() throws IdexxDicomAEConfigServiceException {

		when(aeTitleDao.findAETitle(AETITLE)).thenReturn(registeredAEList);
		when(aeTitleDao.findAETitle(AETITLE, INSTITUTENAME)).thenReturn(registeredAEList);
		doNothing().when(aeTitleDao).deleteAETitle(aeTitle);
		int val = service.doService(aeTitleDTO);
		assertTrue("Delete AE Failed#1", 1 == val);
		assertTrue("Delete AE failed", null != registeredAEList);

	}

	/**
	 * Test do service2.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public final void testDoService2() throws IdexxDicomAEConfigServiceException {

		when(aeTitleDao.findAETitle(AETITLE)).thenReturn(registeredAEList);
		when(aeTitleDao.findAETitle(AETITLE, INSTITUTENAME)).thenReturn(registeredAEList2);
		doNothing().when(aeTitleDao).deleteAETitle(aeTitle);
		int val = service.doService(aeTitleDTO);
		assertTrue("Delete AE Failed#1", 1 == val);
	}

	/**
	 * Test do service3.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public final void testDoService3() throws IdexxDicomAEConfigServiceException {

		when(aeTitleDao.findAETitle(AETITLE)).thenThrow(new IdexxDicomAEConfigDbException());
		service.doService(aeTitleDTO);
	}

	/**
	 * Test send response.
	 */
	@Test
	public final void testSendResponse() {

		Object val = service.sendResponse();
		assertTrue("SendResponse Not yet implemented", val != null);
	}

}
