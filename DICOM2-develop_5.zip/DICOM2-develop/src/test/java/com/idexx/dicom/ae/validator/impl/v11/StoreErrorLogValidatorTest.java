package com.idexx.dicom.ae.validator.impl.v11;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.services.dto.v11.IdexxErrorLogParamDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

// TODO: Auto-generated Javadoc
/**
 * The Class StoreErrorLogValidatorTest.
 *
 * @author smallela
 * @version 1.3
 */
public class StoreErrorLogValidatorTest {

	/** The Constant AETITLE. */
	private final static String AETITLE = "TestAET";

	/** The Constant ERRORTYPE. */
	private final static String ERRORTYPE = "ErrorType";

	/** The Constant INSTITUTE. */
	private final static String INSTITUTE = "InstituteName";

	/** The Constant STARTDATE. */
	private final static String STARTDATE = "2014-01-24T11:20:24.0z";

	/** The Constant ENDDATE. */
	private final static String ENDDATE = "2014-01-28T11:20:24.0z";

	/** The store error validator. */
	@InjectMocks
	private StoreErrorLogValidatorImpl storeErrorValidator = new StoreErrorLogValidatorImpl();

	/** The idexx error log param dto. */
	IdexxErrorLogParamDTO idexxErrorLogParamDTO;

	/** The expected ex. */
	@Rule
	public ExpectedException expectedEx = ExpectedException.none();

	/**
	 * Sets the up.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Before
	public void setUp() throws Exception {

		idexxErrorLogParamDTO = new IdexxErrorLogParamDTO();
		idexxErrorLogParamDTO.setAeTitle(AETITLE);
		idexxErrorLogParamDTO.setErrorType(ERRORTYPE);
		idexxErrorLogParamDTO.setInstituteName(INSTITUTE);
		idexxErrorLogParamDTO.setStartDate(STARTDATE);
		idexxErrorLogParamDTO.setEndDate(ENDDATE);

		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test when start date is empty then return error msg.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Test
	public final void testWhenStartDateIsEmptyThenReturnErrorMsg() throws Exception {

		idexxErrorLogParamDTO.setStartDate(null);
		expectedEx.expect(IdexxDicomAEConfigServiceException.class);
		expectedEx.expectMessage("ERR_argument_missing_mandatory");
		storeErrorValidator.validate(idexxErrorLogParamDTO);
	}

	/**
	 * Test when end date is empty then return error msg.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Test
	public final void testWhenEndDateIsEmptyThenReturnErrorMsg() throws Exception {

		idexxErrorLogParamDTO.setEndDate(null);
		expectedEx.expect(IdexxDicomAEConfigServiceException.class);
		expectedEx.expectMessage("ERR_argument_missing_mandatory");
		storeErrorValidator.validate(idexxErrorLogParamDTO);
	}

	/**
	 * Test when start date is not valid then return error msg.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Test
	public final void testWhenStartDateIsNotValidThenReturnErrorMsg() throws Exception {

		idexxErrorLogParamDTO.setStartDate("abcd");
		idexxErrorLogParamDTO.setEndDate("2014-01-24T11:20:24.0z");
		expectedEx.expect(IdexxDicomAEConfigServiceException.class);
		expectedEx.expectMessage("ERR_invalid_start_date");
		storeErrorValidator.validate(idexxErrorLogParamDTO);
	}

	/**
	 * Test when end date is not valid then return error msg.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Test
	public final void testWhenEndDateIsNotValidThenReturnErrorMsg() throws Exception {

		idexxErrorLogParamDTO.setStartDate("2014-01-24T11:20:24.0z");
		idexxErrorLogParamDTO.setEndDate("abcd");
		expectedEx.expect(IdexxDicomAEConfigServiceException.class);
		expectedEx.expectMessage("ERR_invalid_end_date");
		storeErrorValidator.validate(idexxErrorLogParamDTO);
	}

	/**
	 * Test when start date is less than end date then return error msg.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Test
	public final void testWhenStartDateIsLessThanEndDateThenReturnErrorMsg() throws Exception {

		storeErrorValidator.validate(idexxErrorLogParamDTO);
	}

	/**
	 * Test when valid start end date then return success.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Test
	public final void testWhenValidStartEndDateThenReturnSuccess() throws Exception {

		boolean isValid = storeErrorValidator.validate(idexxErrorLogParamDTO);
		Assert.assertTrue(isValid);
	}
}
