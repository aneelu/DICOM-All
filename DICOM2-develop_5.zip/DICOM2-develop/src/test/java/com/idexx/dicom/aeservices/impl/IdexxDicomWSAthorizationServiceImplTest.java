/**
 * 
 */
package com.idexx.dicom.aeservices.impl;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.ae.entities.IdexxAPIKey;
import com.idexx.dicom.aeservices.IdexxDicomWSAthorizationService;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

// TODO: Auto-generated Javadoc
/**
 * The Class IdexxDicomWSAthorizationServiceImplTest.
 *
 * @author smallela
 * @version 1.3
 */
public class IdexxDicomWSAthorizationServiceImplTest {

	/** The Constant TEST_VALID_API_KEY. */
	private static final String TEST_VALID_API_KEY = "VALID_API_KEY";

	/** The Constant TEST_INVALID_API_KEY. */
	private static final String TEST_INVALID_API_KEY = "INVALID_API_KEY";

	/** The service. */
	@InjectMocks
	private IdexxDicomWSAthorizationServiceImpl service = new IdexxDicomWSAthorizationServiceImpl();

	/** The ae title dao. */
	@Mock
	private AETitleDao aeTitleDao;

	/** The idexx api key. */
	IdexxAPIKey idexxAPIKey = new IdexxAPIKey();

	/**
	 * Sets the up.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Before
	public void setUp() throws Exception {

		MockitoAnnotations.initMocks(this);

	}

	/**
	 * Test authorize1.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public void testAuthorize1() throws IdexxDicomAEConfigServiceException {

		when(aeTitleDao.getIdexxAPIKey(TEST_VALID_API_KEY)).thenReturn(idexxAPIKey);
		assertTrue("WS Authorization Failed", service.authorize(TEST_VALID_API_KEY));
	}

	/**
	 * Test authorize2.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public void testAuthorize2() throws IdexxDicomAEConfigServiceException {

		when(aeTitleDao.getIdexxAPIKey(TEST_VALID_API_KEY)).thenReturn(null);
		String errorCode = null;
		try {
			service.authorize(TEST_INVALID_API_KEY);
		} catch (IdexxDicomAEConfigServiceException exp) {
			errorCode = exp.getErrorCode();
			throw exp;
		}
		assertTrue("WS Authorization Failed", IdexxDicomWSAthorizationService.INVALID_API_KEY.equals(errorCode));
	}

	/**
	 * Test authorize3.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public void testAuthorize3() throws IdexxDicomAEConfigServiceException {

		String errorCode = null;
		try {
			service.authorize("");
		} catch (IdexxDicomAEConfigServiceException exp) {
			errorCode = exp.getErrorCode();
			throw exp;
		}
		assertTrue("WS Authorization Failed", IdexxDicomWSAthorizationService.MISSING_MANDATORY.equals(errorCode));
	}

}
