/**
 * <h1>JUnit test cases for CreateRequestValidator class.</h1>
 */
package com.idexx.dicom.services.requestservice.validator;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO;

/**
 * <pre>
 * JUnit test cases for CreateRequestValidator class.
 * </pre>
 * 
 * @author nayeemuddin
 * @version 1.3
 */
public class CreateRequestValidatorTest {
	
	
	CreateRequestValidator createRequestValidator = new CreateRequestValidator();
	
	@InjectMocks
	CreateRequestValidator createRequestValidatorMock = Mockito.mock(CreateRequestValidator.class);

	/**
	 * 
	 * @throws java.lang.Exception
	 * 
	 */
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(createRequestValidator);
	}

	/**
	 * Test method for
	 * {@link com.idexx.dicom.services.requestservice.validator.CreateRequestValidator#validate(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * @throws IdexxDicomAEConfigServiceException 
	 * Test with all expected parameters
	 */
	@Test
	public void testValidate() throws IdexxDicomAEConfigServiceException {
		
		int actual = 1;
		when(createRequestValidatorMock.validate(any(RequestDetailsDTO.class))).thenReturn(actual);
		
		RequestDetailsDTO requestDetailsDTO = new RequestDetailsDTO();
		requestDetailsDTO.setApiKey("TestAPIKey");
		requestDetailsDTO.setClientLastName("TestLastName");
		requestDetailsDTO.setModality("TestModality");
		requestDetailsDTO.setPatientId("TestPatientId");
		requestDetailsDTO.setSapId("124564");
		requestDetailsDTO.setPatientName("TestPatient");
		requestDetailsDTO.setPimsIssuer("TestPIMsIssuer");
		requestDetailsDTO.setRequestingDoctor("TestRequestingDoctor");
		
		int expected = createRequestValidator.validate(requestDetailsDTO);
		assertEquals(expected, actual);
	}
	
	/**
	 * Test method for
	 * {@link com.idexx.dicom.services.requestservice.validator.CreateRequestValidator#validate(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * @throws IdexxDicomAEConfigServiceException 
	 * Test for Mandatory param missing.
	 */
	@Test (expected = IdexxDicomAEConfigServiceException.class)
	public void testValidate1() throws IdexxDicomAEConfigServiceException {
		
		when(createRequestValidatorMock.validate(any(RequestDetailsDTO.class)))
		.thenThrow(new IdexxDicomAEConfigServiceException(
				CreateRequestValidator.MISSING_MANDATORY, CreateRequestValidator.MISSING_MANDATORY));
		
		RequestDetailsDTO requestDetailsDTO = new RequestDetailsDTO();
		requestDetailsDTO.setApiKey("");
		requestDetailsDTO.setClientLastName("TestLastName");
		requestDetailsDTO.setModality("TestModality");
		requestDetailsDTO.setPatientId("TestPatientId");
		requestDetailsDTO.setSapId("124564");
		requestDetailsDTO.setPatientName("TestPatient");
		requestDetailsDTO.setPimsIssuer("TestPIMsIssuer");
		requestDetailsDTO.setRequestingDoctor("TestRequestingDoctor");
		
		String errorCode = null;
		try {
			createRequestValidator.validate(requestDetailsDTO);
		} catch (IdexxDicomAEConfigServiceException exp) {
			errorCode = exp.getMessage();
			throw exp;
		}
		assertTrue("Invalid Response recieved", CreateRequestValidator.MISSING_MANDATORY.equals(errorCode));
		
	}
	
	/**
	 * Test method for
	 * {@link com.idexx.dicom.services.requestservice.validator.CreateRequestValidator#validate(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * @throws IdexxDicomAEConfigServiceException 
	 * Test for Numeric SAP_ID
	 */
	@Test (expected = IdexxDicomAEConfigServiceException.class)
	public void testValidate2() throws IdexxDicomAEConfigServiceException {
		
		when(createRequestValidatorMock.validate(any(RequestDetailsDTO.class)))
		.thenThrow(new IdexxDicomAEConfigServiceException(
				CreateRequestValidator.INVALID_SAPID, CreateRequestValidator.INVALID_SAPID));
		
		RequestDetailsDTO requestDetailsDTO = new RequestDetailsDTO();
		requestDetailsDTO.setApiKey("TestAPIKey");
		requestDetailsDTO.setClientLastName("TestLastName");
		requestDetailsDTO.setModality("TestModality");
		requestDetailsDTO.setPatientId("TestPatientId");
		requestDetailsDTO.setSapId("124564ABC");
		requestDetailsDTO.setPatientName("TestPatient");
		requestDetailsDTO.setPimsIssuer("TestPIMsIssuer");
		requestDetailsDTO.setRequestingDoctor("TestRequestingDoctor");
		
		String errorCode = null;
		try {
			createRequestValidator.validate(requestDetailsDTO);
		} catch (IdexxDicomAEConfigServiceException exp) {
			errorCode = exp.getMessage();
			throw exp;
		}
		assertTrue("Invalid Response recieved", CreateRequestValidator.INVALID_SAPID.equals(errorCode));
		
	}

}
