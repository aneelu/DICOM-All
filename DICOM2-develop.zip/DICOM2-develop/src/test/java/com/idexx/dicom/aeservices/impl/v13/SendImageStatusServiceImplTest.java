/**
 * <h1>JUnit test cases for SendImageStatusServiceImpl</h1>
 */
package com.idexx.dicom.aeservices.impl.v13;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.jmock.Expectations;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.idexx.dicom.IdexxdicomServicesApplication;
import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.ae.validator.impl.v13.IdexxSendImageStatusValidatorImpl;
import com.idexx.dicom.aeservices.impl.v13.IdexxDicomWSAthorizationServiceImpl;
import com.idexx.dicom.aeservices.impl.v13.SendImageStatusServiceImpl;
import com.idexx.dicom.dao.ws.IdexxSendImageJobDao;
import com.idexx.dicom.services.IdexxDicomServiceConstants;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v13.IdexxSendImageJobStatusDTO;
import com.idexx.dicom.services.sendimage.dto.v13.SendImageStatusParamDTO;

/**
 * <pre>JUnit test cases for SendImageStatusServiceImpl</pre>
 * @author nayeemuddin
 * @version 1.3
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = IdexxdicomServicesApplication.class)
public class SendImageStatusServiceImplTest {
	
	JUnit4Mockery context = new JUnit4Mockery() {{
	      setImposteriser(ClassImposteriser.INSTANCE);
	   }};
	   
	 // Service class to test 
	 SendImageStatusServiceImpl sendImageStatusService;
	 
	 IdexxSendImageJobDao sendImageJobDao = context.mock(IdexxSendImageJobDao.class);	 
	 IdexxSendImageStatusValidatorImpl validator = context.mock(IdexxSendImageStatusValidatorImpl.class);
	 IdexxDicomWSAthorizationServiceImpl idexxDicomWsAuthorizeService = context.mock(IdexxDicomWSAthorizationServiceImpl.class);
	

	/**
	 * <pre>JUnit test cases for SendImageStatusServiceImpl</pre>
	 * @throws java.lang.Exception
	 * 
	 */
	@Before
	public void setUp() throws Exception {
		sendImageStatusService = new SendImageStatusServiceImpl();
		
        ReflectionTestUtils.setField(sendImageStatusService, "validator", validator);
        ReflectionTestUtils.setField(sendImageStatusService, "sendImageJobDao", sendImageJobDao);
        ReflectionTestUtils.setField(sendImageStatusService, "idexxDicomWsAuthorizeService", idexxDicomWsAuthorizeService);
	}

	/**
	 * Test method for {@link com.idexx.dicom.aeservices.impl.v13.SendImageStatusServiceImpl#performService(com.idexx.dicom.services.sendimage.dto.v13.SendImageStatusParamDTO)}.
	 * @throws IdexxDicomAEConfigServiceException 
	 */
	@Test
	public void testPerformService() throws IdexxDicomAEConfigServiceException {
		
		final List<String> jobIds = new ArrayList<String>();
        jobIds.add("1");
        jobIds.add("2");
        jobIds.add("3");
        final List<IdexxSendImageJob> outputJobIds = new ArrayList<IdexxSendImageJob>();
        IdexxSendImageJob outputjobId1 = new IdexxSendImageJob();
        IdexxSendImageJob outputjobId2 = new IdexxSendImageJob();
        outputjobId1.setJobId("1");
        outputjobId2.setJobId("2");
        outputJobIds.add(outputjobId1);
        outputJobIds.add(outputjobId2);
        context.checking(new Expectations() {
            {
                oneOf(idexxDicomWsAuthorizeService).authorize(with(any(String.class)));
                will(returnValue(true));
                oneOf(validator).validate(with(any(SendImageStatusParamDTO.class)));
                will(returnValue(1));
                oneOf(sendImageJobDao).getJob(jobIds);
                will(returnValue(outputJobIds));
            }
        });
        SendImageStatusParamDTO sendImageJob = new SendImageStatusParamDTO();
        final List<String> inputJobIds = new ArrayList<String>();
        inputJobIds.add("1");
        inputJobIds.add("2");
        inputJobIds.add("3");
        sendImageJob.setJobId(inputJobIds);
        sendImageJob.setApiKey("Test1");
        List<IdexxSendImageJobStatusDTO> val = (List<IdexxSendImageJobStatusDTO>) sendImageStatusService.performService(sendImageJob);
        assertTrue("Invalid Response recieved", null != val);
	}
	
	/**
	 * Test method for {@link com.idexx.dicom.aeservices.impl.v13.SendImageStatusServiceImpl#performService(com.idexx.dicom.services.sendimage.dto.v13.SendImageStatusParamDTO)}.
	 * @throws IdexxDicomAEConfigServiceException 
	 */
	@Test (expected = IdexxDicomAEConfigServiceException.class )
	public void testPerformService1() throws IdexxDicomAEConfigServiceException {
		SendImageStatusParamDTO dto = new SendImageStatusParamDTO();
        final List<String> inputJobIds = new ArrayList<String>();
        inputJobIds.add("1");
        inputJobIds.add("2");
        inputJobIds.add("3");
        dto.setJobId(inputJobIds);
        dto.setApiKey("Test1");
        context.checking(new Expectations() {
            {
                oneOf(idexxDicomWsAuthorizeService).authorize(with(any(String.class)));
                will(throwException(new IdexxDicomAEConfigServiceException(
                        IdexxDicomWSAthorizationServiceImpl.INVALID_API_KEY)));
            }
        });
        String errorCode = null;
        try {
        	sendImageStatusService.performService(dto);
        } catch (IdexxDicomAEConfigServiceException exp) {
            errorCode = exp.getMessage();
            throw exp;
        }
        assertTrue("Invalid Response recieved", IdexxDicomWSAthorizationServiceImpl.INVALID_API_KEY.equals(errorCode));  
	}
	
}
