/**
 * 
 *  
 */
package com.idexx.dicom.aeservices.impl.v13;

import static org.junit.Assert.assertTrue;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.idexx.dicom.IdexxdicomServicesApplication;
import com.idexx.dicom.ae.validator.impl.v13.AbstractAETitleValidator;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.dto.v13.CreateAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;


/**
 * <pre>Test Cases Related CreateAETitleService</pre>
 * @author smallela
 * @version 1.3
 */

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = IdexxdicomServicesApplication.class)
public class CreateAETitleServiceTest {
    private static final int DEFAULT_PORT = 8080;
    
    private CreateAETitleService service;

    public Mockery context = new JUnit4Mockery() {{
    	         setImposteriser(ClassImposteriser.INSTANCE);
    	     }};


    AbstractAETitleValidator mockValidator = context.mock(AbstractAETitleValidator.class);    
    AETitleDao mockDao = context.mock(AETitleDao.class);
    IdexxDicomWSAthorizationServiceImpl idexxDicomWsAuthorizeService = context.mock(IdexxDicomWSAthorizationServiceImpl.class);
    
    CreateAETitleDTO dto = new CreateAETitleDTO();

    @Before
        public void setUp() throws Exception {
    	dto.setAeTitle("Test1");
    	dto.setSapId("SAPID");
    	dto.setInstituteName("TestIng");
    	dto.setApiKey("TESTAPIKEY");
    	dto.setHostName("TestHost");
    	dto.setIdentifiedByAeTitleOnly(false);
    	dto.setDvmSpecialist(true);
    	context.checking(new Expectations() {
    		{
    			oneOf(mockValidator).validate(dto);
    			will(returnValue(1));
    			
    		}
    	});
    	service = new CreateAETitleService();
    	ReflectionTestUtils.setField(service, "validator", mockValidator);
    	ReflectionTestUtils.setField(service, "aeTitleDao", mockDao);
    	
    }
    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.CreateAETitleService#validate(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public final void testValidate() throws IdexxDicomAEConfigServiceException {
    	int val = service.validate(dto);
        assertTrue("Create AE Failed#1", 1 == val);

    }
    

      

}
