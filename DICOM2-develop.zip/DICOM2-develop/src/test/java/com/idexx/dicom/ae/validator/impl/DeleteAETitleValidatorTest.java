/**
 * 
 */
package com.idexx.dicom.ae.validator.impl;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.jmock.Expectations;
import org.jmock.auto.Mock;
import org.jmock.integration.junit4.JUnitRuleMockery;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.springframework.test.util.ReflectionTestUtils;

import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.dto.AETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;


/**
 * <pre>Test Cases Related DeleteAETitleValidator</pre>
 * @author smallela
 * @version 1.3
 */

@RunWith(JUnit4.class)
public class DeleteAETitleValidatorTest {
    
    private DeleteAETitleValidator validator;
    
    @Rule
    public JUnitRuleMockery context = new JUnitRuleMockery();
    
    @Mock
    private AETitleDao mockDao;
    
    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.DeleteAETitleValidator 
     * #validateInputFields(com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     * 
     *             To test the failure case of mandatory field missing
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public final void testValidateInputFields() throws IdexxDicomAEConfigServiceException {
        validator = new DeleteAETitleValidator();
        AETitleDTO dto = new AETitleDTO();
        int val = validator.validateInputFields(dto);
        assertTrue("Validation Failing#1", val == 1);
        
    }
    
    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.DeleteAETitleValidator 
     * #validateInputFields(com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     * 
     *             To test the success case of AETitle received in Request
     */
    @Test
    public final void testValidateInputFields2() throws IdexxDicomAEConfigServiceException {
        validator = new DeleteAETitleValidator();
        AETitleDTO dto = new AETitleDTO();
        dto.setAeTitle("Test1");
        int val = validator.validateInputFields(dto);
        assertTrue("Validation Failing#1", val == 1);
        
    }
    
    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.DeleteAETitleValidator 
     * #validateDBFields(com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     *             To test the DB failure
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public final void testValidateDBFields() throws IdexxDicomAEConfigServiceException {
        
        context.checking(new Expectations() {
            {
                oneOf(mockDao).findAETitle("Test1");
                will(throwException(new IdexxDicomAEConfigDbException()));
            }
        });
        validator = new DeleteAETitleValidator();
        ReflectionTestUtils.setField(validator, "aeTitleDao", mockDao);
        AETitleDTO aeTitleDTO = new AETitleDTO();
        aeTitleDTO.setAeTitle("Test1");
        int val = validator.validateDBFields(aeTitleDTO);
        assertTrue("DB Validating Failed#1", 1 == val);
    }
    
    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.DeleteAETitleValidator 
     * #validateDBFields(com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     *             To Test the case of no records found with AEtitle
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public final void testValidateDBFields2() throws IdexxDicomAEConfigServiceException {
        final List<AETitle> registeredAEList = new ArrayList<AETitle>();
        context.checking(new Expectations() {
            {
                oneOf(mockDao).findAETitle("Test1");
                will(returnValue(registeredAEList));
            }
        });
        validator = new DeleteAETitleValidator();
        ReflectionTestUtils.setField(validator, "aeTitleDao", mockDao);
        AETitleDTO aeTitleDTO = new AETitleDTO();
        aeTitleDTO.setAeTitle("Test1");
        int val = validator.validateDBFields(aeTitleDTO);
        assertTrue("DB Validating Failed#2", 1 == val);
    }
    
    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.DeleteAETitleValidator
     *  #validateDBFields(com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     *             To test the success case of record exists with Identified by
     *             AETitle Only as true
     */
    @Test
    public final void testValidateDBFields3() throws IdexxDicomAEConfigServiceException {
        final List<AETitle> registeredAEList = new ArrayList<AETitle>();
        AETitle aeTitle = new AETitle();
        aeTitle.setAeTitle("Test1");
        aeTitle.setIdentifiedByaeTitleOnly(true);
        registeredAEList.add(aeTitle);
        context.checking(new Expectations() {
            {
                oneOf(mockDao).findAETitle("Test1");
                will(returnValue(registeredAEList));
            }
        });
        validator = new DeleteAETitleValidator();
        ReflectionTestUtils.setField(validator, "aeTitleDao", mockDao);
        AETitleDTO aeTitleDTO = new AETitleDTO();
        aeTitleDTO.setAeTitle("Test1");
        int val = validator.validateDBFields(aeTitleDTO);
        assertTrue("DB Validating Failed#3", 1 == val);
    }
    
    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.DeleteAETitleValidator 
     * #validateDBFields(com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public final void testValidateDBFields4() throws IdexxDicomAEConfigServiceException {
        final List<AETitle> registeredAEList = new ArrayList<AETitle>();
        AETitle aeTitle = new AETitle();
        aeTitle.setAeTitle("Test1");
        aeTitle.setIdentifiedByaeTitleOnly(false);
        registeredAEList.add(aeTitle);
        context.checking(new Expectations() {
            {
                oneOf(mockDao).findAETitle("Test1");
                will(returnValue(registeredAEList));
            }
        });
        validator = new DeleteAETitleValidator();
        ReflectionTestUtils.setField(validator, "aeTitleDao", mockDao);
        AETitleDTO aeTitleDTO = new AETitleDTO();
        aeTitleDTO.setAeTitle("Test1");
        int val = validator.validateDBFields(aeTitleDTO);
        assertTrue("DB Validating Failed#3", 1 == val);
    }
    
    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.DeleteAETitleValidator 
     * #validateDBFields(com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     *             To test the case of No records found with AETitle and
     *             InstituteName
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public final void testValidateDBFields5() throws IdexxDicomAEConfigServiceException {
        final List<AETitle> registeredAEList = new ArrayList<AETitle>();
        final List<AETitle> registeredAEListOther = new ArrayList<AETitle>();
        AETitle aeTitle = new AETitle();
        aeTitle.setAeTitle("Test1");
        aeTitle.setInstituteName("TestinGother");
        aeTitle.setIdentifiedByaeTitleOnly(false);
        registeredAEList.add(aeTitle);
        
        context.checking(new Expectations() {
            {
                oneOf(mockDao).findAETitle("Test1");
                will(returnValue(registeredAEList));
                
                oneOf(mockDao).findAETitle("Test1", "Testing");
                will(returnValue(registeredAEListOther));
            }
        });
        validator = new DeleteAETitleValidator();
        ReflectionTestUtils.setField(validator, "aeTitleDao", mockDao);
        AETitleDTO aeTitleDTO = new AETitleDTO();
        aeTitleDTO.setAeTitle("Test1");
        aeTitleDTO.setInstituteName("Testing");
        int val = validator.validateDBFields(aeTitleDTO);
        assertTrue("DB Validating Failed#3", 1 == val);
    }
    
    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.DeleteAETitleValidator 
     * #validateDBFields(com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     *             To test the success case of AETitle and InstituteName
     */
    @Test
    public final void testValidateDBFields6() throws IdexxDicomAEConfigServiceException {
        final List<AETitle> registeredAEList = new ArrayList<AETitle>();
        AETitle aeTitle = new AETitle();
        aeTitle.setAeTitle("Test1");
        aeTitle.setInstituteName("Testing");
        aeTitle.setIdentifiedByaeTitleOnly(false);
        registeredAEList.add(aeTitle);
        
        context.checking(new Expectations() {
            {
                oneOf(mockDao).findAETitle("Test1");
                will(returnValue(registeredAEList));
                
                oneOf(mockDao).findAETitle("Test1", "Testing");
                will(returnValue(registeredAEList));
            }
        });
        validator = new DeleteAETitleValidator();
        ReflectionTestUtils.setField(validator, "aeTitleDao", mockDao);
        AETitleDTO aeTitleDTO = new AETitleDTO();
        aeTitleDTO.setAeTitle("Test1");
        aeTitleDTO.setInstituteName("Testing");
        int val = validator.validateDBFields(aeTitleDTO);
        assertTrue("DB Validating Failed#3", 1 == val);
    }
    
}
