/**
 * 
 */
package com.idexx.dicom.ae.validator.impl.v13;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.jmock.Expectations;
import org.jmock.auto.Mock;
import org.jmock.integration.junit4.JUnitRuleMockery;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.springframework.test.util.ReflectionTestUtils;

import com.idexx.dicom.ae.entities.AEEntity;
import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.entities.IdexxInvalidAE;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.dto.v13.AETitleDTO;
import com.idexx.dicom.services.dto.v13.CreateAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;


/**
 * <pre>Test Cases Related CreateAETitleValidator</pre>
 * @author smallela
 * @version 1.3
 */

@RunWith(JUnit4.class)
public class CreateAETitleValidatorTest {

    private static final int DEFAULT_DCM_PORT = 11112;
    private static final int DEFAULT_PORT = 8080;
    private CreateAETitleValidator validator;

    @Rule
    public JUnitRuleMockery context = new JUnitRuleMockery();

    @Mock
    private AETitleDao mockDao;

    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.v13.CreateAETitleValidator 
     * #validateInputFields(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * 
     * To test no mandatory fields passed in request .
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public final void testValidateInputFields() throws IdexxDicomAEConfigServiceException {
        validator = new CreateAETitleValidator();
        AETitleDTO dto = new CreateAETitleDTO();
        int val = validator.validateInputFields(dto);
        assertTrue("Validation Failing#1", val == 1);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.v13.CreateAETitleValidator 
     * #validateInputFields(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * 
     * To test no mandatory fields passed in request .
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public final void testValidateInputFieldsNoHost() throws IdexxDicomAEConfigServiceException {
        validator = new CreateAETitleValidator();
        CreateAETitleDTO dto = new CreateAETitleDTO();
        dto.setDvmSpecialist(true);
        dto.setAeTitle("Test1");
        int val = validator.validateInputFields(dto);
        assertTrue("Validation Failing#1", val == 1);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.v13.CreateAETitleValidator 
     * #validateInputFields(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * 
     * To test no mandatory fields passed in request .
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public final void testValidateInputFieldsNoPort() throws IdexxDicomAEConfigServiceException {
        validator = new CreateAETitleValidator();
        CreateAETitleDTO dto = new CreateAETitleDTO();
        dto.setDvmSpecialist(true);
        dto.setAeTitle("Test1");
        dto.setHostName("127.0.0.1");
        int val = validator.validateInputFields(dto);
        assertTrue("Validation Failing#1", val == 1);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.v13.CreateAETitleValidator 
     * #validateInputFields(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * 
     * To test no mandatory fields passed in request .
     */

    public final void testValidateInputFieldsHostPortExists() throws IdexxDicomAEConfigServiceException {
        validator = new CreateAETitleValidator();
        CreateAETitleDTO dto = new CreateAETitleDTO();
        dto.setDvmSpecialist(true);
        dto.setAeTitle("Test1");
        dto.setHostName("127.0.0.1");
        dto.setPort(DEFAULT_DCM_PORT);
        int val = validator.validateInputFields(dto);
        assertTrue("Validation Failing#1", val == 1);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.v13.CreateAETitleValidator 
     * #validateInputFields(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * 
     * To test no mandatory fields passed in request .
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public final void testValidateInputFieldsNoAPIKey() throws IdexxDicomAEConfigServiceException {
        validator = new CreateAETitleValidator();
        CreateAETitleDTO dto = new CreateAETitleDTO();
        dto.setDvmSpecialist(false);
        dto.setAeTitle("Test1");
        int val = validator.validateInputFields(dto);
        assertTrue("Validation Failing#1", val == 1);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.v13.CreateAETitleValidator 
     * #validateInputFields(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * 
     * To test no mandatory fields passed in request .
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public final void testValidateInputFieldsNoSAPID() throws IdexxDicomAEConfigServiceException {
        validator = new CreateAETitleValidator();
        CreateAETitleDTO dto = new CreateAETitleDTO();
        dto.setDvmSpecialist(false);
        dto.setAeTitle("Test1");
        dto.setApiKey("TestAPI");
        int val = validator.validateInputFields(dto);
        assertTrue("Validation Failing#1", val == 1);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.v13.CreateAETitleValidator 
     * #validateInputFields(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * . To Test Mandatory fields for the case of IdentifiedByAETitleOnly is
     * false and institute name passed in
     */
    @Test
    public final void testValidateInputFields2() throws IdexxDicomAEConfigServiceException {
        validator = new CreateAETitleValidator();
        CreateAETitleDTO dto = new CreateAETitleDTO();
        dto.setDvmSpecialist(true);
        dto.setHostName("localhst");
        dto.setPort(DEFAULT_PORT);
        dto.setAeTitle("Test1");
        dto.setSapId("SAPID");
        dto.setInstituteName("TestIng");
        dto.setApiKey("TESTAPIKEY");
        int val = validator.validateInputFields(dto);
        assertTrue("Validation Faled#2", 1 == val);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.v13.CreateAETitleValidator 
     * #validateInputFields(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * To Test mandatory fields for the case of IdentifiedByAETitleOnly is true
     */
    @Test
    public final void testValidateInputFields3() throws IdexxDicomAEConfigServiceException {
        validator = new CreateAETitleValidator();
        CreateAETitleDTO dto = new CreateAETitleDTO();
        dto.setDvmSpecialist(false);
        dto.setHostName("localhst");
        dto.setPort(DEFAULT_PORT);
        dto.setAeTitle("Test1");
        dto.setSapId("SAPID");
        dto.setIdentifiedByAeTitleOnly(true);
        dto.setApiKey("TESTAPIKEY");
        int val = validator.validateInputFields(dto);
        assertTrue("Validation Faled#2", 1 == val);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.v13.CreateAETitleValidator 
     * #validateInputFields(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * . To Test Mandatory fields for the case of IdentifiedByAETitleOnly is
     * false
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public final void testValidateInputFields4() throws IdexxDicomAEConfigServiceException {
        validator = new CreateAETitleValidator();
        CreateAETitleDTO dto = new CreateAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setSapId("SAPID");
        dto.setApiKey("TESTAPIKEY");
        int val = validator.validateInputFields(dto);
        assertTrue("Validation Faled#2", 1 == val);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.v13.CreateAETitleValidator 
     * #validateDBFields(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * .To Test the General DB Failure
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public final void testValidateDBFields() throws IdexxDicomAEConfigServiceException {
        context.checking(new Expectations() {
            {
                oneOf(mockDao).getInvalidAETitle("Test1");
                will(throwException(new IdexxDicomAEConfigDbException()));
            }
        });
        validator = new CreateAETitleValidator();
        ReflectionTestUtils.setField(validator, "aeTitleDao", mockDao);
        CreateAETitleDTO dto = new CreateAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setSapId("SAPID");
        dto.setInstituteName("TestIng");
        dto.setApiKey("TESTAPIKEY");
        dto.setDvmSpecialist(false);
        dto.setIdentifiedByAeTitleOnly(false);
        int val = validator.validateDBFields(dto);
        assertTrue("DB Validating Failed#1", 1 == val);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.v13.CreateAETitleValidator 
     * #validateDBFields(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * To Test success case with identifiedByAETitleOnly as false and record
     * exists for AETitle and InstituteName
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public final void testValidateDBFields2() throws IdexxDicomAEConfigServiceException {
        final IdexxInvalidAE ae = new IdexxInvalidAE();
        ae.setAeTitle("Test1");
        context.checking(new Expectations() {
            {
                oneOf(mockDao).getInvalidAETitle("Test1");
                will(returnValue(ae));
            }
        });

        validator = new CreateAETitleValidator();
        ReflectionTestUtils.setField(validator, "aeTitleDao", mockDao);
        CreateAETitleDTO dto = new CreateAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setSapId("SAPID");
        dto.setInstituteName("Testing");
        dto.setApiKey("TESTAPIKEY");
        dto.setIdentifiedByAeTitleOnly(false);

        int val = validator.validateDBFields(dto);
        assertTrue("DB Validating Failed#2", 1 == val);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.v13.CreateAETitleValidator 
     * #validateDBFields(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * To Test Successful creation
     */
    @Test
    public final void testValidateDBFields3() throws IdexxDicomAEConfigServiceException {
        final IdexxInvalidAE ae = null;
        final List<AETitle> registeredAEList = new ArrayList<AETitle>();
        context.checking(new Expectations() {
            {
                oneOf(mockDao).getInvalidAETitle("Test1");
                will(returnValue(ae));

                atLeast(1).of(mockDao).findAETitle("Test1");
                will(returnValue(registeredAEList));
            }
        });
        validator = new CreateAETitleValidator();
        ReflectionTestUtils.setField(validator, "aeTitleDao", mockDao);
        CreateAETitleDTO dto = new CreateAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setSapId("SAPID");
        dto.setInstituteName("TestIng");
        dto.setApiKey("TESTAPIKEY");
        dto.setIdentifiedByAeTitleOnly(true);
        int val = validator.validateDBFields(dto);
        assertTrue("DB Validating Failed#1", 1 == val);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.v13.CreateAETitleValidator 
     * #validateDBFields(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * To Test Successful creation
     */
    @Test
    public final void testValidateDBFieldsAe() throws IdexxDicomAEConfigServiceException {
        final List<AEEntity> registeredAEList = new ArrayList<AEEntity>();
        context.checking(new Expectations() {
            {
                atLeast(1).of(mockDao).findAE("Test1");
                will(returnValue(registeredAEList));
            }
        });
        validator = new CreateAETitleValidator();
        ReflectionTestUtils.setField(validator, "aeTitleDao", mockDao);
        CreateAETitleDTO dto = new CreateAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setDvmSpecialist(true);
        dto.setHostName("127.0.0.1");
        dto.setPort(DEFAULT_DCM_PORT);
        int val = validator.validateDBFields(dto);
        assertTrue("DB Validating Failed#1", 1 == val);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.v13.CreateAETitleValidator 
     * #validateDBFields(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * To Test Successful creation
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public final void testValidateDBFieldsAeExists() throws IdexxDicomAEConfigServiceException {
        AEEntity ae = new AEEntity();
        ae.setAeTitle("Test1");
        final List<AEEntity> registeredAEList = new ArrayList<AEEntity>();
        registeredAEList.add(ae);
        context.checking(new Expectations() {
            {
                atLeast(1).of(mockDao).findAE("Test1");
                will(returnValue(registeredAEList));
            }
        });
        validator = new CreateAETitleValidator();
        ReflectionTestUtils.setField(validator, "aeTitleDao", mockDao);
        CreateAETitleDTO dto = new CreateAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setDvmSpecialist(true);
        dto.setHostName("127.0.0.1");
        dto.setPort(DEFAULT_DCM_PORT);
        int val = validator.validateDBFields(dto);
        assertTrue("DB Validating Failed#1", 1 == val);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.v13.CreateAETitleValidator 
     * #validateDBFields(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * To Test Existence of a record with identifiedByAETitleOnly as true
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public final void testValidateDBFields4() throws IdexxDicomAEConfigServiceException {
        final IdexxInvalidAE ae = null;
        final List<AETitle> registeredAEList = new ArrayList<AETitle>();
        AETitle aeTitle = new AETitle();
        aeTitle.setAeTitle("Test1");
        aeTitle.setIdentifiedByaeTitleOnly(true);
        registeredAEList.add(aeTitle);
        context.checking(new Expectations() {
            {
                oneOf(mockDao).getInvalidAETitle("Test1");
                will(returnValue(ae));

                atLeast(1).of(mockDao).findAETitle("Test1");
                will(returnValue(registeredAEList));
            }
        });
        validator = new CreateAETitleValidator();
        ReflectionTestUtils.setField(validator, "aeTitleDao", mockDao);
        CreateAETitleDTO dto = new CreateAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setSapId("SAPID");
        dto.setInstituteName("TestIng");
        dto.setApiKey("TESTAPIKEY");
        dto.setIdentifiedByAeTitleOnly(true);
        int val = validator.validateDBFields(dto);
        assertTrue("DB Validating Failed#2", 1 == val);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.v13.CreateAETitleValidator 
     * #validateDBFields(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * To Test failure case with identifiedByAETitleOnly as false and record
     * exists for AETitle and InstituteName
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public final void testValidateDBFields5() throws IdexxDicomAEConfigServiceException {
        final IdexxInvalidAE ae = null;

        final List<AETitle> registeredAEList = new ArrayList<AETitle>();
        AETitle aeTitle = new AETitle();
        aeTitle.setAeTitle("Test1");
        aeTitle.setIdentifiedByaeTitleOnly(false);
        aeTitle.setInstituteName("Testing");
        registeredAEList.add(aeTitle);

        context.checking(new Expectations() {
            {
                oneOf(mockDao).getInvalidAETitle("Test1");
                will(returnValue(ae));

                atLeast(1).of(mockDao).findAETitle("Test1");
                will(returnValue(registeredAEList));

                atLeast(1).of(mockDao).findAETitle("Test1", "Testing");
                will(returnValue(registeredAEList));

            }
        });

        validator = new CreateAETitleValidator();
        ReflectionTestUtils.setField(validator, "aeTitleDao", mockDao);
        CreateAETitleDTO dto = new CreateAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setSapId("SAPID");
        dto.setInstituteName("Testing");
        dto.setApiKey("TESTAPIKEY");
        dto.setIdentifiedByAeTitleOnly(false);
        int val = validator.validateDBFields(dto);
        assertTrue("DB Validating Failed#2", 1 == val);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.v13.CreateAETitleValidator 
     * #validateDBFields(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * To Test success case with identifiedByAETitleOnly as false and record not
     * exists for AETitle and InstituteName
     */
    @Test
    public final void testValidateDBFields6() throws IdexxDicomAEConfigServiceException {
        final IdexxInvalidAE ae = null;
        final List<AETitle> registeredAEList = new ArrayList<AETitle>();
        final List<AETitle> registeredAEListEmpty = new ArrayList<AETitle>();
        AETitle aeTitle = new AETitle();
        aeTitle.setAeTitle("Test1");
        aeTitle.setIdentifiedByaeTitleOnly(false);
        aeTitle.setInstituteName("TestingOther");
        registeredAEList.add(aeTitle);
        context.checking(new Expectations() {
            {
                oneOf(mockDao).getInvalidAETitle("Test1");
                will(returnValue(ae));

                atLeast(1).of(mockDao).findAETitle("Test1");
                will(returnValue(registeredAEList));

                atLeast(1).of(mockDao).findAETitle("Test1", "Testing");
                will(returnValue(registeredAEListEmpty));
            }
        });

        validator = new CreateAETitleValidator();
        ReflectionTestUtils.setField(validator, "aeTitleDao", mockDao);
        CreateAETitleDTO dto = new CreateAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setSapId("SAPID");
        dto.setInstituteName("Testing");
        dto.setApiKey("TESTAPIKEY");
        dto.setIdentifiedByAeTitleOnly(false);
        int val = validator.validateDBFields(dto);
        assertTrue("DB Validating Failed#2", 1 == val);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.v13.CreateAETitleValidator 
     * #validateDBFields(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * To Test success case with identifiedByAETitleOnly as false and record not
     * exists for AETitle and InstituteName
     */
    @Test
    public final void testValidate() throws IdexxDicomAEConfigServiceException {
        final IdexxInvalidAE ae = null;
        final List<AETitle> registeredAEList = new ArrayList<AETitle>();
        final List<AETitle> registeredAEListEmpty = new ArrayList<AETitle>();
        AETitle aeTitle = new AETitle();
        aeTitle.setAeTitle("Test1");
        aeTitle.setIdentifiedByaeTitleOnly(false);
        aeTitle.setInstituteName("TestingOther");
        registeredAEList.add(aeTitle);
        context.checking(new Expectations() {
            {
                oneOf(mockDao).getInvalidAETitle("Test1");
                will(returnValue(ae));

                atLeast(1).of(mockDao).findAETitle("Test1");
                will(returnValue(registeredAEList));

                atLeast(1).of(mockDao).findAETitle("Test1", "Testing");
                will(returnValue(registeredAEListEmpty));
            }
        });

        validator = new CreateAETitleValidator();
        ReflectionTestUtils.setField(validator, "aeTitleDao", mockDao);
        CreateAETitleDTO dto = new CreateAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setSapId("SAPID");
        dto.setInstituteName("Testing");
        dto.setApiKey("TESTAPIKEY");
        dto.setIdentifiedByAeTitleOnly(false);
        int val = validator.validate(dto);
        assertTrue("DB Validating Failed#2", 1 == val);
    }

}
