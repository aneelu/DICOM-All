/**
 * <h1>JUnit test cases for IdexxSendImageValidatorImpl class.</h1>
 */
package com.idexx.dicom.ae.validator.impl.v13;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.idexx.dicom.IdexxdicomServicesApplicationTests;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v13.SendImageJobParamDTO;

/**
 * <pre>JUnit test cases for IdexxSendImageValidatorImpl class.</pre>
 * @author nayeemuddin
 * @version 1.3
 */
public class IdexxSendImageValidatorImplTest extends IdexxdicomServicesApplicationTests{
	
	private IdexxSendImageValidatorImpl idexxSendImageValidator;
	private SendImageJobParamDTO dto;

	/**
	 * @throws java.lang.Exception
	 * 
	 */
	@Before
	public void setUp() throws Exception {
		idexxSendImageValidator = new IdexxSendImageValidatorImpl();
		dto = new SendImageJobParamDTO();
	}

	/**
	 * Test method for {@link com.idexx.dicom.ae.validator.impl.v13.IdexxSendImageValidatorImpl#validate(com.idexx.dicom.services.sendimage.dto.v13.SendImageJobParamDTO)}.
	 */
	@Test
	public void testValidate() {
		
		try {
			idexxSendImageValidator.validate(dto);
			fail("SendImageValidator Failed to validate 1.0 ");
		} catch (IdexxDicomAEConfigServiceException exp) {
			assertTrue("SendImageValidator Failed to validate 1.1 ", IdexxSendImageValidatorImpl.MISSING_MANDATORY.equalsIgnoreCase(exp.getErrorCode()));
		}
		
		//setting API Key
		dto.setApiKey("TestAPIKey");
		try {
			idexxSendImageValidator.validate(dto);
			fail("SendImageValidator Failed to validate 2.0 ");
		} catch (IdexxDicomAEConfigServiceException exp) {
			assertTrue("SendImageValidator Failed to validate 2.1 ", IdexxSendImageValidatorImpl.MISSING_MANDATORY.equalsIgnoreCase(exp.getErrorCode()));
		}
		
		//setting Destination AE Title
		dto.setDestinationAETitle("DestAETtitleTest");
		try {
			idexxSendImageValidator.validate(dto);
			fail("SendImageValidator Failed to validate 3.0 ");
		} catch (IdexxDicomAEConfigServiceException exp) {
			assertTrue("SendImageValidator Failed to validate 3.1 ", IdexxSendImageValidatorImpl.MISSING_MANDATORY.equalsIgnoreCase(exp.getErrorCode()));
		}
		
		//setting Destination AE Host
		dto.setDestinationHost("DestAEHostTest");
		try {
			idexxSendImageValidator.validate(dto);
			fail("SendImageValidator Failed to validate 4.0 ");
		} catch (IdexxDicomAEConfigServiceException exp) {
			assertTrue("SendImageValidator Failed to validate 4.1 ", IdexxSendImageValidatorImpl.MISSING_MANDATORY.equalsIgnoreCase(exp.getErrorCode()));
		}
		
		//setting Destination Port as 0
		dto.setDestinationPort(0);
		try {
			idexxSendImageValidator.validate(dto);
			fail("SendImageValidator Failed to validate 5.0 ");
		} catch (IdexxDicomAEConfigServiceException exp) {
			assertTrue("SendImageValidator Failed to validate 5.1 ", IdexxSendImageValidatorImpl.MISSING_MANDATORY.equalsIgnoreCase(exp.getErrorCode()));
		}
				
		//setting Destination Port
		dto.setDestinationPort(123);
		try {
			idexxSendImageValidator.validate(dto);
			fail("SendImageValidator Failed to validate 6.0 ");
		} catch (IdexxDicomAEConfigServiceException exp) {
			assertTrue("SendImageValidator Failed to validate 6.1 ", IdexxSendImageValidatorImpl.MISSING_MANDATORY.equalsIgnoreCase(exp.getErrorCode()));
		}
		
		
		//setting Image Asset ID
		dto.setImageAssetId("1234");
		try {
			idexxSendImageValidator.validate(dto);
			fail("SendImageValidator Failed to validate 7.0 ");
		} catch (IdexxDicomAEConfigServiceException exp) {
			assertTrue("SendImageValidator Failed to validate 7.1 ", IdexxSendImageValidatorImpl.MISSING_MANDATORY.equalsIgnoreCase(exp.getErrorCode()));
		}
		
		//setting Sending AE Title
		dto.setSendingAETitle("SendAETitleTest");
		try {
			int val = idexxSendImageValidator.validate(dto);
			assertTrue("SendImageValidator Failed to validate 8.0 ", 1 == val);
		} catch (IdexxDicomAEConfigServiceException exp) {
			fail("SendImageValidator Failed to validate 8.1 ");			
		}
		
	}

}
