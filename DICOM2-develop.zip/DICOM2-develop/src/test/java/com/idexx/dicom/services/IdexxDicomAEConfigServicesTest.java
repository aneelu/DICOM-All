/**
 * 
 */
package com.idexx.dicom.services;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.jmock.Expectations;
import org.jmock.auto.Mock;
import org.jmock.integration.junit4.JUnitRuleMockery;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.springframework.test.util.ReflectionTestUtils;

import com.idexx.dicom.aeservices.AEService;
import com.idexx.dicom.services.dto.AETitleDTO;
import com.idexx.dicom.services.dto.CreateAETitleDTO;
import com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO;
import com.idexx.dicom.services.dto.ReadAETitleDTO;
import com.idexx.dicom.services.dto.SetEnabledAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;


/**
 * <pre>Test Cases Related IdexxDicomAEConfigServices</pre>
 * @author smallela
 * @version 1.3
 */

@RunWith(JUnit4.class)
public class IdexxDicomAEConfigServicesTest {

    IdexxDicomAEConfigServices service;
    @Rule
    public JUnitRuleMockery context = new JUnitRuleMockery();

    @Mock
    private AEService createServiceMock;
    @Mock
    private AEService readServiceMock;
    @Mock
    private AEService deleteServiceMock;
    @Mock
    private AEService setEnabledAEServiceMock;
    
    

    /**
     * Test method for
     * {@link com.idexx.dicom.services.impl.IdexxDicomAEConfigServiceImpl 
     * #createAETitle(com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)}
     * .
     * @throws IdexxDicomAEConfigServiceException 
     */
    @Test
    public final void testCreateAETitle() throws IdexxDicomAEConfigServiceException {
        CreateAETitleDTO dto = new CreateAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setSapId("SAPID");
        dto.setInstituteName("TestIng");
        dto.setApiKey("TESTAPIKEY");
        dto.setIdentifiedByAeTitleOnly(false);
        context.checking(new Expectations() {
            {
                oneOf(createServiceMock).performService(with(any(CreateAETitleDTO.class)));
                
                
            }
        });
        service = new IdexxDicomAEConfigServices();
        ReflectionTestUtils.setField(service, "createService", createServiceMock);
        service.createAETitle(dto);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.services.impl.IdexxDicomAEConfigServiceImpl#readAETitle(java.lang.String, java.lang.String, java.lang.String)}
     * .
     * @throws IdexxDicomAEConfigServiceException 
     */
    @Test
    public final void testReadAETitle() throws IdexxDicomAEConfigServiceException {
        final List<IdexxDicomApplicationEntityDTO> dtos = new ArrayList<IdexxDicomApplicationEntityDTO>();
        ReadAETitleDTO dto = new ReadAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setSapId("SAPID");
        dto.setInstituteName("TestIng");
        dto.setApiKey("TESTAPIKEY");
        context.checking(new Expectations() {
            {
                oneOf(readServiceMock).performService(with(any(ReadAETitleDTO.class)));
                oneOf(readServiceMock).sendResponse();
                will(returnValue(dtos));
                
            }
        });
        service = new IdexxDicomAEConfigServices();
        ReflectionTestUtils.setField(service, "readService", readServiceMock);
        Object outputVal = service.readAETitle(dto);
        assertTrue("Not yet implemented", null != outputVal);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.services.impl.IdexxDicomAEConfigServiceImpl#deleteAETitle(java.lang.String, java.lang.String)}
     * .
     * @throws IdexxDicomAEConfigServiceException 
     */
    @Test
    public final void testDeleteAETitle() throws IdexxDicomAEConfigServiceException {
        AETitleDTO dto = new AETitleDTO();
        dto.setAeTitle("Test1");
        dto.setInstituteName("TestIng");
        dto.setApiKey("TESTAPIKEY");
        context.checking(new Expectations() {
            {
                oneOf(deleteServiceMock).performService(with(any(AETitleDTO.class)));
                
                
            }
        });
        service = new IdexxDicomAEConfigServices();
        ReflectionTestUtils.setField(service, "deleteService", deleteServiceMock);
        service.deleteAETitle(dto);

    }

    /**
     * Test method for
     * {@link com.idexx.dicom.services.impl.IdexxDicomAEConfigServiceImpl#setEnableAETitle(java.lang.String, java.lang.String, boolean)}
     * .
     * @throws IdexxDicomAEConfigServiceException 
     */
    @Test
    public final void testSetEnableAETitle() throws IdexxDicomAEConfigServiceException {
        SetEnabledAETitleDTO dto = new SetEnabledAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setInstituteName("TestIng");
        dto.setApiKey("TESTAPIKEY");
        dto.setEnabled(true);
        context.checking(new Expectations() {
            {
                oneOf(setEnabledAEServiceMock).performService(with(any(SetEnabledAETitleDTO.class)));
                
                
            }
        });
        service = new IdexxDicomAEConfigServices();
        ReflectionTestUtils.setField(service, "setEnabledAEService", setEnabledAEServiceMock);
        service.setEnableAETitle(dto);
        assertTrue("Not yet implemented", true); 

    }
    
    

}
