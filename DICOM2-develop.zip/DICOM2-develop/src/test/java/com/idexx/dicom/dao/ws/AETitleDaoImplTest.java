/**
 * 
 */
package com.idexx.dicom.dao.ws;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.jmock.Expectations;
import org.jmock.auto.Mock;
import org.jmock.integration.junit4.JUnitRuleMockery;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.annotation.Transactional;

import com.idexx.dicom.IdexxdicomServicesApplication;
import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.entities.IdexxAPIKey;
import com.idexx.dicom.ae.entities.IdexxInvalidAE;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.impl.AETitleDaoImpl;

/**
 * @author vkandagatla
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = IdexxdicomServicesApplication.class)
public class AETitleDaoImplTest {
    @Autowired
    AETitleDao dao2Test;

    AETitleDao mockDao;

    @Rule
    public JUnitRuleMockery context = new JUnitRuleMockery();

    @Mock
    private EntityManager mockEntityManager;

    @Mock
    private Query query;

    @PersistenceContext
    private EntityManager entityManager;

	@Test
	public void contextLoads() {
	}

    @Test(expected = IdexxDicomAEConfigDbException.class)
    public void exceptionTest1() {

        context.checking(new Expectations() {
            {
                oneOf(mockEntityManager).createQuery(with(any(String.class)));
                will(returnValue(query));
                oneOf(query).setParameter(with(any(String.class)), with(any(Object.class)));
                will(returnValue(query));
                oneOf(query).getResultList();
                will(throwException(new IllegalStateException()));
            }
        });
        mockDao = new AETitleDaoImpl();
        ReflectionTestUtils.setField(mockDao, "entityManager", mockEntityManager);
        mockDao.findAETitle("test");
    }

    @Test(expected = IdexxDicomAEConfigDbException.class)
    public void exceptionTest2() {
        mockDao = new AETitleDaoImpl();
        ReflectionTestUtils.setField(mockDao, "entityManager", mockEntityManager);
        context.checking(new Expectations() {
            {
                oneOf(mockEntityManager).createQuery(with(any(String.class)));
                will(returnValue(query));
                exactly(2).of(query).setParameter(with(any(String.class)), with(any(Object.class)));
                will(returnValue(query));
                oneOf(query).getResultList();
                will(throwException(new IllegalStateException()));
            }
        });
        mockDao.findAETitle("test", "test");
    }

    @Test(expected = IdexxDicomAEConfigDbException.class)
    public void exceptionTest3() {
        final int numberOfTimes = 3;
        mockDao = new AETitleDaoImpl();
        ReflectionTestUtils.setField(mockDao, "entityManager", mockEntityManager);
        context.checking(new Expectations() {
            {
                oneOf(mockEntityManager).createQuery(with(any(String.class)));
                will(returnValue(query));
                exactly(numberOfTimes).of(query).setParameter(with(any(String.class)), with(any(Object.class)));
                will(returnValue(query));
                oneOf(query).getResultList();
                will(throwException(new IllegalStateException()));
            }
        });
        mockDao.findAETitle("test", "test", "test");
    }

    @Test(expected = IdexxDicomAEConfigDbException.class)
    public  void exceptionTest4() {
        mockDao = new AETitleDaoImpl();
        ReflectionTestUtils.setField(mockDao, "entityManager", mockEntityManager);
        context.checking(new Expectations() {
            {
                oneOf(mockEntityManager).merge((with(any(AETitle.class))));
                will(throwException(new IllegalStateException()));
            }
        });
        mockDao.createAETitle(new AETitle());
    }

    @Test(expected = IdexxDicomAEConfigDbException.class)
    public void exceptionTest5() {
        mockDao = new AETitleDaoImpl();
        ReflectionTestUtils.setField(mockDao, "entityManager", mockEntityManager);
        context.checking(new Expectations() {
            {
                oneOf(mockEntityManager).remove((with(any(AETitle.class))));
                will(throwException(new IllegalStateException()));
            }
        });
        mockDao.deleteAETitle(new AETitle());
    }

    @Test(expected = IdexxDicomAEConfigDbException.class)
    public void exceptionTest6() {
        mockDao = new AETitleDaoImpl();
        ReflectionTestUtils.setField(mockDao, "entityManager", mockEntityManager);
        context.checking(new Expectations() {
            {
                oneOf(mockEntityManager).merge((with(any(AETitle.class))));
                will(throwException(new IllegalStateException()));
            }
        });
        mockDao.updateAETitle(new AETitle());
    }

    @Test(expected = IdexxDicomAEConfigDbException.class)
    public void exceptionTest7() throws Exception {
        mockDao = new AETitleDaoImpl();
        final int numberOfTimes = 1;
        ReflectionTestUtils.setField(mockDao, "entityManager", mockEntityManager);
        context.checking(new Expectations() {
            {
                oneOf(mockEntityManager).createQuery(with(any(String.class)));
                will(returnValue(query));
                exactly(numberOfTimes).of(query).setParameter(with(any(String.class)), with(any(Object.class)));
                will(returnValue(query));
                oneOf(query).getSingleResult();
                will(throwException(new IllegalStateException()));
            }
        });
        mockDao.getInvalidAETitle("Test");

    }

    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {
    }

    /**
     * Test method for {@link com.idexx.dicom.dao.ws.AETitleDao#createAETitle()}
     * .
     */
    @Test
    @Transactional(readOnly = false)
    public void testAETitleDAO() {
        // Sample AE TITLE
        AETitle aeTitle = new AETitle();
        aeTitle.setAeTitle("Test2CreateAETitle");
        aeTitle.setApiKey("APIKeyTest");
        aeTitle.setEnabled(true);
        aeTitle.setIdentifiedByaeTitleOnly(true);
        aeTitle.setInstituteName("TestInstituteName");
        aeTitle.setSapId("TEST2SAPID");
        aeTitle.setId(1);
        // Create Test
        dao2Test.createAETitle(aeTitle);
        // Find Test
        List<AETitle> aeTitles = dao2Test.findAETitle("Test2CreateAETitle");
        assertNotNull(aeTitles);
        assertThat(aeTitles.size(), is(1));
        // Find Test
        aeTitles = dao2Test.findAETitle("Test2CreateAETitle", "TestInstituteName");
        assertNotNull(aeTitles);
        assertThat(aeTitles.size(), is(1));
        // Find Test
        aeTitles = dao2Test.findAETitleBySapId("TEST2SAPID");
        assertNotNull(aeTitles);
        assertThat(aeTitles.size(), is(1));

        // Find Test
        aeTitles = dao2Test.findAETitle("Test2CreateAETitle", "TestInstituteName", "TEST2SAPID");
        assertNotNull(aeTitles);
        assertThat(aeTitles.size(), is(1));

        // Find Test
        aeTitles = dao2Test.findAETitleBySapIdAndInstituteName("TEST2SAPID", "TestInstituteName");
        assertNotNull(aeTitles);
        assertThat(aeTitles.size(), is(1));

        // Update Test
        aeTitle.setSapId("TEST2SAPID2");
        this.dao2Test.updateAETitle(aeTitle);
        aeTitles = dao2Test.findAETitleByAETitleAndSapId("Test2CreateAETitle", "TEST2SAPID2");
        assertNotNull(aeTitles);
        assertThat(aeTitles.size(), is(1));
        assertThat(aeTitles.get(0).getSapId(), is("TEST2SAPID2"));
        // delete test
        aeTitles = dao2Test.findAETitle("Test2CreateAETitle");
        assertNotNull(aeTitles);
        assertTrue(aeTitles.size() > 0);
        dao2Test.deleteAETitle(aeTitles.get(0));
        // Find Test
        aeTitles = dao2Test.findAETitle("Test2CreateAETitle");
        assertNotNull(aeTitles);
        assertThat(aeTitles.size(), is(0));
        entityManager.close();
        aeTitles = dao2Test.findAETitle("Test2CreateAETitle");
    }

    @Test
    @Transactional
    public void testGetInvalidAE() {
        IdexxInvalidAE invalidAE = new IdexxInvalidAE();
        invalidAE.setAeTitle("Test");
        entityManager.merge(invalidAE);
        IdexxInvalidAE aeActual = dao2Test.getInvalidAETitle("Test");
        assertThat("Invalid IdexxInvalidAE", aeActual.getAeTitle(), is("Test"));
    }

    @Test
    @Transactional
    public void testGetIdexxAPIKey() {
        IdexxAPIKey iAPIKey = new IdexxAPIKey();
        iAPIKey.setApiKey("idex123456");
        entityManager.merge(iAPIKey);
        IdexxAPIKey iAPIKeyActual = dao2Test.getIdexxAPIKey("idex123456");
        assertThat("Invalid IdexxInvalidAE", iAPIKeyActual.getApiKey(), is("idex123456"));
    }

}
