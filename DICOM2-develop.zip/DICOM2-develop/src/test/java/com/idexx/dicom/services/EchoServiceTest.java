/**
 * 
 *   
 */
package com.idexx.dicom.services;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

    /**
     * 
     * @author lamarawadi
     * @version 1.3
     */
    @RunWith(JUnit4.class)
	public class EchoServiceTest {

	    // Web service URL    
	    private final String wsURL = "http://localhost:8080/idexx-dicomws/DicomServiceV1_1";
	       
	    // Request XML path    
	    private final String requestXMLPath = "src/test/resources/echo-soapui-project.xml";    
	       
	    @Test
	    public void test() {
//	        // Invoke the Web service    
//	        try {
//	            String webServiceResponse = SoapHttpClient.getResponse(wsURL,requestXMLPath);
//	            System.out.println("Response1111111111111: " + webServiceResponse); 
//	        } catch (FileNotFoundException  e) {
//	            e.printStackTrace();
//	        } catch (ConnectException ce) {
//	            ce.printStackTrace();
//	        } catch (Exception ee) {
//	            ee.printStackTrace();
//	        }
	    }
	}