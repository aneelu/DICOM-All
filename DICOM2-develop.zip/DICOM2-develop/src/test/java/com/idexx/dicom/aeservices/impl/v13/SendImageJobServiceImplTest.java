/**
 * <h1>Junit Test class for SendImageJobServiceImpl service using JMock</h1>
 */
package com.idexx.dicom.aeservices.impl.v13;


import static org.junit.Assert.assertTrue;

import org.jmock.Expectations;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.idexx.dicom.IdexxdicomServicesApplicationTests;
import com.idexx.dicom.ae.entities.BaseDicomImPluginConfig;
import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.ae.validator.impl.v13.IdexxSendImageValidatorImpl;
import com.idexx.dicom.dao.ws.IdexxSendImageJobDao;
import com.idexx.dicom.services.IdexxDicomServiceConstants;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v13.SendImageJobParamDTO;

/**
 * <pre>Junit Test class for SendImageJobServiceImpl service using JMock</pre>
 * @author nayeemuddin
 * @version 1.3
 */
public class SendImageJobServiceImplTest extends IdexxdicomServicesApplicationTests{
	
	JUnit4Mockery context = new JUnit4Mockery() {{
	      setImposteriser(ClassImposteriser.INSTANCE);
	   }};
	   
	 // Service class to test 
	 SendImageJobServiceImpl sendImageJobService;


	 IdexxSendImageJobDao sendImageJobDao = context.mock(IdexxSendImageJobDao.class);	 
	 IdexxSendImageValidatorImpl validator = context.mock(IdexxSendImageValidatorImpl.class);
	 IdexxDicomWSAthorizationServiceImpl idexxDicomWsAuthorizeService = context.mock(IdexxDicomWSAthorizationServiceImpl.class);
	 
	 private SendImageJobParamDTO dto;	    
	 private String jobId = "";

	/**
	 * @throws java.lang.Exception
	 * 
	 */
	@Before
	public void setUp() throws Exception {
		dto = new SendImageJobParamDTO();
        dto.setApiKey("Test");
        dto.setDestinationAETitle("Test");
        dto.setDestinationHost("TestHost");
        dto.setDestinationPort(0);
        dto.setImageAssetId("123");
        
		sendImageJobService = new SendImageJobServiceImpl();
		
        ReflectionTestUtils.setField(sendImageJobService, "validator", validator);
        ReflectionTestUtils.setField(sendImageJobService, "sendImageJobDao", sendImageJobDao);
        ReflectionTestUtils.setField(sendImageJobService, "idexxDicomWsAuthorizeService", idexxDicomWsAuthorizeService);
	}

	/**
	 * Test method for {@link com.idexx.dicom.aeservices.impl.v13.SendImageJobServiceImpl#performService(com.idexx.dicom.services.sendimage.dto.v13.SendImageJobParamDTO)}.
	 * @throws IdexxDicomAEConfigServiceException 
	 */
	@Test (expected = IdexxDicomAEConfigServiceException.class)
	public void testPerformService() throws IdexxDicomAEConfigServiceException {
		context.checking(new Expectations(){
			{
				oneOf(idexxDicomWsAuthorizeService).authorize(with(any(String.class)));
				will(throwException(new IdexxDicomAEConfigServiceException(IdexxDicomWSAthorizationServiceImpl.INVALID_API_KEY)));
			}
		});
		
		String errorCode = null;
		try {
			sendImageJobService.performService(dto);
		} catch (IdexxDicomAEConfigServiceException e) {
			errorCode = e.getErrorCode();
			throw e;
		}
		
		assertTrue("Invalid response recieved", IdexxDicomWSAthorizationServiceImpl.INVALID_API_KEY.equals(errorCode));
		
	}
	
	/**
	 * Test method for {@link com.idexx.dicom.aeservices.impl.v13.SendImageJobServiceImpl#performService(com.idexx.dicom.services.sendimage.dto.v13.SendImageJobParamDTO)}.
	 * @throws IdexxDicomAEConfigServiceException 
	 */
	@Test
	public void testPerformService1() throws IdexxDicomAEConfigServiceException {
		final BaseDicomImPluginConfig config = new BaseDicomImPluginConfig();
        config.setConfigName(IdexxDicomServiceConstants.SEND_RETRY_COUNT);
        config.setConfigValue(String.valueOf(IdexxDicomServiceConstants.DEFAULT_SEND_RETRY_COUNT));
        
        context.checking(new Expectations(){
        	{
        		oneOf(idexxDicomWsAuthorizeService).authorize(with(any(String.class)));
        		will(returnValue(true));
        		oneOf(validator).validate(with(any(SendImageJobParamDTO.class)));
        		will(returnValue(1));
        		oneOf(sendImageJobDao).createJob(with(any(IdexxSendImageJob.class)));
        		will(returnValue(jobId));
        		
        	}
        });
        
        final int port = 8080;
        SendImageJobParamDTO sendImageJob = new SendImageJobParamDTO();
        sendImageJob.setDestinationAETitle("Test");
        sendImageJob.setDestinationHost("Test2");
        sendImageJob.setDestinationPort(port);
        sendImageJob.setImageAssetId("123");
        sendImageJob.setApiKey("Test1");
        String val =  sendImageJobService.performService(sendImageJob);
        assertTrue("Invalid Response recieved", "".equals(val));
	}
	
}
