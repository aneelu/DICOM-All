/**
 * <h1>JUnit test cases for CreateRequestServiceImpl class using Mockito.</h1>
 */
package com.idexx.dicom.services.requestservice;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import com.idexx.dicom.IdexxdicomServicesApplicationTests;
import com.idexx.dicom.aeservices.impl.v13.IdexxDicomWSAthorizationServiceImpl;
import com.idexx.dicom.domain.RequestDetails;
import com.idexx.dicom.mapper.EntityMapper;
import com.idexx.dicom.repo.RequestDetailsRepository;
import com.idexx.dicom.sendimage.ImageManagerStoreServiceProviderWraper;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO;
import com.idexx.dicom.services.requestservice.validator.CreateRequestValidator;
import com.idexx.imaging.imagemanager.soap.IDEXXImageManagerServices;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;
import com.idexx.imaging.imagemanager.soap.PatientDTO;
import com.idexx.imaging.imagemanager.soap.PatientSearchRequestDTO;
import com.idexx.imaging.imagemanager.soap.StoreImageMetaDataDTO;

/**
 * <pre>
 * JUnit test cases for CreateRequestServiceImpl class using Mockito.
 * </pre>
 * 
 * @author nayeemuddin
 * @version 1.3
 */
public class CreateRequestServiceImplTest extends IdexxdicomServicesApplicationTests {

	@InjectMocks
	CreateRequestServiceImpl createRequestServiceImpl = new CreateRequestServiceImpl();

	RequestDetailsRepository requestDetailsDao;
	EntityMapper entityMapper;
	IdexxDicomWSAthorizationServiceImpl idexxDicomWsAuthorizeService;
	ImageManagerStoreServiceProviderWraper imageManagerStoreServiceProviderWraper;
	CreateRequestValidator createRequestValidator;
	IDEXXImageManagerServices idexxImService;

	/**
	 * <pre>
	 * Initialize and create Mockito objects for the classes involved in  CreateRequestServiceImpl class.
	 * </pre>
	 * 
	 * @throws java.lang.Exception
	 * 
	 */
	@Before
	public void setUp() throws Exception {
		requestDetailsDao = mock(RequestDetailsRepository.class);
		entityMapper = mock(EntityMapper.class);
		idexxDicomWsAuthorizeService = mock(IdexxDicomWSAthorizationServiceImpl.class);
		imageManagerStoreServiceProviderWraper = mock(ImageManagerStoreServiceProviderWraper.class);
		createRequestValidator = mock(CreateRequestValidator.class);
		idexxImService = mock(IDEXXImageManagerServices.class);

		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test method for 
	 * Patient record exist in Image Manger DB and create record in Dicom DB.
	 * {@link com.idexx.dicom.services.requestservice.CreateRequestServiceImpl#createRequest(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * 
	 * @throws IdexxDicomAEConfigServiceException
	 * @throws IdexxServiceException_Exception
	 */
	@Test
	public void testCreateRequest() throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {
		String studyInstancsUID = "1.2.826.0.1.3680043.2.950.2014052026.20160114140241";
		List<PatientDTO> listPatient = new ArrayList<PatientDTO>();
		RequestDetails requestDetails = new RequestDetails();

		when(idexxDicomWsAuthorizeService.authorize(any(String.class))).thenReturn(true);
		when(createRequestValidator.validate(any(RequestDetailsDTO.class))).thenReturn(1);
		when(entityMapper.generateStudyInstanceUid(any(RequestDetailsDTO.class))).thenReturn(studyInstancsUID);
		when(imageManagerStoreServiceProviderWraper.getService()).thenReturn(idexxImService);
		when(idexxImService.searchPatient(any(PatientSearchRequestDTO.class))).thenReturn(listPatient);
		when(requestDetailsDao.save(any(RequestDetails.class))).thenReturn(requestDetails);

		RequestDetailsDTO requestDTO = new RequestDetailsDTO();
		requestDTO.setApiKey("TestAPIKey_Valid");

		String response = createRequestServiceImpl.createRequest(requestDTO);
		assertEquals(response, studyInstancsUID);
	}

	/**
	 * Test method for
	 *  Patient record does not exist in Image Manger DB and invoke Image Manager service
	 *  to create Patient record in Image Manager DB and then create record in Dicom DB.
	 * {@link com.idexx.dicom.services.requestservice.CreateRequestServiceImpl#createRequest(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * @throws IdexxDicomAEConfigServiceException
	 * @throws IdexxServiceException_Exception
	 * 
	 */
	@Test
	public void testCreateRequest1() throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {

		String studyInstancsUID = "1.2.826.0.1.3680043.2.950.2014052026.20160114140241";
		String storeImageMetaDataResp = "1.2.826.0.1.3680043.2.950.201402.20160113000000.nbekaed3trukgpdwgyr5daavx.1";
		List<PatientDTO> listPatient = new ArrayList<PatientDTO>();
		RequestDetails requestDetails = new RequestDetails();

		when(idexxDicomWsAuthorizeService.authorize(any(String.class))).thenReturn(true);
		when(createRequestValidator.validate(any(RequestDetailsDTO.class))).thenReturn(1);
		when(entityMapper.generateStudyInstanceUid(any(RequestDetailsDTO.class))).thenReturn(studyInstancsUID);
		when(imageManagerStoreServiceProviderWraper.getService()).thenReturn(idexxImService);
		when(idexxImService.searchPatient(any(PatientSearchRequestDTO.class))).thenReturn(listPatient);
		when(idexxImService.storeImageMetaData(any(StoreImageMetaDataDTO.class))).thenReturn(storeImageMetaDataResp);
		when(requestDetailsDao.save(any(RequestDetails.class))).thenReturn(requestDetails);

		RequestDetailsDTO requestDTO = new RequestDetailsDTO();
		requestDTO.setApiKey("TestAPIKey_Valid");

		String response = createRequestServiceImpl.createRequest(requestDTO);
		assertEquals(response, studyInstancsUID);
	}

	/**
	 * Test method for Invalid API key test
	 * {@link com.idexx.dicom.services.requestservice.CreateRequestServiceImpl#createRequest(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * @throws IdexxDicomAEConfigServiceException
	 * @throws IdexxServiceException_Exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public void testCreateRequest2() throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {

		when(idexxDicomWsAuthorizeService.authorize(any(String.class)))
				.thenThrow(new IdexxDicomAEConfigServiceException(IdexxDicomWSAthorizationServiceImpl.INVALID_API_KEY,
						IdexxDicomWSAthorizationServiceImpl.INVALID_API_KEY));

		RequestDetailsDTO requestDTO = new RequestDetailsDTO();
		requestDTO.setApiKey("TestAPIKey_Invalid");
		String errorCode = null;
		try {
			createRequestServiceImpl.createRequest(requestDTO);
		} catch (IdexxDicomAEConfigServiceException exp) {
			errorCode = exp.getMessage();
			throw exp;
		}
		assertTrue("Invalid Response recieved", IdexxDicomWSAthorizationServiceImpl.INVALID_API_KEY.equals(errorCode));

	}

}
