/**
 * 
 *  
 */
package com.idexx.dicom.aeservices.impl;

import static org.junit.Assert.assertTrue;

import org.jmock.Expectations;
import org.jmock.auto.Mock;
import org.jmock.integration.junit4.JUnitRuleMockery;
import org.jmock.lib.action.VoidAction;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.springframework.test.util.ReflectionTestUtils;

import com.idexx.dicom.ae.entities.AEEntity;
import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.validator.AETitleValidator;
import com.idexx.dicom.aeservices.IdexxDicomWSAthorizationService;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.dto.AETitleDTO;
import com.idexx.dicom.services.dto.CreateAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;


/**
 * <pre>Test Cases Related CreateAETitleService</pre>
 * @author smallela
 * @version 1.3
 */

@RunWith(JUnit4.class)
public class CreateAETitleServiceTest {
    private static final int DEFAULT_PORT = 8080;
    private CreateAETitleService service;

    @Rule
    public JUnitRuleMockery context = new JUnitRuleMockery();

    @Mock
    private AETitleDao mockDao;

    @Mock
    private AETitleValidator mockValidator;

    @Mock
    private IdexxDicomWSAthorizationService idexxDicomWsAuthorizeService;

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.CreateAETitleService#validate(com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public final void testValidate() throws IdexxDicomAEConfigServiceException {
        CreateAETitleDTO dto = new CreateAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setSapId("SAPID");
        dto.setInstituteName("TestIng");
        dto.setApiKey("TESTAPIKEY");
        dto.setIdentifiedByAeTitleOnly(false);
        context.checking(new Expectations() {
            {
                oneOf(mockValidator).validate(with(any(AETitleDTO.class)));
                will(returnValue(1));

            }
        });
        service = new CreateAETitleService();
        ReflectionTestUtils.setField(service, "validator", mockValidator);

        int val = service.validate(dto);
        assertTrue("Create AE Failed#1", 1 == val);

    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.CreateAETitleService#validate(com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public final void testPerformService() throws IdexxDicomAEConfigServiceException {
        CreateAETitleDTO dto = new CreateAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setSapId("SAPID");
        dto.setInstituteName("TestIng");
        dto.setApiKey("TESTAPIKEY");
        dto.setIdentifiedByAeTitleOnly(false);
        context.checking(new Expectations() {
            {
                oneOf(idexxDicomWsAuthorizeService).authorize(with(any(String.class)));
                will(returnValue(true));
                oneOf(mockValidator).validate(with(any(AETitleDTO.class)));
                will(returnValue(1));
                oneOf(mockDao).createAETitle(with(any(AETitle.class)));
            }
        });
        service = new CreateAETitleService();
        ReflectionTestUtils.setField(service, "validator", mockValidator);
        ReflectionTestUtils.setField(service, "idexxDicomWsAuthorizeService", idexxDicomWsAuthorizeService);
        ReflectionTestUtils.setField(service, "aeTitleDao", mockDao);
        service.performService(dto);
        assertTrue("Create AE Failed#1", true);

    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.CreateAETitleService#doService(com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public final void testDoService1() throws IdexxDicomAEConfigServiceException {
        final AETitle aeTitle = new AETitle();

        CreateAETitleDTO dto = new CreateAETitleDTO();
        dto.setDvmSpecialist(true);
        dto.setHostName("localhost");
        dto.setPort(DEFAULT_PORT);
        dto.setAeTitle("Test123");
        dto.setSapId("SAPID");
        dto.setInstituteName("TestIng");
        dto.setApiKey("TESTAPIKEY");
        dto.setIdentifiedByAeTitleOnly(true);
        aeTitle.setAeTitle(dto.getAeTitle());
        aeTitle.setApiKey(dto.getApiKey());
        aeTitle.setSapId(dto.getSapId());
        aeTitle.setInstituteName(dto.getInstituteName());
        aeTitle.setIdentifiedByaeTitleOnly(dto.isIdentifiedByAeTitleOnly());

        context.checking(new Expectations() {
            {
                oneOf(mockDao).createAE(with(any(AEEntity.class)));
                will(VoidAction.INSTANCE);

            }
        });
        service = new CreateAETitleService();
        ReflectionTestUtils.setField(service, "aeTitleDao", mockDao);

        int val = service.doService(dto);
        assertTrue("Create AE Failed#1", 1 == val);

    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.CreateAETitleService#doService(com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public final void testDoService2() throws IdexxDicomAEConfigServiceException {
        final AETitle aeTitle = new AETitle();

        CreateAETitleDTO dto = new CreateAETitleDTO();
        dto.setDvmSpecialist(false);
        dto.setHostName("localhost");
        dto.setPort(DEFAULT_PORT);
        dto.setAeTitle("Test1");
        dto.setSapId("SAPID");
        dto.setInstituteName("TestIng");
        dto.setApiKey("TESTAPIKEY");
        dto.setIdentifiedByAeTitleOnly(true);
        aeTitle.setAeTitle(dto.getAeTitle());
        aeTitle.setApiKey(dto.getApiKey());
        aeTitle.setSapId(dto.getSapId());
        aeTitle.setInstituteName(dto.getInstituteName());
        aeTitle.setIdentifiedByaeTitleOnly(dto.isIdentifiedByAeTitleOnly());

        context.checking(new Expectations() {
            {
                oneOf(mockDao).createAETitle(with(any(AETitle.class)));
                will(throwException(new IdexxDicomAEConfigDbException()));

            }
        });
        service = new CreateAETitleService();
        ReflectionTestUtils.setField(service, "aeTitleDao", mockDao);

        service.doService(dto);

    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.CreateAETitleService#doService(com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public final void testDoService3() throws IdexxDicomAEConfigServiceException {
        final AETitle aeTitle = new AETitle();

        CreateAETitleDTO dto = new CreateAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setSapId("SAPID");
        dto.setInstituteName("TestIng");
        dto.setApiKey("TESTAPIKEY");
        dto.setIdentifiedByAeTitleOnly(true);
        aeTitle.setAeTitle(dto.getAeTitle());
        aeTitle.setApiKey(dto.getApiKey());
        aeTitle.setSapId(dto.getSapId());
        aeTitle.setInstituteName(dto.getInstituteName());
        aeTitle.setIdentifiedByaeTitleOnly(dto.isIdentifiedByAeTitleOnly());

        context.checking(new Expectations() {
            {
                oneOf(mockDao).createAETitle(with(any(AETitle.class)));
                will(throwException(new IdexxDicomAEConfigDbException()));

            }
        });
        service = new CreateAETitleService();
        ReflectionTestUtils.setField(service, "aeTitleDao", mockDao);

        service.doService(dto);

    }

}
