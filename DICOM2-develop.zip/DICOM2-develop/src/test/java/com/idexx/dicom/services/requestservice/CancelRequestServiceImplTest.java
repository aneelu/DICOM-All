/**
 * 
 */
package com.idexx.dicom.services.requestservice;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.domain.RequestDetails;
import com.idexx.dicom.repo.RequestDetailsRepository;
import com.idexx.dicom.sendimage.SendImageJobConstants;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;

/**
 * <pre>Test Cases Related CancelRequestServiceImpl</pre>
 * @author smallela
 * @version 1.3
 */
public class CancelRequestServiceImplTest {
	
	@InjectMocks
	CancelRequestServiceImpl cancelRequestService=new CancelRequestServiceImpl();
	private RequestDetailsRepository requestDetailsDao;
	private RequestDetails requestDetails;
	//private String StudyInstanceUID=null;
	
	
	@Before
	public void setUp() throws Exception {
		
		requestDetails = mock(RequestDetails.class); 
		requestDetailsDao = mock(RequestDetailsRepository.class);
		MockitoAnnotations.initMocks(this);
		
	}
	/**
	 *Test method for
     * {@link com.idexx.dicom.services.requestservice.CancelRequestServiceImpl#cancelRequest
	 * @throws IdexxDicomAEConfigServiceException
	 * @throws IdexxServiceException_Exception
	 * 
	 */
	@Test
	public void cancelRequest() throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {
		final String actual = "Update Successfully";
		List<RequestDetails> listReqDetails= new ArrayList<RequestDetails>();
		requestDetails=new RequestDetails();
		requestDetails.getStudyInstanceUID();
		requestDetails.setStatus(SendImageJobConstants.REQUEST_STATUS_CANCEL);
		listReqDetails.add(requestDetails);
		when(requestDetailsDao.findByStudyInstanceUID(any(String.class))).thenReturn(listReqDetails);
		when(requestDetailsDao.save(any(RequestDetails.class))).thenReturn(requestDetails);
		
		String expected=cancelRequestService.cancelRequest(requestDetails.getStudyInstanceUID());
		assertEquals(expected, actual);
		
		
	}
	
}
