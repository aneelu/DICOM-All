package com.idexx.dicom.ae.validator.impl.v13;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import com.idexx.dicom.services.dto.v13.IdexxErrorLogParamDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;


/**
 * <pre>Description of the class</pre>
 * @author rkaranam
 * @version 1.3
 */
@RunWith(JUnit4.class)
public class StoreErrorLogValidatorTest {

    @Rule
    public ExpectedException expectedEx = ExpectedException.none();

    private IdexxErrorLogParamDTO dto = new IdexxErrorLogParamDTO();
    
	private StoreErrorLogValidatorImpl storeErrorValidator = new StoreErrorLogValidatorImpl();
	
	@Test
	public final void testWhenStartDateIsEmptyThenReturnErrorMsg() throws Exception {
        dto.setStartDate(null);
        storeErrorValidator = new StoreErrorLogValidatorImpl();
        expectedEx.expect(IdexxDicomAEConfigServiceException.class);
        expectedEx.expectMessage("ERR_argument_missing_mandatory");
        storeErrorValidator.validate(dto);
	}
	
	@Test
	public final void testWhenEndDateIsEmptyThenReturnErrorMsg() throws Exception {
	    dto.setEndDate(null);
        storeErrorValidator = new StoreErrorLogValidatorImpl();
        expectedEx.expect(IdexxDicomAEConfigServiceException.class);
        expectedEx.expectMessage("ERR_argument_missing_mandatory");
        storeErrorValidator.validate(dto);
	}
	
    @Test
    public final void testWhenStartDateIsNotValidThenReturnErrorMsg() throws Exception {
        dto.setStartDate("abcd");
        dto.setEndDate("2014-01-24T11:20:24.0z");
        expectedEx.expect(IdexxDicomAEConfigServiceException.class);
        expectedEx.expectMessage("ERR_invalid_start_date");
        storeErrorValidator.validate(dto);
    }

    @Test
    public final void testWhenEndDateIsNotValidThenReturnErrorMsg() throws Exception {
        dto.setStartDate("2014-01-24T11:20:24.0z");
        dto.setEndDate("abcd");
        expectedEx.expect(IdexxDicomAEConfigServiceException.class);
        expectedEx.expectMessage("ERR_invalid_end_date");
        storeErrorValidator.validate(dto);
    }

    @Test
    public final void testWhenStartDateIsLessThanEndDateThenReturnErrorMsg() throws Exception {
        dto.setStartDate("2014-04-29T12:00:00.0+05:30");
        dto.setEndDate("2014-04-29T12:00:00.0+05:30");

        //dto.setStartDate("2014-03-24T11:20:24.0z");
        //dto.setEndDate("2013-01-24T11:20:24.0z");
        //2014-04-29T12:00:00.0+05:30
        //expectedEx.expect(IdexxDicomAEConfigServiceException.class);
        //expectedEx.expectMessage("ERR_invalid_date_range");
        storeErrorValidator.validate(dto);
    }

    @Test
    public final void testWhenValidStartEndDateThenReturnSuccess() throws Exception {
        dto.setStartDate("2013-03-24T11:20:24.0z");
        dto.setEndDate("2014-01-24T11:20:24.0z");
        boolean isValid = storeErrorValidator.validate(dto);
        Assert.assertTrue(isValid);
    }
}
