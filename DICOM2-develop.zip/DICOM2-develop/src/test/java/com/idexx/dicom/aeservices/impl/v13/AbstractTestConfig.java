package com.idexx.dicom.aeservices.impl.v13;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.idexx.dicom.IdexxdicomServicesApplication;

/**
 * Abstract class will start up spring boot application context for unit tests 
 * @author vvanjarana
 * @version 1.3
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = IdexxdicomServicesApplication.class)
public abstract class AbstractTestConfig {
    
	@Test
	public void contextLoads() {
	}
}
