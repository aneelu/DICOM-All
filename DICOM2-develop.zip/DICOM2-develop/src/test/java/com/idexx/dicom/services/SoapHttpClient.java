/**
 * 
 * 
 */
package com.idexx.dicom.services;

/**
 * @author lamarawadi
 * @version 1.3
 */
import java.io.BufferedReader;

import java.io.FileNotFoundException;
import java.io.FileReader;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.RequestEntity;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.lang.StringUtils;

	@SuppressWarnings("resource")
	public class SoapHttpClient {

		public static String getResponse(String webServiceURL, String requestXMLPath)
				throws FileNotFoundException, Exception {
			PostMethod post = null;
			HttpClient client = new HttpClient();

			StringBuffer requestFileContents = new StringBuffer();
			BufferedReader bufferedReader = new BufferedReader(new FileReader(
					requestXMLPath));
			String line = null;
			while ((line = bufferedReader.readLine()) != null) {
				requestFileContents.append(line);
			}

			post = new PostMethod(webServiceURL);
			post.setRequestHeader("Accept",
					"application/soap+xml,application/dime,multipart/related,text/*");
			post.setRequestHeader("SOAPAction", "");

			RequestEntity entity = new StringRequestEntity(
					requestFileContents.toString(), "text/xml", "utf-8");
			post.setRequestEntity(entity);

			int result = client.executeMethod(post);
			String response = StringUtils.EMPTY;
			if (result == 200) {
				response = post.getResponseBodyAsString();
			}
			post.releaseConnection();
			return response;
		}
	}