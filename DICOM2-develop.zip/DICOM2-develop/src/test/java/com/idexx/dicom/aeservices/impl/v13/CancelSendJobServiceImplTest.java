/**
 * <h1>JUnit Test cases for CancelSendJobServiceImpl class</h1>
 */
package com.idexx.dicom.aeservices.impl.v13;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.jmock.Expectations;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.idexx.dicom.IdexxdicomServicesApplication;
import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.ae.validator.impl.v13.CancelSendJobServiceValidatorImpl;
import com.idexx.dicom.aeservices.impl.v13.CancelSendJobServiceImpl;
import com.idexx.dicom.dao.ws.IdexxSendImageJobDao;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v13.CancelSendJobParamDTO;


/**
 * <pre>JUnit Test cases for CancelSendJobServiceImpl class</pre>
 * @author nayeemuddin
 * @version 1.3
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = IdexxdicomServicesApplication.class)
public class CancelSendJobServiceImplTest {
	
	JUnit4Mockery context = new JUnit4Mockery() {
		{
			setImposteriser(ClassImposteriser.INSTANCE);
		}
	};
	
	//Service class need to test 
	CancelSendJobServiceImpl cancelSendJobService;
	
	 CancelSendJobServiceValidatorImpl validator = context.mock(CancelSendJobServiceValidatorImpl.class);
	 IdexxSendImageJobDao cancelSendImageJobDao = context.mock(IdexxSendImageJobDao.class);
	

	/**
	 * <pre>creating object required before test </pre>
	 * @throws java.lang.Exception
	 * 
	 */
	@Before
	public void setUp() throws Exception {
		cancelSendJobService = new  CancelSendJobServiceImpl();
		
	     ReflectionTestUtils.setField(cancelSendJobService, "validator", validator);
	     ReflectionTestUtils.setField(cancelSendJobService, "cancelSendImageJobDao", cancelSendImageJobDao);
	}

	/**
	 * Test method for {@link com.idexx.dicom.aeservices.impl.v13.CancelSendJobServiceImpl#performService(com.idexx.dicom.services.sendimage.dto.v13.CancelSendJobParamDTO)}.
	 * @throws IdexxDicomAEConfigServiceException 
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testPerformService() throws IdexxDicomAEConfigServiceException {
		final String actual = "update successful";		
        final List<IdexxSendImageJob> idexJobs = new ArrayList<IdexxSendImageJob>();
        IdexxSendImageJob sib = new IdexxSendImageJob();
        sib.setJobId("2c9690c6402138490140247fe1000006");
        idexJobs.add(sib);
        
        context.checking(new Expectations() {
            {
                oneOf(validator).validate(with(any(CancelSendJobParamDTO.class)));
                will(returnValue(1));                
                oneOf(cancelSendImageJobDao).getJob(with(any(List.class)));
                will(returnValue(idexJobs));                
                oneOf(cancelSendImageJobDao).cancelSendJob(with(any(IdexxSendImageJob.class)));
                will(returnValue(actual));
            }
        });
        
        CancelSendJobParamDTO fdto = new CancelSendJobParamDTO();
        fdto.setJobId("2c9690c6402138490140247fe1000006");
        fdto.setJobStatusDescription("Cancelling the job");

        String expected = cancelSendJobService.performService(fdto);
        assertEquals(expected, actual);
	}

}
