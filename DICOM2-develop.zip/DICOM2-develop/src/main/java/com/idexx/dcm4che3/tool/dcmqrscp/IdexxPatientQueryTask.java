package com.idexx.dcm4che3.tool.dcmqrscp;

import java.util.ArrayList;
import java.util.List;

import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;
import org.dcm4che3.data.VR;
import org.dcm4che3.net.Association;
import org.dcm4che3.net.pdu.PresentationContext;
import org.dcm4che3.net.service.BasicQueryTask;
import org.dcm4che3.net.service.DicomServiceException;

public class IdexxPatientQueryTask extends BasicQueryTask {

    protected final String availability;
    protected final String[] patIDs;
    protected Attributes patRec;
    
    // Static db
    private List<String> patients;
    // Static db
    

    public IdexxPatientQueryTask(Association as, PresentationContext pc, Attributes rq, Attributes keys,
            String availability) throws DicomServiceException {
        super(as, pc, rq, keys);
        this.availability = availability;
        this.patIDs = keys.getStrings(Tag.PatientID);
        loadPatients();
    }

    @Override
    public boolean hasMoreMatches() throws DicomServiceException {
    	return patients.size() != 0;
    }

    @Override
    public Attributes nextMatch() throws DicomServiceException {
        String pat = patients.get(0);
        Attributes attrs = new Attributes(2);
        attrs.setString(Tag.StudyDescription, VR.LO, "StudyDescription");
        attrs.setString(Tag.PatientBreedDescription, VR.LO, "PatientBreedDescription");
        attrs.setString(Tag.PatientBirthDate, VR.DA, "02/02/2000");
        attrs.setString(Tag.PatientSex, VR.CS, "M");
        attrs.setString(Tag.ResponsiblePerson, VR.PN, "ResponsiblePerson");
        attrs.setString(Tag.PatientID, VR.LO, pat);
        attrs.setString(Tag.PatientName, VR.PN, "PatientName");
        attrs.setString(Tag.PatientSpeciesDescription, VR.LO, "PatientSpeciesDescription");
        attrs.setString(Tag.ScheduledProcedureStepStatus, VR.CS, "ScheduledProcedureStepStatus");
        attrs.setString(Tag.StudyDate, VR.DA, "02/02/2015");
        attrs.setString(Tag.ScheduledProcedureStepStartDate, VR.DA, "02/02/2015");
        attrs.setString(Tag.StudyTime, VR.TM, "02/02/2015:10:10");
        attrs.setString(Tag.ModalitiesInStudy, VR.CS, "02/02/2015");
        attrs.setString(Tag.AccessionNumber, VR.SH, "000001");
        attrs.setString(Tag.StudyID, VR.SH, "000001");
        attrs.setString(Tag.StudyInstanceUID, VR.UI, "000001");
        attrs.setString(Tag.Modality, VR.CS, "PACS");
        attrs.setString(Tag.SeriesNumber, VR.IS, "000001");
        attrs.setString(Tag.SeriesInstanceUID, VR.UI, "000001");
        attrs.setString(Tag.InstanceNumber, VR.IS, "00001");
        attrs.setString(Tag.SOPInstanceUID, VR.UI, "1111010010");
        attrs.setString(Tag.RequestingPhysician, VR.PN, "RequestingPhysician");
        attrs.setString(Tag.RequestedProcedureDescription, VR.LO, "RequestedProcedureDescription");
        attrs.setString(Tag.RequestedProcedureID, VR.SH, "RequestedProcedureID");
        attrs.setString(Tag.IssuerOfPatientID, VR.LO, "IssuerOfPatientID");
        attrs.setString(Tag.ScheduledProcedureStepStartDate, VR.DA, "33242343");
        attrs.setString(Tag.ScheduledProcedureStepStatus, VR.CS, "ScheduledProcedureStepStatus");
        attrs.setString(Tag.ScheduledProcedureStepID, VR.SH, "ScheduledProcedureStepID");
        patients.remove(pat);
        return attrs;
    }

    @Override
    protected Attributes adjust(Attributes match) throws DicomServiceException {
        Attributes adjust = super.adjust(match);
        adjust.remove(Tag.DirectoryRecordType);
        if (keys.contains(Tag.SOPClassUID))
             adjust.setString(Tag.SOPClassUID, VR.UI,
                     match.getString(Tag.ReferencedSOPClassUIDInFile));
        if (keys.contains(Tag.SOPInstanceUID))
             adjust.setString(Tag.SOPInstanceUID, VR.UI,
                     match.getString(Tag.ReferencedSOPInstanceUIDInFile));
        adjust.setString(Tag.QueryRetrieveLevel, VR.CS,
                keys.getString(Tag.QueryRetrieveLevel));
        adjust.setString(Tag.RetrieveAETitle, VR.AE, as.getCalledAET());
        if (availability != null)
            adjust.setString(Tag.InstanceAvailability, VR.CS, availability);
        adjust.setString(Tag.StorageMediaFileSetID, VR.SH, /*ddr.getFileSetID()*/"FileSetID");
        adjust.setString(Tag.StorageMediaFileSetUID, VR.UI, /*ddr.getFileSetUID()*/"FileSetUID");
        match.setString(Tag.SOPClassUID, VR.UI,
                match.getString(Tag.ReferencedSOPClassUIDInFile));
        match.setString(Tag.SOPInstanceUID, VR.UI,
                match.getString(Tag.ReferencedSOPInstanceUIDInFile));

        return adjust;
    }

/*    private void wrappedFindNextPatient() throws DicomServiceException {
        try {
            findNextPatient();
        } catch (IOException e) {
            throw new DicomServiceException(Status.UnableToProcess, e);
        }
    }

    protected boolean findNextPatient() throws IOException {
        if (patRec == null)
            patRec = ddr.findPatientRecord(patIDs);
        else if (patIDs != null && patIDs.length == 1)
            patRec = null;
        else
            patRec = ddr.findNextPatientRecord(patRec, patIDs);

        return patRec != null;
    }
*/    
    private void loadPatients() {
        patients = new ArrayList<String>();
    	patients.add("PID00001");
//    	patients.add("PID00002");
//    	patients.add("PID00003");
    }
}
