package com.idexx.dcm4che3.tool.mppsscp;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.IOD;
import org.dcm4che3.data.Tag;
import org.dcm4che3.data.ValidationResult;
import org.dcm4che3.net.ApplicationEntity;
import org.dcm4che3.net.Association;
import org.dcm4che3.net.Connection;
import org.dcm4che3.net.Device;
import org.dcm4che3.net.TransferCapability;
import org.dcm4che3.net.service.BasicCEchoSCP;
import org.dcm4che3.net.service.BasicMPPSSCP;
import org.dcm4che3.net.service.DicomServiceException;
import org.dcm4che3.net.service.DicomServiceRegistry;
import org.dcm4che3.tool.common.CLIUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Gunter Zeilinger <gunterze@gmail.com>
 */
public class MppsSCP {

    private static ResourceBundle rb =
            ResourceBundle.getBundle("org.dcm4che3.tool.mppsscp.messages");

    private static final Logger LOG = LoggerFactory.getLogger(MppsSCP.class);

    private Device device = null;
    private ApplicationEntity ae = null;
    private Connection conn = null;
    private IOD mppsNCreateIOD;
    private IOD mppsNSetIOD;

    protected final BasicMPPSSCP mppsSCP = new BasicMPPSSCP() {

        @Override
        protected Attributes create(Association as, Attributes rq,
                                    Attributes rqAttrs, Attributes rsp) throws DicomServiceException {
       		return MppsSCP.this.create(as, rq, rqAttrs);
//       		rsp.setString(Tag.Status, VR.US, /*ddr.getFileSetID()*/"273");
        }

        @Override
        protected Attributes set(Association as, Attributes rq, Attributes rqAttrs,
                                 Attributes rsp) throws DicomServiceException {
            return MppsSCP.this.set(as, rq, rqAttrs);
        }
    };
    private boolean started = false;

    public MppsSCP(String[] args, Device device, ApplicationEntity ae, Connection conn, DicomServiceRegistry serviceRegistry) throws IOException, ParseException, GeneralSecurityException {
    	this.device = device;
    	this.ae = ae;
    	this.conn = conn;
        CommandLine cl = MppsSCP.parseComandLine(args);

        serviceRegistry.addDicomService(new BasicCEchoSCP());
        serviceRegistry.addDicomService(mppsSCP);
        this.ae.setDimseRQHandler(serviceRegistry);

        CLIUtils.configureBindServer(this.conn, ae, cl);
        CLIUtils.configure(this.conn, cl);
        configureTransferCapability(ae, cl);

        configure(cl.hasOption("no-validate"),
                cl.getOptionValue("mpps-ncreate-iod", "resource:mpps-ncreate-iod.xml"),
                cl.getOptionValue("mpps-nset-iod", "resource:mpps-nset-iod.xml"),
                cl.hasOption("ignore"),
                cl.getOptionValue("directory", "."));

        start();
    }

    private void configure(boolean hasOptionNoValidate,
                           String mppsNCreateIOD,
                           String mppsNSetIOD,
                           boolean ignore,
                           String directory) throws IOException, GeneralSecurityException {
        configureIODs(this, hasOptionNoValidate,
                mppsNCreateIOD,
                mppsNSetIOD);

/*        ExecutorService executorService = Executors.newCachedThreadPool();
        ScheduledExecutorService scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
        device.setScheduledExecutor(scheduledExecutorService);
        device.setExecutor(executorService);*/
    }

    public void start() throws IOException, GeneralSecurityException {
        started = true;
    }

    public void stop() {

        if (!started) return;

        started = false;

        device.unbindConnections();
        ((ExecutorService) device.getExecutor()).shutdown();
        device.getScheduledExecutor().shutdown();

        //very quick fix to block for listening connection
        while (device.getConnections().get(0).isListening())
        {
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                // ignore
            }
        }

    }

    private void setMppsNCreateIOD(IOD mppsNCreateIOD) {
        this.mppsNCreateIOD = mppsNCreateIOD;
    }

    private void setMppsNSetIOD(IOD mppsNSetIOD) {
        this.mppsNSetIOD = mppsNSetIOD;
    }

    private static CommandLine parseComandLine(String[] args) throws ParseException {
        Options opts = new Options();
        CLIUtils.addBindServerOption(opts);
        CLIUtils.addAEOptions(opts);
        CLIUtils.addCommonOptions(opts);
        return CLIUtils.parseComandLine(args, opts, rb, MppsSCP.class);
    }

    private static void configureIODs(MppsSCP main, boolean hasOptionNoValidate, String mppsNCreateIOD, String mppsNSetIOD)
            throws IOException {
        if (!hasOptionNoValidate) {
            main.setMppsNCreateIOD(IOD.load(mppsNCreateIOD));
            main.setMppsNSetIOD(IOD.load(mppsNSetIOD));
        }
    }

    private static void configureTransferCapability(ApplicationEntity ae,
                                                    CommandLine cl) throws IOException {
        Properties p = CLIUtils.loadProperties(
                cl.getOptionValue("sop-classes",
                        "resource:sop-classes.properties"),
                null);
        for (String cuid : p.stringPropertyNames()) {
            String ts = p.getProperty(cuid);
            ae.addTransferCapability(
                    new TransferCapability(null,
                            CLIUtils.toUID(cuid),
                            TransferCapability.Role.SCP,
                            CLIUtils.toUIDs(ts)));
        }
    }

    private Attributes create(Association as, Attributes rq, Attributes rqAttrs)
            throws DicomServiceException {
        if (mppsNCreateIOD != null) {
            ValidationResult result = rqAttrs.validate(mppsNCreateIOD);
            if (!result.isValid())
                throw DicomServiceException.valueOf(result, rqAttrs);
        }
        
        String patientID = rqAttrs.getString(Tag.PatientID);
        String sopInstanceUID = rq.getString(Tag.SOPInstanceUID);
        String ppsStatus = rq.getString(Tag.PerformedProcedureStepStatus);
        String scheduledStepAttributesSeq = rqAttrs.getString(Tag.ScheduledStepAttributesSequence);
        String studyInstanceUID = rqAttrs.getString(Tag.StudyInstanceUID);
        String spsID = rqAttrs.getString(Tag.ScheduledProcedureStepID);
        
        return null;
    }

    private Attributes set(Association as, Attributes rq, Attributes rqAttrs)
            throws DicomServiceException {
        if (mppsNSetIOD != null) {
            ValidationResult result = rqAttrs.validate(mppsNSetIOD);
            if (!result.isValid())
                throw DicomServiceException.valueOf(result, rqAttrs);
        }

        return null;
    }
}
