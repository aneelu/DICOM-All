/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dicom.conf;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.idexx.logging.common.LoggerUtil;

/**
 * <pre>
 * Loading data source based on the environment
 * </pre>
 * 
 * @author vvanjarana
 * @version 1.3
 */
@Configuration
public class DBConfig {

    @Autowired
    private Environment environment;

    public DriverManagerDataSource dataSource;

    @Profile("dev")
    @Bean
    public DataSource getDevConfigXml() {	
	LoggerUtil.importent(DBConfig.class,
		"DriverClassName: " + environment.getRequiredProperty("jdbc.dev.driverClassName"));
	LoggerUtil.importent(DBConfig.class, "jdbc.dev.url: " + environment.getRequiredProperty("jdbc.dev.url"));
	LoggerUtil.importent(DBConfig.class,
		"jdbc.dev.username: " + environment.getRequiredProperty("jdbc.dev.username"));	
	dataSource = new DriverManagerDataSource();
	dataSource.setDriverClassName(environment.getRequiredProperty("jdbc.dev.driverClassName"));
	dataSource.setUrl(environment.getRequiredProperty("jdbc.dev.url"));
	dataSource.setUsername(environment.getRequiredProperty("jdbc.dev.username"));
	dataSource.setPassword(environment.getRequiredProperty("jdbc.dev.password"));
	return dataSource;
    }

    @Profile("qa")
    @Bean
    public DataSource getQAConfigXml() {
	LoggerUtil.importent(DBConfig.class,
		"DriverClassName: " + environment.getRequiredProperty("jdbc.qa.driverClassName"));
	LoggerUtil.importent(DBConfig.class, "jdbc.qa.url: " + environment.getRequiredProperty("jdbc.qa.url"));
	LoggerUtil.importent(DBConfig.class,
		"jdbc.qa.username: " + environment.getRequiredProperty("jdbc.qa.username"));	
	dataSource = new DriverManagerDataSource();
	dataSource.setDriverClassName(environment.getRequiredProperty("jdbc.qa.driverClassName"));
	dataSource.setUrl(environment.getRequiredProperty("jdbc.qa.url"));
	dataSource.setUsername(environment.getRequiredProperty("jdbc.qa.username"));
	dataSource.setPassword(environment.getRequiredProperty("jdbc.qa.password"));
	return dataSource;
    }

    public DataSource getDataSource() {
	return this.dataSource;
    }

}
