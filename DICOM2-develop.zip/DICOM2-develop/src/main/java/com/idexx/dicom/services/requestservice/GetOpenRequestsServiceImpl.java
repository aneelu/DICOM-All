/**
 * <h1>Get Open request service to pims like Neo and Animana</h1>
 */
package com.idexx.dicom.services.requestservice;

import org.springframework.stereotype.Service;

import com.idexx.dicom.services.requestservice.dto.GetOpenRequestDTO;
import com.idexx.imaging.imagemanager.soap.PatientDTO;

/**
 * <pre>Get Open request service to pims like Neo and Animana </pre>
 * @author nayeemuddin
 * @version 1.3
 */
@Service
public class GetOpenRequestsServiceImpl {
	
	GetOpenRequestDTO dto;
	
	/**
	 * 
	 * @return
	 *
	 */
	public GetOpenRequestDTO getOpenRequests(){
		
		
		PatientDTO patientDTO = new PatientDTO();
		patientDTO.setId("123");
		patientDTO.setBreed("BULLDOG");
		patientDTO.setClinicId("4566");
		patientDTO.setGender("Male");
		patientDTO.setPatientName("Test1");
		patientDTO.setApplicationPatientId("76452709");
		patientDTO.setActiveFlag(1);
		
		dto = new GetOpenRequestDTO();
		
		dto.setAccessionNumber("123");
		dto.setModality("ModalityTest");
		dto.setPatient(patientDTO);
		dto.setRequestingDoctor("ABC");
		dto.setRequestNotes("TestNotes");
		dto.setStatus("PENDING");
		
		return dto;
		
	}

}
