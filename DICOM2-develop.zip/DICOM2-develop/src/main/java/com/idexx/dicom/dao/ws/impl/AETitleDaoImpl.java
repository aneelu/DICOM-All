/**
 * Database Paeristance for AE Title Related CRUD Operations.
 * Every Method will throw a run time exception IdexxDicomAEConfigDbException
 * Because, A functional requirement is explicitly stating, the software need to show DB related exceptions.
 */
package com.idexx.dicom.dao.ws.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.idexx.dicom.ae.entities.AEEntity;
import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.entities.IdexxAPIKey;
import com.idexx.dicom.ae.entities.IdexxInvalidAE;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.AETitleDao;

/**
 * @author vkandagatla
 * 
 */
@Repository
@SuppressWarnings("unchecked")
public class AETitleDaoImpl implements AETitleDao {

    @PersistenceContext
    private EntityManager entityManager;

    private static final String AET_PARAM1 = "AETITLE";
    private static final String AET_PARAM2 = "INSTITUTE_NAME";
    private static final String AET_PARAM3 = "SAP_ID";
    private static final String AET_PARAM4 = "API_KEY";
    private static final String AET_PARAM5 = "aet";
    private static final String QUERY_ALL_AE_TITLES = "SELECT AET FROM AETitle AET";
    private static final String QUERY_PREFIX = "SELECT AET FROM AETitle AET WHERE AET.aeTitle=:";
    private static final String QUERY_PREFIX_AE = "SELECT AE FROM AEEntity AE WHERE AE.aeTitle=:";
    
    public AETitleDaoImpl(EntityManager entityManager) {
        super();
        this.entityManager = entityManager;
    }

    public AETitleDaoImpl() {
        super();
    }

    public final List<AETitle> getAllAETitles() {
        try {
            Query query = entityManager.createQuery(QUERY_ALL_AE_TITLES);
            query.setMaxResults(Integer.MAX_VALUE);
            return query.getResultList();
        } catch (Exception e) {
            throw new IdexxDicomAEConfigDbException(e);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.dao.ws.AETitleDao#findAETitle(java.lang.String)
     */
    public final List<AETitle> findAETitle(final String aeTitle) {
        try {
            final String query = QUERY_PREFIX + AET_PARAM1;
            return entityManager.createQuery(query).setParameter("AETITLE", aeTitle).getResultList();
        } catch (Exception e) {
            throw new IdexxDicomAEConfigDbException(e);
        }

    }

    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.dao.ws.AETitleDao#findAETitle(java.lang.String,
     * java.lang.String)
     */
    public final List<AETitle> findAETitle(final String aeTitle, final String instituteName) {
        try {
            final String query = QUERY_PREFIX + AET_PARAM1 + " AND AET.instituteName=:" + AET_PARAM2;
            return entityManager.createQuery(query).setParameter(AET_PARAM1, aeTitle)
                    .setParameter(AET_PARAM2, instituteName).getResultList();
        } catch (Exception e) {

            throw new IdexxDicomAEConfigDbException(e);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.dao.ws.AETitleDao#findAETitle(java.lang.String,
     * java.lang.String, java.lang.String)
     */

    public final List<AETitle> findAETitle(final String aeTitle, final String instituteName, final String sapId) {
        try {
            final String query = QUERY_PREFIX + AET_PARAM1 + " AND AET.instituteName=:" + AET_PARAM2
                    + " AND AET.sapId=:SAP_ID";
            return entityManager.createQuery(query).setParameter(AET_PARAM1, aeTitle)
                    .setParameter(AET_PARAM2, instituteName).setParameter(AET_PARAM3, sapId).getResultList();
        } catch (Exception e) {

            throw new IdexxDicomAEConfigDbException(e);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.dao.ws.AETitleDao#findAE(java.lang.String)
     */
    public final List<AEEntity> findAE(final String aeTitle) {
        try {
            final String query = QUERY_PREFIX_AE + AET_PARAM5;
            return entityManager.createQuery(query).setParameter(AET_PARAM5, aeTitle).getResultList();
        } catch (Exception e) {
            throw new IdexxDicomAEConfigDbException(e);
        }

    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.dao.ws.AETitleDao#createAETitle(com.idexx.dicom.ae.entities
     * .AETitle)
     */
    public final void createAETitle(final AETitle aeTitle) {
        try {
            entityManager.merge(aeTitle);
        } catch (Exception e) {

            throw new IdexxDicomAEConfigDbException(e);
        }

    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.dao.ws.AETitleDao#createAE(com.idexx.dicom.ae.entities
     * .AEEntity)
     */
    public final void createAE(final AEEntity aeEntity) {
        try {
            entityManager.persist(aeEntity);
        } catch (Exception e) {

            throw new IdexxDicomAEConfigDbException(e);
        }

    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.dao.ws.AETitleDao#deleteAETitle(com.idexx.dicom.ae.entities
     * .AETitle)
     */
    public final void deleteAETitle(final AETitle aeTitle) {
        try {
            entityManager.remove(aeTitle);
        } catch (Exception e) {

            throw new IdexxDicomAEConfigDbException(e);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.dao.ws.AETitleDao#updateAETitle(com.idexx.dicom.ae.entities
     * .AETitle)
     */
    public final void updateAETitle(final AETitle aeTitle) {
        try {
            entityManager.merge(aeTitle);
        } catch (Exception e) {

            throw new IdexxDicomAEConfigDbException(e);
        }

    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.dao.ws.AETitleDao#getInvalidAETitle(java.lang.String)
     */
    public final IdexxInvalidAE getInvalidAETitle(final String aeTitle) {
        IdexxInvalidAE iae = null;
        try {
            final String query = "SELECT AET FROM IdexxInvalidAE AET WHERE AET.aeTitle=:" + AET_PARAM1;
            iae = (IdexxInvalidAE) entityManager.createQuery(query).setParameter(AET_PARAM1, aeTitle).getSingleResult();
        } catch (NoResultException e) {
            iae = null;
        } catch (Exception e) {

            throw new IdexxDicomAEConfigDbException(e);
        }
        return iae;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.dao.ws.AETitleDao#getInvalidAETitle(java.lang.String)
     */
    public final IdexxAPIKey getIdexxAPIKey(final String apiKey) {
        IdexxAPIKey apiKeyObj = null;
        try {
            final String query = "SELECT IAPI FROM IdexxAPIKey IAPI WHERE IAPI.apiKey=:" + AET_PARAM4;
            apiKeyObj = (IdexxAPIKey) entityManager.createQuery(query).setParameter(AET_PARAM4, apiKey)
                    .getSingleResult();
        } catch (NoResultException e) {
            apiKeyObj = null;
        } catch (Exception e) {

            throw new IdexxDicomAEConfigDbException(e);
        }
        return apiKeyObj;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.dao.ws.AETitleDao#findAETitleBySapId(java.lang.String,
     * java.lang.String)
     */
    public final List<AETitle> findAETitleByAETitleAndSapId(final String aeTitle, final String sapId) {
        try {
            final String query = QUERY_PREFIX + AET_PARAM1 + " AND AET.sapId=:" + AET_PARAM3;
            return entityManager.createQuery(query).setParameter(AET_PARAM1, aeTitle).setParameter(AET_PARAM3, sapId)
                    .getResultList();
        } catch (Exception e) {

            throw new IdexxDicomAEConfigDbException(e);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.dao.ws.AETitleDao#findAETitleBySapId(java.lang.String,
     * java.lang.String)
     */
    public final List<AETitle> findAETitleBySapIdAndInstituteName(final String sapId, final String instituteName) {
        try {
            final String query = "SELECT AET FROM AETitle AET WHERE AET.instituteName=:" + AET_PARAM2
                    + " AND AET.sapId=:" + AET_PARAM3;
            return entityManager.createQuery(query).setParameter(AET_PARAM2, instituteName)
                    .setParameter(AET_PARAM3, sapId).getResultList();
        } catch (Exception e) {

            throw new IdexxDicomAEConfigDbException(e);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.dao.ws.AETitleDao#findAETitleBySapId(java.lang.String,
     * java.lang.String)
     */
    public final List<AETitle> findAETitleBySapId(final String sapId) {
        try {
            final String query = "SELECT AET FROM AETitle AET WHERE AET.sapId=:" + AET_PARAM3;
            return entityManager.createQuery(query).setParameter(AET_PARAM3, sapId).getResultList();
        } catch (Exception e) {

            throw new IdexxDicomAEConfigDbException(e);
        }
    }

}
