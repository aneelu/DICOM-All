package com.idexx.dicom.sendimage;

import java.util.List;

import com.idexx.dicom.services.sendimage.dto.SendImagePendingJobDTO;

/**
 * @author vkandagatla
 * 
 */
public interface SendImageJobProvider {
    /**
     * @return All pending jobs which are available for processing next
     *         iteration for scheduler These jobs retry count should be greater
     *         than zero
     */
    List<SendImagePendingJobDTO> getPendingJobs();
    
    /**
     *  Updated all Jobs whose status In Progress to PENDING
     */
    void updateInProgressJobs();
}
