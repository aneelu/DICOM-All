/**
 * 
 */
package com.idexx.dicom.logging.common;

public class LoggerAspectUtil {
    
    private static final String CLASS_METHOD_SEPARATOR = ".";
    private static final String ARGUMENTS_SEPARATOR = ",";
    private static final String START_METHOD = "( ";
    private static final String END_METHOD = "); ";
    private static final String METHOD_START_PREFIX = "ENTERING METHOD::";
    private static final String METHOD_END_PREFIX = "EXITING METHOD::";
    
    private LoggerAspectUtil() {
        
    }
    
    /**
     * @param cls
     * @param methodName
     * @param args
     * @return
     */
    public static StringBuilder getMethodSignatureForLogging(final Class<?> cls, final String methodName, final Object[] args) {
        final StringBuilder logMessage = new StringBuilder();
        logMessage.append(cls.getName()).
                append(CLASS_METHOD_SEPARATOR).
                append(methodName).
                append(START_METHOD);
        if (null != args) {
            for (int i = 0; i < args.length; i++) {
                logMessage.append(args[i]).append(ARGUMENTS_SEPARATOR);
            }
            if (args.length > 0) {
                logMessage.deleteCharAt(logMessage.length() - 1);
            }
        }
        logMessage.append(END_METHOD);
        return logMessage;
    }
    
    /**
     * @param cls
     * @param methodName
     * @param args
     */
    public static void logMethodStart(final Class<?> cls, final String methodName, final Object[] args) {
        StringBuilder strBuilder = getMethodSignatureForLogging(cls, methodName, args);
        strBuilder.insert(0, METHOD_START_PREFIX);
        LoggerUtil.importent(cls, strBuilder.toString());
    }
    
    /**
     * @param cls
     * @param methodName
     * @param args
     */
    public static void logMethodEnd(final Class<?> cls, final String methodName, final Object[] args) {
        StringBuilder strBuilder = getMethodSignatureForLogging(cls, methodName, args);
        strBuilder.insert(0, METHOD_END_PREFIX);
        LoggerUtil.importent(cls, strBuilder.toString());
    }
    
    /**
     * @param cls
     * @param methodName
     * @param args
     * @param throwable
     */
    public static void logMethodException(final Class<?> cls, final String methodName, final Object[] args, final Throwable throwable) {
        StringBuilder strBuilder = getMethodSignatureForLogging(cls, methodName, args);
        LoggerUtil.error(cls, "EXCEPTION IN METHOD::CAUSE:::START::");
        LoggerUtil.error(cls, "EXCEPTION IN METHOD::CAUSE:::" + strBuilder.toString(), throwable.getCause());
        LoggerUtil.error(cls, "EXCEPTION IN METHOD::CAUSE:::END::");
        LoggerUtil.error(cls, "EXCEPTION IN METHOD::MESSAGE:::START::");
        LoggerUtil.error(cls, "EXCEPTION IN METHOD::MESSAGE:::" + strBuilder.toString() + "::" + throwable.getMessage());
        LoggerUtil.error(cls, "EXCEPTION IN METHOD::MESSAGE:::END::");
    }
    
    /**
     * @param cls
     * @param methodName
     * @param args
     * @param time
     */
    public static void executionTime(final Class<?> cls, final String methodName, final Object[] args, final long timeInMillis) {
        StringBuilder strBuilder = getMethodSignatureForLogging(cls, methodName, args);
        strBuilder.insert(0, "Execution Time for:::");
        strBuilder.insert(strBuilder.length(), " is::: " + timeInMillis + " ms.");
        LoggerUtil.importent(cls, strBuilder.toString());
    }
}
