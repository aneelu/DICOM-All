/**
 * 
 */
package com.idexx.dicom.services.dto.v11;

import java.io.Serializable;

/**
 * @author vkandagatla
 * 
 */
public class IdexxFailureLogDTO extends AETitleDTO implements Serializable {
    
    /**
     * Generated
     */
    private static final long serialVersionUID = 9051297213849541577L;

    private String ipAddress;
    private String manufacturer;
    private String manufacturerModelName;
    private String modality;
    private String failedDateTime;
    private String patientName;
    private String responsiblePersonName;
    private String hostName;
    private String errorType;
    private String errorMessage;
    
    /**
     * @return the ipAddress
     */
    public final String getIpAddress() {
        return ipAddress;
    }
    
    /**
     * @param ipAddress
     *            the ipAddress to set
     */
    public final void setIpAddress(final String ipAddress) {
        this.ipAddress = ipAddress;
    }
    
    /**
     * @return the manufacturer
     */
    public final String getManufacturer() {
        return manufacturer;
    }
    
    /**
     * @param manufacturer
     *            the manufacturer to set
     */
    public final void setManufacturer(final String manufacturer) {
        this.manufacturer = manufacturer;
    }
    
    /**
     * @return the manufacturerModelName
     */
    public final String getManufacturerModelName() {
        return manufacturerModelName;
    }
    
    /**
     * @param manufacturerModelName
     *            the manufacturerModelName to set
     */
    public final void setManufacturerModelName(final String manufacturerModelName) {
        this.manufacturerModelName = manufacturerModelName;
    }
    
    /**
     * @return the modality
     */
    public final String getModality() {
        return modality;
    }
    
    /**
     * @param modality
     *            the modality to set
     */
    public final void setModality(final String modality) {
        this.modality = modality;
    }
    
    /**
     * @return the failedDateTime in UTC format
     */
    
    public final String getFailedDateTime() {
        return failedDateTime;
    }
    
    /**
     * @param failedDateTime
     *            the failedDateTime to set
     */
    public final void setFailedDateTime(final String failedDateTime) {
        this.failedDateTime = failedDateTime;
    }
    
    /**
     * @return the patientName
     */
    public final String getPatientName() {
        return patientName;
    }
    
    /**
     * @param patientName
     *            the patientName to set
     */
    public final void setPatientName(final String patientName) {
        this.patientName = patientName;
    }
    
    /**
     * @return the responsiblePersonName
     */
    public final String getResponsiblePersonName() {
        return responsiblePersonName;
    }
    
    /**
     * @param responsiblePersonName
     *            the responsiblePersonName to set
     */
    public final void setResponsiblePersonName(final String responsiblePersonName) {
        this.responsiblePersonName = responsiblePersonName;
    }
    
    /**
     * @return the hostName
     */
    public final String getHostName() {
        return hostName;
    }
    
    /**
     * @param hostName
     *            the hostName to set
     */
    public final void setHostName(final String hostName) {
        this.hostName = hostName;
    }

    /**
     * error type
     * @return
     */
    public String getErrorType() {
        return errorType;
    }

    public void setErrorType(String errorType) {
        this.errorType = errorType;
    }

    /**
     * error message
     * @return
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
