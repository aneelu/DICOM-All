/**
 * 
 */
package com.idexx.dicom.logging.intf;

import org.apache.log4j.Level;


public interface IdexxLoggerFactory {
    IdexxLogger createLogger(Class<?> cls, Level logLevel);
}
