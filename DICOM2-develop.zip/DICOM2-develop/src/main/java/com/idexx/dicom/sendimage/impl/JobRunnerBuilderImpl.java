/**
 * 
 */
package com.idexx.dicom.sendimage.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.idexx.dicom.dao.ws.DicomConfigDao;
import com.idexx.dicom.sendimage.ImagePresignedUrlProvider;
import com.idexx.dicom.sendimage.JobRunnerBuilder;
import com.idexx.dicom.sendimage.SendImage;
import com.idexx.dicom.sendimage.SendImageJobProvider;
import com.idexx.dicom.sendimage.SendImageJobUpdateService;
import com.idexx.dicom.sendimage.TimedImageDownloader;
import com.idexx.dicom.services.sendimage.dto.SendImagePendingJobDTO;
import com.idexx.logging.common.LoggerUtil;

/**
 * @author vkandagatla
 * 
 */
@Service("jobRunnerBuilder")
public class JobRunnerBuilderImpl implements JobRunnerBuilder {
    @Autowired
    private SendImageJobProvider jobProvider;
    @Autowired
    private SendImageJobUpdateService jobUpdateService;
    @Autowired
    private ImagePresignedUrlProvider presignedUrlProvider;
    @Autowired
    private TimedImageDownloader imageDownloader;
    @Autowired
    private DicomConfigDao configDao;
    @Autowired
    private SendImage sendImageService;
    
    /**
     * Default
     */
    public JobRunnerBuilderImpl() {
        jobProvider = new SendImageJobProviderImpl();        
    }
    
    /**
     * @return
     */
    @Transactional
    public final List<Runnable> build() {
        jobProvider.updateInProgressJobs();
        List<SendImagePendingJobDTO> jobs = this.jobProvider.getPendingJobs();
        boolean jobsExists = this.isJobExists(jobs);
        LoggerUtil.info(getClass(), "Jobs Exists: " + jobsExists);
        if (jobsExists) {
            return this.createJobProcessors(jobs);
        } else {
            return null;
        }
    }
    
    /**
     * @param jobs
     * @return
     */
    private List<Runnable> createJobProcessors(final List<SendImagePendingJobDTO> jobs) {
        List<Runnable> processors = new ArrayList<Runnable>();
        for (SendImagePendingJobDTO job : jobs) {
            Runnable processor = new SendImageProcessorImpl(job,
                    jobUpdateService, presignedUrlProvider, imageDownloader, configDao, sendImageService);
            processors.add(processor);
        }
        return processors;
    }
    
    /**
     * @param jobs
     * @return
     */
    private boolean isJobExists(final List<SendImagePendingJobDTO> jobs) {
        return ((null != jobs && !jobs.isEmpty()));
    }
}
