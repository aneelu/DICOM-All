/**
 * Logger Util
 */
package com.idexx.dicom.logging.common;

import org.apache.log4j.Level;

import com.idexx.dicom.logging.intf.IdexxLogger;
import com.idexx.dicom.logging.intf.IdexxLoggerFactory;

public final class LoggerUtil {
    private LoggerUtil() {
    }
    
    private static IdexxLoggerFactory loggerFactory;
    static {
        loggerFactory = IdexxLoggerFactoryImpl.getInstance();
    }
    
    /**
     * @param cls
     * @param message
     */
    public static void debug(final Class<?> cls, final String message) {
        loggerFactory.createLogger(cls, Level.DEBUG).log(cls, message);
    }
    
    /**
     * @param cls
     * @param message
     * @param throwable
     */
    public static void debug(final Class<?> cls, final String message, final Throwable throwable) {
        loggerFactory.createLogger(cls, Level.DEBUG).log(cls, message, throwable);
    }
    
    /**
     * @param cls
     * @param message
     * @param throwable
     */
    public static void info(final Class<?> cls, final String message, final Throwable throwable) {
        loggerFactory.createLogger(cls, Level.INFO).log(cls, message, throwable);
    }
    
    /**
     * @param cls
     * @param message
     */
    public static void info(final Class<?> cls, final String message) {
        loggerFactory.createLogger(cls, Level.INFO).log(cls, message);
    }
    
    /**
     * @param cls
     * @param message
     */
    public static void trace(final Class<?> cls, final String message) {
        loggerFactory.createLogger(cls, Level.TRACE).log(cls, message);
    }
    
    /**
     * @param cls
     * @param message
     * @param throwable
     */
    public static void trace(final Class<?> cls, final String message, final Throwable throwable) {
        loggerFactory.createLogger(cls, Level.TRACE).log(cls, message, throwable);
    }
    
    /**
     * @param cls
     * @param message
     */
    public static void warn(final Class<?> cls, final String message) {
        loggerFactory.createLogger(cls, Level.TRACE).log(cls, message);
    }
    
    /**
     * @param cls
     * @param message
     * @param throwable
     */
    public static void warn(final Class<?> cls, final String message, final Throwable throwable) {
        loggerFactory.createLogger(cls, Level.WARN).log(cls, message, throwable);
    }
    
    /**
     * @param cls
     * @param message
     * @param throwable
     */
    public static void error(final Class<?> cls, final String message, final Throwable throwable) {
        loggerFactory.createLogger(cls, Level.ERROR).log(cls, message, throwable);
    }
    
    /**
     * @param cls
     * @param message
     */
    public static void error(final Class<?> cls, final String message) {
        loggerFactory.createLogger(cls, Level.ERROR).log(cls, message);
    }
    
    /**
     * @param cls
     * @param message
     */
    public static void importent(final Class<?> cls, final String message) {
        IdexxLogger logger = loggerFactory.createLogger(cls, Level.INFO);
        logger.log(cls, message);
    }
    
    /**
     * @param cls
     * @param logLevel
     * @param message
     */
    public static void log(final Class<?> cls, final Level logLevel, final String message) {
        final int level = logLevel.toInt();
        switch (level) {
            case Level.TRACE_INT:
                LoggerUtil.trace(cls, message);
                break;
            case Level.INFO_INT:
                LoggerUtil.info(cls, message);
                break;
            case Level.WARN_INT:
                LoggerUtil.warn(cls, message);
                break;
            case Level.ERROR_INT:
                LoggerUtil.error(cls, message);
                break;
            default:
                LoggerUtil.debug(cls, message);
                break;
        }
    }
    
    /**
     * @param cls
     * @param logLevel
     * @param message
     * @param throwable
     */
    public static void log(final Class<?> cls, final Level logLevel, final String message, final Throwable throwable) {
        final int level = logLevel.toInt();
        switch (level) {
            case Level.TRACE_INT:
                LoggerUtil.trace(cls, message, throwable);
                break;
            case Level.INFO_INT:
                LoggerUtil.info(cls, message, throwable);
                break;
            case Level.WARN_INT:
                LoggerUtil.warn(cls, message, throwable);
                break;
            case Level.ERROR_INT:
                LoggerUtil.error(cls, message, throwable);
                break;
            default:
                LoggerUtil.debug(cls, message, throwable);
                break;
        }
    }
}
