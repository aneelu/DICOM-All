package com.idexx.dicom.domain;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "REQUEST_DETAILS")
public class RequestDetails implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "system-uuid")
    @GenericGenerator(name = "system-uuid", strategy = "uuid")
	private String Id;

	@NotNull
	@Column(name="PATIENT_ID")
	private String patientId;
	
	@NotNull
	@Column(name="PIMS_ISSUER")
	private String pimsIssuer;
	
	@Column(name="STUDY_INSTANCE_UID")
	private String studyInstanceUID;
	
	@Column(name="API_KEY")
	private String apiKey;
	
	@Column(name="SAP_ID")
	private String sapId;
	
	@Column(name="MODALITY")
	private String modality;
	
	@Column(name="REQUEST_NOTES")
	private String requestNotes;
	
	@Column(name="REQUESTING_DOCTOR")
	private String requestingDoctor;
	
	@Column(name="ACCESSION_NUMBER")
	private String accessionNumber;
	
	@Column(name="STATUS")
	private String status;
	
	@Column(name="CREATE_TIMESTAMP")
	private Timestamp createTimeStamp;
	
	@Column(name="UPDATE_TIMESTAMP")
	private Timestamp updateTimeStamp;
	

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return Id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		Id = id;
	}

	/**
	 * @return the patientId
	 */
	public String getPatientId() {
		return patientId;
	}

	/**
	 * @param patientId the patientId to set
	 */
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	
	
	/**
	 * @return the studyInstanceUID
	 */
	public String getStudyInstanceUID() {
	    return studyInstanceUID;
	}

	/**
	 * @param studyInstanceUID the studyInstanceUID to set
	 */
	public void setStudyInstanceUID(String studyInstanceUID) {
	    this.studyInstanceUID = studyInstanceUID;
	}

	/**
	 * @return the pimsIssuer
	 */
	public String getPimsIssuer() {
		return pimsIssuer;
	}

	/**
	 * @param pimsIssuer the pimsIssuer to set
	 */
	public void setPimsIssuer(String pimsIssuer) {
		this.pimsIssuer = pimsIssuer;
	}

	/**
	 * @return the apiKey
	 */
	public String getApiKey() {
		return apiKey;
	}

	/**
	 * @param apiKey the apiKey to set
	 */
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}

	/**
	 * @return the sapId
	 */
	public String getSapId() {
		return sapId;
	}

	/**
	 * @param sapId the sapId to set
	 */
	public void setSapId(String sapId) {
		this.sapId = sapId;
	}

	/**
	 * @return the modality
	 */
	public String getModality() {
		return modality;
	}

	/**
	 * @param modality the modality to set
	 */
	public void setModality(String modality) {
		this.modality = modality;
	}

	/**
	 * @return the requestNotes
	 */
	public String getRequestNotes() {
		return requestNotes;
	}

	/**
	 * @param requestNotes the requestNotes to set
	 */
	public void setRequestNotes(String requestNotes) {
		this.requestNotes = requestNotes;
	}

	/**
	 * @return the requestingDoctor
	 */
	public String getRequestingDoctor() {
		return requestingDoctor;
	}

	/**
	 * @param requestingDoctor the requestingDoctor to set
	 */
	public void setRequestingDoctor(String requestingDoctor) {
		this.requestingDoctor = requestingDoctor;
	}

	/**
	 * @return the accessionNumber
	 */
	public String getAccessionNumber() {
		return accessionNumber;
	}

	/**
	 * @param accessionNumber the accessionNumber to set
	 */
	public void setAccessionNumber(String accessionNumber) {
		this.accessionNumber = accessionNumber;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the createTimeStamp
	 */
	public Timestamp getCreateTimeStamp() {
		return createTimeStamp;
	}

	/**
	 * @param createTimeStamp the createTimeStamp to set
	 */
	public void setCreateTimeStamp(Timestamp createTimeStamp) {
		this.createTimeStamp = createTimeStamp;
	}

	/**
	 * @return the updateTimeStamp
	 */
	public Timestamp getUpdateTimeStamp() {
		return updateTimeStamp;
	}

	/**
	 * @param updateTimeStamp the updateTimeStamp to set
	 */
	public void setUpdateTimeStamp(Timestamp updateTimeStamp) {
		this.updateTimeStamp = updateTimeStamp;
	}

	public RequestDetails() {
	}
	
	public RequestDetails(String patientId, String pimsIssuer) {
		this.patientId = patientId;
		this.pimsIssuer = pimsIssuer;
	}


}
