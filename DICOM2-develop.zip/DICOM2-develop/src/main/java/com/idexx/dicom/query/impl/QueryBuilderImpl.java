package com.idexx.dicom.query.impl;

import org.apache.commons.lang.StringUtils;

import com.idexx.dicom.query.QueryBuilder;
import com.idexx.logging.common.LoggerUtil;

public class QueryBuilderImpl implements QueryBuilder {

	/**
	 * Builds the native SQL query
	 * 
	 * @return
	 */
	@SuppressWarnings("unused")
	public String getSelectQuery(final String aeTitle,
			final String instituteName, final String errorType) {

		StringBuilder sql = new StringBuilder(
				" FROM IdexxDicomServiceFailureLog IDFL WHERE ");
		sql.append(" IDFL.failedDateTime >= :START_DATE ");
		sql.append(" AND IDFL.failedDateTime <= :END_DATE ");

		if (!StringUtils.isEmpty(aeTitle)) {
			sql.append(" AND IDFL.aeTitle = :AE_TITLE");
		}

		if (!StringUtils.isEmpty(instituteName)) {
			sql.append(" AND IDFL.instituteName = :INSTITUTE_NAME ");
		}

		if (!StringUtils.isEmpty(errorType)) {
			sql.append(" AND IDFL.errorType = :ERROR_TYPE ");
		}

		LoggerUtil.importent(getClass(),
				"Failure Log Query is ::: " + sql.toString());

		return sql.toString();
	}
}
