/**
 * 
 */
package com.idexx.dicom.entities.store;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author vkandagatla
 * 
 */
@Entity
@Table(name = "dcm_component_field_mapping")
public class DicomComponentFieldMapping implements Serializable {
    /**
     * Generated
     */
    private static final long serialVersionUID = 7175836177997132054L;
    private int dcmMappingId;
    private int idxComponentId;

    /**
     * @return the dcmMappingId
     */
    @Id
    @Column(name = "dcm_mapping_id")
    public int getDcmMappingId() {
        return dcmMappingId;
    }

    /**
     * @param dcmMappingId
     *            the dcmMappingId to set
     */
    public void setDcmMappingId(int dcmMappingId) {
        this.dcmMappingId = dcmMappingId;
    }

    /**
     * @return the idxComponentId
     */
    @Column(name = "idx_component_id")
    public int getIdxComponentId() {
        return idxComponentId;
    }

    /**
     * @param idxComponentId
     *            the idxComponentId to set
     */
    public void setIdxComponentId(int idxComponentId) {
        this.idxComponentId = idxComponentId;
    }
}
