/**
 * 
 */
package com.idexx.dicom.logging.impl;

public class InfoLogger extends AbstractIdexxLogger {
    
    /**
     * @param cls
     */
    public InfoLogger(final Class<?> cls) {
        super(cls);
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.logging.impl.AbstractIdexxLogger#isEnabled()
     */
    @Override
    public final boolean isEnabled() {
        return this.getLogger().isInfoEnabled();
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.logging.impl.AbstractIdexxLogger#log(java.lang.String)
     */
    @Override
    public final void log(final String message) {
        this.getLogger().info(message);
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.logging.impl.AbstractIdexxLogger#log(java.lang.String,
     * java.lang.Throwable)
     */
    @Override
    public final void log(final String message, final Throwable throwable) {
        this.getLogger().info(message, throwable);
    }
    
}
