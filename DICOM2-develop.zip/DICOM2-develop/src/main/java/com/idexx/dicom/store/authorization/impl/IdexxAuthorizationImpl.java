/**
 * 
 */
package com.idexx.dicom.store.authorization.impl;

import org.springframework.stereotype.Component;

import com.idexx.dicom.dto.IdexxAuthorizationObject;
import com.idexx.dicom.store.authorization.IdexxAuthorization;

/**
 * @author vkandagatla
 *
 */
public class IdexxAuthorizationImpl implements IdexxAuthorization {
    private IdexxAuthorizationObject authorizationObject;
    private boolean authorized;
    /**
     * @param authorizationObject the authorizationObject to set
     */
    public final void setAuthorizationObject(final IdexxAuthorizationObject authorizationObject) {
        this.authorizationObject = authorizationObject;
    }

    /**
     * @param authorized the authorized to set
     */
    public final void setAuthorized(final boolean authorized) {
        this.authorized = authorized;
    }

    /**
     * Default
     */
    public IdexxAuthorizationImpl() {
    }
    
    /**
     * @param authorizationObject
     */
    public IdexxAuthorizationImpl(final IdexxAuthorizationObject authorizationObject) {
        this.authorizationObject = authorizationObject;
    }

    /* (non-Javadoc)
     * @see com.idexx.dicom.store.authorization.IdexxAuthorization#isAuthorized()
     */
    @Override
    public final boolean isAuthorized() {
        return authorized;
    }
    
    /* (non-Javadoc)
     * @see com.idexx.dicom.store.authorization.IdexxAuthorization#getAuthorizationObject()
     */
    @Override
    public final IdexxAuthorizationObject getAuthorizationObject() {
        return authorizationObject;
    }
    
}
