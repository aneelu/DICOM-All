/**
 * 
 */
package com.idexx.dicom.store;

/**
 * @author vkandagatla
 *
 */
public interface DefaultValueProvider<T> {

    T getValue();
}
