/**
 *
 */
package com.idexx.dicom.services.requestservice.dto;

import com.idexx.imaging.imagemanager.soap.PatientDTO;

/**
 * @author nayeemuddin
 * @version 1.3
 */
public class GetOpenRequestDTO {
	
	private PatientDTO Patient;
	private String modality;
	private String requestingDoctor;
	private String requestNotes;
	private String accessionNumber;
	private String status;
	
	
	/**
	 * @return the patient
	 */
	public PatientDTO getPatient() {
		return Patient;
	}
	/**
	 * @param patient the patient to set
	 */
	public void setPatient(PatientDTO patient) {
		Patient = patient;
	}
	/**
	 * @return the modality
	 */
	public String getModality() {
		return modality;
	}
	/**
	 * @param modality the modality to set
	 */
	public void setModality(String modality) {
		this.modality = modality;
	}
	/**
	 * @return the requestingDoctor
	 */
	public String getRequestingDoctor() {
		return requestingDoctor;
	}
	/**
	 * @param requestingDoctor the requestingDoctor to set
	 */
	public void setRequestingDoctor(String requestingDoctor) {
		this.requestingDoctor = requestingDoctor;
	}
	/**
	 * @return the requestNotes
	 */
	public String getRequestNotes() {
		return requestNotes;
	}
	/**
	 * @param requestNotes the requestNotes to set
	 */
	public void setRequestNotes(String requestNotes) {
		this.requestNotes = requestNotes;
	}
	/**
	 * @return the accessionNumber
	 */
	public String getAccessionNumber() {
		return accessionNumber;
	}
	/**
	 * @param accessionNumber the accessionNumber to set
	 */
	public void setAccessionNumber(String accessionNumber) {
		this.accessionNumber = accessionNumber;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	

}
