/**
 * 
 */
package com.idexx.dicom.sendimage.impl;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.entities.BaseDicomImPluginConfig;
import com.idexx.dicom.dao.ws.DicomConfigDao;
import com.idexx.dicom.sendimage.SendImageJobConstants;
import com.idexx.dicom.sendimage.ThreadController;
import com.idexx.logging.common.LoggerUtil;

/**
 * @author vkandagatla
 * 
 */
public class ThreadControllerImpl implements ThreadController {
    /**
     * @param sendImageQue
     */
    public ThreadControllerImpl(final ConcurrentLinkedQueue<Runnable> sendImageQue, final DicomConfigDao configDao) {
        super();
        this.sendImageQue = sendImageQue;
        this.configDao = configDao;
    }

    ConcurrentLinkedQueue<Runnable> sendImageQue;

    /*
     * @see com.idexx.dicom.sendimage.ThreadController#isThreadAvailable()
     */
    @Override
    public final boolean isThreadAvailable() {
        return this.sendImageQue.size() > 0;
    }

    /*
     * @see
     * com.idexx.dicom.sendimage.ThreadController#createThread(com.idexx.dicom
     * .sendimage.impl.SendImageJobRunner)
     */
    @Override
    public final void start() {
        this.createNextPool();
    }

    /**
     * Create next set of jobs for pooling
     */
    private void createNextPool() {

        if (isThreadAvailable()) {
            ExecutorService pool = this.createPool();
            if (pool.isTerminated()) {
                LoggerUtil.importent(getClass(), "Pool is terminated...Creating next pool");
                createNextPool();
            } else {
                LoggerUtil.importent(getClass(), "Waiting All Thread to complete");
                while (!pool.isTerminated()) {
                    try {
                        Thread.sleep(SendImageJobConstants.SEND_IMAGE_JOB_PAUSE_TIME);
                    } catch (InterruptedException e) {
                        LoggerUtil.error(getClass(), e.getMessage());
                    }
                }
            }
        }
    }

    private ExecutorService createPool() {
        int poolsize = this.computeExecutorCount();
        LoggerUtil.importent(getClass(), "Creating Executor Pool: " + poolsize);
        ExecutorService pool = Executors.newFixedThreadPool(poolsize);
        for (int start = 0; start < poolsize; start++) {
            Runnable processor = this.sendImageQue.poll();
            pool.execute(processor);
        }
        pool.shutdown();

        return pool;
    }

    /**
     * @return Determines how many thread executor objects should be created
     */
    private int computeExecutorCount() {
        int defaultThreadCount = this.getThreadCount();
        int queueLength = this.sendImageQue.size();
        int count = defaultThreadCount;
        if (queueLength < defaultThreadCount) {
            count = queueLength;
        }
        LoggerUtil.importent(getClass(), "Processing for " + count + " number of jobs");
        return count;
    }

    private DicomConfigDao configDao;

    /**
     * @return
     */
    private int getThreadCount() {
        LoggerUtil.importent(getClass(), "Getting THREAD COUNT COUNT CONFIG VALUE");
        int defaultCount = SendImageJobConstants.DEFAULT_QUARTZ_THREAD_COUNT;
        BaseDicomImPluginConfig config = configDao.getConfig(SendImageJobConstants.QUARTZ_THREAD_COUNT_CONFIG_NAME);

        String configValue = config.getConfigValue();
        if (!StringUtils.isEmpty(configValue)) {
            try {
                defaultCount = Integer.valueOf(configValue);
            } catch (NumberFormatException nfe) {
                defaultCount = SendImageJobConstants.DEFAULT_QUARTZ_THREAD_COUNT;
            }
        }
        LoggerUtil.importent(getClass(), "THREAD COUNT CONFIG VALUE IS: " + defaultCount);
        return defaultCount;
    }

}
