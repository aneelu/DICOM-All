package com.idexx.dicom.conf;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import com.idexx.dicom.logging.LoggerService;


@Configuration
@EnableAspectJAutoProxy
public class AspectJAutoConfig {

	@Bean	
	public LoggerService loggerAspect(){
		return new LoggerService();
	}
}

