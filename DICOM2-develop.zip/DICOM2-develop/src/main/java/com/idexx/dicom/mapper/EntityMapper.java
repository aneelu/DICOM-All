/**
 * <h1>Mapper class for Create Request service</h1>
 */
package com.idexx.dicom.mapper;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.stereotype.Component;

import com.idexx.dicom.domain.RequestDetails;
import com.idexx.dicom.sendimage.SendImageJobConstants;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO;
import com.idexx.imaging.imagemanager.soap.ImageDTO;
import com.idexx.imaging.imagemanager.soap.PatientDTO;
import com.idexx.imaging.imagemanager.soap.PatientSearchRequestDTO;
import com.idexx.imaging.imagemanager.soap.StoreImageMetaDataDTO;
import com.idexx.imaging.imagemanager.soap.StudyDTO;
import com.idexx.logging.common.LoggerUtil;

/**
 * <pre>
 * Mapper class for Create Request service.
 * </pre>
 * 
 * @author smallela
 * @version 1.3
 */

@Component("entityMapper")
public class EntityMapper {

	public static final String INVALID_BIRTH_DATE = "Invalid Patient birth date format";

	/**
	 * <pre>
	 * Method returns RequestDetails
	 * </pre>
	 * 
	 * @param dto
	 * @return
	 */
	public RequestDetails dtoToEntityMapper(RequestDetailsDTO dto) {
		RequestDetails req = new RequestDetails();
		req.setAccessionNumber(dto.getAccessionNumber());
		req.setApiKey(dto.getApiKey());
		req.setModality(dto.getModality());
		req.setPatientId(dto.getPatientId());
		req.setPimsIssuer(dto.getPimsIssuer());
		req.setRequestingDoctor(dto.getRequestingDoctor());
		req.setRequestNotes(dto.getRequestNotes());
		req.setSapId(dto.getSapId());
		req.setStudyInstanceUID(dto.getStudyInstanceUID());
		req.setCreateTimeStamp(new Timestamp(System.currentTimeMillis()));
		req.setStatus(SendImageJobConstants.JOB_STATUS_PENDING);
		return req;
	}

	/**
	 * <pre>
	 * Method returns PatientSearchRequestDTO
	 * </pre>
	 * 
	 * @param req
	 * @return
	 */
	public PatientSearchRequestDTO getPatientDTO(RequestDetailsDTO req) {
		PatientSearchRequestDTO patientSearchRequestDTO = new PatientSearchRequestDTO();
		patientSearchRequestDTO.setApiKey(req.getApiKey());
		patientSearchRequestDTO.setClientFirstName(req.getClientFirstName());
		patientSearchRequestDTO.setClientLastName(req.getClientLastName());
		patientSearchRequestDTO.setIncludeDeletes(true);
		patientSearchRequestDTO.setIncludeInactivePatients(true);
		patientSearchRequestDTO.setClinicId(req.getSapId());
		patientSearchRequestDTO.setApplicationPatientId(req.getPatientId());
		return patientSearchRequestDTO;

	}

	/**
	 * <pre>
	 * Method to generate Study Instance Unique ID
	 * </pre>
	 * 
	 * @param req
	 * @return
	 */
	public String generateStudyInstanceUid(RequestDetailsDTO req) {
		SimpleDateFormat studySDF = new SimpleDateFormat(SendImageJobConstants.SIMPLE_DATE_FORMAT);
		String studyTimestamp = studySDF.format(new Date());
		StringBuilder sb = new StringBuilder();
		sb.append(SendImageJobConstants.IDEXX_DICOM_PREFIX).append(".").append(req.getSapId()).append(".")
				.append(studyTimestamp);
		return sb.toString();
	}

	/**
	 * <pre>
	 * Method returns PatientDTO
	 * </pre>
	 * 
	 * @param req
	 * @return
	 */
	public PatientDTO getPatient(RequestDetailsDTO req) {

		PatientDTO patientDTO = new PatientDTO();

		patientDTO.setApplicationPatientId(req.getPatientId());
		patientDTO.setBreed(req.getBreed());
		patientDTO.setClientFirstName(req.getClientFirstName());
		patientDTO.setClientLastName(req.getClientLastName());
		patientDTO.setClinicId(req.getSapId());

		if (null != req.getPatientDOB()) {
			patientDTO.setDob(getFormatDOB(req.getPatientDOB()));
		}

		patientDTO.setGender(req.getSex());
		patientDTO.setPatientName(req.getPatientName());
		patientDTO.setSpecies(req.getSpecies());

		return patientDTO;
	}

	/**
	 * <pre>
	 * Store Image Data DTO
	 * </pre>
	 * 
	 * @param req
	 * @return
	 */
	public StoreImageMetaDataDTO getStoreImageMetaData(RequestDetailsDTO req) {

		StoreImageMetaDataDTO storeImageMetaDataDTO = new StoreImageMetaDataDTO();
		ImageDTO imageDTO = new ImageDTO();

		storeImageMetaDataDTO.setApiKey(req.getApiKey());
		storeImageMetaDataDTO.setClinicId(req.getSapId());
		storeImageMetaDataDTO.setImage(imageDTO);
		storeImageMetaDataDTO.setPatient(getPatient(req));
		storeImageMetaDataDTO.setStudy(getStudy(req));

		return storeImageMetaDataDTO;
	}

	/**
	 * 
	 * <pre>
	 * Method to set the Study DTOs
	 * </pre>
	 * 
	 * @param req
	 * @param studyInstanceUid
	 * @return
	 *
	 */
	public StudyDTO getStudy(RequestDetailsDTO req) {
		StudyDTO studyDTO = new StudyDTO();
		studyDTO.setStudyDate(getStudydDate());
		studyDTO.setStudyInstanceUid(req.getStudyInstanceUID());
		studyDTO.setDoctor(req.getRequestingDoctor());
		if(null != req.getAccessionNumber()){
			studyDTO.setAscessionNumber(req.getAccessionNumber());
		}
		return studyDTO;
	}

	/**
	 * Return Study date in XMLGregorianCalendar format.
	 * 
	 * @return
	 *
	 */
	protected XMLGregorianCalendar getStudydDate() {
		XMLGregorianCalendar xmlGC = null;

		SimpleDateFormat studySDF = new SimpleDateFormat(SendImageJobConstants.CREATE_PATIENT_DATE_FORMAT);
		String studyDate = studySDF.format(new Date());
		try {
			xmlGC = DatatypeFactory.newInstance().newXMLGregorianCalendar(studyDate);
		} catch (DatatypeConfigurationException e) {
			LoggerUtil.error(getClass(), "Exception in Study date format.");
			e.printStackTrace();
		}

		return xmlGC;
	}

	/**
	 * 
	 * <pre>
	 * Return date in XMLGregorianCalendar format.
	 * </pre>
	 * 
	 * @param strDdate
	 * @return
	 * @throws IdexxDicomAEConfigServiceException
	 *
	 */
	protected XMLGregorianCalendar getFormatDOB(String strDdate) {
		String strPatientDOB = null;
		XMLGregorianCalendar xmlGC = null;
		SimpleDateFormat sdf = new SimpleDateFormat(SendImageJobConstants.PATIENT_DOB_FORMAT);

		try {
			Date dobDate = sdf.parse(strDdate);
			SimpleDateFormat sdf1 = new SimpleDateFormat(SendImageJobConstants.CREATE_PATIENT_DATE_FORMAT);
			strPatientDOB = sdf1.format(dobDate);

			xmlGC = DatatypeFactory.newInstance().newXMLGregorianCalendar(strPatientDOB);
		} catch (ParseException e) {
			LoggerUtil.error(getClass(), INVALID_BIRTH_DATE);
			e.printStackTrace();
		} catch (DatatypeConfigurationException e) {
			e.printStackTrace();
		}

		return xmlGC;
	}

}
