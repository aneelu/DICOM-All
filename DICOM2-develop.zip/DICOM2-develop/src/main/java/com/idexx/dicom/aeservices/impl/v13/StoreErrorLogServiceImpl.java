package com.idexx.dicom.aeservices.impl.v13;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.entities.IdexxDicomServiceFailureLog;
import com.idexx.dicom.ae.validator.IdexxValidator;
import com.idexx.dicom.ae.validator.impl.v13.StoreErrorLogValidatorImpl;
import com.idexx.dicom.dao.ws.FailureServiceDao;
import com.idexx.dicom.services.dto.v13.IdexxErrorLogParamDTO;
import com.idexx.dicom.services.dto.v13.IdexxFailureLogDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.logging.common.LoggerUtil;

/**
 * <pre>Description of the class</pre>
 * @author rkaranam
 * @version 1.3
 */
@Service("storeErrorLogServiceV13")
public class StoreErrorLogServiceImpl implements IdexxValidator {

	@Autowired
	@Qualifier("storeErrorLogValidatorV13")
	private StoreErrorLogValidatorImpl validator;

	private List<IdexxFailureLogDTO> dtos;

	@Autowired
	private FailureServiceDao failureLogDAO;

	@Transactional
	public List<IdexxFailureLogDTO> performService(
			final IdexxErrorLogParamDTO dto)
			throws IdexxDicomAEConfigServiceException {
		this.validate(dto);
		this.doService(dto);
		return dtos;
	}

	protected boolean validate(final IdexxErrorLogParamDTO dto)
			throws IdexxDicomAEConfigServiceException {
		return validator.validate(dto);
	}


	protected int doService(final IdexxErrorLogParamDTO iflDto)
			throws IdexxDicomAEConfigServiceException {
		List<IdexxDicomServiceFailureLog> errorLogList = failureLogDAO.getFailureLogErrorMessages(
				this.convertToDate(iflDto.getStartDate()),
				this.convertToDate(iflDto.getEndDate()), iflDto.getAeTitle(),
				iflDto.getInstituteName(), iflDto.getErrorType());
		setDTOList(errorLogList);
		return 1;
	}

	/**
	 * This method set the AETitles to IdexxDicomApplicationEntityDTO list
	 * 
	 * @param aeTitleList
	 */
    private void setDTOList(final List<IdexxDicomServiceFailureLog> failureLogList) {
        dtos = new ArrayList<IdexxFailureLogDTO>();
        IdexxFailureLogDTO dto = null;
        Calendar calender = Calendar.getInstance();
        
        for (IdexxDicomServiceFailureLog failureLog : failureLogList) {
            dto = new IdexxFailureLogDTO();
            dto.setIpAddress(failureLog.getIpAddress());
            dto.setAeTitle(failureLog.getAeTitle());
            dto.setInstituteName(failureLog.getInstituteName());
            dto.setManufacturer(failureLog.getManufacturer());
            dto.setManufacturerModelName(failureLog.getManufacturerModelName());
            dto.setModality(failureLog.getModality());
            dto.setPatientName(failureLog.getPatientName());
            calender.setTime(failureLog.getFailedDateTime());
            dto.setFailedDateTime(convertDateToUTCString(calender.getTime()));
            String responsiblePersonName = failureLog.getResponsiblePersonName();
            if (StringUtils.isEmpty(responsiblePersonName)) {
                responsiblePersonName = "";
            }
            dto.setResponsiblePersonName(responsiblePersonName);
            String hostName = failureLog.getHostName();
            if (StringUtils.isEmpty(hostName)) {
                hostName = "";
            }
            dto.setHostName(hostName);
            dto.setErrorType(failureLog.getErrorType());
            dto.setErrorMessage(failureLog.getErrorMessage());
            dtos.add(dto);
        }
    }


	/**
	 * 
	 * @param date
	 * @return
	 */
	private Date convertToDate(final String date) {
		Date toDate = null;
		DateTimeFormatter formatter = DateTimeFormat
				.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
		try {
			toDate = formatter.parseDateTime(date).toDate();
		} catch (IllegalArgumentException iae) {
			LoggerUtil.importent(getClass(),
					"Date Format is invalid: Input Date is: " + date + " :: "
							+ iae.getLocalizedMessage());
		}
		return toDate;
	}

	/**
	 * 
	 * @param date
	 * @return
	 */
	private String convertDateToUTCString(final Date date) {
		String toDate = null;
		DateTimeFormatter formatter = DateTimeFormat
				.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
		toDate = formatter.print(new DateTime(date));
		return toDate;
	}

}
