package com.idexx.dicom.ae.validator.impl.v13;

import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.stereotype.Service;

import com.idexx.dicom.ae.validator.IdexxValidator;
import com.idexx.dicom.services.dto.v13.IdexxErrorLogParamDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.logging.common.LoggerUtil;

/**
 * <pre>Description of the class</pre>
 * @author rkaranam
 * @version 1.3
 */
@Service("storeErrorLogValidatorV13")
public class StoreErrorLogValidatorImpl implements IdexxValidator {

    public boolean validate(final IdexxErrorLogParamDTO dto) throws IdexxDicomAEConfigServiceException {
        return validateInputFields(dto);
    }
    
    /**
     * @param dto
     * @return
     */
    private boolean isValidDateRange(final IdexxErrorLogParamDTO dto) {
        return dto.getStartDate().compareTo(dto.getEndDate()) <= 0;
    }
    
    /**
     * @param dto
     * @return
     */
    private boolean isMandatoryFieldsEmpty(final IdexxErrorLogParamDTO dto) {
        return ((null != dto.getStartDate() && !dto.getStartDate().isEmpty())
        && (null != dto.getEndDate() && !dto.getEndDate().isEmpty()));
    }

    /**
     * 
     * @param dto
     * @return
     * @throws IdexxDicomAEConfigServiceException
     */
    protected final boolean validateInputFields(final IdexxErrorLogParamDTO dto) throws IdexxDicomAEConfigServiceException {
    	boolean isValid = Boolean.TRUE;

    	IdexxErrorLogParamDTO iflDto = (IdexxErrorLogParamDTO) dto;
        if (!isMandatoryFieldsEmpty(iflDto)) {
        	isValid = Boolean.FALSE;
        	throw new IdexxDicomAEConfigServiceException(MISSING_MANDATORY,
                    MISSING_MANDATORY);
        }
        if (!isValidDateFormat(dto.getStartDate())) {
        	isValid = Boolean.FALSE;
        	throw new IdexxDicomAEConfigServiceException(INVALID_START_DATE,
                    INVALID_START_DATE);
        }
        if (!isValidDateFormat(dto.getEndDate())) {
        	isValid = Boolean.FALSE;
        	throw new IdexxDicomAEConfigServiceException(INVALID_END_DATE,
                    INVALID_END_DATE);
        }
        if (!isValidDateRange(iflDto)) {
        	isValid = Boolean.FALSE;
        	throw new IdexxDicomAEConfigServiceException(INVALID_DATE_RANGE,
                    INVALID_DATE_RANGE);
        }
        return isValid;
    }
    
    private boolean isValidDateFormat(final String date) {
        boolean valid = false;
        DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        try {
            formatter.parseDateTime(date);
            valid = true;
        } catch (UnsupportedOperationException uoe) {
            LoggerUtil.importent(getClass(), "Date Format is invalid: Input Date is: "
                    + date + " :: " + uoe.getLocalizedMessage());
        } catch (IllegalArgumentException iae) {
            LoggerUtil.importent(getClass(), "Date Format is invalid: Input Date is: "
                    + date + " :: " + iae.getLocalizedMessage());
        }
        return valid;
    }
}
