/**
 * <h1>Cancel Request Service implementation for Neo and Animana</h1>
 */
package com.idexx.dicom.services.requestservice;

import java.sql.Timestamp;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.idexx.dicom.domain.RequestDetails;
import com.idexx.dicom.repo.RequestDetailsRepository;
import com.idexx.dicom.sendimage.SendImageJobConstants;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;
import com.idexx.logging.common.LoggerUtil;



/**
 * <pre>CancelRequestService Implementation to cancel request Service Jobs.</pre>
 * @author smallela
 * @version 1.3
 */
@Service
public class CancelRequestServiceImpl {
	
	
    @Autowired
    private RequestDetailsRepository requestDetailsDao;
   
    
    
	/**
	 * <pre>Cancel Request takes StudyInstanceUID as input and process the cancel request and return json response as Update Successfully or StudyInstanceUID does not exists </pre>
	 * @param StudyInstanceUID
	 * @return String
	 * @throws IdexxDicomAEConfigServiceException
	 * @throws IdexxServiceException_Exception
	 * 
	 */
	@Transactional
    public String cancelRequest(String StudyInstanceUID) throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception{
		String message = "";
		try{
		List<RequestDetails> listReqDetails= requestDetailsDao.findByStudyInstanceUID(StudyInstanceUID);
		
    	if(null!=listReqDetails && listReqDetails.size()>0) {
    		RequestDetails reqDetails = listReqDetails.get(0);
    		reqDetails.setStatus(SendImageJobConstants.REQUEST_STATUS_CANCEL);
    		reqDetails.setUpdateTimeStamp(new Timestamp(System.currentTimeMillis()));
    		requestDetailsDao.save(reqDetails);    	
    		message = "Update Successfully";
     	}else{
    		message = "StudyInstanceUID does not exists";
       	}
		}catch(Exception exception){
			LoggerUtil.error(getClass(), exception.getLocalizedMessage(), exception);
	        throw new IdexxServiceException_Exception("Exception occured : ", null, exception);
			
		}
    return message;
	}
	
}
