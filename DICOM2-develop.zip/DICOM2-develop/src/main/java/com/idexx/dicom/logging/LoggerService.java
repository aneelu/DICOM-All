package com.idexx.dicom.logging;


import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.util.StopWatch;

import com.idexx.dicom.logging.common.LoggerAspectUtil;


@Aspect
public class LoggerService {

    @Before("execution(* com.idexx.dicom.*.*.*.*(..)) "
            + "&& !within(LoggerService)"
            + "&& !within(com.idexx.dicom.logging.common.LoggerUtil)")
	public void doLogBefore(JoinPoint joinPoint) {
		 LoggerAspectUtil.logMethodStart(joinPoint.getTarget().getClass(), joinPoint.getSignature().getName(), joinPoint.getArgs());
	}
    
    @Before("execution(* com.idexx.dicom.*.*.*.*(..)) "
            + "&& !within(LoggerService)")
    public final void doLogAfter(final JoinPoint joinPoint) throws Throwable {
        LoggerAspectUtil.logMethodEnd(joinPoint.getTarget().getClass(), joinPoint.getSignature().getName(), joinPoint.getArgs());
    }

	@AfterThrowing(pointcut = "execution(* com.idexx.dicom.*.*.*.*(..)) && !within(LoggerService) ", throwing = "exep")
    public final void doLogException(final JoinPoint joinPoint, final Throwable exep) throws Throwable {
        LoggerAspectUtil.logMethodException(joinPoint.getTarget().getClass(),
                joinPoint.getSignature().getName(), joinPoint.getArgs(), exep);
    }
	
    /**
     * @param joinPoint
     * @return
     * @throws Throwable
     */
    @Around("execution(* com.idexx.dicom.*.*.*.*(..)) "
            + "&& !within(LoggerService) ")
    public final Object doLogAround(final ProceedingJoinPoint joinPoint) throws Throwable {
        final StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        
        final Object retVal = joinPoint.proceed();
        
        stopWatch.stop();
        
        LoggerAspectUtil.executionTime(joinPoint.getTarget().getClass(),
                joinPoint.getSignature().getName(), joinPoint.getArgs(), stopWatch.getTotalTimeMillis());
        return retVal;
    }
    
}
