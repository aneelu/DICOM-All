package com.idexx.dicom.storescp;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.cli.ParseException;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;
import org.dcm4che3.data.VR;
import org.dcm4che3.io.DicomOutputStream;
import org.dcm4che3.net.ApplicationEntity;
import org.dcm4che3.net.Association;
import org.dcm4che3.net.Device;
import org.dcm4che3.net.PDVInputStream;
import org.dcm4che3.net.Status;
import org.dcm4che3.net.TransferCapability;
import org.dcm4che3.net.pdu.PresentationContext;
import org.dcm4che3.net.service.BasicCEchoSCP;
import org.dcm4che3.net.service.BasicCStoreSCP;
import org.dcm4che3.net.service.DicomServiceException;
import org.dcm4che3.net.service.DicomServiceRegistry;
import org.dcm4che3.tool.storescp.StoreSCP;
import org.dcm4che3.util.SafeClose;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.idexx.dicom.dto.IdexxAuthorizationObject;
import com.idexx.dicom.services.IdexxDicomServiceConstants;
import com.idexx.dicom.store.DicomStoreServiceWithMetadataExtraction;
import com.idexx.dicom.store.authorization.IdexxAuthorization;
import com.idexx.dicom.store.impl.DicomStoreIMPluginService;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;
import com.idexx.logging.common.LoggerUtil;

@Service("storeSCPImpl")
public class StoreSCPImpl {

    int status;
    private final List<Attributes> rqCMDs = new ArrayList<Attributes>();
    private final List<String> instanceLocations = new ArrayList<String>();
    private final List<File> instanceFiles = new ArrayList<File>();
    InputStream inputStream;

    @Autowired
    DicomStoreIMPluginService dicomStoreIMPluginService;

    @Autowired
    DicomStoreServiceWithMetadataExtraction dicomStoreService;

    public String init(Device device, ApplicationEntity ae, DicomServiceRegistry serviceRegistry)
	    throws IOException, ParseException, GeneralSecurityException {

	try {
	    StoreSCP main = new StoreSCP();
	    main.setStatus(0);
	    ae.addTransferCapability(new TransferCapability(null, "*", TransferCapability.Role.SCP, "*"));
	    serviceRegistry.addDicomService(new BasicCEchoSCP());
	    serviceRegistry.addDicomService(cstoreSCP);
	    device.setDimseRQHandler(serviceRegistry);

	} catch (IOException e) {
	    throw new DicomServiceException(Status.ProcessingFailure, e);
	}
	return "Success";
    }

    private final BasicCStoreSCP cstoreSCP = new BasicCStoreSCP("*") {

	@Override
	protected void store(Association as, PresentationContext pc, Attributes rq, PDVInputStream data, Attributes rsp)
		throws IOException {
	    rsp.setInt(Tag.Status, VR.US, status);
	    String iuid = rq.getString(Tag.AffectedSOPInstanceUID);
	    String tsuid = pc.getTransferSyntax();
	    LoggerUtil.importent(getClass(), "Calling AET;" + as.getCallingAET());
	    LoggerUtil.importent(getClass(), "Called AET;" + as.getCalledAET());
	    Attributes attr = data.readDataset(tsuid);

	    InetAddress inetAddr = as.getSocket().getInetAddress();
	    Map<String, Object> props = dicomStoreIMPluginService.buildService();
	    IdexxAuthorization idexxAuthorization = dicomStoreService.getAuthorization(attr, as.getCallingAET(),
		    inetAddr.getHostAddress(), inetAddr.getHostName());
	    if (null == idexxAuthorization || (!idexxAuthorization.isAuthorized())) {
		throw new DicomServiceException(Status.ProcessingFailure, as.getCallingAET() + " is not Authorized ");
	    }
	    IdexxAuthorizationObject idexxAuthorizationObject = idexxAuthorization.getAuthorizationObject();
	    try {
		String storedImageReponse = dicomStoreService.callStoreImgMetaDataService(attr,
			idexxAuthorizationObject, as.getCallingAET(), props);
		LoggerUtil.importent(getClass(), "Stored Image Response created: " + storedImageReponse);

		try {
		    File file = getFileToWriteDCMFile(iuid + "." + props.get("fileType"));
		    DicomOutputStream out = new DicomOutputStream(file);
		    try {
			attr.writeTo(out);
		    } finally {
			SafeClose.close(out);
			rqCMDs.add(rq);
			instanceFiles.add(file);
			instanceLocations.add(file.getAbsolutePath());
		    }

		    storedImageReponse = dicomStoreService.callStoreUploadImgService(file, idexxAuthorizationObject,
			    storedImageReponse, as.getCallingAET(), props);
		    LoggerUtil.importent(getClass(), "upload Image Response created: " + storedImageReponse);

		} catch (IdexxServiceException_Exception e1) {
		    throw new DicomServiceException(Status.ProcessingFailure, as.getCallingAET() + " Exception :" + e1);
		}
	    } catch (Exception e) {
		throw new DicomServiceException(Status.ProcessingFailure, e);
	    }
	}

    };

    private File getFileToWriteDCMFile(String fileName) {
	File dcmFile = null;
	String destFolder = "";
	try {
	    destFolder = System.getProperty(IdexxDicomServiceConstants.JAVA_TEMP_LOCATION) + File.separator
		    + "tempFiles";
	    File dir = new File(destFolder);
	    if (!dir.exists()) {
		dir.mkdirs();
	    }
	    dcmFile = new File(dir.getAbsolutePath() + File.separator + fileName);
	} catch (Exception e) {
	    LoggerUtil.error(getClass(), "Error in writing the dcm file to temp location : " + destFolder);
	}
	return dcmFile;
    }

}
