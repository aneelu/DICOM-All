/**
 * <h1>Service to create request to integrate pims like Neo & Animana.</h1>
 */
package com.idexx.dicom.services.requestservice;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.idexx.dicom.aeservices.impl.v13.IdexxDicomWSAthorizationServiceImpl;
import com.idexx.dicom.mapper.EntityMapper;
import com.idexx.dicom.repo.RequestDetailsRepository;
import com.idexx.dicom.sendimage.ImageManagerStoreServiceProviderWraper;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO;
import com.idexx.dicom.services.requestservice.validator.CreateRequestValidator;
import com.idexx.imaging.imagemanager.soap.IDEXXImageManagerServices;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;
import com.idexx.imaging.imagemanager.soap.PatientDTO;
import com.idexx.logging.common.LoggerUtil;

/**
 * <pre>
 * Service to create request to integrate pims like Neo & Animana
 * </pre>
 * 
 * @author vvanjarana
 * @version 1.3
 */
@Service("createRequestServiceImpl")
public class CreateRequestServiceImpl {

    @Autowired
    private RequestDetailsRepository requestDetailsDao;
    
    @Autowired
    @Qualifier("entityMapper")
    EntityMapper entityMapper;

    @Autowired
    @Qualifier("idexxDicomWSAthorizationServiceImplV13")
    private IdexxDicomWSAthorizationServiceImpl idexxDicomWsAuthorizeService;
    
    @Autowired
    ImageManagerStoreServiceProviderWraper imageManagerStoreServiceProviderWraper;
    
    @Autowired
    @Qualifier("requestServiceValidator")
    CreateRequestValidator createRequestValidator;
    
    /**
     * 
     * <pre>Method to create request in Dicom host DB.</pre>
     * @param requestDetails
     * @return
     * @throws IdexxDicomAEConfigServiceException
     * @throws IdexxServiceException_Exception
     *
     */
    public String createRequest(RequestDetailsDTO requestDetails)
	    throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {
    	String studyInstanceUid = null;
    	boolean authorize = false;
    	
		//Authorize API Key
    	authorize = idexxDicomWsAuthorizeService.authorize(requestDetails.getApiKey());
    	
    	if(authorize){
    		//Validate all the Mandatory input parameter
        	createRequestValidator.validate(requestDetails);
        	studyInstanceUid = processRequest(requestDetails);
    	}
    	
		return studyInstanceUid;
    }
    
    /**
     * 
     * <pre>Method to process the create request</pre>
     * @param requestDetails
     * @return
     * @throws IdexxDicomAEConfigServiceException
     * @throws IdexxServiceException_Exception
     *
     */
    @Transactional
    protected String processRequest(RequestDetailsDTO requestDetails) 
    		throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception{
    	boolean isPatientCreated = false;
    	boolean isPatientExist = false;
    	
    	String studyInstanceUid = entityMapper.generateStudyInstanceUid(requestDetails);
    	requestDetails.setStudyInstanceUID(studyInstanceUid);
    	
    	IDEXXImageManagerServices idexxImService = imageManagerStoreServiceProviderWraper.getService();	
    	
		List<PatientDTO> listPatient = idexxImService.searchPatient(entityMapper.getPatientDTO(requestDetails));
		try {
			if (null != listPatient && listPatient.size() <= 0) {
				 String result = idexxImService.storeImageMetaData(entityMapper.getStoreImageMetaData(requestDetails));
				 LoggerUtil.info(CreateRequestServiceImpl.class, "storeImageMetaDataResponse = "+result);
				 isPatientCreated = true;
			}else{
				isPatientExist = true;
			}

		} catch (IdexxServiceException_Exception exp) {
			LoggerUtil.error(getClass(), "Unable to create Patient record");
			exp.printStackTrace();
			throw new IdexxServiceException_Exception("Unable to create Patient record", null);
		}
		
		if(isPatientCreated || isPatientExist){
			requestDetailsDao.save(entityMapper.dtoToEntityMapper(requestDetails));
		}
		LoggerUtil.info(getClass(), "Create Request Created Successfully.");
		
		return studyInstanceUid;
    }


}
