/**
 * 
 */
package com.idexx.dicom.controller;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;

import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.requestservice.CancelRequestServiceImpl;
import com.idexx.dicom.services.requestservice.CreateRequestServiceImpl;
import com.idexx.dicom.services.requestservice.GetOpenRequestsServiceImpl;
import com.idexx.dicom.services.requestservice.dto.GetOpenRequestDTO;
import com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;
import com.idexx.logging.common.LoggerUtil;

/**
 * Controller for integrating DICOM to any other pims like Neo & Animana
 * 
 * @author vvanjarana
 * @version 1.3
 */
@Controller("integrationController")
public class IntegrationController {

	@Autowired
	CreateRequestServiceImpl createRequestService;

	@Autowired
	CancelRequestServiceImpl cancelRequestService;
	
	@Autowired
	GetOpenRequestsServiceImpl getOpenRequestsService;

	@POST
	@Path("/createRequest")
	@Produces(MediaType.APPLICATION_JSON)
	public String createRequestService(@RequestBody RequestDetailsDTO reqDetails)
			throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {
		try {
			String response = null;
			response = createRequestService.createRequest(reqDetails);
			LoggerUtil.info(getClass(), "StudyInstanceUID = "+response);
			return response;
		} catch (Exception e) {
			return "Error: " + e;
		}
	}

	@POST
	@Path("/cancelRequest/{StudyInstanceUID}")
	public String cancelRequestService(@PathParam("StudyInstanceUID") String StudyInstanceUID)
			throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {
		String result = null;
		try {
			if(null != StudyInstanceUID && StudyInstanceUID.length() > 0){
				result = cancelRequestService.cancelRequest(StudyInstanceUID);
			}else{
				 throw new IdexxServiceException_Exception("Mandatory field StudyInstanceUID is missing : ", null);
			}
		} catch (Exception e) {
			throw new IdexxServiceException_Exception("Exception occured : "  , null, e);
		}
		return result;
	}

	@GET
	@Path("/getOpenRequests")
	@Produces(MediaType.APPLICATION_JSON)
	public GetOpenRequestDTO getOpenRequests() throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {
		GetOpenRequestDTO dto = null;
		try {
			 dto = getOpenRequestsService.getOpenRequests();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return dto;
		
	}

}
