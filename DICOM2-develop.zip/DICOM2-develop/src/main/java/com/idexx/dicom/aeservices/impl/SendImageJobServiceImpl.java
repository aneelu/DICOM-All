/**
 * 
 */
package com.idexx.dicom.aeservices.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.ae.validator.IdexxSendImageValidator;
import com.idexx.dicom.aeservices.IdexxDicomWSAthorizationService;
import com.idexx.dicom.aeservices.SendImageJobService;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.IdexxSendImageJobDao;
import com.idexx.dicom.services.IdexxDicomServiceConstants;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.SendImageJobParamDTO;
import com.idexx.logging.common.LoggerUtil;

/**
 * @author mdindukurthi
 * 
 */
@Service("getIdexxSendImageValidator")
public class SendImageJobServiceImpl implements SendImageJobService {

    @Autowired
    @Qualifier("idexxSendImageValidator")
    private IdexxSendImageValidator validator;

    @Autowired
    private IdexxSendImageJobDao sendImageJobDao;

    @Autowired
    private IdexxDicomWSAthorizationService idexxDicomWsAuthorizeService;

    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.aeservices.AEService#performService()
     */
    @Transactional
    public final String performService(final SendImageJobParamDTO dto) throws IdexxDicomAEConfigServiceException {
        String jobId = null;
        boolean authorized = false;
        authorized = idexxDicomWsAuthorizeService.authorize(dto.getApiKey());
        if (authorized) {
            this.validate(dto);
            jobId = this.doService(dto);
        }

        return jobId;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.aeservices.impl.AbstractAEServiceImpl#validate(com.idexx
     * .dicom.services.dto.IdexxDicomApplicationEntityDTO)
     */

    protected final int validate(final SendImageJobParamDTO dto) throws IdexxDicomAEConfigServiceException {
        SendImageJobParamDTO imageParamDTO = (SendImageJobParamDTO) dto;
        return validator.validate(imageParamDTO);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.aeservices.impl.AbstractAEServiceImpl#doService(com.idexx
     * .dicom.services.dto.IdexxDicomApplicationEntityDTO)
     */

    protected final String doService(final SendImageJobParamDTO dto) throws IdexxDicomAEConfigServiceException {
        String jobId = null;
        try {
            // setRetryCount();
            IdexxSendImageJob sendImageJob = new IdexxSendImageJob();
            sendImageJob.setDestinationAETitle(dto.getDestinationAETitle());
            sendImageJob.setDestinationHostName(dto.getDestinationHost());
            sendImageJob.setDestinationPort(dto.getDestinationPort());
            sendImageJob.setImageAssetId(dto.getImageAssetId());
            sendImageJob.setJobStatus(IdexxDicomServiceConstants.STATUS_PENDING);
            sendImageJob.setJobStatusDescription(IdexxDicomServiceConstants.PENDING_INIT_DESC);
            sendImageJob.setRetriesCount(IdexxDicomServiceConstants.DEFAULT_SEND_RETRY_COUNT);
            sendImageJob.setSendingAETitle(dto.getSendingAETitle());
            jobId = sendImageJobDao.createJob(sendImageJob);

        } catch (Exception exp) {
            LoggerUtil.error(getClass(), exp.getLocalizedMessage(), exp);
            throw new IdexxDicomAEConfigDbException(exp);
        }
        return jobId;

    }

    /*
     * private void setRetryCount() { BaseDicomImPluginConfig configBean =
     * this.configDao.getConfig(IdexxDicomServiceConstants.SEND_RETRY_COUNT);
     * int retryCount = -1; String configValue = null; if (null != configBean) {
     * configValue = configBean.getConfigValue(); } if
     * (!StringUtils.isEmpty(configValue)) { try { retryCount =
     * Integer.valueOf(configValue); } catch (NumberFormatException nfe) {
     * retryCount = -1; } } if (retryCount >= 0) { this.sendRetryCount =
     * retryCount; } }
     */

}
