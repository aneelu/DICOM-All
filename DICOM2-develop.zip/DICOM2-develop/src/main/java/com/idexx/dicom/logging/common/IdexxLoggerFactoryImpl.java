/**
 * 
 */
package com.idexx.dicom.logging.common;

import org.apache.log4j.Level;

import com.idexx.dicom.logging.impl.DebugLogger;
import com.idexx.dicom.logging.impl.ErrorLogger;
import com.idexx.dicom.logging.impl.InfoLogger;
import com.idexx.dicom.logging.impl.TraceLogger;
import com.idexx.dicom.logging.impl.WarnLogger;
import com.idexx.dicom.logging.intf.IdexxLogger;
import com.idexx.dicom.logging.intf.IdexxLoggerFactory;


public class IdexxLoggerFactoryImpl implements IdexxLoggerFactory {
    
    private IdexxLoggerFactoryImpl() {
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.logging.intf.IdexxLoggerFactory#createLogger(java.lang.Class,
     * org.apache.log4j.Level)
     */
    public final IdexxLogger createLogger(final Class<?> cls, final Level logLevel) {
        IdexxLogger logger = null;
        int level = logLevel.toInt();
        switch (level) {
            case Level.TRACE_INT:
                logger = new TraceLogger(cls);
                break;
            case Level.ERROR_INT:
                logger = new ErrorLogger(cls);
                break;
            case Level.INFO_INT:
                logger = new InfoLogger(cls);
                break;
            case Level.WARN_INT:
                logger = new WarnLogger(cls);
                break;
            default:
                logger = new DebugLogger(cls);
                break;
        }
        return logger;
    }
    
    private static IdexxLoggerFactory instance;
    static {
        instance = new IdexxLoggerFactoryImpl();
    }
    
    public static IdexxLoggerFactory getInstance() {
        return instance;
    }
}
