/**
 * 
 */
package com.idexx.dicom;

import java.util.Map;

import javax.xml.ws.BindingProvider;
import javax.xml.ws.soap.SOAPBinding;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.springframework.stereotype.Service;

import com.idexx.dicom.query.soap.IQRService11;
import com.idexx.dicom.query.soap.QRService11;
import com.idexx.imaging.imagemanager.soap.IDEXXImageManagerServices;
import com.idexx.imaging.imagemanager.soap.IDEXXImageManagerServices_Service;
import com.idexx.logging.common.LoggerUtil;

/**
 * @author sbitla
 * 
 */
@Service
public class ImageManagerStoreServiceProviderImpl implements ImageManagerStoreServiceProvider {
    
    private static final int CHUNK_SIZE = 8192;
    
    private String imageManagerServiceURL;
    private long connectionTimeout;
    
    /**
     * 
     */
    public ImageManagerStoreServiceProviderImpl(final String imServiceURL, final long connectionTimeout) {
        this.imageManagerServiceURL = imServiceURL;
        this.connectionTimeout = connectionTimeout;
    }
    
    public ImageManagerStoreServiceProviderImpl() {}
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.store.ImageManagerStoreServiceProvider#getService()
     */
    public final IDEXXImageManagerServices getService()  {
        LoggerUtil.info(getClass(), "IM_MANAGER_URL: " + imageManagerServiceURL);
        
        IDEXXImageManagerServices_Service service = new IDEXXImageManagerServices_Service();
        IDEXXImageManagerServices port = service.getIDEXXImageManagerServicesPort();
        BindingProvider bindingProvider = (BindingProvider) port;
        Client client = ClientProxy.getClient(port);
        HTTPConduit conduit = (HTTPConduit) client.getConduit();
        HTTPClientPolicy policy = conduit.getClient();
        policy.setConnectionTimeout(connectionTimeout);
        Map<String, Object> ctxt = bindingProvider.getRequestContext();
        ctxt.put("com.sun.xml.internal.ws.transport.http.client.streaming.chunk.size", Integer.valueOf(CHUNK_SIZE));
        ctxt.put("com.sun.xml.internal.ws.connect.timeout", Integer.valueOf(1));
        ctxt.put("javax.xml.ws.service.endpoint.address", imageManagerServiceURL);
        SOAPBinding soapBinding = (SOAPBinding) bindingProvider.getBinding();
        soapBinding.setMTOMEnabled(true);
        return port;
    }
    
    /*
     * Image Manager Query Service Handler
     */
    public final IQRService11 getQueryService() {
        LoggerUtil.info(getClass(), "queryWorkListURL: " + imageManagerServiceURL);
        QRService11 service = new QRService11();
        IQRService11 port = service.getBasicHttpBindingIQRService11();
        BindingProvider bindingProvider = (BindingProvider) port;
        Client client = ClientProxy.getClient(port);
        HTTPConduit conduit = (HTTPConduit) client.getConduit();
        HTTPClientPolicy policy = conduit.getClient();
        policy.setConnectionTimeout(connectionTimeout);
        Map<String, Object> ctxt = bindingProvider.getRequestContext();
        ctxt.put("com.sun.xml.internal.ws.transport.http.client.streaming.chunk.size", Integer.valueOf(CHUNK_SIZE));
        ctxt.put("com.sun.xml.internal.ws.connect.timeout", Integer.valueOf(1));
        ctxt.put("javax.xml.ws.service.endpoint.address", imageManagerServiceURL);
        return port;
    }
    
}
