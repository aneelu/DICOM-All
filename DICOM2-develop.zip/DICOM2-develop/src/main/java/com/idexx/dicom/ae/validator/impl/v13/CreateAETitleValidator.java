/**
 * 
 */
package com.idexx.dicom.ae.validator.impl.v13;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.entities.AEEntity;
import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.entities.IdexxInvalidAE;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.dto.v13.AETitleDTO;
import com.idexx.dicom.services.dto.v13.CreateAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * <pre>CreateAETitleValidator Implementation to check input parameters for Create AETitle web Service</pre>
 * @author smallela
 * @version 1.3
 */

@Service("createAETitleValidatorV13")
public class CreateAETitleValidator extends AbstractAETitleValidator {
	@Autowired
    private AETitleDao aeTitleDao;

	 /**
     * <pre>this method validates InputFields(AeTitle,HostName,ApiKey,InstituteName are empty or not) for Create AETitle service Job</pre>
     * @param dto
     * @return int
     * @throws IdexxDicomAEConfigServiceException
     * 
     */ 
	
    @Override
    protected final int validateInputFields(final AETitleDTO dto) throws IdexxDicomAEConfigServiceException {

        CreateAETitleDTO createAEDTO = (CreateAETitleDTO) dto;
        if ((StringUtils.isEmpty(createAEDTO.getAeTitle()))) {
            throw new IdexxDicomAEConfigServiceException(MISSING_MANDATORY, MISSING_MANDATORY);
        }

        if (createAEDTO.isDvmSpecialist()) {
            if ((StringUtils.isEmpty(createAEDTO.getHostName())) || (createAEDTO.getPort() == 0)) {
                throw new IdexxDicomAEConfigServiceException(MISSING_MANDATORY, MISSING_MANDATORY);

            }
        } else {
            if ((StringUtils.isEmpty(createAEDTO.getApiKey())) || (StringUtils.isEmpty(createAEDTO.getSapId()))) {
                throw new IdexxDicomAEConfigServiceException(MISSING_MANDATORY, MISSING_MANDATORY);
            } else if ((!createAEDTO.isIdentifiedByAeTitleOnly())
                    && (StringUtils.isEmpty(createAEDTO.getInstituteName()))) {
                throw new IdexxDicomAEConfigServiceException(MISSING_INSTITUTE_NAME, MISSING_INSTITUTE_NAME);
            }

        }
        return 1;
    }

    /**
     * <pre>this method validates DBFields(RECORD_ALREADY_EXISTS,INVALID_AETITLE,GENERAL_DB_FAILURE) for create AETitle service Job</pre>
     * @param dto
     * @return int
     * @throws IdexxDicomAEConfigServiceException
     * 
     */   
    
    @Override
    @Transactional
    protected final int validateDBFields(final AETitleDTO dto) throws IdexxDicomAEConfigServiceException {

        CreateAETitleDTO createAEDTO = (CreateAETitleDTO) dto;
        try {
            if (createAEDTO.isDvmSpecialist()) {
                if (isAEExist(createAEDTO.getAeTitle())) {
                    throw new IdexxDicomAEConfigServiceException(RECORD_ALREADY_EXISTS);

                }

            } else {
                if (isValidateAeTitle(dto.getAeTitle())) {

                    if (isAETitleExistWithAETitleOnly(dto.getAeTitle())) {
                        throw new IdexxDicomAEConfigServiceException(RECORD_ALREADY_EXISTS);
                    } else if (isAETitleExist(dto.getAeTitle()) && createAEDTO.isIdentifiedByAeTitleOnly()) {
                        throw new IdexxDicomAEConfigServiceException(RECORD_ALREADY_EXISTS);

                    } else if (isAETitleExist(dto.getAeTitle())
                            && !createAEDTO.isIdentifiedByAeTitleOnly()
                            && isAETitleExistsWithInstituteName(createAEDTO.getAeTitle(),
                                    createAEDTO.getInstituteName())) {
                        throw new IdexxDicomAEConfigServiceException(RECORD_ALREADY_EXISTS);
                    }
                } else {
                    throw new IdexxDicomAEConfigServiceException(INVALID_AETITLE);
                }
            }
        } catch (IdexxDicomAEConfigDbException e) {
            throw new IdexxDicomAEConfigServiceException(GENERAL_DB_FAILURE, e);
        }

        return 1;
    }

    private boolean isAETitleExistsWithInstituteName(final String aeTitle, final String instituteName) {
        boolean isExists = false;
        List<AETitle> registeredAEList = aeTitleDao.findAETitle(aeTitle, instituteName);
        if (null != registeredAEList && registeredAEList.size() > 0) {
            isExists = true;
        }

        return isExists;
    }

    private boolean isAETitleExist(final String aeTitle) {
        boolean isExists = false;
        List<AETitle> registeredAEList = aeTitleDao.findAETitle(aeTitle);
        if (null != registeredAEList && registeredAEList.size() >= 1) {
            isExists = true;
        }
        return isExists;
    }

    private boolean isAEExist(final String aeTitle) {
        boolean isExists = false;
        List<AEEntity> registeredAEList = aeTitleDao.findAE(aeTitle);
        if (null != registeredAEList && registeredAEList.size() >= 1) {
            isExists = true;
        }
        return isExists;
    }

    private boolean isAETitleExistWithAETitleOnly(final String aeTitle) {
        boolean isExists = false;
        List<AETitle> registeredAEList = aeTitleDao.findAETitle(aeTitle);
        if (null != registeredAEList && registeredAEList.size() >= 1
                && registeredAEList.get(0).isIdentifiedByaeTitleOnly()) {
            isExists = true;
        }
        return isExists;
    }

    protected final boolean isValidateAeTitle(final String aeTitle) {
        boolean isValid = true;
        IdexxInvalidAE ae = aeTitleDao.getInvalidAETitle(aeTitle);
        if (ae != null) {
            isValid = false;
        }
        return isValid;
    }
}
