/**
 * 
 */
package com.idexx.dicom.store.authorization;

import com.idexx.dicom.dto.IdexxAuthorizationObject;

/**
 * @author vkandagatla
 * 
 */
public interface IdexxAuthorization {
    boolean isAuthorized();
    
    IdexxAuthorizationObject getAuthorizationObject();
}
