/**
 * <h1>Class to validate the Create Request mandatory parameters.</h1>
 */
package com.idexx.dicom.services.requestservice.validator;

import org.apache.commons.lang.math.NumberUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO;

/**
 * <pre>Class to validate the Create Request mandatory parameters.</pre>
 * @author nayeemuddin
 * @version 1.3
 */
@Service("requestServiceValidator")
public class CreateRequestValidator {
	
		public static final String MISSING_MANDATORY = "ERR_argument_missing_mandatory";
		public static final String INVALID_SAPID = "ERR_sapid_must_be_numeric";
		
		/**
		 * 
		 * <pre>Method to validate create request mandatory parameters.</pre>
		 * @param dto
		 * @return
		 * @throws IdexxDicomAEConfigServiceException
		 *
		 */
		public int validate(final RequestDetailsDTO dto) throws IdexxDicomAEConfigServiceException {
	        if (StringUtils.isEmpty(dto.getApiKey())
	                || StringUtils.isEmpty(dto.getClientLastName())
	                || StringUtils.isEmpty(dto.getPatientId())
	                || StringUtils.isEmpty(dto.getPatientName())
	                || StringUtils.isEmpty(dto.getSapId())
	                || StringUtils.isEmpty(dto.getPimsIssuer())) {
	            throw new IdexxDicomAEConfigServiceException(
	                    MISSING_MANDATORY, MISSING_MANDATORY );
	        }
	        if (!StringUtils.isEmpty(dto.getSapId()) && !NumberUtils.isNumber(dto.getSapId())) {
	            throw new IdexxDicomAEConfigServiceException(
	            		INVALID_SAPID, INVALID_SAPID);
	        }
	        return 1;
	    }

}
