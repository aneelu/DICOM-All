package com.idexx.dicom.ae.validator.impl.v13;

import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.stereotype.Service;

import com.idexx.dicom.ae.validator.IdexxValidator;
import com.idexx.dicom.services.dto.v13.IdexxFailureLogParamDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.logging.common.LoggerUtil;


/**
 * <pre>Description of the class</pre>
 * @author rkaranam
 * @version 1.3
 */
@Service("getStoreFailuresValidatorV13")
public class GetStoreFailuresValidator implements IdexxValidator {
    public int validate(final IdexxFailureLogParamDTO dto) throws IdexxDicomAEConfigServiceException {
        validateInputFields(dto);
        return 1;
    }
    
    /**
     * @param dto
     * @return
     */
    private boolean isValidDateRange(final IdexxFailureLogParamDTO dto) {
        return dto.getStartDate().compareTo(dto.getEndDate()) <= 0;
    }
    
    /**
     * @param dto
     * @return
     */
    private boolean isMandatoryFieldsEmpty(final IdexxFailureLogParamDTO dto) {
        return ((null != dto.getStartDate() && !dto.getStartDate().isEmpty())
        && (null != dto.getEndDate() && !dto.getEndDate().isEmpty()));
    }
    
    protected final int validateInputFields(final IdexxFailureLogParamDTO dto) throws IdexxDicomAEConfigServiceException {
        IdexxFailureLogParamDTO iflDto = (IdexxFailureLogParamDTO) dto;
        if (!isMandatoryFieldsEmpty(iflDto)) {
            throw new IdexxDicomAEConfigServiceException(MISSING_MANDATORY,
                    MISSING_MANDATORY);
        }
        if (!isValidDateFormat(dto.getStartDate())) {
            throw new IdexxDicomAEConfigServiceException(INVALID_START_DATE,
                    INVALID_START_DATE);
        }
        if (!isValidDateFormat(dto.getEndDate())) {
            throw new IdexxDicomAEConfigServiceException(INVALID_END_DATE,
                    INVALID_END_DATE);
        }
        if (!isValidDateRange(iflDto)) {
            throw new IdexxDicomAEConfigServiceException(INVALID_DATE_RANGE,
                    INVALID_DATE_RANGE);
        }
        return 1;
    }
    
    private boolean isValidDateFormat(final String date) {
        boolean valid = false;
        DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        try {
            formatter.parseDateTime(date);
            valid = true;
        } catch (UnsupportedOperationException uoe) {
            LoggerUtil.importent(getClass(), "Date Format is invalid: Input Date is: "
                    + date + " :: " + uoe.getLocalizedMessage());
        } catch (IllegalArgumentException iae) {
            LoggerUtil.importent(getClass(), "Date Format is invalid: Input Date is: "
                    + date + " :: " + iae.getLocalizedMessage());
        }
        return valid;
    }
}
