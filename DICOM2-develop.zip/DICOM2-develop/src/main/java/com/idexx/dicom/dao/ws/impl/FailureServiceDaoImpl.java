/**
 * DAO for Failure Service
 */
package com.idexx.dicom.dao.ws.impl;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Repository;

import com.idexx.dicom.ae.entities.IdexxDicomServiceFailureLog;
import com.idexx.dicom.dao.ws.FailureServiceDao;
import com.idexx.dicom.query.QueryBuilder;
import com.idexx.dicom.query.impl.QueryBuilderImpl;
import com.idexx.logging.common.LoggerUtil;

/**
 * @author anarayana
 * 
 */
@Repository
public class FailureServiceDaoImpl implements FailureServiceDao {
    @PersistenceContext
    private EntityManager entityManager;
    
    private static final String FAILURE_LOG_QUERY = "FROM IdexxDicomServiceFailureLog IDFL WHERE "
            + "IDFL.failedDateTime >= :START_DATE "
            + "AND IDFL.failedDateTime <= :END_DATE";

    private static final int MAX_RECORDS = 500;
    /*
     * @see
     * com.idexx.dicom.dao.ws.FailureServiceDao#getFailureLog(java.lang.String,
     * java.util.Date, java.util.Date)
     */
    @SuppressWarnings("unchecked")
    public final List<IdexxDicomServiceFailureLog> getFailureLog(
            final Date startDate,
            final Date endDate) {
        LoggerUtil.importent(getClass(), "Getting AE Authorization Failure LOGs from table: idx_failure_log::Start Date: " 
            + startDate + " ::: END Date:" + endDate);
        return entityManager.createQuery(FAILURE_LOG_QUERY)
                .setParameter("START_DATE", startDate)
                .setParameter("END_DATE", endDate).getResultList();
    }

    /*
     * @see 
     * com.idexx.dicom.dao.ws.FailureServiceDao#getFailureLog(java.util.Date, java.util.Date, 
     * java.lang.String, java.lang.String)
     * 
     */
    @SuppressWarnings("unchecked")
    public final List<IdexxDicomServiceFailureLog> getFailureLogErrorMessages (
            final Date startDate,
            final Date endDate,
    		final String aeTitle,
    		final String instituteName,
    		final String errorType) {
		LoggerUtil.importent(getClass(), "Getting Failure LOGs from table: idx_failure_log::Start Date: " 
	            + startDate + " ::: END Date:" + endDate + " ::: AE_TITLE:" + aeTitle + " ::: INSTITUTE NAME:" + instituteName);
		QueryBuilder queryBuilder = new QueryBuilderImpl();
		
		Query query = entityManager.createQuery(queryBuilder.getSelectQuery(aeTitle, instituteName, errorType));
		query.setMaxResults(MAX_RECORDS);
		query.setParameter("START_DATE", startDate);
		query.setParameter("END_DATE", endDate);
		
		if (!StringUtils.isEmpty(errorType)) {
			query.setParameter("ERROR_TYPE", errorType);
		}
		
		if (!StringUtils.isEmpty(aeTitle)) {
			query.setParameter("AE_TITLE", aeTitle);
		}
		
		if (!StringUtils.isEmpty(instituteName)) {
			query.setParameter("INSTITUTE_NAME", instituteName);
		}
		
		return query.getResultList();
	}

}
