/**
 * 
 */
package com.idexx.dicom.logging.impl;

import org.apache.log4j.Level;


public class WarnLogger extends AbstractIdexxLogger {
    
    /**
     * @param cls
     */
    public WarnLogger(final Class<?> cls) {
        super(cls);
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.logging.impl.AbstractIdexxLogger#isEnabled()
     */
    @Override
    public final boolean isEnabled() {
        return this.getLogger().isEnabledFor(Level.WARN);
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.logging.impl.AbstractIdexxLogger#log(java.lang.String)
     */
    @Override
    public final void log(final String message) {
        this.getLogger().warn(message);
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.logging.impl.AbstractIdexxLogger#log(java.lang.String,
     * java.lang.Throwable)
     */
    @Override
    public final void log(final String message, final Throwable throwable) {
        this.getLogger().warn(message, throwable);
    }
    
}
