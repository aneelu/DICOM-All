/**
 * 
 */
package com.idexx.dicom.aeservices.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.idexx.dicom.aeservices.AEService;
import com.idexx.dicom.aeservices.IdexxDicomWSAthorizationService;
import com.idexx.dicom.services.dto.AETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * @author vkandagatla
 * 
 */
public abstract class AbstractAEServiceImpl implements AEService {
    @Autowired
    private IdexxDicomWSAthorizationService idexxDicomWsAuthorizeService;

    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.aeservices.AEService#performService()
     */
    @Transactional
    public final void performService(final AETitleDTO dto) throws IdexxDicomAEConfigServiceException {
        boolean authorized = false;
        authorized = isAPIKeyValid(dto.getApiKey());
        if (authorized) {
            this.validate(dto);
            this.doService(dto);
        }

    }

    protected abstract int validate(AETitleDTO dto) throws IdexxDicomAEConfigServiceException;

    protected abstract int doService(AETitleDTO dto) throws IdexxDicomAEConfigServiceException;

    public Object sendResponse() {
        return new Integer(0);
    }

    public final boolean isAPIKeyValid(final String apiKey) throws IdexxDicomAEConfigServiceException {
        return idexxDicomWsAuthorizeService.authorize(apiKey);
    }

}
