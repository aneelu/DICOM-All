/**
 * 
 */
package com.idexx.dicom.store.authorization.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.idexx.dicom.exceptions.IdexxDicomAuthorizationException;
import com.idexx.dicom.logging.common.LoggerUtil;
import com.idexx.dicom.store.authorization.AuthorizationFailureService;
import com.idexx.dicom.store.authorization.IdexxAuthorization;
import com.idexx.dicom.store.authorization.IdexxAuthorizationService;

/**
 * @author vkandagatla
 * 
 */
@Service("idexxDicomAuthorizationHandler")
public class IdexxDicomAuthorizationHandlerImpl {
    
   @Autowired
   private IdexxAuthorizationService authorizationService;
   
   @Autowired
   private AuthorizationFailureService failureService;
    
    public IdexxDicomAuthorizationHandlerImpl() {
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.store.authorization.IdexxDicomAuthorizationHandler#
     * performaAuthorization(java.lang.String, java.lang.String,
     * java.lang.String, java.lang.String, java.lang.String, java.lang.String)
     */
    
    public IdexxAuthorization performaAuthorization(final String aeTitle, final String instituteName,
            final String ip, final String hostName, final String manufacturer,
            final String manufacturerModelName, final String modality, final String patientName, final String respPerName) {
	IdexxAuthorization authorization = null;
      try {
            authorization = authorizationService.authorize(aeTitle, instituteName);
        } catch (IdexxDicomAuthorizationException idae) {
            LoggerUtil.importent(getClass(), "NOT AUTHORIZED");
            failureService.logIdexxAuthorizationFailure(aeTitle, instituteName, ip, hostName, manufacturer, 
                    manufacturerModelName, modality, patientName, respPerName);
            authorization = null;
        }catch(Exception exp){
            LoggerUtil.error(getClass(), exp.getLocalizedMessage(), exp);
            LoggerUtil.importent(getClass(), "NOT AUTHORIZED");
            failureService.logIdexxAuthorizationFailure(aeTitle, instituteName, ip, hostName, manufacturer, 
                    manufacturerModelName, modality, patientName, respPerName);
            authorization = null;
        }
        return authorization;
    }

}
