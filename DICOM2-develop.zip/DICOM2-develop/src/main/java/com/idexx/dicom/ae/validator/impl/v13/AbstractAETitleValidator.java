/**
 * 
 * 
 */
package com.idexx.dicom.ae.validator.impl.v13;

import org.springframework.stereotype.Component;

import com.idexx.dicom.services.dto.v13.AETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * <pre>AbstractAETitleValidator Implementation to check input parameters for AETitle web Service</pre>
 * @author smallela
 * @version 1.3
 */
@Component("readAETitleValidatorV13")
public abstract class AbstractAETitleValidator {
    
	public static String MISSING_MANDATORY = "ERR_argument_missing_mandatory";
    String MISSING_INSTITUTE_NAME = "ERR_argument_missing_institute";
    String RECORD_ALREADY_EXISTS = "ERR_record_already_exists";
    String NO_RECORD_FOUND = "ERR_no_record_found";
    String GENERAL_DB_FAILURE = "ERR_general_db_fail";
    String INVALID_AETITLE = "ERR_invalid_AE_title";
    String INVALID_DATE_RANGE = "ERR_invalid_date_range";
    String INVALID_START_DATE = "ERR_invalid_start_date";
    String INVALID_END_DATE = "ERR_invalid_end_date";
	
    /**
     * <pre>Validate apiKey,aeTitle,instituteName of AETitle service Job</pre>
     * @param dto
     * @return int
     * @throws IdexxDicomAEConfigServiceException
     * 
     */
    
    public int validate(final AETitleDTO dto) throws IdexxDicomAEConfigServiceException {
        validateInputFields(dto);
        validateDBFields(dto);
        return 1;
    }
    
    /**
     * <pre>this method validates InputFields(aeTitle,instituteName,apiKey) of AETitle service Job</pre>
     * @param dto
     * @return int
     * @throws IdexxDicomAEConfigServiceException
     * 
     */ 
    
    protected abstract int validateInputFields(AETitleDTO dto) throws IdexxDicomAEConfigServiceException;
    
    
    /**
     * <pre>this method validates DBFields(RECORD_ALREADY_EXISTS,INVALID_AETITLE,GENERAL_DB_FAILURE) of AETitle service Job</pre>
     * @param dto
     * @return int
     * @throws IdexxDicomAEConfigServiceException
     * 
     */  
    protected abstract int validateDBFields(AETitleDTO dto) throws IdexxDicomAEConfigServiceException;
    
}