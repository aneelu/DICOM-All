/**
 * 
 */
package com.idexx.dicom.aeservices.impl.v11;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.ae.validator.v11.CancelSendJobServiceValidator;
import com.idexx.dicom.aeservices.v11.CancelSendJobService;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.IdexxSendImageJobDao;
import com.idexx.dicom.sendimage.SendImageJobConstants;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v11.CancelSendJobParamDTO;
import com.idexx.logging.common.LoggerUtil;

/**
 * @author anarayana
 * 
 */
@Service("cancelSendJobServiceImplV11")
public class CancelSendJobServiceImpl implements CancelSendJobService {

    @Autowired
    @Qualifier("cancelSendJobServiceValidatorV11")
    private CancelSendJobServiceValidator validator;

    @Autowired
    private IdexxSendImageJobDao cancelSendImageJobDao;

    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.aeservices.AEService#performService()
     */
    @Transactional
    public final String performService(final CancelSendJobParamDTO dto) throws IdexxDicomAEConfigServiceException {
            this.validate(dto);
            String message = this.doService(dto);
        return message;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.aeservices.impl.AbstractAEServiceImpl#validate(com.idexx
     * .dicom.services.dto.IdexxDicomApplicationEntityDTO)
     */

    protected final int validate(final CancelSendJobParamDTO dto) throws IdexxDicomAEConfigServiceException {
        return validator.validate(dto);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.aeservices.impl.AbstractAEServiceImpl#doService(com.idexx
     * .dicom.services.dto.IdexxDicomApplicationEntityDTO)
     */

    protected final String doService(final CancelSendJobParamDTO dto) throws IdexxDicomAEConfigServiceException {
        String message = null;
        try {
            List<IdexxSendImageJob> jobList = new ArrayList<IdexxSendImageJob>();
            List<String> jobIdList = new ArrayList<String>();
            jobIdList.add(dto.getJobId());
            jobList = cancelSendImageJobDao.getJob(jobIdList);
            if (!jobList.isEmpty()) {
                IdexxSendImageJob idexxCancelJob = jobList.get(0);
                idexxCancelJob.setJobStatus(SendImageJobConstants.JOB_STATUS_CANCEL);
                message = cancelSendImageJobDao.cancelSendJob(idexxCancelJob);
            } else {
                message = "JobId " + dto.getJobId() + " does not exists.";
            }
        } catch (Exception exp) {
            LoggerUtil.error(getClass(), exp.getLocalizedMessage(), exp);
            throw new IdexxDicomAEConfigDbException(exp);
        }
        return message;
    }
}
