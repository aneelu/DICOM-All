package com.idexx.dicom.services;

import static org.quartz.CronScheduleBuilder.cronSchedule;
import static org.quartz.JobBuilder.newJob;
import static org.quartz.TriggerBuilder.newTrigger;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.SchedulerException;
import org.quartz.TriggerKey;
import org.quartz.impl.StdScheduler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.entities.BaseDicomImPluginConfig;
import com.idexx.dicom.dao.ws.DicomConfigDao;
import com.idexx.dicom.sendimage.JobRunnerBuilder;
import com.idexx.dicom.sendimage.SendImageJobConstants;
import com.idexx.dicom.sendimage.impl.SchedulerJob;
import com.idexx.logging.common.LoggerUtil;

/**
 * Servlet implementation class SendImageDispatcherServlet
 */
@Controller
public class SendImageJobSchedulerController {
    private static final String JOB_NAME = "SendImageJob";
    private static final String TRIGGER_NAME = "SendImageJob";
    private static final String GROUP_NAME = "SendImageJobGroup";

    private JobKey jobKey;
    private TriggerKey triggerKey;
    @Autowired
    private DicomConfigDao configDao;

    @Autowired
    private JobRunnerBuilder jobRunnerBuilder;

    /**
     * @see DispatcherServlet#DispatcherServlet()
     */
    public SendImageJobSchedulerController() {
        super();
        jobKey = new JobKey(JOB_NAME, GROUP_NAME);
        triggerKey = new TriggerKey(TRIGGER_NAME, GROUP_NAME);
    }

    @PostConstruct
    public final void init() {
        try {
            if (!this.canSchedule()) {
                LoggerUtil.importent(getClass(), "This Server does not schedule any jobs.");
                return;
            } else {
                this.initialize();
            }
        } catch (UnknownHostException exp) {
            LoggerUtil.error(getClass(), exp.getLocalizedMessage(), exp);
            return;
        }

    }

    private void initialize() {
        try {
            InitialContext initialContext = new InitialContext();
            StdScheduler scheduler = (StdScheduler) initialContext.lookup("Quartz");

            LoggerUtil.importent(getClass(), "Got Scheduler" + scheduler.getSchedulerName());

            JobDetail job = this.createJob(scheduler);
            LoggerUtil.importent(getClass(), "Created JOB Detail: " + job.getDescription());

            String triggerExpression = this.getFrequency();
            CronTrigger trigger = newTrigger().withIdentity(triggerKey).withSchedule(cronSchedule(triggerExpression))
                    .build();
            LoggerUtil.importent(getClass(), "Created Cron Trigger: " + triggerExpression);

            Date ft = scheduler.scheduleJob(job, trigger);
            LoggerUtil.importent(getClass(), job.getKey() + " has scheduled to run at: " + ft
                    + " and repeat based on expression: " + trigger.getCronExpression());

            LoggerUtil.importent(getClass(), "Starting Scheduler");
            scheduler.start();
        } catch (NamingException namingException) {
            LoggerUtil.error(getClass(), namingException.getMessage());
        } catch (SchedulerException sexp) {
            LoggerUtil.error(getClass(), sexp.getMessage());
        }
    }

    private JobDetail createJob(final StdScheduler scheduler) throws SchedulerException {
        boolean jobExists = scheduler.checkExists(jobKey);
        if (jobExists) {
            scheduler.unscheduleJob(triggerKey);
            scheduler.deleteJob(jobKey);
        }
        JobDetail job = newJob(SchedulerJob.class).withIdentity(jobKey).build();
        // tell the job to delay some small amount... to simulate
        // work...
        long timeDelay = (long) (getDefaultThreadSleap());
        job.getJobDataMap().put(SchedulerJob.DELAY_TIME, timeDelay);
        job.getJobDataMap().put(SchedulerJob.JOB_BUILDER, jobRunnerBuilder);
        job.getJobDataMap().put(SchedulerJob.CONFIG_DAO, configDao);
        return job;
    }

    /**
     * @return
     */
    private String getFrequency() {

        BaseDicomImPluginConfig config = configDao.getConfig(SendImageJobConstants.SEND_IMAGE_CRON_EXPRESSION);
        String expression = SendImageJobConstants.DEFAULT_SEND_IMAGE_CRON_EXPRESSION;
        if (null != config && !StringUtils.isEmpty(config.getConfigValue())) {
            expression = config.getConfigValue();
        }
        LoggerUtil.importent(getClass(), "Scheduler Frequency: " + expression);
        return expression;
    }

    public final boolean canSchedule() throws UnknownHostException {
        LoggerUtil.importent(getClass(), "Checking whether to execute");
        BaseDicomImPluginConfig config = configDao
                .getConfig(SendImageJobConstants.SEND_IMAGE_SCHEDULER_STATE_CONFIG_NAME);
        String configValue = config.getConfigValue();
        LoggerUtil.importent(getClass(), "SEND_IMAGE_STATE: " + configValue);
        return SendImageJobConstants.SEND_IMAGE_SEND_IMAGE_STATE_SCHEDULED.equalsIgnoreCase(configValue)
                && this.canRunFromThisHost();
    }

    private boolean canRunFromThisHost() throws UnknownHostException {
        return this.getHostName().equalsIgnoreCase(this.getSchedulerHost());
    }

    private String getSchedulerHost() {
        BaseDicomImPluginConfig config = configDao.getConfig(SendImageJobConstants.SCHEDULER_RUN_HOST_CONFIG_NAME);
        String hostName = SendImageJobConstants.DEFAULT_SCHEDULER_RUN_HOST;
        if (null != config) {
            hostName = config.getConfigValue();
        }
        LoggerUtil.importent(getClass(), "SCHEDULER_RUN_HOST_NAME: " + hostName);
        return hostName;
    }

    private String getHostName() throws UnknownHostException {
        String hostName = null;
        InetAddress ia = InetAddress.getLocalHost();
        hostName = ia.getCanonicalHostName();
        LoggerUtil.importent(getClass(), "Host Name: " + hostName);
        return hostName;
    }

    /**
     * @return
     */
    private int getDefaultThreadSleap() {
        LoggerUtil.importent(getClass(), "Getting THREAD SLEEP CONFIG VALUE");
        int defaultCount = SendImageJobConstants.DEFAULT_SEND_IMAGE_SCHEDULER_SLEEP_TIME;
        BaseDicomImPluginConfig config = configDao
                .getConfig(SendImageJobConstants.SEND_IMAGE_SCHEDULER_SLEEP_TIME_CONFIG_VALUE);

        String configValue = config.getConfigValue();
        if (!StringUtils.isEmpty(configValue)) {
            try {
                defaultCount = Integer.valueOf(configValue);
            } catch (NumberFormatException nfe) {
                defaultCount = SendImageJobConstants.DEFAULT_SEND_IMAGE_SCHEDULER_SLEEP_TIME;
            }
        }
        LoggerUtil.importent(getClass(), "THREAD SLEEP CONFIG VALUIS: " + defaultCount);
        return defaultCount;
    }

}
