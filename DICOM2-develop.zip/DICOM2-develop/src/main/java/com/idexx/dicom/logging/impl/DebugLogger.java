/**
 * 
 */
package com.idexx.dicom.logging.impl;


public class DebugLogger extends AbstractIdexxLogger {
    
    /**
     * @param cls
     */
    public DebugLogger(final Class<?> cls) {
        super(cls);
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.logging.impl.AbstractIdexxLogger#isEnabled()
     */
    @Override
    public final boolean isEnabled() {
        return this.getLogger().isDebugEnabled();
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.logging.impl.AbstractIdexxLogger#log(java.lang.String)
     */
    @Override
    public final void log(final String message) {
        this.getLogger().debug(message);
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.logging.impl.AbstractIdexxLogger#log(java.lang.String,
     * java.lang.Throwable)
     */
    @Override
    public final void log(final String message, final Throwable throwable) {
        this.getLogger().debug(message, throwable);
    }
    
}
