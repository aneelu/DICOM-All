/**
 * 
 */
package com.idexx.dicom.repo;

import com.idexx.dicom.domain.RequestDetails;
import java.lang.String;
import java.util.List;

/**
 * @author vvanjarana
 *
 */
public interface RequestDetailsRepository extends IdexxRepository<RequestDetails, String>{
	
	RequestDetails save(RequestDetails reqDetails);
	List<RequestDetails> findByStudyInstanceUID(String studyinstanceuid);
	
}
