/**
 * 
 */
package com.idexx.dicom.store;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;

import com.idexx.dicom.entities.store.DicomImageManagerMapping;
import com.idexx.logging.common.LoggerUtil;

/**
 * @author anarayana
 * 
 */
public class ImageTitleExtractor extends AbstractExtractor {

    public ImageTitleExtractor(final List<DicomImageManagerMapping> mapping) {
        super(mapping);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.store.ImageManagerAttributeExtractorFromDicomElement#
     * exractAtribute(org.dcm4che.data.Dataset)
     */
    @Override
    public final String exractAtribute(final Attributes dataset) {
        
        String imageTitle = StringUtils.EMPTY;
        String tagComments = this.getTagValueAsString(Tag.ImageComments, dataset);
        String bodyPartExamined = this.getTagValueAsString(Tag.BodyPartExamined, dataset);
        
        LoggerUtil.info(ImageTitleExtractor.class, "exractAtribute == tagComments: " + tagComments + ", bodyPartExamined: " + bodyPartExamined);
        if (!StringUtils.isEmpty(tagComments)) {
            imageTitle =  tagComments;
            LoggerUtil.info(ImageTitleExtractor.class, "tagComments imageTitle: ");
        } else if (!StringUtils.isEmpty(bodyPartExamined)) {
            imageTitle = bodyPartExamined;
            LoggerUtil.info(ImageTitleExtractor.class, "bodyPartExamined imageTitle: ");
        }
        
        return imageTitle;
    }

}
