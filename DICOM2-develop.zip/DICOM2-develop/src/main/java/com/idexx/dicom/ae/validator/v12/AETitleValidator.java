/**
 * 
 */
package com.idexx.dicom.ae.validator.v12;

import com.idexx.dicom.services.dto.v12.AETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * @author vkandagatla
 * 
 */
public interface AETitleValidator extends IdexxValidator {
    
    int validate(AETitleDTO dto) throws IdexxDicomAEConfigServiceException;
}
