/**
 * 
 */
package com.idexx.logging.common;

import org.apache.log4j.Level;

import com.idexx.logging.impl.DebugLogger;
import com.idexx.logging.impl.ErrorLogger;
import com.idexx.logging.impl.InfoLogger;
import com.idexx.logging.impl.TraceLogger;
import com.idexx.logging.impl.WarnLogger;
import com.idexx.logging.intf.IdexxLogger;
import com.idexx.logging.intf.IdexxLoggerFactory;

/**
 * @author vkandagatla
 * 
 */
public class IdexxLoggerFactoryImpl implements IdexxLoggerFactory {
    
    private IdexxLoggerFactoryImpl() {
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.logging.intf.IdexxLoggerFactory#createLogger(java.lang.Class,
     * org.apache.log4j.Level)
     */
    public final IdexxLogger createLogger(final Class<?> cls, final Level logLevel) {
        IdexxLogger logger = null;
        int level = logLevel.toInt();
        switch (level) {
            case Level.TRACE_INT:
                logger = new TraceLogger(cls);
                break;
            case Level.ERROR_INT:
                logger = new ErrorLogger(cls);
                break;
            case Level.INFO_INT:
                logger = new InfoLogger(cls);
                break;
            case Level.WARN_INT:
                logger = new WarnLogger(cls);
                break;
            default:
                logger = new DebugLogger(cls);
                break;
        }
        return logger;
    }
    
    private static IdexxLoggerFactory instance;
    static {
        instance = new IdexxLoggerFactoryImpl();
    }
    
    public static IdexxLoggerFactory getInstance() {
        return instance;
    }
}
