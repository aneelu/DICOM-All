/**
 * 
 */
package com.idexx.logging.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.util.StopWatch;

import com.idexx.logging.common.LoggerAspectUtil;

/**
 * @author vkandagatla
 * 
 */
@Aspect
public class LoggerAspect {
    
    /**
     * @param joinPoint
     * @throws Throwable
     */
    @Before("execution(* com.idexx..*.*(..)) "
            + "&& !within(LoggerAspect) "
            + "&& !within(com.idexx.logging.common.LoggerUtil)")
    public final void doLogBefore(final JoinPoint joinPoint) throws Throwable {
        LoggerAspectUtil.logMethodStart(joinPoint.getTarget().getClass(), joinPoint.getSignature().getName(), joinPoint.getArgs());
    }
    
    /**
     * @param joinPoint
     * @throws Throwable
     */
    @After("execution(* com.idexx..*.*(..)) "
            + "&& !within(LoggerAspect) ")
    public final void doLogAfter(final JoinPoint joinPoint) throws Throwable {
        LoggerAspectUtil.logMethodEnd(joinPoint.getTarget().getClass(), joinPoint.getSignature().getName(), joinPoint.getArgs());
    }
    
    /**
     * @param joinPoint
     * @return
     * @throws Throwable
     */
    @Around("execution(* com.idexx..*.*(..)) "
            + "&& !within(LoggerAspect) ")
    public final Object doLogAround(final ProceedingJoinPoint joinPoint) throws Throwable {
        final StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        
        final Object retVal = joinPoint.proceed();
        
        stopWatch.stop();
        
        LoggerAspectUtil.executionTime(joinPoint.getTarget().getClass(),
                joinPoint.getSignature().getName(), joinPoint.getArgs(), stopWatch.getTotalTimeMillis());
        return retVal;
    }
    
    @AfterThrowing(pointcut = "execution(* com.idexx..*.*(..)) && !within(LoggerAspect)", throwing = "exep")
    public final void doLogException(final JoinPoint joinPoint, final Throwable exep) throws Throwable {
        LoggerAspectUtil.logMethodException(joinPoint.getTarget().getClass(),
                joinPoint.getSignature().getName(), joinPoint.getArgs(), exep);
    }
}
