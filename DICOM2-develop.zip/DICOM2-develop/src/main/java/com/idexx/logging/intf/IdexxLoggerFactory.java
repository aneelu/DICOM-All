/**
 * 
 */
package com.idexx.logging.intf;

import org.apache.log4j.Level;

/**
 * @author vkandagatla
 *
 */
public interface IdexxLoggerFactory {
    IdexxLogger createLogger(Class<?> cls, Level logLevel);
}
