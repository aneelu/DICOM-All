/**
 * 
 */
package com.idexx.logging.impl;

import org.apache.log4j.Logger;

import com.idexx.logging.intf.IdexxLogger;

/**
 * @author vkandagatla
 * 
 */
public abstract class AbstractIdexxLogger implements IdexxLogger {
    private Logger logger;
    
    /**
     * 
     */
    public AbstractIdexxLogger(final Class<?> cls) {
        logger = Logger.getLogger(cls);
    }
    
    public final Logger getLogger() {
        return logger;
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.logging.intf.IdexxLogger#log(java.lang.Class,
     * java.lang.String)
     */
    public final void log(final Class<?> cls, final String message) {
        if (isEnabled()) {
            this.log(message);
        }
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.logging.intf.IdexxLogger#log(java.lang.Class,
     * java.lang.String, java.lang.Throwable)
     */
    public final void log(final Class<?> cls, final String message, final Throwable throwable) {
        if (isEnabled()) {
            this.log(message, throwable);
        }
    }
    
    /**
     * @return Return true if specific Logger is enabled for subclasses of this
     *         class
     */
    public abstract boolean isEnabled();
    
    /**
     * @param message
     * @return Logs specific message to this logger
     */
    public abstract void log(String message);
    
    /**
     * @param message
     * @param throwable
     * @return Logs specific message and exception to this logger
     */
    public abstract void log(String message, Throwable throwable);
}
