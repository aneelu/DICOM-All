/**
 * 
 */
package com.idexx.logging.impl;

/**
 * @author vkandagatla
 * 
 */
public class TraceLogger extends AbstractIdexxLogger {
    
    /**
     * @param cls
     */
    public TraceLogger(final Class<?> cls) {
        super(cls);
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.logging.intf.IdexxLogger#log(java.lang.Class,
     * java.lang.String)
     */
    public final void log(final String message) {
        this.getLogger().trace(message);
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.logging.intf.IdexxLogger#log(java.lang.Class,
     * java.lang.String, java.lang.Throwable)
     */
    public final void log(final String message, final Throwable throwable) {
        this.getLogger().trace(message, throwable);
    }
    
    /**
     * @return
     */
    public final boolean isEnabled() {
        return this.getLogger().isTraceEnabled();
    }
    
}
