/**
 * 
 */
package com.idexx.logging.impl;

import org.apache.log4j.Level;

/**
 * @author vkandagatla
 * 
 */
public class ErrorLogger extends AbstractIdexxLogger {
    
    /**
     * @param cls
     */
    public ErrorLogger(final Class<?> cls) {
        super(cls);
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.logging.impl.AbstractIdexxLogger#isEnabled()
     */
    @Override
    public final boolean isEnabled() {
        return this.getLogger().isEnabledFor(Level.ERROR);
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.logging.impl.AbstractIdexxLogger#log(java.lang.String)
     */
    @Override
    public final void log(final String message) {
        this.getLogger().error(message);
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.logging.impl.AbstractIdexxLogger#log(java.lang.String,
     * java.lang.Throwable)
     */
    @Override
    public final void log(final String message, final Throwable throwable) {
        this.getLogger().error(message, throwable);
    }
    
}
