/**
 * Idexx Logger Interface
 */
package com.idexx.logging.intf;

/**
 * @author vkandagatla
 * 
 */
public interface IdexxLogger {
    
    /**
     * @param cls
     * @param message
     * Logs given message for a class object
     */
    void log(Class<?> cls, String message);
    
    /**
     * @param cls
     * @param message
     * @param throwable
     * Logs given message and Exception for a class
     */
    void log(Class<?> cls, String message, Throwable throwable);
}
