package com.idexx.dicom.services.requestservice.dto;

import java.util.List;

import com.idexx.dicom.dto.MappingRuleDTO;

public class SaveMappingRuleRequestDTO {
	private List<MappingRuleDTO> mappingRules;
	private String apiKey;
	private String sapId;

	public List<MappingRuleDTO> getMappingRules() {
		return mappingRules;
	}
	public void setMappingRules(List<MappingRuleDTO> mappingRules) {
		this.mappingRules = mappingRules;
	}
	public String getApiKey() {
		return apiKey;
	}
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}
	public String getSapId() {
		return sapId;
	}
	public void setSapId(String sapId) {
		this.sapId = sapId;
	}
	
	
}
