/**
 * 
 */
package com.idexx.dicom.dao.store.impl;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.entities.IdexxDicomServiceFailureLog;
import com.idexx.dicom.dao.store.IdexxDicomAuthenticationDao;

/**
 * @author vkandagatla
 * 
 */

@Repository
public class IdexxDicomAuthenticationDaoImpl implements IdexxDicomAuthenticationDao {
    
    @PersistenceContext
    EntityManager entityManager;
    /**
     * @param entityManager
     */
    public IdexxDicomAuthenticationDaoImpl(final EntityManager entityManager) {
        this.entityManager = entityManager;
    }
    
    public IdexxDicomAuthenticationDaoImpl() {
        
    }
    
    private static final String AET_PARAM1 = "AETITLE";
    private static final String AET_PARAM2 = "INSTITUTE_NAME";
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.store.dao.IdexxDicomAuthenticationDao#getAeTitle(java
     * .lang.String)
     */
    @SuppressWarnings("unchecked")
    @Override
    @Transactional
    public final List<AETitle> getAeTitle(final String aeTitle) {
        List<AETitle> aeTitles = null;
        
        final String query = "SELECT AET FROM AETitle AET WHERE AET.aeTitle=:" + AET_PARAM1;
        aeTitles = (List<AETitle>) entityManager.createQuery(query).setParameter("AETITLE", aeTitle).getResultList();

        
        return aeTitles;
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.store.dao.IdexxDicomAuthenticationDao#getAeTitle(java
     * .lang.String, java.lang.String)
     */
    @SuppressWarnings("unchecked")
    @Override
    @Transactional
    public final List<AETitle> getAeTitle(final String aeTitle, final String instituteName) {
        List<AETitle> aeTitles = null;
        final String query = "SELECT AET FROM AETitle AET WHERE AET.aeTitle=:"
                + AET_PARAM1 + " AND AET.instituteName=:" + AET_PARAM2;
        
        aeTitles = entityManager.createQuery(query).
                setParameter(AET_PARAM1, aeTitle).
                setParameter(AET_PARAM2, instituteName).
                getResultList();
        
        return aeTitles;
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.store.dao.IdexxDicomAuthenticationDao#updateAETitle(com
     * .idexx.dicom.ae.entities.AETitle)
     */
    @Override
    @Transactional
    public final void updateAETitle(final AETitle aeTitle) {        
        entityManager.merge(aeTitle);                
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.store.dao.IdexxDicomAuthenticationDao#
     * logDicomServiceAuthorizationFailure
     * (com.idexx.dicom.store.entities.IdexxDicomServiceFailureLog)
     */
    @Override
    @Transactional
    public final void logDicomServiceAuthorizationFailure(final IdexxDicomServiceFailureLog log) {
        log.setFailedDateTime(new Timestamp(System.currentTimeMillis()));        
        entityManager.persist(log);        
        entityManager.flush();        
    }
    
}
