/**
 * 
 */
package com.idexx.dicom.dao.sendimage.impl;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.LockModeType;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.dao.sendimage.DicomJobDao;

/**
 * @author vkandagatla
 * 
 */
@Repository
public class DicomJobDaoImpl implements DicomJobDao {
    @PersistenceContext
    private EntityManager entityManager;

    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.sendimage.dao.DicomJobDao#getPendingJobs()
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<IdexxSendImageJob> getPendingJobs(String jobCount) {
        List<IdexxSendImageJob> jobs = entityManager.createQuery(PENDING_JOB_QUERY)
                .setParameter(PENDING_STATUS_PARAM_NAME, PENDING_JOB_STATUS)
                .setMaxResults(Integer.valueOf(jobCount))
                .setLockMode(LockModeType.PESSIMISTIC_WRITE).getResultList();
        return jobs;
    }

    /**
     * update all jobs whose status IN-PRORGESS to PENDING
     */    
    @Override
    public void updateAllInProgressJobs(String oldRecordsCount) {
	Timestamp dateCriteria = new Timestamp(System.currentTimeMillis() - (Long.valueOf(oldRecordsCount) * (60 * 60 * 1000L)));	
        List<IdexxSendImageJob> jobs = entityManager.createQuery(INPROGRESS_JOB_QUERY).setParameter(INTERVAL_PARAM, dateCriteria).getResultList();
        for (IdexxSendImageJob job : jobs) {
            job.setJobStatus(PENDING_JOB_STATUS);
            job.setScheduleTimestamp(new Timestamp(System.currentTimeMillis()));
            entityManager.persist(job);
        }
    }
    
    /* (non-Javadoc)
     * @see com.idexx.dicom.dao.sendimage.DicomJobDao#updateJobsToInProgressStatus(java.util.List)
     */
    @Override
    public void updateJobsToInProgressStatus(List<IdexxSendImageJob> jobs) {        
        for (IdexxSendImageJob job : jobs) {
            job.setJobStatus(INPROGRESS_JOB_STATUS);            
            job.setScheduleTimestamp(new Timestamp(System.currentTimeMillis()));
            entityManager.persist(job);
        }
    }
    
    
    /* (non-Javadoc)
     * @see com.idexx.dicom.dao.sendimage.DicomJobDao#updateJobsToInProgressStatus()
     */
    @Override
    public void updateJobsToInProgressStatus() {
        List<IdexxSendImageJob> jobs = entityManager.createQuery(PENDING_JOB_QUERY).setParameter(PENDING_STATUS_PARAM_NAME, PENDING_JOB_STATUS)
        .getResultList();
        for (IdexxSendImageJob job : jobs) {
            job.setJobStatus(INPROGRESS_JOB_STATUS);            
            job.setScheduleTimestamp(new Timestamp(System.currentTimeMillis()));
            entityManager.persist(job);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.sendimage.dao.DicomJobDao#getJobByJobId(java.lang.String)
     */
    @Override
    public IdexxSendImageJob getJobByJobId(final String jobId) {
        IdexxSendImageJob job = (IdexxSendImageJob) entityManager.createQuery(JOB_QUERY_BY_JOB_ID)
                .setParameter(JOB_ID_PARAM, jobId).getSingleResult();
        return job;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.sendimage.dao.DicomJobDao#updateJob(com.idexx.dicom.ae
     * .entities.IdexxSendImageJob)
     */
    @Override
    public void updateJob(final IdexxSendImageJob job) {
        Timestamp timeStamp = new Timestamp(System.currentTimeMillis());
        job.setUpdatedDateTime(timeStamp);
        entityManager.persist(job);
    }

}
