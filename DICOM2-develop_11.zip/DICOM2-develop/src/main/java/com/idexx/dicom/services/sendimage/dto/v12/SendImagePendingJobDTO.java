/**
 * 
 */
package com.idexx.dicom.services.sendimage.dto.v12;

/**
 * @author vkandagatla
 * 
 */
public class SendImagePendingJobDTO extends AbstractIdexxSendImageJobDTO {
    private String destinationAETitle;
    private String destinationHostName;
    private int destinationPort;
    private int retriesCount;
    private String downloadedIMFilePath;
    private String sendingAETitle;
    private String imageAssetId;
    
    /**
     * Default Constructor
     */
    public SendImagePendingJobDTO() {
    }
    
    /**
     * @param jobId
     * @param jobStatusCode
     * @param jobStatusDescription
     */
    public SendImagePendingJobDTO(final String jobId,
            final String jobStatusCode,
            final String jobStatusDescription) {
        super(jobId, jobStatusCode, jobStatusDescription);
    }
    
    /**
     * @return the destinationAETitle
     */
    public final String getDestinationAETitle() {
        return destinationAETitle;
    }
    
    /**
     * @param destinationAETitle
     *            the destinationAETitle to set
     */
    public final void setDestinationAETitle(final String destinationAETitle) {
        this.destinationAETitle = destinationAETitle;
    }
    
    /**
     * @return the destinationHostName
     */
    public final String getDestinationHostName() {
        return destinationHostName;
    }
    
    /**
     * @param destinationHostName
     *            the destinationHostName to set
     */
    public final void setDestinationHostName(final String destinationHostName) {
        this.destinationHostName = destinationHostName;
    }
    
    /**
     * @return the destinationPort
     */
    public final int getDestinationPort() {
        return destinationPort;
    }
    
    /**
     * @param destinationPort
     *            the destinationPort to set
     */
    public final void setDestinationPort(final int destinationPort) {
        this.destinationPort = destinationPort;
    }
    
    /**
     * @return the retriesCount
     */
    public final int getRetriesCount() {
        return retriesCount;
    }
    
    /**
     * @param retriesCount
     *            the retriesCount to set
     */
    public final void setRetriesCount(final int retriesCount) {
        this.retriesCount = retriesCount;
    }
    
    /**
     * @return the downloadedIMFilePath
     */
    public final String getDownloadedIMFilePath() {
        return downloadedIMFilePath;
    }
    
    /**
     * @param downloadedIMFilePath
     *            the downloadedIMFilePath to set
     */
    public final void setDownloadedIMFilePath(final String downloadedIMFilePath) {
        this.downloadedIMFilePath = downloadedIMFilePath;
    }
    
    /**
     * @return the sendingAETitle
     */
    public final String getSendingAETitle() {
        return sendingAETitle;
    }
    
    /**
     * @param sendingAETitle
     *            the sendingAETitle to set
     */
    public final void setSendingAETitle(final String sendingAETitle) {
        this.sendingAETitle = sendingAETitle;
    }
    
    /**
     * @return the imageAssetId
     */
    public final String getImageAssetId() {
        return imageAssetId;
    }
    
    /**
     * @param imageAssetId
     *            the imageAssetId to set
     */
    public final void setImageAssetId(final String imageAssetId) {
        this.imageAssetId = imageAssetId;
    }
    
}
