/**
 * 
 */
package com.idexx.dicom.sendimage.impl;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.util.StringUtils;

import com.idexx.dicom.DicomObjectBuilder;
import com.idexx.dicom.ae.entities.BaseDicomImPluginConfig;
import com.idexx.dicom.conversion.ImagePropertiesProvider;
import com.idexx.dicom.conversion.impl.DicomObjectBuilderImpl;
import com.idexx.dicom.conversion.impl.ImageProperties;
import com.idexx.dicom.conversion.impl.ImagePropertiesProviderImpl;
import com.idexx.dicom.dao.ws.DicomConfigDao;
import com.idexx.dicom.sendimage.ImagePresignedUrlProvider;
import com.idexx.dicom.sendimage.SendImage;
import com.idexx.dicom.sendimage.SendImageJobConstants;
import com.idexx.dicom.sendimage.SendImageJobUpdateService;
import com.idexx.dicom.sendimage.TimedImageDownloader;
import com.idexx.dicom.sendimage.exceptions.SendRetryCountExceedException;
import com.idexx.dicom.services.IdexxDicomServiceConstants;
import com.idexx.dicom.services.sendimage.dto.SendImagePendingJobDTO;
import com.idexx.dicom.util.CommonUtil;
import com.idexx.imaging.imagemanager.soap.ImageDTO;
import com.idexx.imaging.imagemanager.soap.PatientDTO;
import com.idexx.imaging.imagemanager.soap.SeriesDTO;
import com.idexx.imaging.imagemanager.soap.StudyDTO;

/**
 * The Class SendImageProcessorImpl.
 *
 * @author vkandagatla
 */
public class SendImageProcessorImpl implements Runnable {

	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(SendImageProcessorImpl.class);

	/** The job update service. */
	private SendImageJobUpdateService jobUpdateService;

	/** The presigned url provider. */
	private ImagePresignedUrlProvider presignedUrlProvider;

	/** The image downloader. */
	private TimedImageDownloader imageDownloader;

	/** The config dao. */
	private DicomConfigDao configDao;

	/** The default retry count. */
	private int defaultRetryCount = SendImageJobConstants.DEFAULT_JOB_RETRY_COUNT;

	/** The send image service. */
	private SendImage sendImageService;

	/** The job. */
	private SendImagePendingJobDTO job;

	/** The patient dto. */
	private PatientDTO patientDTO;

	/** The study dto. */
	private StudyDTO studyDTO;

	/** The series dto. */
	private SeriesDTO seriesDTO;

	/** The image dto. */
	private ImageDTO imageDTO;

	/** The presigned url. */
	private String presignedUrl;

	/** The file name extension. */
	private String fileNameExtension = IdexxDicomServiceConstants.DICOM_FILE_EXTENSION1;

	/** The send image base dir. */
	private String sendImageBaseDir;

	/**
	 * Default Processor.
	 *
	 * @param job
	 *            the job
	 * @param jobUpdateService
	 *            the job update service
	 * @param presignedUrlProvider
	 *            the presigned url provider
	 * @param imageDownloader
	 *            the image downloader
	 * @param configDao
	 *            the config dao
	 * @param sendImageService
	 *            the send image service
	 */
	public SendImageProcessorImpl(final SendImagePendingJobDTO job, final SendImageJobUpdateService jobUpdateService,
			final ImagePresignedUrlProvider presignedUrlProvider, final TimedImageDownloader imageDownloader,
			final DicomConfigDao configDao, final SendImage sendImageService) {
		this.sendImageService = sendImageService;
		this.configDao = configDao;
		this.imageDownloader = imageDownloader;
		this.presignedUrlProvider = presignedUrlProvider;
		this.job = job;
		this.jobUpdateService = jobUpdateService;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public final void run() {
		try {
			this.process();
		} catch (SendRetryCountExceedException e1) {
			LOG.error(e1.getLocalizedMessage(), e1);
		} catch (SendImageException e1) {
			LOG.error(e1.getLocalizedMessage(), e1);
		} catch (InterruptedException e) {
			LOG.error(e.getLocalizedMessage(), e);
		} catch (IOException e) {
			LOG.error(e.getLocalizedMessage(), e);
		}

	}

	/**
	 * Process.
	 *
	 * @throws SendRetryCountExceedException
	 *             the send retry count exceed exception
	 * @throws SendImageException
	 *             the send image exception
	 * @throws InterruptedException
	 *             the interrupted exception
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public final void process()
			throws SendRetryCountExceedException, SendImageException, InterruptedException, IOException {
		LOG.info("Started JOB PROCESSING...");
		this.sendImageBaseDir = this.getSendImageBaseDir();
		// Step 1: get configured retry count
		this.defaultRetryCount = this.getRetryCount();
		// Step 2: Is the count exceeded?
		if (this.isRetryCountExceeded(job.getRetriesCount())) {
			LOG.info("RETRY COUNT EXCEEDED");
			this.updateJobStatus(job.getJobId(), job.getRetriesCount(), "RETRY COUNT EXCEEDED");
			throw new SendRetryCountExceedException(
					"Retry Count Exceed for job:" + job.getJobId() + ":: Retry count is: " + job.getRetriesCount());
		}
		// Step 3: increase job's retry count
		LOG.info("INCREASING RETRY COUNT");
		this.jobUpdateService.increaseRetryCount(job.getJobId());
		// Step 4: update job to progress status
		this.updateInProgressStatus(job.getJobId(), SendImageJobConstants.JOB_STATUS_DESC_PROGRESS);
		if (!isFileDownloaded(job)) {

			// Step 5: get presigned url for image with image asset id

			try {

				getPatientPropertiesForPresignedURL();
			} catch (Exception exp) {
				this.updateJobStatus(job.getJobId(), job.getRetriesCount(), exp.getLocalizedMessage());
				throw new SendImageException("Unable to get Image Presigned URL for job:" + job.getJobId());
			}
			// Step 6: update presigned url to db
			LOG.info("UPDATING IMAGE PRESIGNED URL to DB");
			this.jobUpdateService.updateImageUrl(job.getJobId(), presignedUrl);
			// Step 7: download Image with presigned URL
			File file = null;
			try {
				file = this.downloadImage();
			} catch (Exception exp) {
				this.updateJobStatus(job.getJobId(), job.getRetriesCount(), exp.getLocalizedMessage());
				throw new SendImageException("Unable to Download URL for job:" + job.getJobId());
			}
			// Step 8: update image file path to job
			this.updateImageFilePathToJob(file);
		}
		// Step 9: send image
		this.sendImage(job);
	}

	/**
	 * Update image file path to job.
	 *
	 * @param file
	 *            Step 8
	 */
	private void updateImageFilePathToJob(final File file) {
		if (null != file) {
			LOG.info("Updating Image File Path to DB ");
			this.jobUpdateService.updateImageFilePath(job.getJobId(), file.getAbsolutePath());
			job.setDownloadedIMFilePath(file.getAbsolutePath());
		}
	}

	/**
	 * Download image.
	 *
	 * @return the file
	 * @throws SendImageException
	 *             the send image exception
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	private File downloadImage() throws SendImageException, IOException {
		File file = null;
		LOG.info("DOWNLOADING IMAGE for " + presignedUrl);
		File tmpFile = this.imageDownloader.downloadImage(presignedUrl, fileNameExtension, sendImageBaseDir);
		LOG.info("Downloaded file: " + tmpFile.getAbsolutePath());
		String imageFileType = CommonUtil.removeDotCharInFileExtension(imageDTO.getFileType());
		LOG.info("Image File Type: " + imageFileType);
		if (!IdexxDicomServiceConstants.DICOM_FILE_EXTENSION1.equalsIgnoreCase(imageFileType)) {
			LOG.info("Converting Downloaded File");
			ImageProperties properties = this.getImageProperties(tmpFile.getAbsolutePath(),
					CommonUtil.getFileNameExtension(imageDTO.getFileType(), "jpg"));
			File convertedFile = this.createDcmFile(tmpFile.getName());
			DicomObjectBuilder dcmObjectBuilder = new DicomObjectBuilderImpl(properties, patientDTO, studyDTO,
					seriesDTO, imageDTO, convertedFile);
			dcmObjectBuilder.build();
			LOG.info("Converted Downloaded file: " + convertedFile.getAbsolutePath());
			file = convertedFile;
		} else {
			file = tmpFile;
		}
		return file;
	}

	/**
	 * Gets the patient properties for presigned url.
	 *
	 * @return the patient properties for presigned url
	 * @throws SendImageException
	 *             the send image exception
	 */
	private void getPatientPropertiesForPresignedURL() throws SendImageException {
		LOG.info("Getting PRESIGNED URL for JOB: " + job.getImageAssetId());
		LOG.info("Getting patientDTO");
		patientDTO = this.presignedUrlProvider.getPresignedUrl(job.getImageAssetId());
		if (null == patientDTO) {
			throw new SendImageException("Unable to get Presigned URL for JOB: " + job.getJobId() + " for asset id:"
					+ job.getImageAssetId());
		}

		List<StudyDTO> studies = patientDTO.getStudies();
		// Get a Study
		if (null != studies && !studies.isEmpty()) {
			LOG.info("Getting study");
			studyDTO = studies.get(0);
		} else {
			throw new SendImageException("Unable to get Patient Details for JOB: " + job.getJobId() + " for asset id:"
					+ job.getImageAssetId());
		}
		// get Series
		List<SeriesDTO> seriesList = null;
		if (null != studyDTO) {
			LOG.info("Getting Serieses");
			seriesList = studyDTO.getSeries();
		} else {
			throw new SendImageException("Unable to get Study Details for JOB: " + job.getJobId() + " for asset id:"
					+ job.getImageAssetId());
		}
		if (null != seriesList && !seriesList.isEmpty()) {
			LOG.info("Getting seriesDTO");
			seriesDTO = seriesList.get(0);
		} else {
			throw new SendImageException("Unable to get Series Details for JOB: " + job.getJobId() + " for asset id:"
					+ job.getImageAssetId());
		}
		// get ImageDto
		List<ImageDTO> imageDTOs = null;
		if (null != seriesDTO) {
			imageDTOs = seriesDTO.getImages();
		} else {
			throw new SendImageException("Unable to get Series Details for JOB: " + job.getJobId() + " for asset id:"
					+ job.getImageAssetId());
		}
		if (null != imageDTOs && !imageDTOs.isEmpty()) {
			imageDTO = imageDTOs.get(0);
		}
		// Get Image URL
		if (null != imageDTO) {
			presignedUrl = imageDTO.getPreSignedUrl();
			LOG.info("Image File Type: " + imageDTO.getFileType());
			fileNameExtension = CommonUtil.getFileNameExtension(imageDTO.getFileType(), fileNameExtension);
		} else {
			throw new SendImageException("Unable to get Image Details for JOB: " + job.getJobId() + " for asset id:"
					+ job.getImageAssetId());
		}
		LOG.info("PRESIGNED URL: " + presignedUrl);
		if (StringUtils.isEmpty(presignedUrl)) {
			throw new SendImageException("Unable to get Presigned URL for JOB: " + job.getJobId() + " for asset id:"
					+ job.getImageAssetId());
		}
	}

	/**
	 * Creates the dcm file.
	 *
	 * @param imageFileName
	 *            the image file name
	 * @return the file
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	private File createDcmFile(final String imageFileName) throws IOException {

		String dir = this.sendImageBaseDir + "/" + IdexxDicomServiceConstants.CONVERTED_IMAGES_DIR;
		CommonUtil.createDir(dir);

		File dcmFile = CommonUtil.createFile(dir, CommonUtil.getFileNameWithOutExtension(imageFileName) + "."
				+ IdexxDicomServiceConstants.DICOM_FILE_EXTENSION1);
		return dcmFile;
	}

	/**
	 * Gets the image properties.
	 *
	 * @param imageFile
	 *            the image file
	 * @param imageFileType
	 *            the image file type
	 * @return the image properties
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	private ImageProperties getImageProperties(final String imageFile, final String imageFileType) throws IOException {
		ImagePropertiesProvider provider = new ImagePropertiesProviderImpl(imageFile, imageFileType);
		return provider.getImageProperties();
	}

	/**
	 * Checks if is file downloaded.
	 *
	 * @param job
	 *            the job
	 * @return If the DownloadedIMFilePath is not empty then the file is
	 *         downloaed
	 */
	private boolean isFileDownloaded(final SendImagePendingJobDTO job) {
		return !StringUtils.isEmpty(job.getDownloadedIMFilePath());
	}

	/**
	 * Send image.
	 *
	 * @param job
	 *            the job
	 * @throws SendImageException
	 *             the send image exception
	 * @throws InterruptedException
	 *             the interrupted exception
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	private void sendImage(final SendImagePendingJobDTO job)
			throws SendImageException, InterruptedException, IOException {
		try {
			LOG.info("Sending Image: " + job.getDownloadedIMFilePath());
			this.sendImageService.sendImage(job);
			LOG.info("Updating JOBS Status to Success for JOB:" + job.getJobId());
			this.jobUpdateService.updateJobStatusToSuccess(job.getJobId());
		} catch (SendImageException exp) {
			this.updateJobStatus(job.getJobId(), job.getRetriesCount(), exp.getMessage());
			throw new SendImageException("Unable to Send Image for job:" + job.getJobId());
		}
	}

	/**
	 * Update job status.
	 *
	 * @param jobId
	 *            the job id
	 * @param retryCount
	 *            the retry count
	 * @param message
	 *            the message
	 */
	private void updateJobStatus(final String jobId, final int retryCount, final String message) {
		if (this.canRetryTheJob(retryCount)) {
			this.jobUpdateService.updateJobStatusToPending(jobId, message);
		} else {
			this.jobUpdateService.updateJobStatusToFailed(jobId);
		}
	}

	/**
	 * Can retry the job.
	 *
	 * @param retryCount
	 *            the retry count
	 * @return true, if successful
	 */
	private boolean canRetryTheJob(final int retryCount) {
		return retryCount + 1 <= this.defaultRetryCount;
	}

	/**
	 * Checks if is retry count exceeded.
	 *
	 * @param jobRetryCount
	 *            the job retry count
	 * @return true, if is retry count exceeded
	 */
	private boolean isRetryCountExceeded(final int jobRetryCount) {
		return jobRetryCount >= defaultRetryCount;

	}

	/**
	 * Gets the retry count.
	 *
	 * @return the retry count
	 */
	private int getRetryCount() {
		LOG.info("Getting RETRY COUNT CONFIG VALUE");
		int defaultCount = SendImageJobConstants.DEFAULT_JOB_RETRY_COUNT;
		BaseDicomImPluginConfig config = configDao.getConfig(SendImageJobConstants.JOB_RETRY_COUNT_CONFIG_VALUE);

		String configValue = config.getConfigValue();
		if (!StringUtils.isEmpty(configValue)) {
			try {
				defaultCount = Integer.valueOf(configValue);
			} catch (NumberFormatException nfe) {
				defaultCount = SendImageJobConstants.DEFAULT_JOB_RETRY_COUNT;
			}
		}
		LOG.info("RETRY COUNT CONFIG VALUE IS: " + defaultCount);
		return defaultCount;
	}

	/**
	 * Gets the send image base dir.
	 *
	 * @return the send image base dir
	 */
	private String getSendImageBaseDir() {
		LOG.info("Getting Send Image Base CONFIG VALUE");
		String baseDir = SendImageJobConstants.SEND_IMAGE_DEFAULT_BASE_DIR;

		BaseDicomImPluginConfig config = configDao.getConfig(SendImageJobConstants.SEND_IMAGE_BASE_DIR_CONFIG_NAME);
		String configValue = config.getConfigValue();
		if (!StringUtils.isEmpty(configValue)) {
			baseDir = configValue;
		}
		return baseDir;
	}

	/**
	 * Update in progress status.
	 *
	 * @param jobId
	 *            the job id
	 * @param reason
	 *            the reason
	 */
	private void updateInProgressStatus(final String jobId, final String reason) {
		LOG.info("UPDATING IN-PROGRESS STATUS");
		this.jobUpdateService.updateJobStatusToInProgress(jobId, reason);
	}

}
