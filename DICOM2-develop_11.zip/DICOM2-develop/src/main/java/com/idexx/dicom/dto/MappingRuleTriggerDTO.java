package com.idexx.dicom.dto;

import java.io.Serializable;

public class MappingRuleTriggerDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6077463135711399907L;
	private String id;
	private String tagKey;
	private String tagValue;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTagValue() {
		return tagValue;
	}

	public void setTagValue(String tagValue) {
		this.tagValue = tagValue;
	}

	public String getTagKey() {
		return tagKey;
	}

	public void setTagKey(String tagKey) {
		this.tagKey = tagKey;
	}

}
