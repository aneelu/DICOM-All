/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dicom.util;

import static org.quartz.CronScheduleBuilder.cronSchedule;
import static org.quartz.JobBuilder.newJob;
import static org.quartz.TriggerBuilder.newTrigger;

import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;

import org.apache.log4j.Logger;
import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.TriggerKey;
import org.quartz.ee.servlet.QuartzInitializerListener;
import org.quartz.impl.StdSchedulerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.entities.BaseDicomImPluginConfig;
import com.idexx.dicom.dao.ws.DicomConfigDao;
import com.idexx.dicom.sendimage.SendImageJobConstants;

/**
 * <pre>
 * Description of the class
 * </pre>
 * 
 * @author vvanjarana
 * @version 1.3
 */
@Service
public class CleanTempFiles extends QuartzInitializerListener {

    private static Logger LOG = Logger.getLogger(CleanTempFiles.class);

    private static final String JOB_NAME = "CleanTempJob";
    private static final String TRIGGER_NAME = "CleanTempTrigger";
    private static final String GROUP_NAME = "CleanTempJobGroup";
    
    private JobKey jobKey;
    private TriggerKey triggerKey;
    
    @Autowired
    private DicomConfigDao configDao;

    @Override
    public void contextInitialized(ServletContextEvent sce) {
	super.contextInitialized(sce);
	ServletContext ctx = sce.getServletContext();
	jobKey = new JobKey(JOB_NAME, GROUP_NAME);
	triggerKey = new TriggerKey(TRIGGER_NAME, GROUP_NAME);

	try {
	    StdSchedulerFactory factory = (StdSchedulerFactory) ctx
		    .getAttribute(QuartzInitializerListener.QUARTZ_FACTORY_KEY);
	    Scheduler scheduler = factory.getScheduler();
	    LOG.info("Got Scheduler" + scheduler.getSchedulerName());
	    JobDetail job = newJob(CleanJob.class).withIdentity(jobKey).build();
	    LOG.info("Created JOB Detail: " + job.getDescription());

	    String triggerExpression = this.getFrequency();
	    CronTrigger trigger = newTrigger().withIdentity(triggerKey).withSchedule(cronSchedule(triggerExpression))
		    .build();
	    LOG.info("Created Cron Trigger: " + triggerExpression);

	    Date ft = scheduler.scheduleJob(job, trigger);
	    LOG.info(job.getKey() + " has scheduled to run at: " + ft + " and repeat based on expression: "
		    + trigger.getCronExpression());

	    LOG.info("Starting Scheduler");
	    scheduler.start();

	} catch (SchedulerException sexp) {
	    LOG.error("SchedulerException is " + sexp);
	}
    }

    /**
     * @return
     */  
    private String getFrequency() {
	BaseDicomImPluginConfig config = configDao.getConfig(SendImageJobConstants.CLEAN_TEMP_CRON_EXPRESSION);
	String expression = SendImageJobConstants.DEFAULT_CLEAN_TEMP_CRON_EXPRESSION;
	if (null != config && !StringUtils.isEmpty(config.getConfigValue())) {
	    expression = config.getConfigValue();
	}
	LOG.info("Scheduler Frequency: " + expression);
	return expression;
    }
}
