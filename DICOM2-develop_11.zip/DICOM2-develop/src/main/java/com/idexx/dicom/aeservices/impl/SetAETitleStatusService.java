/**
 * 
 */
package com.idexx.dicom.aeservices.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.validator.AETitleValidator;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.dto.AETitleDTO;
import com.idexx.dicom.services.dto.SetEnabledAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * @author rmalla
 * 
 */
@Service("setAETitleStatusService")
public class SetAETitleStatusService extends AbstractAEServiceImpl {
	private static final Logger LOG = Logger.getLogger(SetAETitleStatusService.class);
	
    @Autowired
    @Qualifier("deleteAETitleValidator")
    private AETitleValidator validator;
    
    @Autowired
    private AETitleDao aeTitleDao;
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.aeservices.impl.AbstractAEServiceImpl#validate(com.idexx
     * .dicom.services.dto.IdexxDicomApplicationEntityDTO)
     */
    @Override
    @Transactional
    public final int validate(final AETitleDTO dto) throws IdexxDicomAEConfigServiceException {
        return validator.validate(dto);
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.aeservices.impl.AbstractAEServiceImpl#doService(com.idexx
     * .dicom.services.dto.IdexxDicomApplicationEntityDTO)
     */
    @Override
    @Transactional
    public final int doService(final AETitleDTO dto) throws IdexxDicomAEConfigServiceException {
        
        SetEnabledAETitleDTO setEnabledAETitleDTO = (SetEnabledAETitleDTO) dto;
        
        AETitle aeTitle = null;
        List<AETitle> registeredAEList = null;
        try {
            registeredAEList = aeTitleDao.findAETitle(setEnabledAETitleDTO.getAeTitle());
            
            if ((null != registeredAEList) && (!registeredAEList.isEmpty())) {
                aeTitle = registeredAEList.get(0);
                if (!aeTitle.isIdentifiedByaeTitleOnly()) {
                    aeTitle = null;
                    registeredAEList = aeTitleDao.findAETitle(setEnabledAETitleDTO.getAeTitle(), setEnabledAETitleDTO.getInstituteName());
                    if ((null != registeredAEList) && (!registeredAEList.isEmpty())) {
                        aeTitle = registeredAEList.get(0);
                    }
                }
                
            }
            if (null != aeTitle) {
                aeTitle.setEnabled(setEnabledAETitleDTO.isEnabled());
                aeTitleDao.updateAETitle(aeTitle);
            }
        } catch (IdexxDicomAEConfigDbException e) {
        	LOG.error("Exception in doService"+ e);
            throw new IdexxDicomAEConfigServiceException(GENERAL_DB_FAILURE, GENERAL_DB_FAILURE);
        }
        return 1;
    }
    
    
}
