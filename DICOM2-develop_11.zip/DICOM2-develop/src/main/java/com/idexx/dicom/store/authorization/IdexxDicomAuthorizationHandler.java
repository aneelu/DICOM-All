/**
 * 
 */
package com.idexx.dicom.store.authorization;

/**
 * @author vkandagatla
 * 
 */
public interface IdexxDicomAuthorizationHandler {
    IdexxAuthorization performaAuthorization(String aeTitle, String instituteName, String ip, String hostName,
            String manufacturer, String manufacturerModelName, String modality, String patientName, String respPerName);
}
