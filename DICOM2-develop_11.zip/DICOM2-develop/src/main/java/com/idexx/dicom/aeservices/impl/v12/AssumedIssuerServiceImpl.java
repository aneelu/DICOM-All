/**
 * 
 */
package com.idexx.dicom.aeservices.impl.v12;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.entities.AssumedIssuer;
import com.idexx.dicom.aeservices.v12.AssumedIssuerService;
import com.idexx.dicom.aeservices.v12.IdexxDicomWSAthorizationService;
import com.idexx.dicom.dao.ws.AssumedIssuerDao;
import com.idexx.dicom.services.dto.v12.AssumedIssuerEntityDTO;
import com.idexx.dicom.services.dto.v12.ReadAssumedIssuerDTO;
import com.idexx.dicom.services.dto.v12.SetAssumedIssuerDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;


@Service("assumedIssuerServiceV12")
public class AssumedIssuerServiceImpl implements AssumedIssuerService {
    
	private static final Logger LOG = Logger.getLogger(AssumedIssuerServiceImpl.class);
	
    String MISSING_MANDATORY_SAP_ID = "ERR_argument_missing_mandatory_sapId";
    String RECORD_NOT_FOUND = "ERR_no_record_exists_for_sapId";
    
    @Autowired
    private IdexxDicomWSAthorizationService idexxDicomWsAuthorizeService;

    @Autowired
    private AssumedIssuerDao assumedIssuerDao;

    @Transactional
    @Override
    public final String setAssumedIssuer(final SetAssumedIssuerDTO dto) throws IdexxDicomAEConfigServiceException {
        String response = "Failure";
        boolean authorized = false;
        authorized = isAPIKeyValid(dto.getApiKey());
        if (authorized) {
            authorized = isValidSapId(dto.getSapId());
        }
        if (authorized) {
            response = saveAssumedIssuer(dto);
        }
        return response;
    }

    private String saveAssumedIssuer(final SetAssumedIssuerDTO dto) {
        LOG.info("SAP_ID " + dto.getSapId());
        LOG.info("ASSUMED_ISSUER_VALUE " + dto.getAssumedIssuerValue());
        AssumedIssuer assumedIssuer = null;
        List<AssumedIssuer> assumedIssuerList = getAssumedIssuer(dto.getSapId());
        if (null != assumedIssuerList && !assumedIssuerList.isEmpty()) {
            assumedIssuer = assumedIssuerList.get(0);
            assumedIssuer.setAssumedIssuerValue(dto.getAssumedIssuerValue());
            assumedIssuerDao.updateAssumedIssuer(assumedIssuer);
        } else {
            assumedIssuer = new AssumedIssuer();
            assumedIssuer.setSapId(dto.getSapId());
            assumedIssuer.setAssumedIssuerValue(dto.getAssumedIssuerValue());
            assumedIssuer.setCreatedDateTime(new Timestamp(new Date().getTime()));
            assumedIssuer.setLastUpdatedDateTime(new Timestamp(new Date().getTime()));
            assumedIssuerDao.createAssumedIssuer(assumedIssuer);
        }
        return "Success";
    }

    @Override
    public AssumedIssuerEntityDTO readAssumedIssuer(ReadAssumedIssuerDTO dto) throws IdexxDicomAEConfigServiceException {
        AssumedIssuerEntityDTO aieDto = null;
        boolean authorized = false;
        authorized = isAPIKeyValid(dto.getApiKey());
        if (authorized) {
            authorized = isValidSapId(dto.getSapId());
        }
        if (authorized) {
            List<AssumedIssuer> assumedIssuerList = getAssumedIssuer(dto.getSapId());
            if (null != assumedIssuerList && !assumedIssuerList.isEmpty()) {
                AssumedIssuer assumedIssuer = assumedIssuerList.get(0);
                if (assumedIssuer != null) {
                    aieDto = new AssumedIssuerEntityDTO();
                    aieDto.setAssumedIssuerValue(assumedIssuer.getAssumedIssuerValue());
                    aieDto.setCreatedDateTime(assumedIssuer.getCreatedDateTime().toString());
                    aieDto.setLastUpdatedDateTime(assumedIssuer.getLastUpdatedDateTime().toString());
                    aieDto.setSapId(assumedIssuer.getSapId());
                } else {
                    aieDto = createNullAssumedIssuerDTO(dto);
                }
            } else {
                aieDto = createNullAssumedIssuerDTO(dto);
            }
        }
        return aieDto;
    }

    private AssumedIssuerEntityDTO createNullAssumedIssuerDTO(ReadAssumedIssuerDTO dto) {
        AssumedIssuerEntityDTO aieDto = new AssumedIssuerEntityDTO();
        aieDto.setAssumedIssuerValue(null);
        aieDto.setSapId(dto.getSapId());
        return aieDto;
    }

    private List<AssumedIssuer> getAssumedIssuer(final String sapId) {
        List<AssumedIssuer> assumedIssuerList = assumedIssuerDao.findAssumedIssuerBySapId(sapId);
        return assumedIssuerList;
    }

    @Override
    public final boolean isAPIKeyValid(final String apiKey) throws IdexxDicomAEConfigServiceException {
        return idexxDicomWsAuthorizeService.authorize(apiKey);
    }

    @Override
    public boolean isValidSapId(final String sapId) throws IdexxDicomAEConfigServiceException {
        if (StringUtils.isEmpty(sapId)) {
            throw new IdexxDicomAEConfigServiceException(MISSING_MANDATORY_SAP_ID, MISSING_MANDATORY_SAP_ID);
        }
        return true;
    }
}
