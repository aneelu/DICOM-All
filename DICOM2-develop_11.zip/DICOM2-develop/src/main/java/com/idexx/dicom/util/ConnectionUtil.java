/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dicom.util;

import org.dcm4che3.net.Connection;
import org.dcm4che3.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.idexx.dicom.dao.store.SystemConfigDao;
import com.idexx.dicom.services.IdexxDicomServiceConstants;
/**
 * <pre>
 * Description of the class
 * </pre>
 * 
 * @author vvanjarana
 * @version 1.3
 */
@Service
public class ConnectionUtil {
    
    @Autowired
    SystemConfigDao systemConfigDao;

    public void addTimeouts(Connection conn) {
	
	String acceptTimeout = systemConfigDao.getConfigValueByConfigName(IdexxDicomServiceConstants.DEFAULT_ACCEPT_TIMEOUT);
	String connectionTimeout = systemConfigDao.getConfigValueByConfigName(IdexxDicomServiceConstants.DEFAULT_CONNECTION_TIMEOUT);
	String releaseTimeout = systemConfigDao.getConfigValueByConfigName(IdexxDicomServiceConstants.DEFAULT_RELEASE_TIMEOUT);
	String requestTimeout = systemConfigDao.getConfigValueByConfigName(IdexxDicomServiceConstants.DEFAULT_REQUEST_TIMEOUT);
	String responseTimeout = systemConfigDao.getConfigValueByConfigName(IdexxDicomServiceConstants.DEFAULT_RESPONSE_TIMEOUT);
	String retrieveTimeout = systemConfigDao.getConfigValueByConfigName(IdexxDicomServiceConstants.DEFAULT_RETRIEVE_TIMEOUT);
	
	conn.setAcceptTimeout(StringUtils.parseIS(acceptTimeout));
	conn.setConnectTimeout(StringUtils.parseIS(connectionTimeout));
	conn.setReleaseTimeout(StringUtils.parseIS(releaseTimeout));
	conn.setRequestTimeout(StringUtils.parseIS(requestTimeout));
	conn.setResponseTimeout(StringUtils.parseIS(responseTimeout));
	conn.setRetrieveTimeout(StringUtils.parseIS(retrieveTimeout));	
	
    }    
}
