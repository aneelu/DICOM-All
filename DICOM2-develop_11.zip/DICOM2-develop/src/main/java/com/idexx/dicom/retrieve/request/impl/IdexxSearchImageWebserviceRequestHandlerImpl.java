/*
 *  Class implements C-Get functionality where it calls DVM Insight Request tokens webservice for Image AssetID
 *  Call Asset Manager Search Image webservice call for Image URl
 *  Downloads Images from Cloud 
 */
package com.idexx.dicom.retrieve.request.impl;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.dcm4che3.data.Attributes;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.idexx.dicom.ImageManagerConfigurationProvider;
import com.idexx.dicom.ImageManagerStoreServiceProvider;
import com.idexx.dicom.ImageManagerStoreServiceProviderImpl;
import com.idexx.dicom.query.request.QueryWebserviceRequestHandler;
import com.idexx.dicom.query.soap.ArrayOfstring;
import com.idexx.dicom.retrieve.download.DownloadImageFromS3;
import com.idexx.dicom.retrieve.request.IdexxSearchImageWebserviceRequestHandler;
import com.idexx.dicom.services.IdexxDicomServiceConstants;
import com.idexx.imaging.imagemanager.soap.IDEXXImageManagerServices;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;
import com.idexx.imaging.imagemanager.soap.ImageDTO;
import com.idexx.imaging.imagemanager.soap.PatientDTO;
import com.idexx.imaging.imagemanager.soap.SearchRequestDTO;
import com.idexx.imaging.imagemanager.soap.SeriesDTO;
import com.idexx.imaging.imagemanager.soap.StudyDTO;
/**
 * 
 * @author apinninti
 *
 */
@Component
public class IdexxSearchImageWebserviceRequestHandlerImpl implements IdexxSearchImageWebserviceRequestHandler, InitializingBean {
    
    private static final Logger LOG = Logger.getLogger("IdexxSearchImageWebserviceRequestHandlerImpl");
    private String apiKey;
    private String baseDir; 
    private String fileExtension = ".dcm";
    private String componentName = "retrieve";

    /*
     * Dependency Query Web Service
     */
    @Autowired
    private QueryWebserviceRequestHandler qrWebService;
    
    /*
     * Dependency
     */
    private IDEXXImageManagerServices idexxImageManagerServices;

    /**
     * 
     */
    @Autowired
    private DownloadImageFromS3 dldImageFromS3;
    
    @Autowired
    private ImageManagerConfigurationProvider imageManagerConfigurationProvider;

    
    
    /**
     * Creating a folder to store images 
     * @return
     * 
     */
    private String createFolderForRetrieve(String filePathName) {
	 File file = null;
	 String pathName = "";
        if (baseDir.endsWith(File.separator)) {
            file = new File(baseDir + filePathName);
        }   else { 
            file = new File(baseDir + File.separator + filePathName);
        }
         
        boolean bool = file.mkdirs();
        if(bool) {
            pathName = file.getAbsolutePath();
        }
        
        return pathName;
    }
    
    /**
     * @param dataset 
     * @param requestTitle
     * @return String[] array of filename that are downloaded from Amazon S3
     */
    @Override
    public final List<String> idexxSearchImageService(final Attributes dataset, final String requestingAETILE)
            throws IdexxServiceException_Exception {
    	ArrayOfstring arrString = qrWebService.getRequestTokens(dataset, requestingAETILE);
    	List<String> imageAssetIdList = arrString.getString();
    	LOG.info("  imageAssetIdList.size() : " + imageAssetIdList.size()); 
        if (imageAssetIdList.isEmpty()) {
            throw  new IdexxServiceException_Exception("Unable retrieve data from DVM Insight", null);
        }
        List<String> fileLoadedName = new ArrayList<String>();   
        
        for (String imageAssetId : imageAssetIdList) { 
            SearchRequestDTO searchRequestDTO = new SearchRequestDTO();
            searchRequestDTO.setApiKey(apiKey);
            searchRequestDTO.setRetrieveImage(true);
            searchRequestDTO.setImageAssetId(imageAssetId);
            
            LOG.info("imageDTO imageAssetId:" + imageAssetId);
            try {
                long startTime = System.currentTimeMillis();
                List<PatientDTO> patientList = idexxImageManagerServices.searchImage(searchRequestDTO);
                LOG.info("060674-searchImage," + requestingAETILE + "," + (System.currentTimeMillis() - startTime) + ","
                        + patientList.size() + "," + imageAssetId);
                fileLoadedName = downloadImageFromS3(fileLoadedName, patientList);
            } catch (Exception exp) {
                LOG.error(" Image Manager SearchImage Serivice Failed  " + imageAssetId + " reason " 
                        + exp.getMessage(), exp);                                
            }
        }        
        
        return fileLoadedName;
    }

    /**
     * Download Image From S3
     * @param fileLoadedName
     * @param patientList
     * @return
     * 
     */
    private List<String> downloadImageFromS3( List<String> fileLoadedName, List<PatientDTO> patientList) {
	boolean bool;
	SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyyMMddHHmmssS");            
	java.util.Date date = new java.util.Date();
	String filePathName = componentName + "/" + sDateFormat.format(date);
	String pathName = createFolderForRetrieve(filePathName);
	
	for (PatientDTO pdto : patientList) {                
	    List<StudyDTO> studyList = pdto.getStudies();
	    for (StudyDTO studyDTO : studyList) {         
	        List<SeriesDTO> seriesList =  studyDTO.getSeries();
	        for (SeriesDTO seriesDTO : seriesList) {
	            List<ImageDTO> imageList = seriesDTO.getImages();
	            for (ImageDTO imageDTO : imageList) {                                             
	                try {                                
	                    String imFileName = imageDTO.getOriginalFileName();                                
	                    if (imFileName.endsWith(fileExtension)) {
	                        imFileName = imFileName.substring(0, imFileName.length() - fileExtension.length());
	                    }
	                    imFileName = imFileName + "_" + sDateFormat.format(date) + fileExtension;
	                    
	                    bool = dldImageFromS3.downloadDicomImageFileFromCloud(imageDTO.getPreSignedUrl(), pathName 
	                                    + "/" + imFileName);
	                    fileLoadedName.add(filePathName + "/" + imFileName);
	                    
	                    LOG.info("imageDTO :" + imageDTO.getPreSignedUrl() + " Successful " + bool);
	                } catch (Exception exp) {
	                    LOG.error(" File download from Amazon S3 failed " + imageDTO.getPreSignedUrl() + " reason " 
	                            + exp.getMessage(), exp);                                
	                }
	            }
	        }
	    }
	}
	 return fileLoadedName;
    }    
    
    /**
     *  return base Directory value that is read from database
     */
    @Override
    public final String getBaseDir() {
        return baseDir;
    }

	@Override
	public void afterPropertiesSet() throws Exception {
        Map<String, String> configMap = imageManagerConfigurationProvider.geCofingurationValues();
        String value = configMap.get("apiKey");
        if (value == null) {
            apiKey = "4KWZKF914D15UOE759AM92131LCG5U712RFH05481IIO3E7H69406K29Q4DQAXK2";
        } else {
            apiKey = value;
        }
        baseDir = System.getProperty(IdexxDicomServiceConstants.JAVA_TEMP_LOCATION) + File.separator + IdexxDicomServiceConstants.DOWNLOADED_IMAGES_DIR;
        value = configMap.get("imageManagerURL");
        String imManagerUrl = null;
        if (value == null) {
            imManagerUrl = "https://imagemanagerqa.idexx.com/AssetManagerWar/soap/img-mgr-api-1.8";
        } else {
            imManagerUrl = value;
        }
        Long wsTimeout = QueryWebserviceRequestHandler.WEBSERVICE_TIMOUT;
        value = configMap.get("wsTimeout");
        if (value != null && !value.isEmpty()) {
            wsTimeout = Long.valueOf(wsTimeout);
        }
       
        ImageManagerStoreServiceProvider storeProvider = new ImageManagerStoreServiceProviderImpl(imManagerUrl,
                wsTimeout);

        idexxImageManagerServices = storeProvider.getService();
	}
}
