package com.idexx.dicom;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

import javax.annotation.PreDestroy;

import org.apache.commons.cli.ParseException;
import org.apache.log4j.Logger;
import org.dcm4che3.net.ApplicationEntity;
import org.dcm4che3.net.Connection;
import org.dcm4che3.net.Device;
import org.dcm4che3.net.service.DicomServiceRegistry;
import org.springframework.context.ApplicationContext;

import com.idexx.dcm4che3.tool.dcmqrscp.DcmQRSCP;
import com.idexx.dcm4che3.tool.mppsscp.MppsSCP;
import com.idexx.dicom.echo.v13.DicomEchoServiceImpl;
import com.idexx.dicom.sendimage.impl.SendImageImpl;
import com.idexx.dicom.storescp.StoreSCPImpl;

public class IdexxDicomServiceRegistry {
	
    private static Logger LOG = Logger.getLogger(IdexxDicomServiceRegistry.class);

    private Device device = new Device("IDEXXDICOM2");
    private ApplicationEntity ae = new ApplicationEntity("*");
    private final Connection conn = new Connection();
    protected boolean started = false;
    InputStream inputStream;

    public IdexxDicomServiceRegistry(ApplicationContext applicationContext, int instance)
	    throws IOException, GeneralSecurityException, ParseException {
	LOG.info( "Registering into Idexx dicom Services");
	Properties prop = getProperties();
	String hostName = prop.getProperty("LocalHostName");
	String port = "11112";
	if(instance == 1) {
		port = prop.getProperty("Port1");
	}
	else {
		port = prop.getProperty("Port2");
	}
	String aeTitle = prop.getProperty("AETitle");
	conn.setHostname(hostName);
	conn.setPort(Integer.valueOf(port));
	conn.setConnectionInstalled(true);
	device.setInstalled(true);

	ae.setAssociationAcceptor(true);
	ae.setAeInstalled(true);
	ae.setAETitle(aeTitle);
	ae.addConnection(conn);
	device.addConnection(conn);
	device.addApplicationEntity(ae);
	ae.setAssociationAcceptor(true);
	ae.addConnection(conn);

	DicomServiceRegistry serviceRegistry = new DicomServiceRegistry();
	started = true;
	
	StoreSCPImpl storeSCPImpl = (StoreSCPImpl) applicationContext.getBean("storeSCPImpl");
	storeSCPImpl.init(device, ae, serviceRegistry);
	
	
	DcmQRSCP dcmQRSCP = (DcmQRSCP) applicationContext.getBean("dcmQRSCP");
	
	String[] args1 = { "-b", aeTitle + ":" + port};
	dcmQRSCP.init(args1, device, ae, conn, serviceRegistry);

	MppsSCP mppsSCP = (MppsSCP) applicationContext.getBean("mppsSCP");
	String[] args2 = { "-b", aeTitle + ":" + port };
	mppsSCP.init(args2, device, ae, conn, serviceRegistry);
	
	DicomEchoServiceImpl dicomEchoServiceImplV13 = (DicomEchoServiceImpl) applicationContext.getBean("dicomEchoServiceImplV13");
	dicomEchoServiceImplV13.init(device,ae,conn);
	
	SendImageImpl sendImageImpl = (SendImageImpl) applicationContext.getBean("sendImage");
	sendImageImpl.init(ae,conn);
	
	ExecutorService executorService = Executors.newCachedThreadPool();
	ScheduledExecutorService scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
	device.setScheduledExecutor(scheduledExecutorService);
	device.setExecutor(executorService);
	device.bindConnections();
    }

    public final Device getDevice() {
	return device;
    }

    public void setDevice(Device device) {
	this.device = device;
    }

    public ApplicationEntity getApplicationEntity() {
	return ae;
    }

    public void setApplicationEntity(ApplicationEntity ae) {
	this.ae = ae;
    }

    private Properties getProperties() throws IOException, FileNotFoundException {
	Properties prop = new Properties();
	String propFileName = "storescpConfig.properties";

	inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(propFileName);

	if (inputStream != null) {
	    prop.load(inputStream);
	} else {
	    throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
	}
	return prop;
    }

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.beans.factory.DisposableBean#destroy()
     */
    @PreDestroy
    public void destroy() throws Exception {
	LOG.info( "DESTROY METHOD CALLED: Closing all opened TCP Ports");

	if (!started)
	    return;

	started = false;

	device.unbindConnections();
	((ExecutorService) device.getExecutor()).shutdown();
	device.getScheduledExecutor().shutdown();

	while (device.getConnections().get(0).isListening()) {
	    try {
	    	Thread.sleep(10);
	    } catch (InterruptedException e) {
	    	LOG.error("UnBinding TCP/IP Ports : " + e);
	    }
	}

    }
}
