/**
 * 
 */
package com.idexx.dicom.aeservices.impl.v12;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.ae.validator.v12.CancelSendJobServiceValidator;
import com.idexx.dicom.aeservices.v12.CancelSendJobService;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.IdexxSendImageJobDao;
import com.idexx.dicom.sendimage.SendImageJobConstants;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v12.CancelSendJobParamDTO;

/**
 * @author anarayana
 * 
 */
@Service("cancelSendJobServiceImplV12")
public class CancelSendJobServiceImpl implements CancelSendJobService {

	private static final Logger LOG = Logger.getLogger(CancelSendJobServiceImpl.class);

    @Autowired
    @Qualifier("cancelSendJobServiceValidatorV12")
    private CancelSendJobServiceValidator validator;

    @Autowired
    private IdexxSendImageJobDao cancelSendImageJobDao;

    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.aeservices.AEService#performService()
     */
    @Transactional
    @Override
    public final String performService(final CancelSendJobParamDTO dto) throws IdexxDicomAEConfigServiceException {
            this.validate(dto);
            String message = this.doService(dto);
        return message;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.aeservices.impl.AbstractAEServiceImpl#validate(com.idexx
     * .dicom.services.dto.IdexxDicomApplicationEntityDTO)
     */

    protected final int validate(final CancelSendJobParamDTO dto) throws IdexxDicomAEConfigServiceException {
        return validator.validate(dto);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.aeservices.impl.AbstractAEServiceImpl#doService(com.idexx
     * .dicom.services.dto.IdexxDicomApplicationEntityDTO)
     */

    protected final String doService(final CancelSendJobParamDTO dto) throws IdexxDicomAEConfigServiceException {
        String message = null;
        try {
            List<IdexxSendImageJob> jobList = new ArrayList<IdexxSendImageJob>();
            List<String> jobIdList = new ArrayList<String>();
            jobIdList.add(dto.getJobId());
            jobList = cancelSendImageJobDao.getJob(jobIdList);
            if (!jobList.isEmpty()) {
                IdexxSendImageJob idexxCancelJob = jobList.get(0);
                idexxCancelJob.setJobStatus(SendImageJobConstants.JOB_STATUS_CANCEL);
                message = cancelSendImageJobDao.cancelSendJob(idexxCancelJob);
            } else {
                message = "JobId " + dto.getJobId() + " does not exists.";
            }
        } catch (Exception exp) {
            LOG.error(exp.getLocalizedMessage(), exp);
            throw new IdexxDicomAEConfigDbException(exp);
        }
        return message;
    }
}
