/**
 * 
 */
package com.idexx.dicom.query.response;

import org.dcm4che3.data.Attributes;

import com.idexx.dicom.query.soap.QRDataSet;

/**
 * @author vkandagatla
 * 
 */
public interface QueryResponseHandler {
    Attributes getDicomDataset(QRDataSet qrDataSet);
}
