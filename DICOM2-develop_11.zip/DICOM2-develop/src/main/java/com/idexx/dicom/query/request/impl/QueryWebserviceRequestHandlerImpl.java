package com.idexx.dicom.query.request.impl;

import java.net.MalformedURLException;
import java.util.Map;

import org.apache.log4j.Logger;
import org.dcm4che3.data.Attributes;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.idexx.dicom.ImageManagerConfigurationProvider;
import com.idexx.dicom.ImageManagerStoreServiceProvider;
import com.idexx.dicom.ImageManagerStoreServiceProviderImpl;
import com.idexx.dicom.query.request.QueryRequestDatasetElementExtractorInterface;
import com.idexx.dicom.query.request.QueryWebserviceRequestHandler;
import com.idexx.dicom.query.soap.ArrayOfQRDataSet;
import com.idexx.dicom.query.soap.ArrayOfstring;
import com.idexx.dicom.query.soap.IQRService11;
import com.idexx.dicom.query.soap.QRService11DicomQRLevel;
import com.idexx.dicom.query.soap.QRService11DicomQRRoot;

@Component
public class QueryWebserviceRequestHandlerImpl implements QueryWebserviceRequestHandler, InitializingBean {
	private String calledAETitle;

	private static final Logger LOG = Logger.getLogger(QueryWebserviceRequestHandlerImpl.class);

	private ImageManagerStoreServiceProvider storeProvider;

	@Autowired
	private QueryRequestDatasetElementExtractorInterface qReqDataSetExtractor;

	@Autowired
	private ImageManagerConfigurationProvider imageManagerConfigurationProvider;

	private IQRService11 service;

	@Override
	public void afterPropertiesSet() throws Exception {
		Map<String, String> configMap = imageManagerConfigurationProvider.geCofingurationValues();

		String value = configMap.get("calledAETitle");
		if (value == null) {
			calledAETitle = "QRLIST";
		} else {
			calledAETitle = value;
		}

		String queryWorkListURL = null;
		value = configMap.get("dvmQueryURL");
		if (value == null) {
			queryWorkListURL = "http://dvminsightqa.idexx.com/dvmwebservices/QRService-1-1.svc";
		} else {
			queryWorkListURL = value;
		}
		Long wsTimeout = QueryWebserviceRequestHandler.WEBSERVICE_TIMOUT;
		value = configMap.get("wsTimeout");
		if (value != null && !value.isEmpty()) {
			wsTimeout = Long.valueOf(wsTimeout);
		}

		storeProvider = new ImageManagerStoreServiceProviderImpl(queryWorkListURL, wsTimeout);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.idexx.dicom.query.request.QueryWebserviceRequestHandler#search(org
	 * .dcm4che.data.Dataset, com.idexx.dicom.query.soap.QRService11DicomQRRoot,
	 * java.lang.String)
	 */
	@Override
	public final ArrayOfQRDataSet search(final Attributes dataset, final QRService11DicomQRRoot qRService11DicomQRRoot,
			final String requestingAETILE) {
		long startTime = System.currentTimeMillis();
		QRService11DicomQRLevel qRService11DicomQRLevel = QRService11DicomQRLevel.STUDY;

		String rootLevel = "PATIENT";

		Map<String, String> responseElementsMap = qReqDataSetExtractor.getElementsExtractedFromDataset(dataset);

		String qLevel = responseElementsMap.get("queryLevel");
		String queryLevel = this.getQueryLevel(qLevel);

		if ("STUDY".equals(qRService11DicomQRRoot.value())) {
			rootLevel = "STUDY";
		} else if ("NONE".equals(qRService11DicomQRRoot.value())) {
			rootLevel = "NONE";
		} else if ("PATIENTSTUDYONLY".equals(qRService11DicomQRRoot.value())) {
			rootLevel = "PATIENTSTUDYONLY";
		} else if ("MODALITYWORKLIST".equals(qRService11DicomQRRoot.value())) {
			rootLevel = "MODALITYWORKLIST";
		}

		LOG.info("QUERY ROOT:" + qRService11DicomQRRoot.value() + "  requestingAETILE " + requestingAETILE
				+ " qRService11DicomQRLevel:" + queryLevel + "rootLevel: " + rootLevel);

		if (service == null) {
			try {
				service = storeProvider.getQueryService();
			} catch (MalformedURLException exc) {
				LOG.error(exc.getMessage(), exc);
			}
		}
		@SuppressWarnings("static-access")
		ArrayOfQRDataSet dataSetArray = service.search(responseElementsMap.get("patientID"),
				responseElementsMap.get("studyUID"), responseElementsMap.get("seriesUID"),
				responseElementsMap.get("instanceUID"), responseElementsMap.get("patientName"),
				responseElementsMap.get("studyDate"), responseElementsMap.get("studyTime"),
				responseElementsMap.get("accessionNumber"), responseElementsMap.get("studyID"),
				responseElementsMap.get("modality"), responseElementsMap.get("seriesNumber"),
				responseElementsMap.get("instanceNumber"), responseElementsMap.get("studyDescription"),
				responseElementsMap.get("seriesDescription"), qRService11DicomQRLevel.fromValue(queryLevel),
				qRService11DicomQRRoot.fromValue(rootLevel), requestingAETILE, calledAETitle);

		LOG.info("060674-search," + requestingAETILE + "," + (System.currentTimeMillis() - startTime) + ","
				+ dataSetArray.getQRDataSet().size());
		return dataSetArray;
	}

	/**
	 * @param dataset
	 * @param requestingAETILE
	 * @return ArrayOfstring
	 */
	@Override
	public final ArrayOfstring getRequestTokens(final Attributes dataset, final String requestingAETILE) {

		QRService11DicomQRLevel qRService11DicomQRLevel = QRService11DicomQRLevel.STUDY;

		Map<String, String> responseElementsMap = qReqDataSetExtractor.getElementsExtractedFromDataset(dataset);

		String qLevel = responseElementsMap.get("queryLevel");
		String queryLevel = this.getQueryLevel(qLevel);

		if ("SERIES".equals(queryLevel.trim()) && responseElementsMap.get("studyUID") != null
				&& responseElementsMap.get("seriesUID") == null) {
			queryLevel = "STUDY";
		}
		LOG.info(" getRequestTokens :: qlEVEL:" + qLevel + "end length" + qLevel.length());
		LOG.info(" qRService11DicomQRLevel:" + queryLevel);

		if (service == null) {
			try {
				service = storeProvider.getQueryService();
			} catch (MalformedURLException exc) {
				LOG.error(exc.getMessage(), exc);
			}
		}
		long startTime = System.currentTimeMillis();
		@SuppressWarnings("static-access")
		ArrayOfstring stringArray = service.returnImageTokens(responseElementsMap.get("patientID"),
				responseElementsMap.get("studyUID"), responseElementsMap.get("seriesUID"),
				responseElementsMap.get("instanceUID"), qRService11DicomQRLevel.fromValue(queryLevel), requestingAETILE,
				calledAETitle);
		LOG.info("060674-getRequestTokens," + requestingAETILE + "," + (System.currentTimeMillis() - startTime));
		return stringArray;
	}

	/**
	 * @param qLevel
	 * @return String
	 */
	private String getQueryLevel(final String qLevel) {
		String queryLevel = "STUDY";
		if ("PATIENT".equalsIgnoreCase(qLevel.trim())) {
			queryLevel = "PATIENT";
		} else if ("SERIES".equalsIgnoreCase(qLevel.trim())) {
			queryLevel = "SERIES";
		} else if ("INSTANCE".equalsIgnoreCase(qLevel.trim())) {
			queryLevel = "INSTANCE";
		} else if ("IMAGE".equalsIgnoreCase(qLevel.trim())) {
			queryLevel = "IMAGE";
		} else if ("NONE".equalsIgnoreCase(qLevel.trim())) {
			queryLevel = "NONE";
		}
		return queryLevel;
	}

}
