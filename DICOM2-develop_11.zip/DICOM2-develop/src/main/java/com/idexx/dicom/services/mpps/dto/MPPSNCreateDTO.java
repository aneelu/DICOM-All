package com.idexx.dicom.services.mpps.dto;

import java.sql.Timestamp;

public class MPPSNCreateDTO {
	private String id;
	private String mppsSOPInstanceUID;
	private String patientId;
	private String performedStationAETitle;
	private Timestamp performedProcedureStepStartDate;
	private Timestamp performedProcedureStepEndDate;
	private String performedStationName;
	private String performedLocation;
	private String performedProcedureStepStatus;
	private String studyInstanceUID;
	private String scheduledProcedureStepId;
	private Timestamp createTimestamp;
	private Timestamp updateTimestamp;
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the mppsSOPInstanceUID
	 */
	public String getMppsSOPInstanceUID() {
		return mppsSOPInstanceUID;
	}
	/**
	 * @param mppsSOPInstanceUID the mppsSOPInstanceUID to set
	 */
	public void setMppsSOPInstanceUID(String mppsSOPInstanceUID) {
		this.mppsSOPInstanceUID = mppsSOPInstanceUID;
	}
	/**
	 * @return the patientId
	 */
	public String getPatientId() {
		return patientId;
	}
	/**
	 * @param patientId the patientId to set
	 */
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	/**
	 * @return the performedStationAETitle
	 */
	public String getPerformedStationAETitle() {
		return performedStationAETitle;
	}
	/**
	 * @param performedStationAETitle the performedStationAETitle to set
	 */
	public void setPerformedStationAETitle(String performedStationAETitle) {
		this.performedStationAETitle = performedStationAETitle;
	}
	/**
	 * @return the performedProcedureStepStartDate
	 */
	public Timestamp getPerformedProcedureStepStartDate() {
		return performedProcedureStepStartDate;
	}
	/**
	 * @param performedProcedureStepStartDate the performedProcedureStepStartDate to set
	 */
	public void setPerformedProcedureStepStartDate(Timestamp performedProcedureStepStartDate) {
		this.performedProcedureStepStartDate = performedProcedureStepStartDate;
	}
	/**
	 * @return the performedProcedureStepEndDate
	 */
	public Timestamp getPerformedProcedureStepEndDate() {
		return performedProcedureStepEndDate;
	}
	/**
	 * @param performedProcedureStepEndDate the performedProcedureStepEndDate to set
	 */
	public void setPerformedProcedureStepEndDate(Timestamp performedProcedureStepEndDate) {
		this.performedProcedureStepEndDate = performedProcedureStepEndDate;
	}
	/**
	 * @return the performedStationName
	 */
	public String getPerformedStationName() {
		return performedStationName;
	}
	/**
	 * @param performedStationName the performedStationName to set
	 */
	public void setPerformedStationName(String performedStationName) {
		this.performedStationName = performedStationName;
	}
	/**
	 * @return the performedLocation
	 */
	public String getPerformedLocation() {
		return performedLocation;
	}
	/**
	 * @param performedLocation the performedLocation to set
	 */
	public void setPerformedLocation(String performedLocation) {
		this.performedLocation = performedLocation;
	}
	/**
	 * @return the performedProcedureStepStatus
	 */
	public String getPerformedProcedureStepStatus() {
		return performedProcedureStepStatus;
	}
	/**
	 * @param performedProcedureStepStatus the performedProcedureStepStatus to set
	 */
	public void setPerformedProcedureStepStatus(String performedProcedureStepStatus) {
		this.performedProcedureStepStatus = performedProcedureStepStatus;
	}
	/**
	 * @return the studyInstanceUID
	 */
	public String getStudyInstanceUID() {
		return studyInstanceUID;
	}
	/**
	 * @param studyInstanceUID the studyInstanceUID to set
	 */
	public void setStudyInstanceUID(String studyInstanceUID) {
		this.studyInstanceUID = studyInstanceUID;
	}
	/**
	 * @return the scheduledProcedureStepId
	 */
	public String getScheduledProcedureStepId() {
		return scheduledProcedureStepId;
	}
	/**
	 * @param scheduledProcedureStepId the scheduledProcedureStepId to set
	 */
	public void setScheduledProcedureStepId(String scheduledProcedureStepId) {
		this.scheduledProcedureStepId = scheduledProcedureStepId;
	}
	/**
	 * @return the createTimestamp
	 */
	public Timestamp getCreateTimestamp() {
		return createTimestamp;
	}
	/**
	 * @param createTimestamp the createTimestamp to set
	 */
	public void setCreateTimestamp(Timestamp createTimestamp) {
		this.createTimestamp = createTimestamp;
	}
	/**
	 * @return the updateTimestamp
	 */
	public Timestamp getUpdateTimestamp() {
		return updateTimestamp;
	}
	/**
	 * @param updateTimestamp the updateTimestamp to set
	 */
	public void setUpdateTimestamp(Timestamp updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

}
