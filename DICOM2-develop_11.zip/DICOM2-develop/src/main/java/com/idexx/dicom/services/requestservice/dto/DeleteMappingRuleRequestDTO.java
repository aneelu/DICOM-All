package com.idexx.dicom.services.requestservice.dto;

import com.idexx.dicom.dto.MappingRuleDTO;

public class DeleteMappingRuleRequestDTO {
	private MappingRuleDTO mappingRule;
	private String apiKey;
	private String sapId;

	public MappingRuleDTO getMappingRule() {
		return mappingRule;
	}
	public void setMappingRule(MappingRuleDTO mappingRule) {
		this.mappingRule = mappingRule;
	}
	public String getApiKey() {
		return apiKey;
	}
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}
	public String getSapId() {
		return sapId;
	}
	public void setSapId(String sapId) {
		this.sapId = sapId;
	}
	
	
}
