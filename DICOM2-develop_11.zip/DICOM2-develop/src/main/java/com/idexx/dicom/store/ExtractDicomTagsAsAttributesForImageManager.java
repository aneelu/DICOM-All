/**
 * 
 */
package com.idexx.dicom.store;

import java.util.List;

import org.dcm4che3.data.Attributes;

import com.idexx.dicom.entities.store.DicomImageManagerMapping;

/**
 * @author vkandagatla
 * 
 */
public class ExtractDicomTagsAsAttributesForImageManager extends AbstractExtractor {

    private Integer tag;

    /**
     * @param tags
     */
    public ExtractDicomTagsAsAttributesForImageManager(final List<DicomImageManagerMapping> mapping, final Integer tag) {
        super(mapping);
        this.tag = tag;
    }

    @Override
    public final String exractAtribute(final Attributes dataSet) {
        String value = this.getTagValueAsString(tag, dataSet);
        return value;
    }

    public static ExtractDicomTagsAsAttributesForImageManager createInstance(
            final List<DicomImageManagerMapping> mapping, final Integer tag) {
        return new ExtractDicomTagsAsAttributesForImageManager(mapping, tag);
    }

}
