/**
 * 
 */
package com.idexx.dicom.aeservices.impl.v13;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.entities.AssumedIssuer;
import com.idexx.dicom.dao.ws.AssumedIssuerDao;
import com.idexx.dicom.services.dto.v13.AssumedIssuerEntityDTO;
import com.idexx.dicom.services.dto.v13.ReadAssumedIssuerDTO;
import com.idexx.dicom.services.dto.v13.SetAssumedIssuerDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * This class is for assumed issuer service
 * 
 * @author vvanjarana
 * @version 1.3
 */
@Component("assumedIssuerServiceV13")
public class AssumedIssuerServiceImpl {

	private static final Logger LOG = Logger.getLogger(AssumedIssuerServiceImpl.class);

	private static final String MISSING_MANDATORY_SAP_ID = "ERR_argument_missing_mandatory_sapId";

	@Autowired
	@Qualifier("idexxDicomWSAthorizationServiceImplV13")
	private IdexxDicomWSAthorizationServiceImpl idexxDicomWsAuthorizeService;

	@Autowired
	private AssumedIssuerDao assumedIssuerDao;

	/**
	 * Creating a record in db
	 * 
	 * @param SetAssumedIssuerDTO
	 * @return Failure or success
	 * @throws IdexxDicomAEConfigServiceException
	 * 
	 */
	@Transactional
	public String setAssumedIssuer(final SetAssumedIssuerDTO dto) throws IdexxDicomAEConfigServiceException {
		String response = "Failure";
		boolean authorized = false;
		authorized = isAPIKeyValid(dto.getApiKey());
		if (authorized) {
			authorized = isValidSapId(dto.getSapId());
		}
		if (authorized) {
			response = saveAssumedIssuer(dto);
		}
		return response;
	}

	private String saveAssumedIssuer(final SetAssumedIssuerDTO dto) {
		LOG.info("SAP_ID " + dto.getSapId());
		LOG.info("ASSUMED_ISSUER_VALUE " + dto.getAssumedIssuerValue());
		AssumedIssuer assumedIssuer = null;
		List<AssumedIssuer> assumedIssuerList = getAssumedIssuer(dto.getSapId());
		if (null != assumedIssuerList && !assumedIssuerList.isEmpty()) {
			assumedIssuer = assumedIssuerList.get(0);
			assumedIssuer.setAssumedIssuerValue(dto.getAssumedIssuerValue());
			assumedIssuerDao.updateAssumedIssuer(assumedIssuer);
		} else {
			assumedIssuer = new AssumedIssuer();
			assumedIssuer.setSapId(dto.getSapId());
			assumedIssuer.setAssumedIssuerValue(dto.getAssumedIssuerValue());
			assumedIssuer.setCreatedDateTime(new Timestamp(new Date().getTime()));
			assumedIssuer.setLastUpdatedDateTime(new Timestamp(new Date().getTime()));
			assumedIssuerDao.createAssumedIssuer(assumedIssuer);
		}
		return "Success";
	}

	/**
	 * Read Assumed Issuer
	 * 
	 * @param ReadAssumedIssuerDTO
	 * @return AssumedIssuerEntityDTO
	 * @throws IdexxDicomAEConfigServiceException
	 * 
	 */
	public AssumedIssuerEntityDTO readAssumedIssuer(ReadAssumedIssuerDTO dto)
			throws IdexxDicomAEConfigServiceException {
		AssumedIssuerEntityDTO aieDto = null;
		boolean authorized = false;
		authorized = isAPIKeyValid(dto.getApiKey());
		if (authorized) {
			authorized = isValidSapId(dto.getSapId());
		}
		if (authorized) {
			List<AssumedIssuer> assumedIssuerList = getAssumedIssuer(dto.getSapId());
			if (null != assumedIssuerList && !assumedIssuerList.isEmpty()) {
				AssumedIssuer assumedIssuer = assumedIssuerList.get(0);
				if (assumedIssuer != null) {
					aieDto = new AssumedIssuerEntityDTO();
					aieDto.setAssumedIssuerValue(assumedIssuer.getAssumedIssuerValue());
					aieDto.setCreatedDateTime(assumedIssuer.getCreatedDateTime().toString());
					aieDto.setLastUpdatedDateTime(assumedIssuer.getLastUpdatedDateTime().toString());
					aieDto.setSapId(assumedIssuer.getSapId());
				} else {
					aieDto = createNullAssumedIssuerDTO(dto);
				}
			} else {
				aieDto = createNullAssumedIssuerDTO(dto);
			}
		}
		return aieDto;
	}

	public AssumedIssuerEntityDTO createNullAssumedIssuerDTO(ReadAssumedIssuerDTO dto) {
		AssumedIssuerEntityDTO aieDto = new AssumedIssuerEntityDTO();
		aieDto.setAssumedIssuerValue(null);
		aieDto.setSapId(dto.getSapId());
		return aieDto;
	}

	private List<AssumedIssuer> getAssumedIssuer(final String sapId) {
		List<AssumedIssuer> assumedIssuerList = assumedIssuerDao.findAssumedIssuerBySapId(sapId);
		return assumedIssuerList;
	}

	/**
	 * Checking for Valid API Key
	 * 
	 * @param apiKey
	 * @return true or false
	 * @throws IdexxDicomAEConfigServiceException
	 * 
	 */
	public boolean isAPIKeyValid(final String apiKey) throws IdexxDicomAEConfigServiceException {
		return idexxDicomWsAuthorizeService.authorize(apiKey);
	}

	/**
	 * Checking for valid SapID
	 * 
	 * @param sapId
	 * @return true or false
	 * @throws IdexxDicomAEConfigServiceException
	 * 
	 */
	public boolean isValidSapId(final String sapId) throws IdexxDicomAEConfigServiceException {
		if (StringUtils.isEmpty(sapId)) {
			throw new IdexxDicomAEConfigServiceException(MISSING_MANDATORY_SAP_ID, MISSING_MANDATORY_SAP_ID);
		}
		return true;
	}
}
