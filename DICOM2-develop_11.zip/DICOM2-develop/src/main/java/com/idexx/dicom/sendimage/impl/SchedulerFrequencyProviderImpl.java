/**
 * 
 */
package com.idexx.dicom.sendimage.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.entities.BaseDicomImPluginConfig;
import com.idexx.dicom.dao.ws.DicomConfigDao;
import com.idexx.dicom.sendimage.SchedulerFrequencyProvider;

/**
 * @author vkandagatla
 * 
 */
@Service
public class SchedulerFrequencyProviderImpl implements SchedulerFrequencyProvider {
    @Autowired
    private DicomConfigDao configDao;
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.sendimage.SchedulerFrequencyProvider#getFrequency()
     */
    @Override
    public final int getFrequency() {
        int frequency = DEFAULT_FREQUENCY;
        BaseDicomImPluginConfig config = configDao.getConfig(SLEEP_TIME);
        String configValue = config.getConfigValue();
        if (!StringUtils.isEmpty(configValue)) {
            frequency = Integer.valueOf(configValue);
        }
        return frequency;
    }
    
}
