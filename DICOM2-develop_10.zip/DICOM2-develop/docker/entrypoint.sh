#!/bin/bash

case "${ENV^^}" in
  LOCAL)
    echo "Environment is local"
    touch ${_tomcatHomeDir}/${_tomcatVersion}/bin/local.properties
    ;;

  *)
    echo "Environment is: ${ENV,,}"
    aws s3 cp s3://IDEXX-Digtal-Autodeploy/DICOM/config/${ENV,,}/${ENV,,}.database.credentials ${_tomcatHomeDir}/${_tomcatVersion}/bin/database.credentials
    ;;
esac

# Setup Tomcat
sed -i -e "s/<ENV>/${ENV,,}/" ${_tomcatHomeDir}/${_tomcatVersion}/bin/setenv.sh
sed -i -e "s,<TOMCAT_HOMEDIR>,${_tomcatHomeDir}," ${_tomcatHomeDir}/${_tomcatVersion}/bin/setenv.sh
sed -i -e "s/<TOMCAT_VERSION>/${_tomcatVersion}/" ${_tomcatHomeDir}/${_tomcatVersion}/bin/setenv.sh
sed -i -e "s/<ENV>/${_proxyNameEnv}/" ${_tomcatHomeDir}/${_tomcatVersion}/conf/server.xml
sed -i -e "s/<JVM_HEAP>/${jvmHeap}/" ${_tomcatHomeDir}/${_tomcatVersion}/bin/setenv.sh

source ${_tomcatHomeDir}/${_tomcatVersion}/bin/database.credentials
sed -i -e "s,<DB_URL>,${dbURL}," ${_tomcatHomeDir}/${_tomcatVersion}/bin/setenv.sh
sed -i -e "s,<DB_USERNAME>,${dbUsername}," ${_tomcatHomeDir}/${_tomcatVersion}/bin/setenv.sh
sed -i -e "s,<DB_PASSWORD>,${dbPassword}," ${_tomcatHomeDir}/${_tomcatVersion}/bin/setenv.sh
sed -i -e "s,<DB_DRIVER_CLASS_NAME>,${dbDriverClassName}," ${_tomcatHomeDir}/${_tomcatVersion}/bin/setenv.sh

# Start Tomcat - Note this launches into foreground, and will keep container alive until Tomcat exits prematurely
${_tomcatHomeDir}/${_tomcatVersion}/bin/catalina.sh run >> "${_tomcatHomeDir}/${_tomcatVersion}/logs/catalina.out" 2>&1
