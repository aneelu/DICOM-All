package com.idexx.dicom.ae.validator.impl.v11;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;

import com.idexx.dicom.constants.IdexxDicomTestConstants;
import com.idexx.dicom.services.dto.v11.IdexxFailureLogParamDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

// TODO: Auto-generated Javadoc
/**
 * The Class GetStoreServiceFailureValidatorTest.
 *
 * @author smallela
 * @version 1.3
 */
public class GetStoreServiceFailureValidatorTest {

	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(GetStoreServiceFailureValidatorTest.class);

	/** The validator. */
	@InjectMocks
	private GetStoreFailuresValidator validator = new GetStoreFailuresValidator();

	/**
	 * Sets the up.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	/**
	 * Test validate.
	 */
	@Test
	public final void testValidate() {
		
		IdexxFailureLogParamDTO idexxFailureLogParamDTO = new IdexxFailureLogParamDTO();
		idexxFailureLogParamDTO.setEndDate(IdexxDicomTestConstants.ENDDATE);
		idexxFailureLogParamDTO.setStartDate(IdexxDicomTestConstants.STARTDATE);
		int val = 0;
		try {
			val = validator.validateInputFields(idexxFailureLogParamDTO);
			fail("validation failed#1");
		} catch (IdexxDicomAEConfigServiceException exp) {
			LOG.error(exp);

		}
		idexxFailureLogParamDTO.setEndDate("1997-12-31T23:59:59.1+05:30");
		idexxFailureLogParamDTO.setStartDate("1997-12-31T25:59:59.1+05:30");
		try {
			val = validator.validateInputFields(idexxFailureLogParamDTO);
			fail("validation failed#2");
		} catch (IdexxDicomAEConfigServiceException exp) {
			LOG.error(exp);
		}
		idexxFailureLogParamDTO.setEndDate("1997-12-31T25:59:59.1+05:30");
		idexxFailureLogParamDTO.setStartDate("1997-12-31T23:59:59.1+05:30");
		try {
			val = validator.validateInputFields(idexxFailureLogParamDTO);
			fail("validation failed#3");
		} catch (IdexxDicomAEConfigServiceException exp) {
			LOG.error(exp);
		}

		idexxFailureLogParamDTO.setEndDate("1997-12-31T22:59:59.1+05:30");
		idexxFailureLogParamDTO.setStartDate("1997-12-31T23:59:59.1+05:30");
		try {
			val = validator.validateInputFields(idexxFailureLogParamDTO);
			fail("validation failed#4");
		} catch (IdexxDicomAEConfigServiceException exp) {
			LOG.error(exp);
		}
		idexxFailureLogParamDTO.setEndDate("1997-12-31T23:59:59.1+05:30");
		idexxFailureLogParamDTO.setStartDate("1997-12-31T23:59:59.1+05:30");
		try {
			val = validator.validateInputFields(idexxFailureLogParamDTO);
			assertTrue("Date Validation Failed", val == 1);
		} catch (IdexxDicomAEConfigServiceException exp) {
			LOG.error(exp);
			fail("validation failed#5");
		}
	}

}
