/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dicom.conf;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.AbstractEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

/**
 * <pre>
 * Loading data source based on the environment
 * </pre>
 * 
 * @author vvanjarana
 * @version 1.3
 */
@Configuration
public class DBConfig {

	private static final Logger LOG = Logger.getLogger(DBConfig.class);

	@Autowired
	private Environment environment;

	public DriverManagerDataSource dataSource;

	@Bean
	public DataSource getDbConfigXml() {
		String env = environment.getProperty(AbstractEnvironment.ACTIVE_PROFILES_PROPERTY_NAME);
		LOG.info("DriverClassName: " + environment.getRequiredProperty("jdbc."+env+".driverClassName"));
		LOG.info("jdbc url: " + environment.getRequiredProperty("jdbc."+env+".url"));
		LOG.info("jdbc username: " + environment.getRequiredProperty("jdbc."+env+".username"));
		dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(environment.getRequiredProperty("jdbc."+env+".driverClassName"));
		dataSource.setUrl(environment.getRequiredProperty("jdbc."+env+".url"));
		dataSource.setUsername(environment.getRequiredProperty("jdbc."+env+".username"));
		dataSource.setPassword(environment.getRequiredProperty("jdbc."+env+".password"));
		return dataSource;
	}

	public DataSource getDataSource() {
		return this.dataSource;
	}

}
