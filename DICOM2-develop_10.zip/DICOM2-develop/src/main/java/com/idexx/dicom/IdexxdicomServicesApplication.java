package com.idexx.dicom;

import java.util.ArrayList;
import java.util.List;

import org.apache.cxf.Bus;
import org.apache.cxf.endpoint.Server;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxrs.JAXRSServerFactoryBean;
import org.apache.cxf.jaxws.EndpointImpl;
import org.apache.cxf.rs.security.cors.CrossOriginResourceSharingFilter;
import org.apache.cxf.transport.servlet.CXFServlet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.embedded.EmbeddedServletContainerFactory;
import org.springframework.boot.context.embedded.ServletRegistrationBean;
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.fasterxml.jackson.jaxrs.json.JacksonJsonProvider;
import com.idexx.dicom.controller.IntegrationController;

@Configuration
@EnableScheduling
@EnableAutoConfiguration
@ComponentScan("com.idexx")
@ImportResource({ "classpath:META-INF/cxf/cxf.xml" })
public class IdexxdicomServicesApplication {

	@Autowired
	private ApplicationContext applicationContext;

	@Autowired
	private IdexxDicomProxyServiceRegistry idexxDicomProxyServiceRegistry1;

	@Autowired
	private IdexxDicomProxyServiceRegistry idexxDicomProxyServiceRegistry2;

	public static void main(String[] args) {
		SpringApplication.run(IdexxdicomServicesApplication.class, args);
	}

	// Replaces the need for web.xml
	@Bean
	public ServletRegistrationBean servletRegistrationBean(ApplicationContext context) {
		return new ServletRegistrationBean(new CXFServlet(), "/*");
	}

	@Bean
	public Server restServer() {
		Bus bus = (Bus) applicationContext.getBean(Bus.DEFAULT_BUS_ID);
		JAXRSServerFactoryBean endpoint = new JAXRSServerFactoryBean();
		endpoint.setServiceBean(integrationController());
		endpoint.setAddress("/");
		List<Object> providers = new ArrayList<Object>();
		providers.add(crossOriginResourceSharingFilter());
		providers.add(jsonProvider());
		endpoint.setProviders(providers);
		endpoint.setBus(bus);
		return endpoint.create();
	}

	@Bean
	public IntegrationController integrationController() {
		return new IntegrationController();
	}

	@Bean
	public CrossOriginResourceSharingFilter crossOriginResourceSharingFilter() {
		return new CrossOriginResourceSharingFilter();
	}

	@Bean
	public JacksonJsonProvider jsonProvider() {
		return new JacksonJsonProvider();
	}

	// Replaces cxf-servlet.xml
	@Bean
	public EndpointImpl dicomService() {
		return getEndPoint("IdexxDicomAEConfigServices", "/DicomService");
	}

	@Bean
	public EndpointImpl dicomServiceV1() {
		return getEndPoint("IdexxDicomAEConfigServicesV1_1", "/DicomServiceV1_1");
	}

	@Bean
	public EndpointImpl dicomServiceV2() {
		return getEndPoint("IdexxDicomAEConfigServicesV1_2", "/DicomServiceV1_2");
	}

	@Bean
	public EndpointImpl dicomServiceV3() {
		return getEndPoint("IdexxDicomAEConfigServicesV1_3", "/DicomServiceV1_3");
	}

	@Bean
	public IdexxDicomServiceRegistry registerDicomServiceOnPort11112() throws Exception {
		return new IdexxDicomServiceRegistry(applicationContext, 1);
	}

	@Bean
	public IdexxDicomServiceRegistry registerDicomServiceOnPort104() throws Exception {
		return new IdexxDicomServiceRegistry(applicationContext, 2);
	}

	@Bean
	public String dummyCall() throws Exception {
		idexxDicomProxyServiceRegistry1.init(1);
		idexxDicomProxyServiceRegistry2.init(2);
		return "";
	}

	private EndpointImpl getEndPoint(String beanName, String serviceURL) {
		Bus bus = (Bus) applicationContext.getBean(Bus.DEFAULT_BUS_ID);
		Object implementor = applicationContext.getBean(beanName);
		EndpointImpl endpoint = new EndpointImpl(bus, implementor);
		endpoint.publish(serviceURL);
		endpoint.getServer().getEndpoint().getInInterceptors().add(new LoggingInInterceptor());
		endpoint.getServer().getEndpoint().getOutInterceptors().add(new LoggingOutInterceptor());
		return endpoint;
	}

	// Configure the embedded tomcat to use same settings as default standalone
	// tomcat deploy
	@Bean
	public EmbeddedServletContainerFactory embeddedServletContainerFactory() {
		// Made to match the context path when deploying to standalone tomcat-
		// can easily be kept in sync w/ properties
		TomcatEmbeddedServletContainerFactory factory = new TomcatEmbeddedServletContainerFactory("/idexx-dicomws",
				8080);
		return factory;
	}
}
