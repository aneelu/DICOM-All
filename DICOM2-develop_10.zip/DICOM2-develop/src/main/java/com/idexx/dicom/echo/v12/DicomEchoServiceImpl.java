package com.idexx.dicom.echo.v12;

import org.springframework.stereotype.Service;

@Service("dicomEchoServiceImplV12")
public class DicomEchoServiceImpl implements DicomEchoService {
	
	private static final String REMOTEHOSTNAME = "aws-dico-jboss-dev01.dicom.idexxi.com";
	private static final int REMOTEPORTNUMBER = 11112;
    String defaultCalledAET = "DCM4CHEE_MAIN";
    

	@Override
	public boolean echo(final String callingAET) {
		return echo(callingAET, REMOTEHOSTNAME, REMOTEPORTNUMBER);
	}

	@Override
	public boolean echo(final String callingAET, final String calledAET) {
		return echo(callingAET, calledAET, REMOTEHOSTNAME, REMOTEPORTNUMBER);
	}

	@Override
	public boolean echo(final String callingAET, final String hostName, final int port) {
		return echo(callingAET, "DCM4CHEE_MAIN", hostName, port);
	}

	@Override
	public boolean echo(final String callingAET, final String calledAET, final String hostName, final int port) {
		return true;
	}
}