/**
 * 
 */
package com.idexx.dicom.sendimage;

import java.util.List;

/**
 * @author vkandagatla
 * 
 */
public interface JobRunnerBuilder {
    /**
     * @return
     */
    List<Runnable> build();  
    void patchInProgresstoPending();
}
