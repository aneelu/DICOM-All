/**
 * 
 */
package com.idexx.dicom.services.requestservice;

import java.io.IOException;
import java.net.URL;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.idexx.dicom.aeservices.impl.v13.IdexxDicomWSAthorizationServiceImpl;
import com.idexx.dicom.dto.IdexxAuthorizationObject;
import com.idexx.dicom.services.IdexxDicomServiceConstants;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.requestservice.dto.CreateRequestErrorCodesConstants;
import com.idexx.dicom.services.requestservice.validator.ErrorDTO;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;

// TODO: Auto-generated Javadoc
/**
 * <pre>
 * Service to take a DICOM file and import for a clinic.
 * </pre>
 * 
 * @author smallela
 * @version 1.3
 */
@Service
public class DicomFileImportService {

	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(DicomFileImportService.class);

	/** The file importer. */
	@Autowired
	private transient DicomFileImporter fileImporter;

	/** The idexx dicom ws authorize service. */
	@Autowired
	@Qualifier("idexxDicomWSAthorizationServiceImplV13")
	private transient IdexxDicomWSAthorizationServiceImpl idexxDicomWsAuthorizeService;

	/**
	 * Import dicom file.
	 *
	 * @param apiKey
	 *            the api key
	 * @param sapID
	 *            the sap id
	 * @param dicomFile
	 *            the dicom file
	 * @param listOfErrors
	 *            the list of errors
	 * @return the string
	 * @throws IdexxServiceException_Exception
	 *             the idexx service exception_ exception
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	public String importDicomFile(String apiKey, String sapID, URL dicomFile, List<ErrorDTO> listOfErrors)
			throws IdexxServiceException_Exception, IOException {
		String message = "";
		if (StringUtils.isBlank(apiKey)) {
			listOfErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.API_KEY_ERROR_CODE,
					CreateRequestErrorCodesConstants.API_KEY_ERROR_CODE_MSG));
		}
		if (StringUtils.isBlank(sapID)) {
			listOfErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.SAP_ID_ERROR_CODE,
					CreateRequestErrorCodesConstants.SAP_ID_ERROR_CODE_MSG));
		}
		if (dicomFile == null) {
			listOfErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.DICOM_URL_ERROR_CODE,
					CreateRequestErrorCodesConstants.DICOM_URL_ERROR_CODE_MSG));
		}
		if (!listOfErrors.isEmpty()) {
			return IdexxDicomServiceConstants.STATUS_FAIL;
		}
		try {
			idexxDicomWsAuthorizeService.authorize(apiKey);
		} catch (IdexxDicomAEConfigServiceException e) {
			LOG.error("APIKey validation failed", e);
			listOfErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.INVALID_API_KEY_ERROR_CODE,
					CreateRequestErrorCodesConstants.INVALID_API_KEY_ERROR_CODE_MSG));
			return IdexxDicomServiceConstants.STATUS_FAIL;
		}
		IdexxAuthorizationObject idexxAuthorizationObject = new IdexxAuthorizationObject(null, null, apiKey, false,
				sapID);
		fileImporter.setDicomFile(dicomFile);
		fileImporter.setIdexxAuthorizationObject(idexxAuthorizationObject);
		String storedImageReponse = fileImporter.performImportFile();
		message = IdexxDicomServiceConstants.STATUS_SUCCESS + ":" + storedImageReponse;
		return message;
	}
}
