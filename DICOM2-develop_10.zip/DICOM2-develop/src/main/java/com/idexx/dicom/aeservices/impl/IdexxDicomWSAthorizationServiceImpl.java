/**
 * 
 */
package com.idexx.dicom.aeservices.impl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.entities.IdexxAPIKey;
import com.idexx.dicom.aeservices.IdexxDicomWSAthorizationService;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * @author vkandagatla
 * 
 */
@Service
public class IdexxDicomWSAthorizationServiceImpl implements IdexxDicomWSAthorizationService {
    
    @Autowired
    private AETitleDao aeTitleDao;
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.aeservices.IdexxDicomWSAthorizationService#authorize(
     * java.lang.String)
     */
    @Override
    public final boolean authorize(final String apiKey) throws IdexxDicomAEConfigServiceException {
        if (StringUtils.isEmpty(apiKey)) {
            throw new IdexxDicomAEConfigServiceException(
                    IdexxDicomWSAthorizationService.MISSING_MANDATORY, IdexxDicomWSAthorizationService.MISSING_MANDATORY);
        }
        IdexxAPIKey idxApiKey = aeTitleDao.getIdexxAPIKey(apiKey);
        boolean validApiKey = false;
        if (null != idxApiKey) {
            validApiKey = true;
        } else {
            throw new IdexxDicomAEConfigServiceException(
                    IdexxDicomWSAthorizationService.INVALID_API_KEY, IdexxDicomWSAthorizationService.INVALID_API_KEY);
        }
        return validApiKey;
    }
    
}
