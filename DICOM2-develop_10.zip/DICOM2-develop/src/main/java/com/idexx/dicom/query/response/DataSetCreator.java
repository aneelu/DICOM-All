/**
 * 
 */
package com.idexx.dicom.query.response;

import java.util.List;

import org.dcm4che3.data.Attributes;

/**
 * @author vkandagatla
 *
 */
public interface DataSetCreator {
    List<Attributes> createDataSet(List<String> idexxQueryResponse);
}
