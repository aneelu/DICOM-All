/**
 * 
 */
package com.idexx.dicom.aeservices;

import java.util.List;

import com.idexx.dicom.services.dto.IdexxFailureLogDTO;
import com.idexx.dicom.services.dto.IdexxFailureLogParamDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * @author vkandagatla
 * 
 */
public interface GetStoreFailuresServiceIntf {
    List<IdexxFailureLogDTO> performService(IdexxFailureLogParamDTO dto) throws IdexxDicomAEConfigServiceException;

}
