package com.idexx.dicom.domain;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

// TODO: Auto-generated Javadoc
/**
 * The Class OwnerPK_.
 */
@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(OwnerPK.class)
public abstract class OwnerPK_ {

	/** The client id. */
	public static volatile SingularAttribute<OwnerPK, String> clientID;

	/** The patient id. */
	public static volatile SingularAttribute<OwnerPK, String> patientID;

}
