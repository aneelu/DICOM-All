package com.idexx.dicom.services;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.ws.BindingType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.idexx.dicom.aeservices.AEService;
import com.idexx.dicom.aeservices.GetStoreFailuresServiceIntf;
import com.idexx.dicom.aeservices.SendImageJobService;
import com.idexx.dicom.aeservices.SendImageStatusService;
import com.idexx.dicom.services.dto.AETitleDTO;
import com.idexx.dicom.services.dto.CreateAETitleDTO;
import com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO;
import com.idexx.dicom.services.dto.IdexxFailureLogDTO;
import com.idexx.dicom.services.dto.IdexxFailureLogParamDTO;
import com.idexx.dicom.services.dto.ReadAETitleDTO;
import com.idexx.dicom.services.dto.SetEnabledAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.IdexxSendImageJobStatusDTO;
import com.idexx.dicom.services.sendimage.dto.SendImageJobParamDTO;
import com.idexx.dicom.services.sendimage.dto.SendImageStatusParamDTO;

/**
 * The Class IdexxDicomAEConfigServices.
 */
@WebService(targetNamespace = "http://idexx.services.dicom.idexx.com/", portName = "IdexxDicomAEConfigServiceImplPort", serviceName = "IdexxDicomAEConfigServices")
@BindingType(javax.xml.ws.soap.SOAPBinding.SOAP12HTTP_BINDING)
@Service("IdexxDicomAEConfigServices")
public class IdexxDicomAEConfigServices {

	/** The create service. */
	@Autowired
	@Qualifier("createAETitleService")
	private AEService createService;

	/** The delete service. */
	@Autowired
	@Qualifier("deleteAETitleService")
	private AEService deleteService;

	/** The read service. */
	@Autowired
	@Qualifier("readAETitleService")
	private AEService readService;

	/** The set enabled ae service. */
	@Autowired
	@Qualifier("setAETitleStatusService")
	private AEService setEnabledAEService;

	/** The get store failures service. */
	@Autowired
	@Qualifier("getStoreFailuresService")
	private GetStoreFailuresServiceIntf getStoreFailuresService;

	/** The send image job service. */
	@Autowired
	@Qualifier("getIdexxSendImageValidator")
	private SendImageJobService sendImageJobService;

	/** The send image status service. */
	@Autowired
	@Qualifier("getSendImageStatusService")
	private SendImageStatusService sendImageStatusService;

	/**
	 * Register the AE or Add DVMSpecialist to AE list.
	 *
	 * @param aeDTO
	 *            the ae dto
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@WebMethod
	public final void createAETitle(final CreateAETitleDTO aeDTO) throws IdexxDicomAEConfigServiceException {

		createService.performService(aeDTO);
	}

	/**
	 * Read the details of the registered AE.
	 *
	 * @param aeTitle
	 *            the ae title
	 * @return the list
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@WebMethod
	public final List<IdexxDicomApplicationEntityDTO> readAETitle(final ReadAETitleDTO aeTitle)
			throws IdexxDicomAEConfigServiceException {

		readService.performService(aeTitle);
		@SuppressWarnings("unchecked")
		List<IdexxDicomApplicationEntityDTO> dtos = (List<IdexxDicomApplicationEntityDTO>) readService.sendResponse();

		return dtos;
	}

	/**
	 * Delete the registered AE title.
	 *
	 * @param aeTitle
	 *            the ae title
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 * @Param aeTitle
	 */
	@WebMethod
	public final void deleteAETitle(final AETitleDTO aeTitle) throws IdexxDicomAEConfigServiceException {
		deleteService.performService(aeTitle);
	}

	/**
	 * Enable/Disable the registered AE.
	 *
	 * @param aeTitle
	 *            the new enable ae title
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@WebMethod
	public final void setEnableAETitle(final SetEnabledAETitleDTO aeTitle) throws IdexxDicomAEConfigServiceException {
		setEnabledAEService.performService(aeTitle);
	}

	/**
	 * Details of the authorization failure instances for Store image.
	 *
	 * @param dto
	 *            the dto
	 * @return List of AEAuthorizationFailureLogDTO
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@WebMethod
	public final List<IdexxFailureLogDTO> getFailures(final IdexxFailureLogParamDTO dto)
			throws IdexxDicomAEConfigServiceException {
		return getStoreFailuresService.performService(dto);

	}

	/**
	 * Request to send Image to third party AE.
	 *
	 * @param dto
	 *            the dto
	 * @return the string
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@WebMethod
	public final String sendImage(final SendImageJobParamDTO dto) throws IdexxDicomAEConfigServiceException {
		return sendImageJobService.performService(dto);
	}

	/**
	 * Get the status of the C-move job requested through SendImage service.
	 *
	 * @param dto
	 *            the dto
	 * @return the c move job status
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@WebMethod
	public final List<IdexxSendImageJobStatusDTO> getCMoveJobStatus(final SendImageStatusParamDTO dto)
			throws IdexxDicomAEConfigServiceException {
		List<IdexxSendImageJobStatusDTO> aeResponse = (List<IdexxSendImageJobStatusDTO>) sendImageStatusService
				.performService(dto);
		return aeResponse;
	}
}
