package com.idexx.dicom.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

// TODO: Auto-generated Javadoc
/**
 * The Class Client.
 */
@Entity
@Table(name = "CLIENT")
public class Client implements Serializable {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The i d. */
	@Id
	@Column(name = "ID")
	private String iD;

	/** The first name. */
	@Column(name = "FIRST_NAME")
	private String firstName;

	/** The last name. */
	@Column(name = "LAST_NAME")
	private String lastName;

	/** The sap id. */
	@Column(name = "SAP_ID")
	private String sapId;

	/** The email. */
	@Column(name = "EMAIl")
	private String email;

	/** The application client id. */
	@Column(name = "APPLICATION_CLIENT_ID")
	private String applicationClientId;

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public String getID() {
		return iD;
	}

	/**
	 * Sets the id.
	 *
	 * @param iD
	 *            the new id
	 */
	public void setID(String iD) {
		this.iD = iD;
	}

	/**
	 * Gets the first name.
	 *
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Sets the first name.
	 *
	 * @param firstName
	 *            the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * Gets the last name.
	 *
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Sets the last name.
	 *
	 * @param lastName
	 *            the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Gets the sap id.
	 *
	 * @return the sapId
	 */
	public String getSapId() {
		return sapId;
	}

	/**
	 * Sets the sap id.
	 *
	 * @param sapId
	 *            the sapId to set
	 */
	public void setSapId(String sapId) {
		this.sapId = sapId;
	}

	/**
	 * Gets the email.
	 *
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Sets the email.
	 *
	 * @param email
	 *            the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Gets the application client id.
	 *
	 * @return the applicationClientId
	 */
	public String getApplicationClientId() {
		return applicationClientId;
	}

	/**
	 * Sets the application client id.
	 *
	 * @param applicationClientId
	 *            the applicationClientId to set
	 */
	public void setApplicationClientId(String applicationClientId) {
		this.applicationClientId = applicationClientId;
	}

	/**
	 * Gets the serialversionuid.
	 *
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
