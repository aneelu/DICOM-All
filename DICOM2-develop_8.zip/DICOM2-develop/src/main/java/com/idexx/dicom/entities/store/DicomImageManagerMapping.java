/**
 * 
 */
package com.idexx.dicom.entities.store;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author vkandagatla
 * 
 */
@Entity
@Table(name = "dcm_im_mappings")
public class DicomImageManagerMapping implements Serializable {

    private static final long serialVersionUID = 7996514120543366413L;
    private int fieldId;
    private int dcmTagId;
    private String imFieldName;
    private int fieldEnabled;
    private String fieldFormat;
    private String defaultValue;
    private String description;

    @Id
    @Column(name = "ID")
    public int getFieldId() {
        return fieldId;
    }

    public void setFieldId(final int fieldId) {
        this.fieldId = fieldId;
    }

    @Column(name = "DCM_TAG_ID")
    public int getDcmTagId() {
        return dcmTagId;
    }

    public void setDcmTagId(final int dcmFieldName) {
        this.dcmTagId = dcmFieldName;
    }

    @Column(name = "IM_FIELD_NAME")
    public String getImFieldName() {
        return imFieldName;
    }

    public void setImFieldName(final String imFieldName) {
        this.imFieldName = imFieldName;
    }

    @Column(name = "Enabled")
    public int getFieldEnabled() {
        return fieldEnabled;
    }

    public void setFieldEnabled(final int fieldEnabled) {
        this.fieldEnabled = fieldEnabled;
    }

    @Column(name = "Field_Format")
    public String getFieldFormat() {
        return fieldFormat;
    }

    public void setFieldFormat(final String fieldFormat) {
        this.fieldFormat = fieldFormat;
    }

    /**
     * @return the defaultValue
     */
    @Column(name = "DEFAULT_VALUE")
    public String getDefaultValue() {
        return defaultValue;
    }

    /**
     * @param defaultValue
     *            the defaultValue to set
     */
    public void setDefaultValue(final String defaultValue) {
        this.defaultValue = defaultValue;
    }

    /**
     * @return the description
     */
    @Column(name = "DESCRIPTION")
    public String getDescription() {
        return description;
    }

    /**
     * @param description
     *            the description to set
     */
    public void setDescription(final String description) {
        this.description = description;
    }
}
