package com.idexx.dicom.domain;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(Client.class)
public abstract class Client_ {

	public static volatile SingularAttribute<Client, String> firstName;
	public static volatile SingularAttribute<Client, String> lastName;
	public static volatile SingularAttribute<Client, String> applicationClientId;
	public static volatile SingularAttribute<Client, String> iD;
	public static volatile SingularAttribute<Client, String> email;
	public static volatile SingularAttribute<Client, String> sapId;

}

