/**
 * 
 */

package com.idexx.dicom.services.dto.v13;

import javax.xml.bind.annotation.XmlElement;

import org.apache.commons.lang.StringUtils;


/**
 * <pre>AETitleDTO hold information About aeTitle and instituteName</pre>
 * @author smallela
 * @version 1.3
 */
public class AETitleDTO {
    
	private String apiKey;
	
	private String aeTitle;
    
    private String instituteName;
    private String modalityTypeCode;
    
    /**
     * @return the apiKey
     */
    @XmlElement(nillable = true, required = true)
    public String getApiKey() {
        return apiKey;
    }

    /**
     * @param apiKey
     *            the apiKey to set
     */
    public void setApiKey(final String apiKey) {
        this.apiKey = apiKey;
    }
    
    /**
     * @return the instituteName
     */
    public  String getInstituteName() {
        return instituteName;
    }
    
    /**
     * @param instituteName
     *            the instituteName to set
     */
    public  void setInstituteName(final String instituteName) {
        this.instituteName = StringUtils.trimToNull(instituteName);
    }
    
    /**
     * @return the aeTitle
     */
    @XmlElement(nillable = true, required = true)
    public String getAeTitle() {
        return aeTitle;
    }
    
    /**
     * @param aeTitle
     *            the aeTitle to set
     */
    public void setAeTitle(final String aeTitle) {
        this.aeTitle = StringUtils.trimToNull(aeTitle);
    }

    public String getModalityTypeCode() {
	return modalityTypeCode;
    }

    public void setModalityTypeCode(String modalityTypeCode) {
	this.modalityTypeCode = modalityTypeCode;
    }
    
}

