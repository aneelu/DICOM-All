/**
 * Provides Frequency for Scheduler
 */
package com.idexx.dicom.sendimage;

/**
 * @author vkandagatla
 * 
 */
public interface SchedulerFrequencyProvider {
    String SLEEP_TIME = "quartzSleepTime";
    int DEFAULT_FREQUENCY = 60000;
    
    int getFrequency();
}
