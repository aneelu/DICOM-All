/**
 * 
 */
package com.idexx.dicom.dao.ws;

import java.util.Date;
import java.util.List;

import com.idexx.dicom.ae.entities.IdexxDicomServiceFailureLog;

/**
 * @author anarayana
 * 
 */
public interface FailureServiceDao {
	List<IdexxDicomServiceFailureLog> getFailureLog(Date startDate, Date endDate);

	List<IdexxDicomServiceFailureLog> getFailureLogErrorMessages(Date startDate,
			Date endDate, String aeTitle, String instituteName, String errorType);
}
