/**
 * Concrete class downloadDicom file from S3
 */
package com.idexx.dicom.retrieve.download.impl;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.idexx.dicom.retrieve.download.DownloadImageFromS3;
// TODO: Auto-generated Javadoc

/**
 * The Class DownloadImageFromS3Impl.
 *
 * @author apinninti
 */
@Component
public class DownloadImageFromS3Impl implements DownloadImageFromS3 {

	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(DownloadImageFromS3Impl.class);

	/**
	 * Download Imae file from Cloud.
	 *
	 * @param preSignedUrl
	 *            the pre signed url
	 * @param fileName
	 *            the file name
	 * @return true, if successful
	 * @throws Exception
	 *             the exception
	 */
	@Override
	public final boolean downloadDicomImageFileFromCloud(final String preSignedUrl, final String fileName)
			throws Exception {
		boolean successful = downloadFile(preSignedUrl, fileName);
		LOG.info(fileName + " Download " + successful);
		return successful;
	}

	/**
	 * Download file.
	 *
	 * @param url
	 *            the url
	 * @param filename
	 *            the filename
	 * @return true, if successful
	 * @throws Exception
	 *             the exception
	 */
	public final boolean downloadFile(final String url, final String filename) throws Exception {
		boolean isSuccess = false;
		DefaultHttpClient httpClient = null;
		ByteArrayOutputStream byteOutStream = null;
		FileOutputStream outStream = null;
		BufferedInputStream bufferedInputStream = null;
		try {
			outStream = new FileOutputStream(filename);
			httpClient = new DefaultHttpClient();
			HttpGet getRequest = new HttpGet(url);
			// check responsecode and failed response throw exception
			HttpResponse response = httpClient.execute(getRequest);
			if (response.getStatusLine().getStatusCode() != HTTP_SUCCESS_STATUS_CODE) {
				throw new Exception("Failed : HTTP error code : " + response.getStatusLine().getStatusCode());
			}

			byteOutStream = new ByteArrayOutputStream();
			bufferedInputStream = new BufferedInputStream(response.getEntity().getContent());

			byte[] bytes = new byte[DOWNLOAD_BUFFER_SIZE];
			int count = 0;

			while ((count = bufferedInputStream.read(bytes, 0, DOWNLOAD_BUFFER_SIZE)) != -1) {
				byteOutStream.write(bytes, 0, count);
			}
			byteOutStream.writeTo(outStream);
			byteOutStream.flush();
			isSuccess = true;

		} catch (ClientProtocolException cpe) {
			LOG.error(cpe.getLocalizedMessage(), cpe);
		} catch (IOException ioe) {
			LOG.error(ioe.getLocalizedMessage(), ioe);
		} finally {
			closeHttpClient(httpClient, byteOutStream, outStream, bufferedInputStream);
		}

		return isSuccess;

	}

	/**
	 * <pre>
	 * Add description for the method
	 * </pre>
	 * 
	 * .
	 *
	 * @param httpClient
	 *            the http client
	 * @param byteOutStream
	 *            the byte out stream
	 * @param outStream
	 *            the out stream
	 * @param bufferedInputStream
	 *            the bis
	 */
	private void closeHttpClient(DefaultHttpClient httpClient, ByteArrayOutputStream byteOutStream,
			FileOutputStream outStream, BufferedInputStream bufferedInputStream) {
		try {
			httpClient.getConnectionManager().shutdown();
		} catch (Exception gex) {
			LOG.error(gex.getLocalizedMessage(), gex);
		}
		if (bufferedInputStream != null) {
			try {
				bufferedInputStream.close();
			} catch (Exception gex) {
				LOG.error(gex.getLocalizedMessage(), gex);
			}
		}
		if (byteOutStream != null) {
			try {
				byteOutStream.close();
			} catch (Exception gex) {
				LOG.error(gex.getLocalizedMessage(), gex);
			}
		}
		try {
			outStream.close();
		} catch (Exception gex) {
			LOG.error(gex.getLocalizedMessage(), gex);
		}
	}

}
