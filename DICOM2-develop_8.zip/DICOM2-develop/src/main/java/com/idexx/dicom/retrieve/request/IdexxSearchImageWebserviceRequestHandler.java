/**
 *  C-Get request handler class
 */
package com.idexx.dicom.retrieve.request;

import java.util.List;

import org.dcm4che3.data.Attributes;

import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;
/**
 * @author apinninti
 * 
 */
public interface IdexxSearchImageWebserviceRequestHandler {
    
    List<String> idexxSearchImageService(Attributes dataset, String requestingAETILE) throws IdexxServiceException_Exception;
    String getBaseDir();
}
