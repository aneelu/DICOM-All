package com.idexx.dicom.query.response.impl;

import javax.xml.bind.JAXBElement;

import org.apache.log4j.Logger;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;
import org.dcm4che3.data.VR;
import org.springframework.stereotype.Component;

import com.idexx.dicom.query.response.QueryResponseHandler;
import com.idexx.dicom.query.soap.QRDataSet;

// TODO: Auto-generated Javadoc
/**
 * Implemented query response handler.
 *
 * @author vvanjarana
 * @version 1.3
 */
@Component
public class QueryResponseHandlerImpl implements QueryResponseHandler {

	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(QueryResponseHandlerImpl.class);

	/** The rsp data. */
	private Attributes rspData = new Attributes();

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.idexx.dicom.query.response.QueryResponseHandler#getDicomDataset(com.
	 * idexx.dicom.query.soap.QRDataSet)
	 */
	@Override
	public final Attributes getDicomDataset(final QRDataSet qrDataSet) {

		if (qrDataSet.getQueryLevel() != null) {
			rspData.setString(Tag.QueryRetrieveLevel, VR.CS, qrDataSet.getQueryLevel().value());
		}
		if (qrDataSet.getPatientName() != null) {
			try {
				createRspData(Tag.PatientName, VR.PN, qrDataSet.getPatientName());
			} catch (Exception exp) {
				rspData.setString(Tag.PatientName, VR.PN, "UNKNOWN");
				LOG.error("Exception is " + exp);
			}
		}
		createRspData(Tag.SpecificCharacterSet, VR.CS, qrDataSet.getCharset());
		createRspData(Tag.StudyDate, VR.DA, qrDataSet.getStudyDate());
		createRspData(Tag.StudyTime, VR.TM, qrDataSet.getStudyTime());
		createRspData(Tag.AccessionNumber, VR.SH, qrDataSet.getAccessionNumber());
		createRspData(Tag.InstanceNumber, VR.IS, qrDataSet.getInstanceNumber());
		createRspData(Tag.ModalitiesInStudy, VR.CS, qrDataSet.getModalitiesInStudy());
		createRspData(Tag.StudyDescription, VR.LO, qrDataSet.getStudyDescription());
		createRspData(Tag.PatientID, VR.LO, qrDataSet.getPatientID());
		createRspData(Tag.PatientBirthDate, VR.DA, qrDataSet.getDateOfBirth());
		createRspData(Tag.PatientSex, VR.CS, qrDataSet.getSex());
		createRspData(Tag.StudyInstanceUID, VR.UI, qrDataSet.getStudyUID());
		createRspData(Tag.Modality, VR.CS, qrDataSet.getModality());
		createRspData(Tag.ReferringPhysicianName, VR.PN, qrDataSet.getReferringPhysicianDICOM());
		createRspData(Tag.SeriesNumber, VR.IS, qrDataSet.getSeriesNumber());
		createRspData(Tag.SeriesInstanceUID, VR.UI, qrDataSet.getSeriesUID());
		createRspData(Tag.StudyID, VR.SH, qrDataSet.getStudyID());
		createRspData(Tag.NumberOfPatientRelatedStudies, VR.IS, qrDataSet.getStudiesInPatient());
		createRspData(Tag.NumberOfPatientRelatedSeries, VR.IS, qrDataSet.getSeriesInPatient());
		createRspData(Tag.NumberOfPatientRelatedInstances, VR.IS, qrDataSet.getInstancesInPatient());
		createRspData(Tag.NumberOfStudyRelatedSeries, VR.IS, qrDataSet.getSeriesInStudy());
		createRspData(Tag.NumberOfStudyRelatedInstances, VR.IS, qrDataSet.getSeriesInStudy());
		createRspData(Tag.NumberOfSeriesRelatedInstances, VR.IS, qrDataSet.getInstancesInSeries());

		return rspData;

	}

	/**
	 * creating attributes field for query retrieval.
	 *
	 * @param tag
	 *            the tag
	 * @param valueRep
	 *            the value rep
	 * @param elem
	 *            the elem
	 */
	public void createRspData(final int tag, final VR valueRep, final JAXBElement<String> elem) {
		if (elem != null) {
			rspData.setString(tag, valueRep, elem.getValue());
		}
	}
}
