/**
 * 
 */
package com.idexx.dicom.dto;

import java.util.List;

import com.idexx.imaging.imagemanager.soap.SeriesDTO;
import com.idexx.imaging.imagemanager.soap.StudyDTO;

/**
 * @author vkandagatla
 *
 */
public class StudyDTOTest extends StudyDTO {
    private List<SeriesDTO> series;

    /**
     * @return the series
     */
    @Override
    public final List<SeriesDTO> getSeries() {
        return series;
    }

    /**
     * @param series
     *            the series to set
     */
    public final void setSeries(final List<SeriesDTO> series) {
        this.series = series;
    }
}
