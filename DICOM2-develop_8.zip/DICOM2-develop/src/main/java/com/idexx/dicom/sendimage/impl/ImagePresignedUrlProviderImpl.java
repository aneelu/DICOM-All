/**
 * 
 */
package com.idexx.dicom.sendimage.impl;

import static com.idexx.dicom.sendimage.SendImageJobConstants.DEFAULT_IMG_MGR_API_KEY;
import static com.idexx.dicom.sendimage.SendImageJobConstants.IMG_MGR_API_KEY_CONFIG_VALUE;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.entities.BaseDicomImPluginConfig;
import com.idexx.dicom.dao.ws.DicomConfigDao;
import com.idexx.dicom.sendimage.ImageManagerStoreServiceProviderWraper;
import com.idexx.dicom.sendimage.ImagePresignedUrlProvider;
import com.idexx.imaging.imagemanager.soap.IDEXXImageManagerServices;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;
import com.idexx.imaging.imagemanager.soap.PatientDTO;
import com.idexx.imaging.imagemanager.soap.SearchRequestDTO;

/**
 * @author vkandagatla
 * 
 */
@Service
public class ImagePresignedUrlProviderImpl implements ImagePresignedUrlProvider {

	private static final Logger LOG = Logger.getLogger(ImagePresignedUrlProviderImpl.class);

	@Autowired
	private DicomConfigDao configDao;

	@Autowired
	private ImageManagerStoreServiceProviderWraper imageManageStoreServiceProviderWraper;

	/**
	 * 
	 */
	public ImagePresignedUrlProviderImpl() {
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.idexx.dicom.sendimage.ImagePresignedUrlProvider#getPresignedUrl(java
	 * .lang.String)
	 */
	@Override
	public final PatientDTO getPresignedUrl(final String imageAssetId) throws SendImageException {
		PatientDTO patientDTO = null;
		try {
			String apiKey = getDefaultStringConfigValue(IMG_MGR_API_KEY_CONFIG_VALUE, DEFAULT_IMG_MGR_API_KEY);
			IDEXXImageManagerServices idexxImageManagerServices = imageManageStoreServiceProviderWraper.getService();
			SearchRequestDTO searchRequestDTO = new SearchRequestDTO();
			searchRequestDTO.setApiKey(apiKey);
			searchRequestDTO.setRetrieveImage(true);
			searchRequestDTO.setImageAssetId(imageAssetId);
			List<PatientDTO> patientList = idexxImageManagerServices.searchImage(searchRequestDTO);
			if (patientList.isEmpty()) {
				throw new SendImageException("Image associated with given AssetId either unavailable or deleted");
			}
			patientDTO = patientList.get(0);
		} catch (IdexxServiceException_Exception exp) {
			LOG.error(exp.getLocalizedMessage(), exp);
			throw new SendImageException("Image associated with given AssetId either unavailable or deleted");
		}
		return patientDTO;
	}

	/**
	 * @return
	 */
	private String getDefaultStringConfigValue(final String key, final String defaultValue) {
		LOG.info("Getting " + key + " CONFIG VALUE");
		String defaultVal = defaultValue;
		BaseDicomImPluginConfig config = configDao.getConfig(key);

		String configValue = config.getConfigValue();
		if (!StringUtils.isEmpty(configValue)) {
			defaultVal = configValue;
		}
		LOG.info("RESULT CONFIG VALUE FOR KEY: " + key + " IS: " + defaultVal);
		return defaultVal;
	}
}
