/**
 * 
 */
package com.idexx.dicom.services.dto.v12;

import javax.xml.bind.annotation.XmlElement;

import org.apache.commons.lang.StringUtils;

/**
 * @author vkandagatla
 * 
 */
public class CreateAETitleDTO extends ReadAETitleDTO {

    private boolean identifiedByAeTitleOnly;

    private String hostName;

    private int port;

    private boolean dvmSpecialist = false;

    /**
     * @return the dvmSpecialist
     */
    @XmlElement(nillable = true, required = true)
    public final boolean isDvmSpecialist() {
        return dvmSpecialist;
    }

    /**
     * @param dvmSpecialist
     *            the dvmSpecialist to set
     */
    public final void setDvmSpecialist(final boolean dvmSpecialist) {
        this.dvmSpecialist = dvmSpecialist;
    }

    /**
     * @return the hostName
     */
    public final String getHostName() {
        return hostName;
    }

    /**
     * @param hostName
     *            the hostName to set
     */
    public final void setHostName(final String hostName) {
        this.hostName = StringUtils.trimToNull(hostName);
    }

    /**
     * @return the port
     */
    public final int getPort() {
        return port;
    }

    /**
     * @param port
     *            the port to set
     */
    public final void setPort(final int port) {
        this.port = port;
    }

    /**
     * @return the identifiedByAeTitleOnly
     */
    @XmlElement(nillable = true, required = true)
    public final boolean isIdentifiedByAeTitleOnly() {
        return identifiedByAeTitleOnly;
    }

    /**
     * @param identifiedByAeTitleOnly
     *            the identifiedByAeTitleOnly to set
     */
    public final void setIdentifiedByAeTitleOnly(final boolean identifiedByAeTitleOnly) {
        this.identifiedByAeTitleOnly = identifiedByAeTitleOnly;
    }
}
