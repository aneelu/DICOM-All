package com.idexx.dcm4che3.tool.dcmqrscp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.DateRange;
import org.dcm4che3.data.Sequence;
import org.dcm4che3.data.Tag;
import org.dcm4che3.data.VR;
import org.dcm4che3.net.Association;
import org.dcm4che3.net.pdu.PresentationContext;
import org.dcm4che3.net.service.BasicQueryTask;
import org.dcm4che3.net.service.DicomServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.idexx.dicom.domain.ExternalPatient;
import com.idexx.dicom.domain.MPPSNCreate;
import com.idexx.dicom.domain.Owner;
import com.idexx.dicom.domain.Patient;
import com.idexx.dicom.domain.RequestDetails;
import com.idexx.dicom.services.IdexxDicomServiceConstants;
import com.idexx.dicom.services.mwl.MWLCFindServiceImpl;
import com.idexx.dicom.services.requestservice.dto.MWLCFindResponseDTO;
import com.idexx.dicom.services.requestservice.dto.SearchDetailsDTO;
import com.idexx.imaging.imagemanager.soap.ExternalPatientIdDTO;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;

// TODO: Auto-generated Javadoc
/**
 * MWL CFIND DICOM Service.
 *
 * @author rkaranam
 * @version 1.3
 */
public class IdexxPatientQueryTask extends BasicQueryTask {

	/** The availability. */
	protected final String availability;

	/** The calling ae title. */
	protected final String callingAeTitle;

	/** The Constant LOG. */
	private static final Logger LOG = LoggerFactory.getLogger(IdexxPatientQueryTask.class);

	/** The c find responses. */
	private List<MWLCFindResponseDTO> cFindResponses;

	/**
	 * Gets the c find responses.
	 *
	 * @return the c find responses
	 */
	public List<MWLCFindResponseDTO> getcFindResponses() {
		return cFindResponses;
	}

	/**
	 * Sets the c find responses.
	 *
	 * @param cFindResponses
	 *            the new c find responses
	 */
	public void setcFindResponses(final List<MWLCFindResponseDTO> cFindResponses) {
		this.cFindResponses = cFindResponses;
	}

	/** The mwl c find service. */
	@Autowired
	private MWLCFindServiceImpl mwlCFindService;

	/**
	 * Instantiates a new idexx patient query task.
	 *
	 * @param association
	 *            the association
	 * @param presentationContext
	 *            the presentation context
	 * @param requestAttributes
	 *            the request attributes
	 * @param keys
	 *            the keys
	 * @param availability
	 *            the availability
	 * @param callingAETitle
	 *            the calling ae title
	 */
	public IdexxPatientQueryTask(Association association, PresentationContext presentationContext,
			Attributes requestAttributes, final Attributes keys, final String availability,
			final String callingAETitle) {
		super(association, presentationContext, requestAttributes, keys);
		this.availability = availability;
		callingAeTitle = callingAETitle;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.dcm4che3.net.service.BasicQueryTask#hasMoreMatches()
	 */
	@Override
	public boolean hasMoreMatches() throws DicomServiceException {
		return !cFindResponses.isEmpty();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.dcm4che3.net.service.BasicQueryTask#nextMatch()
	 */
	@Override
	public Attributes nextMatch() throws DicomServiceException {

		LOG.debug("MWL C-Find nextMatch() is invoked");

		MWLCFindResponseDTO response = cFindResponses.get(0);
		Attributes attrs = new Attributes(2);
		Attributes seqAttributes = new Attributes(2);

		attrs.setString(Tag.StudyInstanceUID, VR.LO, response.getStudyInstanceUID());
		attrs.setString(Tag.PatientID, VR.LO, response.getApplicationPatientId());
		attrs.setString(Tag.PatientName, VR.PN, response.getPatientName());
		attrs.setDate(Tag.PatientBirthDate, VR.DA, response.getDateOfBirth());
		attrs.setString(Tag.PatientSex, VR.CS, response.getGender());
		attrs.setString(Tag.PatientSpeciesDescription, VR.LO, response.getSpecies());
		attrs.setString(Tag.PatientBreedDescription, VR.LO, response.getBreed());
		attrs.setString(Tag.PatientWeight, VR.DS, String.valueOf(response.getWeight()));

		attrs.setString(Tag.ResponsiblePerson, VR.PN,
				response.getResponsiblePeron() == null ? "" : response.getResponsiblePeron());
		attrs.setString(Tag.ResponsibleOrganization, VR.LO, response.getResponsibleOrganization());

		attrs.setString(Tag.Modality, VR.CS, response.getModality());
		attrs.setString(Tag.AccessionNumber, VR.SH, response.getAccessionNumber());

		attrs.setString(Tag.RequestedProcedureID, VR.SH, "");
		attrs.setString(Tag.RequestedProcedureDescription, VR.LO, response.getRequestedProcedureDescription());

		Sequence otherPatientSeq = attrs.ensureSequence(Tag.OtherPatientIDsSequence, 2);

		for (ExternalPatientIdDTO dto : response.getExternalPatientIdDTO()) {
			Attributes otherPatientIdsAttributes = new Attributes(2);
			otherPatientIdsAttributes.setString(Tag.PatientID, VR.LO, dto.getPimsPatientId());
			otherPatientIdsAttributes.setString(Tag.IssuerOfPatientID, VR.LO, dto.getIssuerOfPatientId());
			otherPatientSeq.add(otherPatientIdsAttributes);
		}

		Sequence seq = attrs.ensureSequence(Tag.ScheduledProcedureStepSequence, 2);
		seqAttributes.setDate(Tag.ScheduledProcedureStepStartDate, VR.DA,
				response.getScheduledProcedureStepStartDate());
		seqAttributes.setString(Tag.ScheduledProcedureStepID, VR.SH, response.getScheduledProcedureStepId());
		seqAttributes.setString(Tag.ScheduledProcedureStepStatus, VR.CS, response.getScheduledProcedureStepStatus());
		seqAttributes.setString(Tag.Modality, VR.CS, response.getModality());

		seq.add(seqAttributes);

		cFindResponses.remove(0);
		return attrs;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.dcm4che3.net.service.BasicQueryTask#adjust(org.dcm4che3.data.
	 * Attributes)
	 */
	@Override
	protected Attributes adjust(final Attributes match) throws DicomServiceException {

		Attributes adjust = super.adjust(match);
		adjust.remove(Tag.DirectoryRecordType);
		if (keys.contains(Tag.SOPClassUID)) {
			adjust.setString(Tag.SOPClassUID, VR.UI, match.getString(Tag.ReferencedSOPClassUIDInFile));
		}
		if (keys.contains(Tag.SOPInstanceUID)) {
			adjust.setString(Tag.SOPInstanceUID, VR.UI, match.getString(Tag.ReferencedSOPInstanceUIDInFile));
		}
		adjust.setString(Tag.QueryRetrieveLevel, VR.CS, keys.getString(Tag.QueryRetrieveLevel));
		adjust.setString(Tag.RetrieveAETitle, VR.AE, as.getCalledAET());
		if (availability != null) {
			adjust.setString(Tag.InstanceAvailability, VR.CS, availability);
		}
		adjust.setString(Tag.StorageMediaFileSetID, VR.SH, "FileSetID");
		adjust.setString(Tag.StorageMediaFileSetUID, VR.UI, "FileSetUID");
		match.setString(Tag.SOPClassUID, VR.UI, match.getString(Tag.ReferencedSOPClassUIDInFile));
		match.setString(Tag.SOPInstanceUID, VR.UI, match.getString(Tag.ReferencedSOPInstanceUIDInFile));

		return adjust;

	}

	/**
	 * Load requests.
	 *
	 * @param keys
	 *            the keys
	 * @throws IdexxServiceException_Exception
	 *             the idexx service exception_ exception
	 * @throws DicomServiceException
	 *             the dicom service exception
	 */
	public void loadRequests(Attributes keys) throws IdexxServiceException_Exception, DicomServiceException {

		LOG.debug("MWL C-Find loadRequests is invoked");

		cFindResponses = new ArrayList<MWLCFindResponseDTO>();

		String patientName = getPatientName(
				(null == keys.getString(Tag.PatientName)) ? "" : keys.getString(Tag.PatientName));

		List<String> modalities = Arrays
				.asList(keys.getNestedDataset(Tag.ScheduledProcedureStepSequence).getStrings(Tag.Modality));

		List<String> status = Arrays.asList(
				keys.getNestedDataset(Tag.ScheduledProcedureStepSequence).getStrings(Tag.ScheduledProcedureStepStatus));

		String sapId = getSapIdFromAeTitle();

		List<RequestDetails> mwlCFindRequests = null;

		DateRange sequenceDateRange = keys.getNestedDataset(Tag.ScheduledProcedureStepSequence)
				.getDateRange(Tag.ScheduledProcedureStepStartDate);

		SearchDetailsDTO searchDetails = getSearchDetailsDTO(keys, patientName, modalities, status, sequenceDateRange,
				sapId);

		mwlCFindRequests = mwlCFindService.findRequestDetails(searchDetails);

		MWLCFindResponseDTO response;

		for (RequestDetails req : mwlCFindRequests) {
			response = new MWLCFindResponseDTO();
			Patient patientDetails = req.getPatient();
			List<ExternalPatient> extPatients = patientDetails.getExternalPatientIds();
			List<ExternalPatientIdDTO> extPatientDTOs = mwlCFindService.getExternalPatientIdList(extPatients);

			response.setPatientId(patientDetails.getID());
			response.setPatientName(patientDetails.getPatientName());
			response.setDateOfBirth(patientDetails.getDob());
			response.setBreed(patientDetails.getBreed());
			response.setGender(patientDetails.getGender());
			response.setApplicationPatientId(patientDetails.getApplicationPatientId());
			response.setWeight(patientDetails.getWeight());

			response.setStudyInstanceUID(req.getStudyInstanceUID());
			response.setModality(req.getModality());
			response.setAccessionNumber(req.getAccessionNumber());
			response.setRequestedProcedureDescription(req.getRequestNotes());
			response.setExternalPatientIdDTO(extPatientDTOs);

			response.setResponsibleOrganization("");
			response.setScheduledProcedureStepId("");
			response.setScheduledProcedureStepStartDate(req.getCreateTimeStamp());
			if (req.getStatus().equalsIgnoreCase(IdexxDicomServiceConstants.MPPS_REQUEST_STATUS_PENDING)) {
				response.setScheduledProcedureStepStatus(IdexxDicomServiceConstants.MPPS_REQUEST_STATUS_SCHEDULED);
			} else {
				List<MPPSNCreate> sequenceData = mwlCFindService.findSequence(req.getStudyInstanceUID());
				if (null != sequenceData && !sequenceData.isEmpty()) {
					response.setScheduledProcedureStepStatus(sequenceData.get(0).getPerformedProcedureStepStatus());
				} else {
					response.setScheduledProcedureStepStatus("");
				}
			}
			Set<Owner> owners = patientDetails.getOwnersWithPatient();
			if (null != owners && !owners.isEmpty()) {
				String clientFirstName = "";
				for (Owner o : owners) {
					clientFirstName = o.getClient().getFirstName();
				}
				response.setResponsiblePeron(patientDetails.getPatientName() + "^" + clientFirstName);
			}

			cFindResponses.add(response);
		}
		LOG.info("C-FIND success");
	}

	/**
	 * Gets the sap id from ae title.
	 *
	 * @return the sap id from ae title
	 * @throws DicomServiceException
	 *             the dicom service exception
	 */
	private String getSapIdFromAeTitle() throws DicomServiceException {
		String sapId = "";
		int exceptionStatus = 0x0106;

		List<String> distinctAeTitle = mwlCFindService.findDistinctAeTitleBySapId(callingAeTitle);
		if (distinctAeTitle != null && distinctAeTitle.size() == 1) {
			sapId = distinctAeTitle.get(0);
		} else {
			LOG.error("Unable to find single sapId for given AE Title " + callingAeTitle);
			DicomServiceException exc = new DicomServiceException(exceptionStatus,
					"Unable to find single sapId for given AE Title " + callingAeTitle);
			throw exc;
		}
		return sapId;
	}

	/**
	 * Gets the search details dto.
	 *
	 * @param keys
	 *            the keys
	 * @param patientName
	 *            the patient name
	 * @param modalities
	 *            the modalities
	 * @param status
	 *            the status
	 * @param sequenceDateRange
	 *            the sequence date range
	 * @param sapId
	 *            the sap id
	 * @return the search details dto
	 */
	private SearchDetailsDTO getSearchDetailsDTO(final Attributes keys, final String patientName,
			final List<String> modalities, final List<String> status, final DateRange sequenceDateRange,
			final String sapId) {
		SearchDetailsDTO searchDetails = new SearchDetailsDTO();
		searchDetails.setPatientId(keys.getString(Tag.PatientID));
		searchDetails.setPatientName(patientName);
		searchDetails.setModalities(modalities);
		searchDetails.setStatus(status);
		searchDetails.setSapId(sapId);

		if (null != sequenceDateRange
				&& (null != sequenceDateRange.getStartDate() && null != sequenceDateRange.getEndDate())) {
			searchDetails.setStartDate(sequenceDateRange.getStartDate());
			searchDetails.setEndDate(sequenceDateRange.getEndDate());
		}
		return searchDetails;
	}

	/**
	 * Gets the patient name.
	 *
	 * @param namePattern
	 *            the name pattern
	 * @return the patient name
	 */
	private String getPatientName(final String namePattern) {
		String patientName = "";
		LOG.info("Patient name from modality : " + namePattern);
		String patientNameAfterRegex = namePattern.replaceAll("[^A-Z|^a-z]", "").replaceFirst("\\^", "");
		Matcher patientNameMatchers = Pattern.compile(patientNameAfterRegex).matcher(patientNameAfterRegex);
		if (patientNameMatchers.find()) {
			patientName = patientNameMatchers.group(0);
			LOG.info("Patient name after regex : " + patientName);
		}
		return patientName;
	}

}
