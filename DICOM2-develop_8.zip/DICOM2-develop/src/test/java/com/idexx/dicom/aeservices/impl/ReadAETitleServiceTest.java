/**
 * 
 */
package com.idexx.dicom.aeservices.impl;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.validator.impl.AbstractAETitleValidator;
import com.idexx.dicom.constants.IdexxDicomTestConstants;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.dto.AETitleDTO;
import com.idexx.dicom.services.dto.ReadAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

// TODO: Auto-generated Javadoc
/**
 * The Class ReadAETitleServiceTest.
 *
 * @author smallela
 * @version 1.3
 */
public class ReadAETitleServiceTest {

	/** The service. */
	@InjectMocks
	private ReadAETitleService service = new ReadAETitleService();

	/** The validator. */
	@Mock
	private AbstractAETitleValidator validator;

	/** The ae title dao. */
	@Mock
	private AETitleDao aeTitleDao;

	/** The read ae title dto. */
	ReadAETitleDTO readAETitleDTO = new ReadAETitleDTO();

	/** The registered ae list. */
	List<AETitle> registeredAEList = new ArrayList<AETitle>();

	/** The ae title. */
	AETitle aeTitle = new AETitle();

	/** The current timestamp. */
	java.sql.Timestamp currentTimestamp;

	/**
	 * Sets the up.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Before
	public void setUp() throws Exception {

		Calendar calendar = Calendar.getInstance();
		java.util.Date now = calendar.getTime();
		currentTimestamp = new java.sql.Timestamp(now.getTime());

		aeTitle.setAeTitle(IdexxDicomTestConstants.AETITLE);
		aeTitle.setInstituteName(IdexxDicomTestConstants.INSTITUTENAME);
		aeTitle.setApiKey(IdexxDicomTestConstants.APIKEY);
		aeTitle.setEnabled(true);
		registeredAEList.add(aeTitle);
		aeTitle.setCreatedDateTime(currentTimestamp);
		aeTitle.setLastAccessedDateTime(currentTimestamp);

		readAETitleDTO.setAeTitle(aeTitle.getAeTitle());
		readAETitleDTO.setInstituteName(aeTitle.getInstituteName());
		readAETitleDTO.setSapId(aeTitle.getSapId());

		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test validate.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public void testValidate() throws IdexxDicomAEConfigServiceException {

		when(validator.validate(any(AETitleDTO.class))).thenReturn(1);
		int val = service.validate(readAETitleDTO);
		assertTrue("Read AE Failed#1", 1 == val);
	}

	/**
	 * Test do service.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public void testDoService() throws IdexxDicomAEConfigServiceException {

		ReadAETitleDTO readAETitleDTO = new ReadAETitleDTO();
		readAETitleDTO.setAeTitle(IdexxDicomTestConstants.AETITLE);
		int val = service.getQueryCase(readAETitleDTO);
		assertTrue("Read AE Failed#2", 1 == val);
	}

	/**
	 * Test do service2.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public void testDoService2() throws IdexxDicomAEConfigServiceException {

		final int expectedResult = 3;
		ReadAETitleDTO readAETitleDTO = new ReadAETitleDTO();
		readAETitleDTO.setAeTitle(IdexxDicomTestConstants.AETITLE);
		readAETitleDTO.setInstituteName(IdexxDicomTestConstants.INSTITUTENAME);
		int val = service.getQueryCase(readAETitleDTO);
		assertTrue("Read AE Failed#3", expectedResult == val);
	}

	/**
	 * Test do service2a.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public void testDoService2a() throws IdexxDicomAEConfigServiceException {

		final int expectedResult = 4;
		ReadAETitleDTO readAETitleDTO = new ReadAETitleDTO();
		readAETitleDTO.setSapId(IdexxDicomTestConstants.SAPID);
		int val = service.getQueryCase(readAETitleDTO);
		assertTrue("Read AE Failed#4", expectedResult == val);
	}

	/**
	 * Test do service3.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public void testDoService3() throws IdexxDicomAEConfigServiceException {

		final int expectedResult = 5;
		ReadAETitleDTO readAETitleDTO = new ReadAETitleDTO();
		readAETitleDTO.setAeTitle(IdexxDicomTestConstants.AETITLE);
		readAETitleDTO.setSapId(IdexxDicomTestConstants.SAPID);
		int val = service.getQueryCase(readAETitleDTO);
		assertTrue("Read AE Failed#5", expectedResult == val);
	}

	/**
	 * Test do service4.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public void testDoService4() throws IdexxDicomAEConfigServiceException {

		final int expectedResult = 6;
		ReadAETitleDTO readAETitleDTO = new ReadAETitleDTO();
		readAETitleDTO.setSapId(IdexxDicomTestConstants.SAPID);
		readAETitleDTO.setInstituteName(IdexxDicomTestConstants.INSTITUTENAME);
		int val = service.getQueryCase(readAETitleDTO);
		assertTrue("Read AE Failed#6", expectedResult == val);
	}

	/**
	 * Test do service5.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public void testDoService5() throws IdexxDicomAEConfigServiceException {

		final int expectedResult = 7;
		ReadAETitleDTO readAETitleDTO = new ReadAETitleDTO();
		readAETitleDTO.setAeTitle(IdexxDicomTestConstants.AETITLE);
		readAETitleDTO.setInstituteName(IdexxDicomTestConstants.INSTITUTENAME);
		readAETitleDTO.setSapId(IdexxDicomTestConstants.SAPID);
		int val = service.getQueryCase(readAETitleDTO);
		assertTrue("Read AE Failed#7", expectedResult == val);
	}

	/**
	 * Test do service6.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public void testDoService6() throws IdexxDicomAEConfigServiceException {

		when(aeTitleDao.findAETitle(IdexxDicomTestConstants.AETITLE)).thenReturn(registeredAEList);
		service.doService(readAETitleDTO);

	}

	/**
	 * Test do service6a.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public void testDoService6a() throws IdexxDicomAEConfigServiceException {

		final List<AETitle> registeredAEList = null;
		when(aeTitleDao.findAETitle(IdexxDicomTestConstants.AETITLE)).thenReturn(registeredAEList);
		service.doService(readAETitleDTO);

	}

	/**
	 * Test do service7.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public void testDoService7() throws IdexxDicomAEConfigServiceException {

		when(aeTitleDao.findAETitle(IdexxDicomTestConstants.AETITLE)).thenThrow(new IdexxDicomAEConfigDbException());
		service.doService(readAETitleDTO);

	}

	/**
	 * Test do service8.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public void testDoService8() throws IdexxDicomAEConfigServiceException {

		when(aeTitleDao.findAETitle(IdexxDicomTestConstants.AETITLE, IdexxDicomTestConstants.INSTITUTENAME)).thenReturn(registeredAEList);
		int val = service.doService(readAETitleDTO);
		assertTrue("Read AE Failed#8", 1 == val);
	}

	/**
	 * Test do service9.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public void testDoService9() throws IdexxDicomAEConfigServiceException {

		aeTitle.setAeTitle(IdexxDicomTestConstants.AETITLE);
		ReadAETitleDTO readAETitleDTO = new ReadAETitleDTO();
		readAETitleDTO.setAeTitle(aeTitle.getAeTitle());
		when(aeTitleDao.findAETitle(IdexxDicomTestConstants.AETITLE)).thenReturn(registeredAEList);
		int val = service.doService(readAETitleDTO);
		assertTrue("Read AE Failed#9", 1 == val);
	}

	/**
	 * Test do service10.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public void testDoService10() throws IdexxDicomAEConfigServiceException {

		aeTitle.setSapId(IdexxDicomTestConstants.SAPID);
		ReadAETitleDTO readAETitleDTO = new ReadAETitleDTO();
		readAETitleDTO.setSapId(aeTitle.getSapId());
		when(aeTitleDao.findAETitleBySapId(IdexxDicomTestConstants.SAPID)).thenReturn(registeredAEList);
		int val = service.doService(readAETitleDTO);
		assertTrue("Read AE Failed#10", 1 == val);
	}

	/**
	 * Test do service11.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public void testDoService11() throws IdexxDicomAEConfigServiceException {

		aeTitle.setAeTitle(IdexxDicomTestConstants.AETITLE);
		aeTitle.setInstituteName(IdexxDicomTestConstants.INSTITUTENAME);
		aeTitle.setSapId(IdexxDicomTestConstants.SAPID);
		ReadAETitleDTO readAETitleDTO = new ReadAETitleDTO();
		readAETitleDTO.setAeTitle(aeTitle.getAeTitle());
		readAETitleDTO.setInstituteName(aeTitle.getInstituteName());
		readAETitleDTO.setSapId(aeTitle.getSapId());
		when(aeTitleDao.findAETitle(IdexxDicomTestConstants.AETITLE, IdexxDicomTestConstants.INSTITUTENAME, IdexxDicomTestConstants.SAPID)).thenReturn(registeredAEList);
		int val = service.doService(readAETitleDTO);
		assertTrue("Read AE Failed#11", 1 == val);
	}

	/**
	 * Test do service12.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public void testDoService12() throws IdexxDicomAEConfigServiceException {

		aeTitle.setInstituteName(IdexxDicomTestConstants.INSTITUTENAME);
		aeTitle.setSapId(IdexxDicomTestConstants.SAPID);
		ReadAETitleDTO readAETitleDTO = new ReadAETitleDTO();
		readAETitleDTO.setInstituteName(aeTitle.getInstituteName());
		readAETitleDTO.setSapId(aeTitle.getSapId());
		when(aeTitleDao.findAETitleBySapIdAndInstituteName(IdexxDicomTestConstants.SAPID, IdexxDicomTestConstants.INSTITUTENAME)).thenReturn(registeredAEList);
		int val = service.doService(readAETitleDTO);
		assertTrue("Read AE Failed#12", 1 == val);
	}

	/**
	 * Test do service13.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public void testDoService13() throws IdexxDicomAEConfigServiceException {

		aeTitle.setAeTitle(IdexxDicomTestConstants.AETITLE);
		aeTitle.setSapId(IdexxDicomTestConstants.SAPID);
		ReadAETitleDTO readAETitleDTO = new ReadAETitleDTO();
		readAETitleDTO.setAeTitle(aeTitle.getAeTitle());
		readAETitleDTO.setSapId(aeTitle.getSapId());
		when(aeTitleDao.findAETitleByAETitleAndSapId(IdexxDicomTestConstants.AETITLE, IdexxDicomTestConstants.SAPID)).thenReturn(registeredAEList);
		int val = service.doService(readAETitleDTO);
		assertTrue("Read AE Failed#13", 1 == val);
	}

	/**
	 * Test do service14.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public void testDoService14() throws IdexxDicomAEConfigServiceException {

		Object obj = service.sendResponse();
		assertTrue("Read AE Failed#14", null == obj);
	}

}
