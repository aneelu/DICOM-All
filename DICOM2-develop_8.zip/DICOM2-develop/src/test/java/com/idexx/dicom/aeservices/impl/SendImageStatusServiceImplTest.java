/**
 * 
 */
package com.idexx.dicom.aeservices.impl;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.ae.validator.IdexxSendImageStatusValidator;
import com.idexx.dicom.aeservices.IdexxDicomWSAthorizationService;
import com.idexx.dicom.constants.IdexxDicomTestConstants;
import com.idexx.dicom.dao.ws.IdexxSendImageJobDao;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.IdexxSendImageJobStatusDTO;
import com.idexx.dicom.services.sendimage.dto.SendImageStatusParamDTO;

// TODO: Auto-generated Javadoc
/**
 * The Class SendImageStatusServiceImplTest.
 *
 * @author smallela
 * @version 1.3
 */
public class SendImageStatusServiceImplTest {

	/** The send image status service. */
	@InjectMocks
	private SendImageStatusServiceImpl sendImageStatusService = new SendImageStatusServiceImpl();

	/** The validator. */
	@Mock
	private IdexxSendImageStatusValidator validator;

	/** The send image job dao. */
	@Mock
	private IdexxSendImageJobDao sendImageJobDao;

	/** The idexx dicom ws authorize service. */
	@Mock
	private IdexxDicomWSAthorizationService idexxDicomWsAuthorizeService;

	/** The output job ids. */
	List<IdexxSendImageJob> outputJobIds = new ArrayList<IdexxSendImageJob>();

	/** The send image job. */
	SendImageStatusParamDTO sendImageJob = new SendImageStatusParamDTO();

	/** The outputjob id1. */
	IdexxSendImageJob outputjobId1 = new IdexxSendImageJob();

	/** The outputjob id2. */
	IdexxSendImageJob outputjobId2 = new IdexxSendImageJob();

	/** The input job ids. */
	List<String> inputJobIds = new ArrayList<String>();

	/** The job ids. */
	List<String> jobIds = new ArrayList<String>();

	/**
	 * Sets the up.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Before
	public void setUp() throws Exception {

		jobIds.add(IdexxDicomTestConstants.JOBID1);
		jobIds.add(IdexxDicomTestConstants.JOBID2);
		jobIds.add(IdexxDicomTestConstants.JOBID3);

		outputjobId1.setJobId(IdexxDicomTestConstants.JOBID1);
		outputjobId2.setJobId(IdexxDicomTestConstants.JOBID2);

		outputJobIds.add(outputjobId1);
		outputJobIds.add(outputjobId2);

		inputJobIds.add(IdexxDicomTestConstants.JOBID1);
		inputJobIds.add(IdexxDicomTestConstants.JOBID2);
		inputJobIds.add(IdexxDicomTestConstants.JOBID3);

		sendImageJob.setJobId(inputJobIds);
		sendImageJob.setApiKey(IdexxDicomTestConstants.APIKEY);

		MockitoAnnotations.initMocks(this);
	}

	/**
	 * Test perform service.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public void testPerformService() throws IdexxDicomAEConfigServiceException {

		when(idexxDicomWsAuthorizeService.authorize(any(String.class))).thenReturn(true);
		when(validator.validate(sendImageJob)).thenReturn(1);
		when(sendImageJobDao.getJob(jobIds)).thenReturn(outputJobIds);
		List<IdexxSendImageJobStatusDTO> val = (List<IdexxSendImageJobStatusDTO>) sendImageStatusService
				.performService(sendImageJob);
		assertTrue("Invalid Response recieved", null != val);
	}

	/**
	 * Test perform service1.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public void testPerformService1() throws IdexxDicomAEConfigServiceException {

		when(idexxDicomWsAuthorizeService.authorize(any(String.class)))
				.thenThrow(new IdexxDicomAEConfigServiceException(IdexxDicomWSAthorizationServiceImpl.INVALID_API_KEY));
		String errorCode = null;
		try {
			sendImageStatusService.performService(sendImageJob);
		} catch (IdexxDicomAEConfigServiceException exp) {
			errorCode = exp.getMessage();
			throw exp;
		}
		assertTrue("Invalid Response recieved", IdexxDicomWSAthorizationServiceImpl.INVALID_API_KEY.equals(errorCode));
	}

}
