/**
 * 
 */
package com.idexx.dicom.services;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.idexx.dicom.aeservices.impl.v13.CreateAETitleService;
import com.idexx.dicom.aeservices.impl.v13.DeleteAETitleService;
import com.idexx.dicom.aeservices.impl.v13.ReadAETitleService;
import com.idexx.dicom.aeservices.impl.v13.SetAETitleStatusService;
import com.idexx.dicom.services.dto.v13.AETitleDTO;
import com.idexx.dicom.services.dto.v13.CreateAETitleDTO;
import com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO;
import com.idexx.dicom.services.dto.v13.ReadAETitleDTO;
import com.idexx.dicom.services.dto.v13.SetEnabledAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * <pre>Test Cases Related IdexxDicomAEConfigServices</pre>
 * @author smallela
 * @version 1.3
 */

public class IdexxDicomAEConfigServicesV1_3Test {

	IdexxDicomAEConfigServicesV1_3 service;
	
	public Mockery context = new JUnit4Mockery() {{
		setImposteriser(ClassImposteriser.INSTANCE);
	}};
	
	CreateAETitleService createServiceMock = context.mock(CreateAETitleService.class);    

	ReadAETitleService readServiceMock = context.mock(ReadAETitleService.class);    
	
	DeleteAETitleService deleteServiceMock = context.mock(DeleteAETitleService.class);    
	
	SetAETitleStatusService setEnabledAEServiceMock = context.mock(SetAETitleStatusService.class);    
      
	/**
     * Test method for
     * {@link com.idexx.dicom.services.impl.v13.IdexxDicomAEConfigServiceImpl 
     * #createAETitle(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * .
     * @throws IdexxDicomAEConfigServiceException 
     */
    @Test
    public void testCreateAETitle() throws IdexxDicomAEConfigServiceException {
        CreateAETitleDTO dto = new CreateAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setSapId("SAPID");
        dto.setInstituteName("TestIng");
        dto.setApiKey("TESTAPIKEY");
        dto.setIdentifiedByAeTitleOnly(false);
        context.checking(new Expectations() {
            {
                oneOf(createServiceMock).performService(with(any(CreateAETitleDTO.class)));
                
                
            }
        });
        service = new IdexxDicomAEConfigServicesV1_3();
        ReflectionTestUtils.setField(service, "createService", createServiceMock);
        //service.createAETitle(dto);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.services.impl.v13.IdexxDicomAEConfigServiceImpl#readAETitle(java.lang.String, java.lang.String, java.lang.String)}
     * .
     * @throws IdexxDicomAEConfigServiceException 
     */
   @Test
    public void testReadAETitle() throws IdexxDicomAEConfigServiceException {
        final List<IdexxDicomApplicationEntityDTO> dtos = new ArrayList<IdexxDicomApplicationEntityDTO>();
        ReadAETitleDTO dto = new ReadAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setSapId("SAPID");
        dto.setInstituteName("TestIng");
        dto.setApiKey("TESTAPIKEY");
        context.checking(new Expectations() {
            {
                oneOf(readServiceMock).performService(with(any(ReadAETitleDTO.class)));
                oneOf(readServiceMock).sendResponse();
                will(returnValue(dtos));
                
            }
        });
        service = new IdexxDicomAEConfigServicesV1_3();
        ReflectionTestUtils.setField(service, "readService", readServiceMock);
        Object outputVal = service.readAETitle(dto);
        assertTrue("Not yet implemented", null != outputVal);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.services.impl.v13.IdexxDicomAEConfigServiceImpl#deleteAETitle(java.lang.String, java.lang.String)}
     * .
     * @throws IdexxDicomAEConfigServiceException 
     */
    @Test
    public  void testDeleteAETitle() throws IdexxDicomAEConfigServiceException {
        AETitleDTO dto = new AETitleDTO();
        dto.setAeTitle("Test1");
        dto.setInstituteName("TestIng");
        dto.setApiKey("TESTAPIKEY");
        context.checking(new Expectations() {
            {
                oneOf(deleteServiceMock).performService(with(any(AETitleDTO.class)));
                
                
            }
        });
        service = new IdexxDicomAEConfigServicesV1_3();
        ReflectionTestUtils.setField(service, "deleteService", deleteServiceMock);
        //service.deleteAETitle(dto);

    }

    /**
     * Test method for
     * {@link com.idexx.dicom.services.impl.v13.IdexxDicomAEConfigServiceImpl#setEnableAETitle(java.lang.String, java.lang.String, boolean)}
     * .
     * @throws IdexxDicomAEConfigServiceException 
     */
    @Test
    public void testSetEnableAETitle() throws IdexxDicomAEConfigServiceException {
        SetEnabledAETitleDTO dto = new SetEnabledAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setInstituteName("TestIng");
        dto.setApiKey("TESTAPIKEY");
        dto.setEnabled(true);
        context.checking(new Expectations() {
            {
                oneOf(setEnabledAEServiceMock).performService(with(any(SetEnabledAETitleDTO.class)));
                
                
            }
        });
        service = new IdexxDicomAEConfigServicesV1_3();
        ReflectionTestUtils.setField(service, "setEnabledAEService", setEnabledAEServiceMock);
        //service.setEnableAETitle(dto);
        assertTrue("Not yet implemented", true); 

    }
    
    

}
