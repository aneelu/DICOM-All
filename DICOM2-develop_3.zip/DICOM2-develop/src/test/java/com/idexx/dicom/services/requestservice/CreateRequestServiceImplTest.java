/**
 * <h1>JUnit test cases for CreateRequestServiceImpl class using Mockito.</h1>
 */
package com.idexx.dicom.services.requestservice;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.Response.Status;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.aeservices.impl.v13.IdexxDicomWSAthorizationServiceImpl;
import com.idexx.dicom.domain.RequestDetails;
import com.idexx.dicom.mapper.EntityMapper;
import com.idexx.dicom.repo.RequestDetailsRepository;
import com.idexx.dicom.sendimage.ImageManagerStoreServiceProviderWraper;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.requestservice.dto.CreateRequestErrorCodesConstants;
import com.idexx.dicom.services.requestservice.dto.CreateRequestServiceResponseDTO;
import com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO;
import com.idexx.dicom.services.requestservice.validator.CreateRequestValidator;
import com.idexx.dicom.services.requestservice.validator.ErrorDTO;
import com.idexx.imaging.imagemanager.soap.IDEXXImageManagerServices;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;
import com.idexx.imaging.imagemanager.soap.PatientDTO;
import com.idexx.imaging.imagemanager.soap.PatientSearchRequestDTO;
import com.idexx.imaging.imagemanager.soap.StoreImageMetaDataDTO;

/**
 * <pre>
 * JUnit test cases for CreateRequestServiceImpl class using Mockito.
 * </pre>
 * 
 * @author nayeemuddin
 * @version 1.3
 */
public class CreateRequestServiceImplTest {
	
	@InjectMocks
	CreateRequestServiceImpl createRequestServiceImpl = new CreateRequestServiceImpl();

	RequestDetailsRepository requestDetailsDao;
	EntityMapper entityMapper;
	IdexxDicomWSAthorizationServiceImpl idexxDicomWsAuthorizeService;
	ImageManagerStoreServiceProviderWraper imageManagerStoreServiceProviderWraper;
	CreateRequestValidator createRequestValidator;
	IDEXXImageManagerServices idexxImService;
	CreateRequestServiceResponseDTO createRequestServiceResponseDTO;
	
	RequestDetailsDTO requestDTO;
	
	@Mock
	private PatientDTO patientDTO;

	/**
	 * <pre>
	 * Initialize and create Mockito objects for the classes involved in  CreateRequestServiceImpl class.
	 * </pre>
	 * 
	 * @throws java.lang.Exception
	 * 
	 */
	@Before
	public void setUp() throws Exception {
		requestDetailsDao = mock(RequestDetailsRepository.class);
		entityMapper = mock(EntityMapper.class);
		idexxDicomWsAuthorizeService = mock(IdexxDicomWSAthorizationServiceImpl.class);
		imageManagerStoreServiceProviderWraper = mock(ImageManagerStoreServiceProviderWraper.class);
		createRequestValidator = mock(CreateRequestValidator.class);
		idexxImService = mock(IDEXXImageManagerServices.class);
		createRequestServiceResponseDTO = mock(CreateRequestServiceResponseDTO.class);

		MockitoAnnotations.initMocks(this);
		
		requestDTO = new RequestDetailsDTO();
		requestDTO.setApiKey("TestAPIKey_Valid");
		requestDTO.setAccessionNumber("A1245");
		requestDTO.setBreed("TestBreed");
		requestDTO.setClientFirstName("TestFirstName");
		requestDTO.setClientLastName("TestLastName");
		requestDTO.setModality("TestModality");
		requestDTO.setPatientDOB("2014-01-12");
		requestDTO.setPatientId("TestPatientID123");
		requestDTO.setPatientName("TestPatietName");
		requestDTO.setPimsIssuer("TestPIMSIssuer");
		requestDTO.setRequestingDoctor("TestDoctor");
		requestDTO.setSapId("12345");
		requestDTO.setSpecies("TestSpecies");
		requestDTO.setSex("Male");
	}

	/**
	 * Test method for Patient record already exist in Patient table, create
	 * request record in Request Details table.
	 * {@link com.idexx.dicom.services.requestservice.CreateRequestServiceImpl#createRequest(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * 
	 * @throws IdexxDicomAEConfigServiceException
	 * @throws IdexxServiceException_Exception
	 */
	@Test
	public void testCreateRequest() throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {
		List<ErrorDTO> listOfErrors = new ArrayList<ErrorDTO>();
		String studyInstanceUID = "1.2.826.0.1.3680043.2.950.2014052026.20160114140241";
		CreateRequestServiceResponseDTO createRequestServiceResponseDTO = new CreateRequestServiceResponseDTO();
		List<PatientDTO> listPatient = new ArrayList<PatientDTO>();
		listPatient.add(patientDTO);
		RequestDetails requestDetails = new RequestDetails();

		when(idexxDicomWsAuthorizeService.authorize(any(String.class))).thenReturn(true);
		when(createRequestValidator.validate(any(RequestDetailsDTO.class))).thenReturn(listOfErrors);
		when(entityMapper.generateStudyInstanceUid(any(RequestDetailsDTO.class))).thenReturn(studyInstanceUID);
		when(imageManagerStoreServiceProviderWraper.getService()).thenReturn(idexxImService);
		when(idexxImService.searchPatient(any(PatientSearchRequestDTO.class))).thenReturn(listPatient);
		when(requestDetailsDao.save(any(RequestDetails.class))).thenReturn(requestDetails);

		createRequestServiceResponseDTO = createRequestServiceImpl.createRequest(requestDTO);
		String response = createRequestServiceResponseDTO.getStudyInstanceUID();

		assertEquals(response, studyInstanceUID);
	}

	/**
	 * Test method for Patient record does not exist in Patient table, so create
	 * Patient record in Patient table and then create request record in Request
	 * Details table.
	 * {@link com.idexx.dicom.services.requestservice.CreateRequestServiceImpl#createRequest(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * 
	 * @throws IdexxDicomAEConfigServiceException
	 * @throws IdexxServiceException_Exception
	 * 
	 */
	@Test
	public void testCreateRequest1() throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {
		List<ErrorDTO> listOfErrors = new ArrayList<ErrorDTO>();
		String studyInstancsUID = "1.2.826.0.1.3680043.2.950.2014052026.20160114140241";
		String storeImageMetaDataResp = "1.2.826.0.1.3680043.2.950.201402.20160113000000.nbekaed3trukgpdwgyr5daavx.1";
		CreateRequestServiceResponseDTO createRequestServiceResponseDTO = new CreateRequestServiceResponseDTO();
		List<PatientDTO> listPatient = new ArrayList<PatientDTO>();
		listPatient.add(patientDTO);
		RequestDetails requestDetails = new RequestDetails();

		when(idexxDicomWsAuthorizeService.authorize(any(String.class))).thenReturn(true);
		when(createRequestValidator.validate(any(RequestDetailsDTO.class))).thenReturn(listOfErrors);
		when(entityMapper.generateStudyInstanceUid(any(RequestDetailsDTO.class))).thenReturn(studyInstancsUID);
		when(imageManagerStoreServiceProviderWraper.getService()).thenReturn(idexxImService);
		when(idexxImService.searchPatient(any(PatientSearchRequestDTO.class))).thenReturn(listPatient);
		when(idexxImService.storeImageMetaData(any(StoreImageMetaDataDTO.class))).thenReturn(storeImageMetaDataResp);
		when(requestDetailsDao.save(any(RequestDetails.class))).thenReturn(requestDetails);

		createRequestServiceResponseDTO = createRequestServiceImpl.createRequest(requestDTO);
		String response = createRequestServiceResponseDTO.getStudyInstanceUID();

		assertEquals(response, studyInstancsUID);
	}
	/**
	 * Test method for any of required input parameters missing.
	 * {@link com.idexx.dicom.services.requestservice.CreateRequestServiceImpl#createRequest(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * 
	 * @throws IdexxDicomAEConfigServiceException
	 * @throws IdexxServiceException_Exception
	 */
	@Test
	public void testCreateRequest2() throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {
		CreateRequestServiceResponseDTO createRequestServiceResponseDTO = new CreateRequestServiceResponseDTO();
		List<ErrorDTO> listOfErrors = new ArrayList<ErrorDTO>();
		ErrorDTO errorCodes = new ErrorDTO();
		errorCodes.setErrorCode(CreateRequestErrorCodesConstants.PATIENT_ID_ERROR_CODE);
		errorCodes.setMessage(CreateRequestErrorCodesConstants.PATIENT_ID_ERROR_CODE_MSG);
		listOfErrors.add(errorCodes);
		createRequestServiceResponseDTO.setErrors(listOfErrors);
		String studyInstanceUID = "1.2.826.0.1.3680043.2.950.2014052026.20160114140241";		
		List<PatientDTO> listPatient = new ArrayList<PatientDTO>();
		RequestDetails requestDetails = new RequestDetails();

		when(idexxDicomWsAuthorizeService.authorize(any(String.class))).thenReturn(true);
		when(createRequestValidator.validate(any(RequestDetailsDTO.class))).thenReturn(listOfErrors);
		when(entityMapper.generateStudyInstanceUid(any(RequestDetailsDTO.class))).thenReturn(studyInstanceUID);
		when(imageManagerStoreServiceProviderWraper.getService()).thenReturn(idexxImService);
		when(idexxImService.searchPatient(any(PatientSearchRequestDTO.class))).thenReturn(listPatient);
		when(requestDetailsDao.save(any(RequestDetails.class))).thenReturn(requestDetails);

		requestDTO.setPatientId("");
		
		List<ErrorDTO> expectedErrorResponse = new ArrayList<ErrorDTO>();
		createRequestServiceResponseDTO = createRequestServiceImpl.createRequest(requestDTO);
		expectedErrorResponse = createRequestServiceResponseDTO.getErrors();
		
		assertEquals(expectedErrorResponse, createRequestServiceResponseDTO.getErrors());

		assertEquals(expectedErrorResponse, createRequestServiceResponseDTO.getErrors());
	}

	/**
	 * Test method for Invalid API key test
	 * {@link com.idexx.dicom.services.requestservice.CreateRequestServiceImpl#createRequest(com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO)}
	 * .
	 * 
	 * @throws IdexxDicomAEConfigServiceException
	 * @throws IdexxServiceException_Exception
	 */
	@Test(expected = IdexxDicomAEConfigServiceException.class)
	public void testCreateRequest3() throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {

		when(idexxDicomWsAuthorizeService.authorize(any(String.class)))
				.thenThrow(new IdexxDicomAEConfigServiceException(IdexxDicomWSAthorizationServiceImpl.INVALID_API_KEY,
						IdexxDicomWSAthorizationServiceImpl.INVALID_API_KEY));

		RequestDetailsDTO requestDTO = new RequestDetailsDTO();
		requestDTO.setAllInputsAvailable(true);
		requestDTO.setApiKey("TestAPIKey_Invalid");
		String errorCode = null;
		try {
			createRequestServiceImpl.createRequest(requestDTO);
		} catch (IdexxDicomAEConfigServiceException exp) {
			errorCode = exp.getMessage();
			throw exp;
		}
		assertTrue("Invalid Response recieved", IdexxDicomWSAthorizationServiceImpl.INVALID_API_KEY.equals(errorCode));

	}
	
	
	@Test
	public void testgetHttpStatusCodeBasedonErrorUnAutorized(){
		ErrorDTO errorDTO = new ErrorDTO();
		errorDTO.setErrorCode(CreateRequestErrorCodesConstants.MODALITY_ERROR_CODE);
		Status status = createRequestServiceImpl.getHttpStatusCodeBasedonError(errorDTO);
		assertEquals(status.getStatusCode(), 401);
	}
	
	@Test
	public void testgetHttpStatusCodeBasedonErrorBadRequest(){
		ErrorDTO errorDTO = new ErrorDTO();
		errorDTO.setErrorCode(CreateRequestErrorCodesConstants.PATIENT_DOB_ERROR_CODE);
		Status status = createRequestServiceImpl.getHttpStatusCodeBasedonError(errorDTO);
		assertEquals(status.getStatusCode() , 400);
	}
}
