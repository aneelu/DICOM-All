/**
 * 
 */
package com.idexx.dicom.aeservices.impl;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.jmock.Expectations;
import org.jmock.auto.Mock;
import org.jmock.integration.junit4.JUnitRuleMockery;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.ae.validator.IdexxSendImageStatusValidator;
import com.idexx.dicom.aeservices.IdexxDicomWSAthorizationService;
import com.idexx.dicom.aeservices.SendImageStatusService;
import com.idexx.dicom.dao.ws.DicomConfigDao;
import com.idexx.dicom.dao.ws.IdexxSendImageJobDao;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.IdexxSendImageJobStatusDTO;
import com.idexx.dicom.services.sendimage.dto.SendImageStatusParamDTO;

/**
 * @author mdindukurthi
 * 
 */
public class SendImageStatusServiceTest {

    private SendImageStatusService sendImgService;

    @Rule
    public JUnitRuleMockery context = new JUnitRuleMockery();

    @Mock
    private IdexxSendImageJobDao sendImageJobDao;

    @Mock
    private IdexxSendImageStatusValidator validator;

    @Mock
    private DicomConfigDao configDao;

    @Mock
    private IdexxDicomWSAthorizationService idexxDicomWsAuthorizeService;

    /**
     * @throws java.lang.Exception
     */
    @Before
    public final void setUp() throws Exception {

        sendImgService = new SendImageStatusServiceImpl();
        ReflectionTestUtils.setField(sendImgService, "validator", validator);
        ReflectionTestUtils.setField(sendImgService, "sendImageJobDao", sendImageJobDao);
        ReflectionTestUtils.setField(sendImgService, "idexxDicomWsAuthorizeService", idexxDicomWsAuthorizeService);

    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.SendImageJobServiceImpl#performService(com.idexx.dicom.services.dto.SendImageJobParamDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public final void testPerformService1() throws IdexxDicomAEConfigServiceException {

        final List<String> jobIds = new ArrayList<String>();
        jobIds.add("1");
        jobIds.add("2");
        jobIds.add("3");
        final List<IdexxSendImageJob> outputJobIds = new ArrayList<IdexxSendImageJob>();
        context.checking(new Expectations() {
            {
                oneOf(idexxDicomWsAuthorizeService).authorize(with(any(String.class)));
                will(returnValue(true));
                oneOf(validator).validate(with(any(SendImageStatusParamDTO.class)));
                will(returnValue(1));
                oneOf(sendImageJobDao).getJob(jobIds);
                will(returnValue(outputJobIds));
            }
        });
        SendImageStatusParamDTO sendImageJob = new SendImageStatusParamDTO();
        final List<String> inputJobIds = new ArrayList<String>();
        inputJobIds.add("1");
        inputJobIds.add("2");
        inputJobIds.add("3");
        sendImageJob.setJobId(inputJobIds);
        sendImageJob.setApiKey("Test1");
        List<IdexxSendImageJobStatusDTO> val = (List<IdexxSendImageJobStatusDTO>) sendImgService
                .performService(sendImageJob);
        assertTrue("Invalid Response recieved", null != val);

    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.SendImageJobServiceImpl#performService(com.idexx.dicom.services.dto.SendImageJobParamDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public final void testPerformService() throws IdexxDicomAEConfigServiceException {

        final List<String> jobIds = new ArrayList<String>();
        jobIds.add("1");
        jobIds.add("2");
        jobIds.add("3");
        final List<IdexxSendImageJob> outputJobIds = new ArrayList<IdexxSendImageJob>();
        IdexxSendImageJob outputjobId1 = new IdexxSendImageJob();
        IdexxSendImageJob outputjobId2 = new IdexxSendImageJob();
        outputjobId1.setJobId("1");
        outputjobId2.setJobId("2");
        outputJobIds.add(outputjobId1);
        outputJobIds.add(outputjobId2);
        context.checking(new Expectations() {
            {
                oneOf(idexxDicomWsAuthorizeService).authorize(with(any(String.class)));
                will(returnValue(true));
                oneOf(validator).validate(with(any(SendImageStatusParamDTO.class)));
                will(returnValue(1));
                oneOf(sendImageJobDao).getJob(jobIds);
                will(returnValue(outputJobIds));
            }
        });
        SendImageStatusParamDTO sendImageJob = new SendImageStatusParamDTO();
        final List<String> inputJobIds = new ArrayList<String>();
        inputJobIds.add("1");
        inputJobIds.add("2");
        inputJobIds.add("3");
        sendImageJob.setJobId(inputJobIds);
        sendImageJob.setApiKey("Test1");
        List<IdexxSendImageJobStatusDTO> val = (List<IdexxSendImageJobStatusDTO>) sendImgService
                .performService(sendImageJob);
        assertTrue("Invalid Response recieved", null != val);

    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.SendImageJobServiceImpl#performService(com.idexx.dicom.services.dto.SendImageJobParamDTO)}
     * . Test for positive: idexxDicomWsAuthorizeService.authorize will return
     * true
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public final void testPerformService2() throws IdexxDicomAEConfigServiceException {
        SendImageStatusParamDTO sendImageJob = new SendImageStatusParamDTO();
        final List<String> inputJobIds = new ArrayList<String>();
        inputJobIds.add("1");
        inputJobIds.add("2");
        inputJobIds.add("3");
        sendImageJob.setJobId(inputJobIds);
        sendImageJob.setApiKey("Test1");
        context.checking(new Expectations() {
            {
                oneOf(idexxDicomWsAuthorizeService).authorize(with(any(String.class)));
                will(throwException(new IdexxDicomAEConfigServiceException(
                        IdexxDicomWSAthorizationService.INVALID_API_KEY)));
            }
        });
        String errorCode = null;
        try {
            sendImgService.performService(sendImageJob);
        } catch (IdexxDicomAEConfigServiceException exp) {
            errorCode = exp.getErrorCode();
            throw exp;
        }
        assertTrue("Invalid Response recieved", IdexxDicomWSAthorizationService.INVALID_API_KEY.equals(errorCode));
    }

}
