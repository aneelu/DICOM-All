/**
 * JUnit test case for SendImageStatusValidatorImpl service class.
 */
package com.idexx.dicom.ae.validator.impl.v13;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v13.SendImageStatusParamDTO;

/**
 * @author nayeemuddin
 *
 */
public class IdexxSendImageStatusValidatorImplTest {

	private IdexxSendImageStatusValidatorImpl validator;
	private SendImageStatusParamDTO dto;

	
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		dto = new SendImageStatusParamDTO();
		validator = new IdexxSendImageStatusValidatorImpl();
	}

	/**
	 * Test method for
	 * {@link com.idexx.dicom.ae.validator.impl.v13.IdexxSendImageStatusValidatorImpl#validate(com.idexx.dicom.services.sendimage.dto.v13.SendImageStatusParamDTO)}
	 * . Test for empty/null API Key 
	 */
	@Test
	public void testValidate() {
		// Setting API key as empty string
		dto.setApiKey("");		
		
		try {
			validator.validate(dto);
			fail("IdexxSendImageStatusValidatorImpl Failed to validate 1.0 ");
		} catch (IdexxDicomAEConfigServiceException exp) {
			assertTrue("IdexxSendImageStatusValidatorImpl Failed to validate 1.1 ",
					IdexxSendImageStatusValidatorImpl.MISSING_MANDATORY.equalsIgnoreCase(exp.getErrorCode()));
		}

		// Setting API key null.
		dto.setApiKey(null);
		
		try {
			validator.validate(dto);
			fail("IdexxSendImageStatusValidatorImpl Failed to validate 2.0 ");
		} catch (IdexxDicomAEConfigServiceException exp) {
			assertTrue("IdexxSendImageStatusValidatorImpl Failed to validate 2.1 ",
					IdexxSendImageStatusValidatorImpl.MISSING_MANDATORY.equalsIgnoreCase(exp.getErrorCode()));
		}

	}
	
	
	/**
	 *  Test method for
	 * {@link com.idexx.dicom.ae.validator.impl.v13.IdexxSendImageStatusValidatorImpl#validate(com.idexx.dicom.services.sendimage.dto.v13.SendImageStatusParamDTO)}
	 * . Test for positive, by passing both API Key and Job Id.
	 */
	@Test
	public void testValidate1() {
		// Setting API key value and Job Id as null.       
		dto.setApiKey("TestAPIKey");
		dto.setJobId(null);
		
		try {
			validator.validate(dto);
			fail("IdexxSendImageStatusValidatorImpl Failed to validate 1.0 ");
		} catch (IdexxDicomAEConfigServiceException exp) {
			assertTrue("IdexxSendImageStatusValidatorImpl Failed to validate 1.1 ",
					IdexxSendImageStatusValidatorImpl.MISSING_MANDATORY.equalsIgnoreCase(exp.getErrorCode()));
		}
				
				
		// Setting both API Key and Job Id
		List<String> jobs = new ArrayList<String>();
		jobs.add("TestJob1");
		dto.setJobId(jobs);
		dto.setApiKey("TestApiKey1");

		try {
			int val = validator.validate(dto);
			assertTrue("IdexxSendImageStatusValidatorImpl Failed to validate 3.0 ", 1 == val);

		} catch (IdexxDicomAEConfigServiceException exp) {
			fail("IdexxSendImageStatusValidatorImpl Failed to validate 3.1 ");
		}

	}

}
