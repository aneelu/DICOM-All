package com.idexx.dicom.aeservices.impl.v13;

import static org.junit.Assert.assertNotNull;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.idexx.dicom.ae.entities.IdexxDicomServiceFailureLog;
import com.idexx.dicom.ae.validator.impl.v13.StoreErrorLogValidatorImpl;
import com.idexx.dicom.dao.ws.FailureServiceDao;
import com.idexx.dicom.services.dto.v13.IdexxErrorLogParamDTO;
import com.idexx.dicom.services.dto.v13.IdexxFailureLogDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;


/**
 * Test for StoreErrorLogServiceImpl using JMock
 * @author rkaranam
 * @version 1.3
 */
public class StoreErrorLogServiceImplTest extends AbstractTestConfig {

	StoreErrorLogServiceImpl classToTest;
    
    public Mockery context = new JUnit4Mockery() {{
        setImposteriser(ClassImposteriser.INSTANCE);
    }};
    
    FailureServiceDao failureLogDAO = context.mock(FailureServiceDao.class);
    
    StoreErrorLogValidatorImpl validator = context.mock(StoreErrorLogValidatorImpl.class);

    private List<IdexxDicomServiceFailureLog> dtos;

    @Before
    public void setUp() throws Exception {
        dtos = new ArrayList<IdexxDicomServiceFailureLog>();
        IdexxDicomServiceFailureLog dto = new IdexxDicomServiceFailureLog();
        dto.setAeTitle("Test");
        dto.setFailedDateTime(new Timestamp((new Date()).getTime()));
        dto.setIpAddress("");
        dto.setManufacturer("");
        dto.setManufacturerModelName("");
        dto.setModality("");
        dto.setPatientName("");
        dtos.add(dto);
        classToTest = new StoreErrorLogServiceImpl();
        ReflectionTestUtils.setField(classToTest, "validator", validator);
        ReflectionTestUtils.setField(classToTest, "failureLogDAO", failureLogDAO);
    }

    @Test
    public void testWhenPerformServiceIsCalledThen()
            throws IdexxDicomAEConfigServiceException {

        context.checking(new Expectations() {
            {
                oneOf(validator).validate(with(any(IdexxErrorLogParamDTO.class)));
                will(returnValue(Boolean.TRUE));
                
                oneOf(failureLogDAO).getFailureLogErrorMessages(with(any(Date.class)), 
                        with(any(Date.class)), 
                        with(any(String.class)),
                        with(any(String.class)), 
                        with(any(String.class)));
                will(returnValue(dtos));
            }
        });
        IdexxErrorLogParamDTO fdto = new IdexxErrorLogParamDTO();
        fdto.setEndDate("2011-05-15T23:58:59.1+05:30");
        fdto.setStartDate("2014-05-15T23:58:59.1+05:30");
        fdto.setAeTitle("");
        fdto.setInstituteName("");
        fdto.setErrorType("");
        List<IdexxFailureLogDTO> dtos = classToTest.performService(fdto);
        for(IdexxFailureLogDTO idx : dtos) {
            assertNotNull(idx.getAeTitle());
            assertNotNull(idx.getFailedDateTime());
            
            
        }
    }
}
