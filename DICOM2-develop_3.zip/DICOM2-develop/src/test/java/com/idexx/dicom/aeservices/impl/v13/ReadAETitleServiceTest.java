/**
 * 
 */
package com.idexx.dicom.aeservices.impl.v13;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.springframework.test.util.ReflectionTestUtils;

import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.validator.impl.v13.AbstractAETitleValidator;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.dto.v13.AETitleDTO;
import com.idexx.dicom.services.dto.v13.ReadAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;


/**
 * <pre>Test Cases Related ReadAETitleService</pre>
 * @author smallela
 * @version 1.3
 */

@RunWith(JUnit4.class)
public class ReadAETitleServiceTest {

    private ReadAETitleService service;
   
    public Mockery context = new JUnit4Mockery() {{
        setImposteriser(ClassImposteriser.INSTANCE);
    }};
    
    AbstractAETitleValidator mockValidator = context.mock(AbstractAETitleValidator.class);    
    AETitleDao mockDao = context.mock(AETitleDao.class);
    IdexxDicomWSAthorizationServiceImpl idexxDicomWsAuthorizeService = context.mock(IdexxDicomWSAthorizationServiceImpl.class);
    

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.ReadAETitleService#validate(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public void testValidate() throws IdexxDicomAEConfigServiceException {
        ReadAETitleDTO dto = new ReadAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setInstituteName("Testing");
        dto.setSapId("SAPId");
        context.checking(new Expectations() {
            {
                oneOf(mockValidator).validate(with(any(AETitleDTO.class)));
                will(returnValue(1));
            }
        });
        service = new ReadAETitleService();
        ReflectionTestUtils.setField(service, "validator", mockValidator);
        int val = service.validate(dto);
        assertTrue("Create AE Failed#1", 1 == val);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.ReadAETitleService#doService(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public void testDoService() throws IdexxDicomAEConfigServiceException {

        service = new ReadAETitleService();
        ReadAETitleDTO dto = new ReadAETitleDTO();
        dto.setAeTitle("Test1");
        int val = service.getQueryCase(dto);
        assertTrue("Read AE Failed#1", 1 == val);
    }

    
    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.ReadAETitleService#doService(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public void testDoService2() throws IdexxDicomAEConfigServiceException {
        final int expectedResult = 3;
        service = new ReadAETitleService();
        ReadAETitleDTO dto = new ReadAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setInstituteName("Testing");
        int val = service.getQueryCase(dto);
        assertTrue("Read AE Failed#1", expectedResult == val);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.ReadAETitleService#doService(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public void testDoService2a() throws IdexxDicomAEConfigServiceException {
        final int expectedResult = 4;
        service = new ReadAETitleService();
        ReadAETitleDTO dto = new ReadAETitleDTO();
        dto.setSapId("sapId");
        int val = service.getQueryCase(dto);
        assertTrue("Read AE Failed#1", expectedResult == val);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.ReadAETitleService#doService(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public void testDoService3() throws IdexxDicomAEConfigServiceException {
        final int expectedResult = 5;
        service = new ReadAETitleService();
        ReadAETitleDTO dto = new ReadAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setSapId("SapId");
        int val = service.getQueryCase(dto);
        assertTrue("Read AE Failed#1", expectedResult == val);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.ReadAETitleService#doService(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public void testDoService4() throws IdexxDicomAEConfigServiceException {
        final int expectedResult = 6;
        service = new ReadAETitleService();
        ReadAETitleDTO dto = new ReadAETitleDTO();
        dto.setSapId("SapId");
        dto.setInstituteName("Testing");
        int val = service.getQueryCase(dto);
        assertTrue("Read AE Failed#1", expectedResult == val);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.ReadAETitleService#doService(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public void testDoService5() throws IdexxDicomAEConfigServiceException {
        final int expectedResult = 7;
        service = new ReadAETitleService();
        ReadAETitleDTO dto = new ReadAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setInstituteName("Testing");
        dto.setSapId("SapId");
        int val = service.getQueryCase(dto);
        assertTrue("Read AE Failed#1", expectedResult == val);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.ReadAETitleService#doService(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public  void testDoService6() throws IdexxDicomAEConfigServiceException {
        final List<AETitle> registeredAEList = new ArrayList<AETitle>();
        service = new ReadAETitleService();
        ReadAETitleDTO dto = new ReadAETitleDTO();
        dto.setAeTitle("Test1");

        context.checking(new Expectations() {
            {
                atLeast(1).of(mockDao).findAETitle("Test1");
                will(returnValue(registeredAEList));
            }
        });
        ReflectionTestUtils.setField(service, "aeTitleDao", mockDao);
        service.doService(dto);

    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.ReadAETitleService#doService(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public  void testDoService6a() throws IdexxDicomAEConfigServiceException {
        final List<AETitle> registeredAEList = null;
        service = new ReadAETitleService();
        ReadAETitleDTO dto = new ReadAETitleDTO();
        dto.setAeTitle("Test1");

        context.checking(new Expectations() {
            {
                atLeast(1).of(mockDao).findAETitle("Test1");
                will(returnValue(registeredAEList));
            }
        });
        ReflectionTestUtils.setField(service, "aeTitleDao", mockDao);
        service.doService(dto);

    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.CreateAETitleService#doService(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public  void testDoService7() throws IdexxDicomAEConfigServiceException {

        service = new ReadAETitleService();
        ReadAETitleDTO dto = new ReadAETitleDTO();
        dto.setAeTitle("Test1");

        context.checking(new Expectations() {
            {
                oneOf(mockDao).findAETitle("Test1");
                will(throwException(new IdexxDicomAEConfigDbException()));

            }
        });
        ReflectionTestUtils.setField(service, "aeTitleDao", mockDao);
        service.doService(dto);

    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.ReadAETitleService#doService(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public void testDoService8() throws IdexxDicomAEConfigServiceException {
        final List<AETitle> registeredAEList = new ArrayList<AETitle>();
        AETitle aeTitle = new AETitle();
        aeTitle.setAeTitle("test1");
        aeTitle.setInstituteName("Testing");
        aeTitle.setApiKey("ApiKey");
        aeTitle.setEnabled(true);
        registeredAEList.add(aeTitle);
        Calendar calendar = Calendar.getInstance();
        java.util.Date now = calendar.getTime();
        java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(now.getTime());

        aeTitle.setCreatedDateTime(currentTimestamp);
        aeTitle.setLastAccessedDateTime(currentTimestamp);
        service = new ReadAETitleService();

        ReadAETitleDTO dto = new ReadAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setInstituteName("Testing");

        context.checking(new Expectations() {
            {
                atLeast(1).of(mockDao).findAETitle("Test1", "Testing");
                will(returnValue(registeredAEList));
            }
        });
        ReflectionTestUtils.setField(service, "aeTitleDao", mockDao);
        int val = service.doService(dto);

        assertTrue("Read AE Failed#1", 1 == val);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.ReadAETitleService#doService(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public void testDoService9() throws IdexxDicomAEConfigServiceException {
        final List<AETitle> registeredAEList = new ArrayList<AETitle>();
        AETitle aeTitle = new AETitle();
        aeTitle.setAeTitle("test1");
        aeTitle.setInstituteName("Testing");
        aeTitle.setApiKey("ApiKey");
        aeTitle.setEnabled(true);
        aeTitle.setSapId("sapId");
        registeredAEList.add(aeTitle);
        Calendar calendar = Calendar.getInstance();
        java.util.Date now = calendar.getTime();
        java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(now.getTime());

        aeTitle.setCreatedDateTime(currentTimestamp);
        service = new ReadAETitleService();

        ReadAETitleDTO dto = new ReadAETitleDTO();

        dto.setSapId("sapId");

        context.checking(new Expectations() {
            {
                atLeast(1).of(mockDao).findAETitleBySapId("sapId");
                will(returnValue(registeredAEList));
            }
        });
        ReflectionTestUtils.setField(service, "aeTitleDao", mockDao);
        int val = service.doService(dto);

        assertTrue("Read AE Failed#1", 1 == val);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.ReadAETitleService#doService(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public  void testDoService10() throws IdexxDicomAEConfigServiceException {
        final List<AETitle> registeredAEList = new ArrayList<AETitle>();
        AETitle aeTitle = new AETitle();
        aeTitle.setAeTitle("test1");
        aeTitle.setInstituteName("Testing");
        aeTitle.setApiKey("ApiKey");
        aeTitle.setEnabled(true);
        aeTitle.setSapId("sapId");
        registeredAEList.add(aeTitle);
        Calendar calendar = Calendar.getInstance();
        java.util.Date now = calendar.getTime();
        java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(now.getTime());

        aeTitle.setCreatedDateTime(currentTimestamp);
        service = new ReadAETitleService();

        ReadAETitleDTO dto = new ReadAETitleDTO();
        dto.setAeTitle("Test1");
        dto.setInstituteName("Testing");
        dto.setSapId("sapId");

        context.checking(new Expectations() {
            {
                atLeast(1).of(mockDao).findAETitle("Test1", "Testing", "sapId");
                will(returnValue(registeredAEList));
            }
        });
        ReflectionTestUtils.setField(service, "aeTitleDao", mockDao);
        int val = service.doService(dto);

        assertTrue("Read AE Failed#1", 1 == val);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.ReadAETitleService#doService(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public void testDoService11() throws IdexxDicomAEConfigServiceException {
        final List<AETitle> registeredAEList = new ArrayList<AETitle>();
        AETitle aeTitle = new AETitle();
        aeTitle.setAeTitle("test1");
        aeTitle.setInstituteName("Testing");
        aeTitle.setApiKey("ApiKey");
        aeTitle.setEnabled(true);
        aeTitle.setSapId("sapId");
        registeredAEList.add(aeTitle);
        Calendar calendar = Calendar.getInstance();
        java.util.Date now = calendar.getTime();
        java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(now.getTime());

        aeTitle.setCreatedDateTime(currentTimestamp);
        service = new ReadAETitleService();

        ReadAETitleDTO dto = new ReadAETitleDTO();
        dto.setInstituteName("Testing");
        dto.setSapId("sapId");

        context.checking(new Expectations() {
            {
                atLeast(1).of(mockDao).findAETitleBySapIdAndInstituteName("sapId", "Testing");
                will(returnValue(registeredAEList));
            }
        });
        ReflectionTestUtils.setField(service, "aeTitleDao", mockDao);
        int val = service.doService(dto);

        assertTrue("Read AE Failed#1", 1 == val);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.v13.ReadAETitleService#doService(com.idexx.dicom.services.dto.v13.IdexxDicomApplicationEntityDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public  void testDoService12() throws IdexxDicomAEConfigServiceException {
        final List<AETitle> registeredAEList = new ArrayList<AETitle>();
        AETitle aeTitle = new AETitle();
        aeTitle.setAeTitle("test1");
        aeTitle.setInstituteName("Testing");
        aeTitle.setApiKey("ApiKey");
        aeTitle.setEnabled(true);
        aeTitle.setSapId("sapId");
        registeredAEList.add(aeTitle);
        Calendar calendar = Calendar.getInstance();
        java.util.Date now = calendar.getTime();
        java.sql.Timestamp currentTimestamp = new java.sql.Timestamp(now.getTime());

        aeTitle.setCreatedDateTime(currentTimestamp);
        service = new ReadAETitleService();

        ReadAETitleDTO dto = new ReadAETitleDTO();
        dto.setAeTitle("test1");
        dto.setSapId("sapId");

        context.checking(new Expectations() {
            {
                atLeast(1).of(mockDao).findAETitleByAETitleAndSapId("test1", "sapId");
                will(returnValue(registeredAEList));
            }
        });
        ReflectionTestUtils.setField(service, "aeTitleDao", mockDao);
        int val = service.doService(dto);

        assertTrue("Read AE Failed#1", 1 == val);
    }

}
