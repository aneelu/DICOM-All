package com.idexx.dicom.aeservices.impl;

import java.util.ArrayList;
import java.util.List;

import org.jmock.Expectations;
import org.jmock.auto.Mock;
import org.jmock.integration.junit4.JUnitRuleMockery;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.ae.validator.v11.CancelSendJobServiceValidator;
import com.idexx.dicom.aeservices.impl.v11.CancelSendJobServiceImpl;
import com.idexx.dicom.aeservices.v11.CancelSendJobService;
import com.idexx.dicom.dao.ws.IdexxSendImageJobDao;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v11.CancelSendJobParamDTO;

public class CancelSendJobServiceTest {

    private CancelSendJobService cancelSendJobService;

    @Rule
    public JUnitRuleMockery context = new JUnitRuleMockery();

    @Mock
    private IdexxSendImageJobDao cancelSendImageJobDao;

    @Mock
    private CancelSendJobServiceValidator validator;

    @Before
    public final void setUp() throws Exception {
        cancelSendJobService = new CancelSendJobServiceImpl();
        ReflectionTestUtils.setField(cancelSendJobService, "validator", validator);
        ReflectionTestUtils.setField(cancelSendJobService, "cancelSendImageJobDao", cancelSendImageJobDao);
    }

    @Test
    public final void testWhenPerformServiceIsCalledThenReturnSuccessMessage()
            throws IdexxDicomAEConfigServiceException {
        final String actual = "update successful";
        final List<IdexxSendImageJob> idexJobs = new ArrayList<IdexxSendImageJob>();
        IdexxSendImageJob sib = new IdexxSendImageJob();
        sib.setJobId("ff80808145f515500145f75bc83b0025");
        idexJobs.add(sib);
        context.checking(new Expectations() {
            {
                oneOf(validator).validate(with(any(CancelSendJobParamDTO.class)));
                will(returnValue(1));
                
                oneOf(cancelSendImageJobDao).getJob(with(any(List.class)));
                will(returnValue(idexJobs));
                oneOf(cancelSendImageJobDao).cancelSendJob(with(any(IdexxSendImageJob.class)));
                will(returnValue(actual));
            }
        });
        CancelSendJobParamDTO fdto = new CancelSendJobParamDTO();
        fdto.setJobId("ff80808145f515500145f75bc83b0025");
        fdto.setJobStatusDescription("Cancelling the job");

        String expected = cancelSendJobService.performService(fdto);
        Assert.assertSame(expected, actual);;
    }
    
}
