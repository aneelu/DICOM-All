/**
 * 
 */
package com.idexx.dicom.ae.validator.impl;

import static org.junit.Assert.assertTrue;

import org.jmock.integration.junit4.JUnitRuleMockery;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import com.idexx.dicom.services.dto.ReadAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;


/**
 * <pre>Test Cases Related ReadAETitleValidator</pre>
 * @author smallela
 * @version 1.3
 */

@RunWith(JUnit4.class)
public class ReadAETitleValidatorTest {
    
    private ReadAETitleValidator validator;
    
    @Rule
    public JUnitRuleMockery context = new JUnitRuleMockery();
    
    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.ReadAETitleValidator
     *  #validateInputFields(com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)}
     * . Test no mandatory fields received in request
     */
    @Test(expected = IdexxDicomAEConfigServiceException.class)
    public final void testValidateInputFields() throws IdexxDicomAEConfigServiceException {
        validator = new ReadAETitleValidator();
        ReadAETitleDTO dto = new ReadAETitleDTO();
        int val = validator.validateInputFields(dto);
        assertTrue("Validation Failing#1", val == 1);
        
        
    }
    
    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.ReadAETitleValidator 
     * #validateInputFields(com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)}
     * . Test AETitle received in request
     */
    @Test
    public final void testValidateInputFields2() throws IdexxDicomAEConfigServiceException {
        validator = new ReadAETitleValidator();
        ReadAETitleDTO dto = new ReadAETitleDTO();
        
        dto.setSapId("SAPID");
        int val = validator.validateInputFields(dto);
        assertTrue("Validation Failing#2", val == 1);
    }
    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.ReadAETitleValidator 
     * #validateInputFields(com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)}
     * . Test AETitle received in request
     */
    @Test
    public final void testValidateInputFields3() throws IdexxDicomAEConfigServiceException {
        validator = new ReadAETitleValidator();
        ReadAETitleDTO dto = new ReadAETitleDTO();
        
        dto.setAeTitle("Test");
        int val = validator.validateInputFields(dto);
        assertTrue("Validation Failing#2", val == 1);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.ReadAETitleValidator
     *  #validateInputFields(com.idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)}
     * . Test no mandatory fields received in request
     */
    @Test
    public final void testValidateDBFields() {
        validator = new ReadAETitleValidator();
        ReadAETitleDTO dto = new ReadAETitleDTO();
        int val = validator.validateDBFields(dto);
        assertTrue("Validation Failing#1", val == 1);
        
    }

   
}
