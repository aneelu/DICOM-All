package com.idexx.dicom.aeservices.impl.v13;

import org.junit.Test;

/**
 * Abstract class will start up spring boot application context for unit tests 
 * @author vvanjarana
 * @version 1.3
 */
public abstract class AbstractTestConfig {
    
	@Test
	public void contextLoads() {
	}
}
