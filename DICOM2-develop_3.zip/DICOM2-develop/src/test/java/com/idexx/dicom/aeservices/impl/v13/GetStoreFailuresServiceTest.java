
package com.idexx.dicom.aeservices.impl.v13;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.jmock.Expectations;
import org.jmock.Mockery;
import org.jmock.integration.junit4.JUnit4Mockery;
import org.jmock.lib.legacy.ClassImposteriser;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.idexx.dicom.ae.entities.IdexxDicomServiceFailureLog;
import com.idexx.dicom.ae.validator.impl.v13.GetStoreFailuresValidator;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.dao.ws.FailureServiceDao;
import com.idexx.dicom.services.dto.v13.IdexxFailureLogParamDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;


/**
 * Test for GetStoreFailuresService using JMock
 * @author rkaranam
 * @version 1.3
 */
public class GetStoreFailuresServiceTest extends AbstractTestConfig {
    private GetStoreFailuresService failureService;
    
    public Mockery context = new JUnit4Mockery() {{
        setImposteriser(ClassImposteriser.INSTANCE);
    }};
    
    FailureServiceDao failureLogDAO = context.mock(FailureServiceDao.class);
    
    AETitleDao aeTitleDao = context.mock(AETitleDao.class);
    
    GetStoreFailuresValidator validator = context.mock(GetStoreFailuresValidator.class);
    
    private List<IdexxDicomServiceFailureLog> dtos;
    
    /**
     * @throws java.lang.Exception
     */
    @Before
    public final void setUp() throws Exception {
        dtos = new ArrayList<IdexxDicomServiceFailureLog>();
        IdexxDicomServiceFailureLog dto = new IdexxDicomServiceFailureLog();
        dto.setAeTitle("Test");
        dto.setFailedDateTime(new Timestamp((new Date()).getTime()));
        dto.setIpAddress("");
        dto.setManufacturer("");
        dto.setManufacturerModelName("");
        dto.setModality("");
        dto.setPatientName("");
        dtos.add(dto);
        failureService = new GetStoreFailuresService();
        ReflectionTestUtils.setField(failureService, "validator", validator);
        ReflectionTestUtils.setField(failureService, "failureLogDAO", failureLogDAO);
        ReflectionTestUtils.setField(failureService, "aeTitleDao", aeTitleDao);
    }
    
    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.GetStoreFailuresService#performService(com.idexx.dicom.services.dto.IdexxFailureLogParamDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public final void testPerformService1() throws IdexxDicomAEConfigServiceException {
        
        context.checking(new Expectations() {
            {
                oneOf(validator).validate(with(any(IdexxFailureLogParamDTO.class)));
                will(returnValue(1));
                oneOf(failureLogDAO).getFailureLog(with(any(Date.class)), with(any(Date.class)));
                oneOf(aeTitleDao).getAllAETitles();
                will(returnValue(dtos));
            }
        });
        IdexxFailureLogParamDTO fdto = new IdexxFailureLogParamDTO();
        fdto.setEndDate("2015-05-15T23:58:59.1+05:30");
        fdto.setStartDate("2013-05-15T23:58:59.1+05:30");
        failureService.performService(fdto);
    }
    
    /**
     * Test method for
     * {@link com.idexx.dicom.aeservices.impl.GetStoreFailuresService#performService(com.idexx.dicom.services.dto.IdexxFailureLogParamDTO)}
     * .
     * 
     * @throws IdexxDicomAEConfigServiceException
     */
    @Test
    public final void testPerformService2() throws IdexxDicomAEConfigServiceException {
        DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        final Date toDate = formatter.parseDateTime("2013-05-15T23:58:59.1+05:30").toDate();
        context.checking(new Expectations() {
            {
                oneOf(validator).validate(with(any(IdexxFailureLogParamDTO.class)));
                will(returnValue(1));
                oneOf(failureLogDAO).getFailureLog(toDate, null);
                oneOf(aeTitleDao).getAllAETitles();
                will(returnValue(dtos));
            }
        });
        IdexxFailureLogParamDTO fdto = new IdexxFailureLogParamDTO();
        fdto.setEndDate("2013-05-15T25:58:59.1+05:30");
        fdto.setStartDate("2013-05-15T23:58:59.1+05:30");
        failureService.performService(fdto);
    }
}
