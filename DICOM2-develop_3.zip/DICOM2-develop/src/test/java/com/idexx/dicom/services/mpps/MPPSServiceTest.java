package com.idexx.dicom.services.mpps;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.dcm4che3.net.service.DicomServiceException;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.domain.MPPSNCreate;
import com.idexx.dicom.domain.MPPSNSet;
import com.idexx.dicom.mapper.EntityMapper;
import com.idexx.dicom.repo.MPPSNCreateRepository;
import com.idexx.dicom.repo.MPPSNSetRepository;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.mpps.dto.MPPSNCreateDTO;
import com.idexx.dicom.services.mpps.dto.MPPSNSetDTO;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;

public class MPPSServiceTest {

	@Rule
	public ExpectedException expectedEx = ExpectedException.none();

	@InjectMocks
	MPPSService objectUnderTest = new MPPSService();

	@Mock
    MPPSNCreateRepository mppsNCreateRepo;
	@Mock
    MPPSNSetRepository mppsNSetRepo;
	@Mock
    EntityMapper entityMapper;
	@Mock
	MPPSNCreate mppsNCreate;
	@Mock
	MPPSNCreate mppsNCreateReturn;
	@Mock
	MPPSNCreateDTO mppsNCreateDTO;
	@Mock
	MPPSNSet mppsNSet;
	@Mock
	MPPSNSet mppsNSetReturn;
	@Mock
	MPPSNSetDTO mppsNSetDTO;

    @Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
    public final void testNewMPPSNCreate() throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {

        when(entityMapper.dtoToEntityMapper(mppsNCreateDTO)).thenReturn(mppsNCreate);
        when(mppsNCreateRepo.save(mppsNCreate)).thenReturn(mppsNCreateReturn);
        when(mppsNCreateReturn.getId()).thenReturn("12345");
        
        assertEquals(objectUnderTest.newMPPSNCreate(mppsNCreateDTO), "12345");
        
        verify(entityMapper, times(1)).dtoToEntityMapper(mppsNCreateDTO);
        verify(mppsNCreateRepo, times(1)).save(mppsNCreate);
        verify(mppsNCreateReturn, times(1)).getId();
	}

	@Test
    public final void testNewMPPSNSet() throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {

        when(entityMapper.dtoToEntityMapper(mppsNSetDTO)).thenReturn(mppsNSet);
        when(mppsNSetRepo.save(mppsNSet)).thenReturn(mppsNSetReturn);
        when(mppsNSetReturn.getId()).thenReturn("12345");
        
        assertEquals(objectUnderTest.newMPPSNSet(mppsNSetDTO), "12345");
        
        verify(entityMapper, times(1)).dtoToEntityMapper(mppsNSetDTO);
        verify(mppsNSetRepo, times(1)).save(mppsNSet);
        verify(mppsNSetReturn, times(1)).getId();
	}

	@Test
    public final void testUpdateMPPSNCreate() throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {

        when(entityMapper.dtoToEntityMapper(mppsNCreateDTO)).thenReturn(mppsNCreate);
        when(mppsNCreateRepo.save(mppsNCreate)).thenReturn(mppsNCreateReturn);
        
        objectUnderTest.newMPPSNCreate(mppsNCreateDTO);
        
        verify(entityMapper, times(1)).dtoToEntityMapper(mppsNCreateDTO);
        verify(mppsNCreateRepo, times(1)).save(mppsNCreate);
	}

	@Test
    public final void testFindMPPSNCreate() throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception, DicomServiceException {

		String mppsSopInstanceUID = "mppsSopInstanceUID";
		List<MPPSNCreate> m = new ArrayList<MPPSNCreate>();
		m.add(mppsNCreate);
		
        when(mppsNCreateRepo.findByMppsSOPInstanceUID(mppsSopInstanceUID)).thenReturn(m);
        when(entityMapper.entityToDTOMapper(mppsNCreate)).thenReturn(mppsNCreateDTO);
		
        assertEquals(objectUnderTest.findMPPSNCreate(mppsSopInstanceUID), mppsNCreateDTO);
		
        verify(entityMapper, times(1)).entityToDTOMapper(mppsNCreate);
        verify(mppsNCreateRepo, times(1)).findByMppsSOPInstanceUID(mppsSopInstanceUID);
	}
	
	@Test
    public final void testNoMPPSNCreateFound() throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception, DicomServiceException {

		String mppsSopInstanceUID = "mppsSopInstanceUID";
		List<MPPSNCreate> m = new ArrayList<MPPSNCreate>();
		
        when(mppsNCreateRepo.findByMppsSOPInstanceUID(mppsSopInstanceUID)).thenReturn(m);
        expectedEx.expect(DicomServiceException.class);
		
        assertEquals(objectUnderTest.findMPPSNCreate(mppsSopInstanceUID), mppsNCreateDTO);
		
        verify(mppsNCreateRepo, times(1)).findByMppsSOPInstanceUID(mppsSopInstanceUID);
        verify(entityMapper, times(0)).entityToDTOMapper(mppsNCreate);
	}

	@Test
    public final void testMultipleMPPSNCreatesFound() throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception, DicomServiceException {

		String mppsSopInstanceUID = "mppsSopInstanceUID";
		List<MPPSNCreate> m = new ArrayList<MPPSNCreate>();
		m.add(mppsNCreate);
		m.add(mppsNCreateReturn);
		
        when(mppsNCreateRepo.findByMppsSOPInstanceUID(mppsSopInstanceUID)).thenReturn(m);
        expectedEx.expect(DicomServiceException.class);
		
        assertEquals(objectUnderTest.findMPPSNCreate(mppsSopInstanceUID), mppsNCreateDTO);
		
        verify(mppsNCreateRepo, times(1)).findByMppsSOPInstanceUID(mppsSopInstanceUID);
        verify(entityMapper, times(0)).entityToDTOMapper(mppsNCreate);
	}
}
