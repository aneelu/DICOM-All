/**
 * 
 */
package com.idexx.dicom.ae.validator.impl;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.idexx.dicom.ae.validator.IdexxSendImageStatusValidator;
import com.idexx.dicom.ae.validator.IdexxValidator;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.SendImageStatusParamDTO;

/**
 * @author vkandagatla
 * 
 */
public class IdexxSendImageStatusValidatorImplTest {
    
    private SendImageStatusParamDTO dto;
    private IdexxSendImageStatusValidator validator;
    
    /**
     * @throws java.lang.Exception
     */
    @Before
    public final void setUp() throws Exception {
        dto = new SendImageStatusParamDTO();
        dto.setApiKey("");
        validator = new IdexxSendImageStatusValidatorImpl();
    }
    
    /**
     * Test method for
     * {@link com.idexx.dicom.ae.validator.impl.IdexxSendImageStatusValidatorImpl 
     * 
     * #validate(com.idexx.dicom.services.sendimage.dto.SendImageStatusParamDTO)}
     * .
     */
    @Test
    public final void testValidate() {
        try {
            validator.validate(dto);
            fail("IdexxSendImageStatusValidatorImpl Failed to validate 1.0 ");
        } catch (IdexxDicomAEConfigServiceException exp) {
            assertTrue("IdexxSendImageStatusValidatorImpl Failed to validate 1.1 ",
                    IdexxValidator.MISSING_MANDATORY.equalsIgnoreCase(exp.getErrorCode()));
        }
        
        dto.setApiKey(null);
        
        try {
            validator.validate(dto);
            fail("IdexxSendImageStatusValidatorImpl Failed to validate 2.0 ");
        } catch (IdexxDicomAEConfigServiceException exp) {
            assertTrue("IdexxSendImageStatusValidatorImpl Failed to validate 2.1 ",
                    IdexxValidator.MISSING_MANDATORY.equalsIgnoreCase(exp.getErrorCode()));
        }
        List<String> jobs = new ArrayList<String>();
        jobs.add("Test1");
        dto.setJobId(jobs);
        dto.setApiKey("Test");
        try {
            int val = validator.validate(dto);
            assertTrue("IdexxSendImageStatusValidatorImpl Failed to validate 3.0 ", 1 == val);
        } catch (IdexxDicomAEConfigServiceException exp) {
            fail("IdexxSendImageStatusValidatorImpl Failed to validate 8.1 ");
        }
    }
}
