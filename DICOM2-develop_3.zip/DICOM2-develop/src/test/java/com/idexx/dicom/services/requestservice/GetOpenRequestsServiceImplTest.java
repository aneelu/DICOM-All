/**
 * 
 */
package com.idexx.dicom.services.requestservice;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.aeservices.impl.v13.IdexxDicomWSAthorizationServiceImpl;
import com.idexx.dicom.domain.RequestDetails;
import com.idexx.dicom.mapper.EntityMapper;
import com.idexx.dicom.repo.RequestDetailsRepository;
import com.idexx.dicom.sendimage.ImageManagerStoreServiceProviderWraper;
import com.idexx.dicom.sendimage.SendImageJobConstants;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.requestservice.dto.GetOpenRequestDTO;
import com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO;
import com.idexx.dicom.services.requestservice.validator.ErrorDTO;
import com.idexx.imaging.imagemanager.soap.IDEXXImageManagerServices;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;
import com.idexx.imaging.imagemanager.soap.PatientDTO;
import com.idexx.imaging.imagemanager.soap.PatientSearchRequestDTO;

/**
 * <pre>
 * Test Cases Related GetOpenRequestsService
 * </pre>
 * 
 * @author smallela
 * @version 1.3
 */
public class GetOpenRequestsServiceImplTest {

    public static final String ACCESSIONNUMBER = "AccessionNumber";
    public static final String APIKEY = "apiKey";
    public static final String MODALITY = "modality";
    public static final String PATIENTID = "patientId";
    public static final String PIMSISSUER = "pimsIssuer";
    public static final String REQUESTINGDOCTOR = "requestingDoctor";
    public static final String REQUESTNOTES = "requestNotes";
    public static final String SAPID = "12345";
    public static final String STUDYINSTANCEUID = "studyInstanceUID";
    public static final String BREED = "breed";
    public static final String PATIENTNAME = "patientName";
    public static final String SPECIES = "species";
    public static final String GENDER = "gender";
    public static final String APPLICATIONPATIENTID = "applicationPatientId";
    public static final String CLIENTFIRSTNAME = "clientFirstName";

    @InjectMocks
    GetOpenRequestsServiceImpl getOpenRequestsService = new GetOpenRequestsServiceImpl();
    private RequestDetailsRepository requestDetailsDao;
    private EntityMapper entityMapper;
    private IDEXXImageManagerServices idexxImService;
    private ImageManagerStoreServiceProviderWraper imageManagerStoreServiceProviderWraper;
    List<GetOpenRequestDTO> listOpenRequest = new ArrayList<GetOpenRequestDTO>();
    RequestDetails requestDetails = new RequestDetails();
    GetOpenRequestDTO getOpenRequestDTO = new GetOpenRequestDTO();
    RequestDetailsDTO requestDetailsDTO = new RequestDetailsDTO();
    List<PatientDTO> listPatient = new ArrayList<PatientDTO>();
    List<RequestDetails> listReqDetails = new ArrayList<RequestDetails>();
    PatientSearchRequestDTO patientSearchRequestDTO = new PatientSearchRequestDTO();
    IdexxDicomWSAthorizationServiceImpl idexxDicomWsAuthorizeService;
    PatientDTO patientdto = new PatientDTO();

    @Before
    public void setUp() throws Exception {

	requestDetails.setAccessionNumber(ACCESSIONNUMBER);
	requestDetails.setApiKey(APIKEY);
	requestDetails.setModality(MODALITY);
	requestDetails.setPatientId(PATIENTID);
	requestDetails.setRequestingDoctor(REQUESTINGDOCTOR);
	requestDetails.setRequestNotes(REQUESTNOTES);
	requestDetails.setSapId(SAPID);
	requestDetails.setStudyInstanceUID(STUDYINSTANCEUID);
	requestDetails.setStatus(SendImageJobConstants.JOB_STATUS_PENDING);
	listReqDetails.add(requestDetails);

	requestDetailsDTO.setAccessionNumber(requestDetails.getAccessionNumber());
	requestDetailsDTO.setApiKey(requestDetails.getApiKey());
	requestDetailsDTO.setModality(requestDetails.getModality());
	requestDetailsDTO.setPatientId(requestDetails.getPatientId());
	requestDetailsDTO.setRequestingDoctor(requestDetails.getRequestingDoctor());
	requestDetailsDTO.setRequestNotes(requestDetails.getRequestNotes());
	requestDetailsDTO.setSapId(requestDetails.getSapId());
	requestDetailsDTO.setStudyInstanceUID(requestDetails.getStudyInstanceUID());
	requestDetailsDTO.setCreateTimeStamp(new Timestamp(System.currentTimeMillis()));
	requestDetailsDTO.setStatus(SendImageJobConstants.JOB_STATUS_PENDING);

	patientSearchRequestDTO.setApiKey(requestDetailsDTO.getApiKey());
	patientSearchRequestDTO.setClientFirstName(requestDetailsDTO.getClientFirstName());
	patientSearchRequestDTO.setClientLastName(requestDetailsDTO.getClientLastName());
	patientSearchRequestDTO.setIncludeDeletes(true);
	patientSearchRequestDTO.setIncludeInactivePatients(true);
	patientSearchRequestDTO.setClinicId(Integer.parseInt(requestDetailsDTO.getSapId()));
	patientSearchRequestDTO.setApplicationPatientId(requestDetailsDTO.getPatientId());

	patientdto.setApplicationPatientId(APPLICATIONPATIENTID);
	patientdto.setBreed(BREED);
	patientdto.setClientFirstName(CLIENTFIRSTNAME);
	listPatient.add(patientdto);

	requestDetailsDao = mock(RequestDetailsRepository.class);
	imageManagerStoreServiceProviderWraper = mock(ImageManagerStoreServiceProviderWraper.class);
	entityMapper = mock(EntityMapper.class);
	idexxDicomWsAuthorizeService = mock(IdexxDicomWSAthorizationServiceImpl.class);
	idexxImService = mock(IDEXXImageManagerServices.class);
	MockitoAnnotations.initMocks(this);
    }

    /**
     * Test method for
     * {@link com.idexx.dicom.services.requestservice.GetOpenRequestsServiceImpl#getOpenRequests}
     * 
     * @throws IdexxDicomAEConfigServiceException
     * @throws IdexxServiceException_Exception
     * 
     */

    @Test
    public void testOpenRequests() throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {
	Logger logger = Logger.getLogger(GetOpenRequestsServiceImplTest.class);
	when(idexxDicomWsAuthorizeService.authorize(APIKEY)).thenReturn(true);
	when(requestDetailsDao.findBySapIdAndStatus(SAPID, SendImageJobConstants.JOB_STATUS_PENDING))
		.thenReturn(listReqDetails);
	when(entityMapper.getPatientSearchRequestDTO(any(RequestDetailsDTO.class))).thenReturn(patientSearchRequestDTO);
	when(idexxImService.searchPatient(any(PatientSearchRequestDTO.class))).thenReturn(listPatient);
	when(imageManagerStoreServiceProviderWraper.getService()).thenReturn(idexxImService);
	if (null != listReqDetails && listReqDetails.size() > 0) {
	    for (RequestDetails req : listReqDetails) {
		when(entityMapper.entityToDtoMapper(req)).thenReturn(requestDetailsDTO);
		PatientDTO patientDTO = listPatient.get(0);
		getOpenRequestDTO.setPatientDTO(patientDTO);
		getOpenRequestDTO.setAccessionNumber(requestDetails.getAccessionNumber());
		getOpenRequestDTO.setModality(requestDetails.getModality());
		getOpenRequestDTO.setRequestingDoctor(requestDetails.getRequestingDoctor());
		getOpenRequestDTO.setRequestNotes(requestDetails.getRequestNotes());
		getOpenRequestDTO.setStatus(requestDetails.getStatus());
		getOpenRequestDTO.setStudyInstanceUID(req.getStudyInstanceUID());
		listOpenRequest.add(getOpenRequestDTO);
	    }
	} else {
	    logger.log(Level.INFO, "No Records found");
	}
	List<ErrorDTO> listOfErrors = new ArrayList<ErrorDTO>();
	listOpenRequest = getOpenRequestsService.getOpenRequests(APIKEY, SAPID, listOfErrors);
	assertTrue("checks list of GetOpenRequestDTO", null != listOpenRequest);
    }
}
