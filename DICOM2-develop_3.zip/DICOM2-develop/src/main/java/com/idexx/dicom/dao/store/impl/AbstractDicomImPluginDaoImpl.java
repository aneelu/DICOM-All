/**
 * 
 */
package com.idexx.dicom.dao.store.impl;

import javax.persistence.EntityManager;

/**
 * @author vkandagatla
 * 
 */
public abstract class AbstractDicomImPluginDaoImpl {
    protected EntityManager entityManager;
    
    /**
     * @param entityManager
     */
    public AbstractDicomImPluginDaoImpl(final EntityManager entityManager) {
        super();
        this.entityManager = entityManager;
    }
}
