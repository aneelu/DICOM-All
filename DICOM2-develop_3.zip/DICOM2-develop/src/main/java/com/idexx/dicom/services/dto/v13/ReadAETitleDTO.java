/**
 * 
 */
package com.idexx.dicom.services.dto.v13;

import javax.xml.bind.annotation.XmlElement;

import org.apache.commons.lang.StringUtils;

/**
 * <pre>ReadAETitleDTO hold information About sapId</pre>
 * @author smallela
 * @version 1.3
 */
public class ReadAETitleDTO extends AETitleDTO {
    private String sapId;

    /**
     * @return the sapId
     */
    @XmlElement(nillable = true, required = true)
    public String getSapId() {
        return sapId;
    }

    /**
     * @param sapId
     *            the sapId to set
     */
    public void setSapId(final String sapId) {
        this.sapId = StringUtils.trimToNull(sapId);
    }
}
