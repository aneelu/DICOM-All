package com.idexx.dicom.domain;

import java.io.Serializable;

public class ExternalPatientPK implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5202168131980323682L;
	protected String patientID;
    protected String issuerOfPatientID;
    public ExternalPatientPK() {}
    public ExternalPatientPK(String patientID, String issuerOfPatientID) {
    	this.patientID = patientID;
    	this.issuerOfPatientID = issuerOfPatientID;
    }
}
