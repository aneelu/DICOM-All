/**
 * Sends an Image to destination AE
 */
package com.idexx.dicom.sendimage;

import java.io.IOException;

import com.idexx.dicom.sendimage.impl.SendImageException;
import com.idexx.dicom.services.sendimage.dto.SendImagePendingJobDTO;

/**
 * @author vkandagatla
 * 
 */
public interface SendImage {
    void sendImage(SendImagePendingJobDTO dto) throws SendImageException, InterruptedException, IOException;
}
