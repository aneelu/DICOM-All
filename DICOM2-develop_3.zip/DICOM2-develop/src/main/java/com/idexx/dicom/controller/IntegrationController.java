/**
 * 
 */
package com.idexx.dicom.controller;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.io.IOUtils;
import org.apache.cxf.rs.security.cors.CrossOriginResourceSharing;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.AbstractEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.json.GsonBuilderUtils;
import org.springframework.web.bind.annotation.RequestBody;

import com.fasterxml.jackson.core.JsonFactory;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.requestservice.CancelRequestServiceImpl;
import com.idexx.dicom.services.requestservice.CreateRequestServiceImpl;
import com.idexx.dicom.services.requestservice.GetOpenRequestsServiceImpl;
import com.idexx.dicom.services.requestservice.dto.CancelRequestDTO;
import com.idexx.dicom.services.requestservice.dto.CreateRequestErrorCodesConstants;
import com.idexx.dicom.services.requestservice.dto.CreateRequestErrorCodesDTO;
import com.idexx.dicom.services.requestservice.dto.CreateRequestServiceResponseDTO;
import com.idexx.dicom.services.requestservice.dto.GetIOpenRequestDTO;
import com.idexx.dicom.services.requestservice.dto.GetOpenRequestDTO;
import com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO;
import com.idexx.dicom.services.requestservice.validator.ErrorDTO;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;

/**
 * Controller for integrating DICOM to any other pims like Neo & Animana
 * 
 * @author vvanjarana
 * @version 1.3
 */
@CrossOriginResourceSharing(allowAllOrigins = true, allowCredentials = true)
public class IntegrationController {

	private static final Logger LOG = Logger.getLogger(IntegrationController.class);

	@Autowired
	private CreateRequestServiceImpl createRequestService;

	@Autowired
	private CancelRequestServiceImpl cancelRequestService;

	@Autowired
	private GetOpenRequestsServiceImpl getOpenRequestsService;

	@Autowired
	private Environment environment;

	@POST
	@Path("/createRequest")
	@Produces(MediaType.APPLICATION_JSON)
	public Response createRequestService(@RequestBody RequestDetailsDTO reqDetails)
			throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {
		CreateRequestServiceResponseDTO createRequestServiceResponseDTO = new CreateRequestServiceResponseDTO();
		try {
			createRequestServiceResponseDTO = createRequestService.createRequest(reqDetails);

			if (null != createRequestServiceResponseDTO.getStudyInstanceUID()) {
				return Response.status(createRequestServiceResponseDTO.getHttpStatusCode())
						.entity(createRequestServiceResponseDTO.getStudyInstanceUID()).type(MediaType.TEXT_PLAIN_TYPE)
						.build();
			} else {
				CreateRequestErrorCodesDTO createRequestErrorCodesDTO = new CreateRequestErrorCodesDTO();
				createRequestErrorCodesDTO.setErrors(createRequestServiceResponseDTO.getErrors());
				return Response
						.status(createRequestService
								.getHttpStatusCodeBasedonError(createRequestServiceResponseDTO.getErrors().get(0)))
						.entity(createRequestErrorCodesDTO).build();
			}
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			return Response.status(CreateRequestErrorCodesConstants.UNAUTHORIZED_HTTP_STATUS_CODE)
					.entity(e.getMessage()).type(MediaType.TEXT_PLAIN_TYPE).build();
		}
	}

	@POST
	@Path("/cancelRequest")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response cancelRequestService(@RequestBody CancelRequestDTO cancelRequestDTO)
			throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {
		String result = null;
		try {
			List<ErrorDTO> listOfErrors = new ArrayList<ErrorDTO>();
			result = cancelRequestService.cancelRequest(cancelRequestDTO.getStudyInstanceUID(),
					cancelRequestDTO.getApiKey(), cancelRequestDTO.getSapId(), listOfErrors);
			if (!listOfErrors.isEmpty()) {
				CreateRequestErrorCodesDTO createRequestErrorCodesDTO = new CreateRequestErrorCodesDTO();
				createRequestErrorCodesDTO.setErrors(listOfErrors);
				return Response.status(createRequestService.getHttpStatusCodeBasedonError(listOfErrors.get(0)))
						.type(MediaType.APPLICATION_JSON_TYPE).entity(createRequestErrorCodesDTO).build();
			}
			return Response.status(HttpStatus.OK.value()).entity(result).type(MediaType.TEXT_PLAIN_TYPE).build();
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			return Response.status(CreateRequestErrorCodesConstants.UNAUTHORIZED_HTTP_STATUS_CODE)
					.entity(e.getMessage()).type(MediaType.TEXT_PLAIN_TYPE).build();
		}
		
	}

	@POST
	@Path("/getOpenRequests")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getOpenRequests(@RequestBody GetIOpenRequestDTO getIOpenRequestDTO) {
		try {
			List<ErrorDTO> listOfErrors = new ArrayList<ErrorDTO>();
			List<GetOpenRequestDTO> dto = getOpenRequestsService.getOpenRequests(getIOpenRequestDTO.getApiKey(),
					getIOpenRequestDTO.getSapId(), listOfErrors);
			if (!listOfErrors.isEmpty()) {
				CreateRequestErrorCodesDTO createRequestErrorCodesDTO = new CreateRequestErrorCodesDTO();
				createRequestErrorCodesDTO.setErrors(listOfErrors);
				return Response.status(createRequestService.getHttpStatusCodeBasedonError(listOfErrors.get(0)))
						.type(MediaType.APPLICATION_JSON_TYPE).entity(createRequestErrorCodesDTO).build();
			}
			return Response.status(HttpStatus.OK.value()).entity(dto).type(MediaType.APPLICATION_JSON_TYPE).build();
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			return Response.status(HttpStatus.INTERNAL_SERVER_ERROR.value()).entity("Unable to complete request")
					.type(MediaType.TEXT_PLAIN_TYPE).build();
		}
	}

	@GET
	@Path("/version")
	@Produces(MediaType.TEXT_PLAIN)
	public String versionView() throws Exception {
		// spring.profiles.active
		String env = environment.getProperty(AbstractEnvironment.ACTIVE_PROFILES_PROPERTY_NAME);
		try {
			return IOUtils.toString(getClass().getResource("/version.txt")) + " : " + env + " : "
					+ InetAddress.getLocalHost().getHostName();
		} catch (Exception e) {
			return "Not Specified: " + " : " + env + " : " + InetAddress.getLocalHost().getHostName();
		}
	}
}
