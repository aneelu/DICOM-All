/**
 * 
 */
package com.idexx.dicom.conversion.impl;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.Logger;

import com.idexx.dicom.DicomObjectBuilder;
import com.idexx.imaging.imagemanager.soap.ImageDTO;
import com.idexx.imaging.imagemanager.soap.PatientDTO;
import com.idexx.imaging.imagemanager.soap.SeriesDTO;
import com.idexx.imaging.imagemanager.soap.StudyDTO;

/**
 * @author vkandagatla
 * 
 */
public class DicomObjectBuilderImpl implements DicomObjectBuilder {
	
	private static final Logger LOG = Logger.getLogger(DicomObjectBuilderImpl.class);
	
    private static final int DEFAULT_BUFFER_SIZE = 1024;
    private static final int JPEG_SAMPLES_PER_PIXELS = 3;
    private static final String MONO_PHOTMETRIC_INTERPRETATION = "MONOCHROME2";
    private static final String YBR_PHOTMETRIC_INTERPRETATION = "YBR_FULL_422";
    private ImageProperties imageProperties;
    private File dcmFile;
    private PatientDTO patientDTO;
    private StudyDTO studyDTO;
    private SeriesDTO seriesDTO;
    private ImageDTO imageDTO;

    public DicomObjectBuilderImpl(final ImageProperties imageProperties, final PatientDTO patientDTO,
            final StudyDTO studyDTO, final SeriesDTO seriesDTO, final ImageDTO imageDTO, final File dcmFile) {}

    /*
     * @see
     * com.idexx.dicom.DicomObjectBuilder#build(com.idexx.dicom.conversion.impl
     * .ImageProperties)
     */
    public final void build() throws IOException {
        LOG.info(imageProperties.toString());
        this.write(dcmFile);
    }

    public final void putPatientAttributes() {}

    /**
     * @param imageFile
     * @param fileLength
     * @param dcmFile
     * @param dataSet
     * @throws IOException
     *             Writes the Image Data and Dicom DataSet to Dicom File
     */
    private void write(final File dcmFile) throws IOException {}

    /**
     * Puts Image Properties to DicomObject
     */
    private void putImageProperties() {}

    /**
     * @param samplesPerPixel
     * @return determines PhotometricInterpretation
     */
    private String getPhotometricInterpretation(final int samplesPerPixel) {
        String photometricInterpretation = MONO_PHOTMETRIC_INTERPRETATION;
        if (samplesPerPixel == JPEG_SAMPLES_PER_PIXELS) {
            photometricInterpretation = YBR_PHOTMETRIC_INTERPRETATION;
        }
        return photometricInterpretation;
    }
}
