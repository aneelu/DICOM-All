/**
 * Get OpenRequests Service implementation to pims like Neo and Animana
 */
package com.idexx.dicom.services.requestservice;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.idexx.dicom.aeservices.impl.v13.IdexxDicomWSAthorizationServiceImpl;
import com.idexx.dicom.domain.Client;
import com.idexx.dicom.domain.ExternalPatient;
import com.idexx.dicom.domain.Owner;
import com.idexx.dicom.domain.Patient;
import com.idexx.dicom.domain.RequestDetails;
import com.idexx.dicom.mapper.EntityMapper;
import com.idexx.dicom.repo.ClientRepo;
import com.idexx.dicom.repo.ExternalPatientRepo;
import com.idexx.dicom.repo.OwnerRepo;
import com.idexx.dicom.repo.PatientRepo;
import com.idexx.dicom.repo.RequestDetailsRepository;
import com.idexx.dicom.services.IdexxDicomServiceConstants;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.requestservice.dto.CreateRequestErrorCodesConstants;
import com.idexx.dicom.services.requestservice.dto.GetOpenRequestDTO;
import com.idexx.dicom.services.requestservice.validator.ErrorDTO;
import com.idexx.dicom.util.CommonUtil;
import com.idexx.imaging.imagemanager.soap.ClientDTO;
import com.idexx.imaging.imagemanager.soap.ExternalPatientIdDTO;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;
import com.idexx.imaging.imagemanager.soap.PatientDTO;

/**
 * <pre>
 * GetOpenRequestsService Implementation to open request Service Jobs based on PENDING status.
 * </pre>
 * 
 * @author smallela
 * @version 1.3
 */
@Service
public class GetOpenRequestsServiceImpl {

	private static final Logger LOG = Logger.getLogger(GetOpenRequestsServiceImpl.class);

	@Autowired
	RequestDetailsRepository requestDetailsDao;

	@Autowired
	EntityMapper entityMapper;

	@Autowired
	@Qualifier("idexxDicomWSAthorizationServiceImplV13")
	private IdexxDicomWSAthorizationServiceImpl idexxDicomWsAuthorizeService;

	@Autowired
	private PatientRepo patientRepo;

	@Autowired
	private ExternalPatientRepo externalPatientRepo;

	@Autowired
	private OwnerRepo ownerRepo;

	@Autowired
	private ClientRepo clientRepo;

	/**
	 * <pre>
	 * GetOpenRequestsService Implementation to open request Service Jobs based on PENDING status and return all request details related to pending status
	 * </pre>
	 * 
	 * @return List<GetOpenRequestDTO>
	 * @throws IdexxDicomAEConfigServiceException
	 * @throws IdexxServiceException_Exception
	 * 
	 */
	public List<GetOpenRequestDTO> getOpenRequests(String apiKey, String sapId, List<ErrorDTO> listofErrors)
			throws IdexxDicomAEConfigServiceException, IdexxServiceException_Exception {

		List<GetOpenRequestDTO> listOpenRequest = new ArrayList<GetOpenRequestDTO>();
		if (StringUtils.isBlank(apiKey)) {
			listofErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.API_KEY_ERROR_CODE,
					CreateRequestErrorCodesConstants.API_KEY_ERROR_CODE_MSG));
		}
		if (StringUtils.isBlank(sapId)) {
			listofErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.SAP_ID_ERROR_CODE,
					CreateRequestErrorCodesConstants.SAP_ID_ERROR_CODE_MSG));
		}
		if (!listofErrors.isEmpty()) {
			return null;
		}
		try {
			idexxDicomWsAuthorizeService.authorize(apiKey);
		} catch (IdexxDicomAEConfigServiceException e) {
			listofErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.INVALID_API_KEY_ERROR_CODE,
					CreateRequestErrorCodesConstants.INVALID_API_KEY_ERROR_CODE_MSG));
			return null;
		}

		List<RequestDetails> listReqDetails = requestDetailsDao.findBySapIdAndStatus(sapId,
				IdexxDicomServiceConstants.MPPS_REQUEST_STATUS_PENDING);
		if (null != listReqDetails && !listReqDetails.isEmpty()) {
			for (RequestDetails req : listReqDetails) {
				Patient patient = patientRepo.findByID(req.getPatientId());
				List<ExternalPatient> extPatients = externalPatientRepo.findByPatientID(req.getPatientId());
				List<ExternalPatientIdDTO> extPatientDTO = new ArrayList<ExternalPatientIdDTO>();
				for (ExternalPatient externalPatient : extPatients) {
					ExternalPatientIdDTO dto = new ExternalPatientIdDTO();
					dto.setIssuerOfPatientId(externalPatient.getIssuerOfPatientID());
					dto.setPimsPatientId(externalPatient.getPimsPatientId());
					extPatientDTO.add(dto);
				}
				PatientDTO patientDTO = new PatientDTO();
				List<Owner> owners = ownerRepo.findByPatientID(req.getPatientId());
				List<ClientDTO> clients = new ArrayList<ClientDTO>();
				for (Owner owner : owners) {
					Client client = clientRepo.findByID(owner.getClientID());
					ClientDTO dto = new ClientDTO();
					// dto.setApplicationClientId(client.getApplicationClientId());
					dto.setClientFirstName(client.getFirstName());
					dto.setClientLastName(client.getLastName());
					dto.setEmail(client.getEmail());
					dto.setId(client.getID());
					boolean primary = false;
					try {
						primary = new Boolean(owner.getPrimaryOwner());
						if (primary) {
							patientDTO.setClientFirstName(dto.getClientFirstName());
							patientDTO.setClientLastName(dto.getClientLastName());
						}
					} catch (Exception exc) {
						primary = false;
					}
					dto.setPrimaryOwner(primary);
					clients.add(dto);
				}
				
				patientDTO.setActiveFlag(patient.getActiveFlag());
				patientDTO.setApplicationPatientId(patient.getApplicationPatientId());
				patientDTO.setBreed(patient.getBreed());
				patientDTO.setClinicId(patient.getClinicId());
				patientDTO.setDob(CommonUtil.getXMLDate(patient.getDob()));
				patientDTO.setEdhdNumber(patient.getEdhdNumber());
				patientDTO.setGender(patient.getGender());
				patientDTO.setId(patient.getID());
				patientDTO.setPatientName(patient.getPatientName());
				patientDTO.setSpecies(patient.getSpecies());
				patientDTO.setWeight(patient.getWeight());
				patientDTO.setWeightUnit(patient.getWeightUnit());
				patientDTO.getExternalPatientIds().addAll(extPatientDTO);
				patientDTO.getOwners().addAll(clients);
				
				GetOpenRequestDTO getOpenRequestDTO = new GetOpenRequestDTO();
				getOpenRequestDTO.setPatientDTO(patientDTO);
				getOpenRequestDTO.setAccessionNumber(req.getAccessionNumber());
				getOpenRequestDTO.setModality(req.getModality());
				getOpenRequestDTO.setRequestingDoctor(req.getRequestingDoctor());
				getOpenRequestDTO.setRequestNotes(req.getRequestNotes());
				getOpenRequestDTO.setStudyInstanceUID(req.getStudyInstanceUID());
				getOpenRequestDTO.setStatus(req.getStatus());
				getOpenRequestDTO.setCreateTimestamp(req.getCreateTimeStamp());
				getOpenRequestDTO.setUpdateTimestamp(req.getUpdateTimeStamp());

				listOpenRequest.add(getOpenRequestDTO);
			}
		} else {
			LOG.info("No Records found for : apiKey: " + apiKey + " sapId: " + sapId);
		}
		return listOpenRequest;
	}
}
