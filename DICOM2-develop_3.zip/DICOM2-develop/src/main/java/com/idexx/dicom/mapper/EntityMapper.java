/**
 * <h1>Mapper class for Create Request service</h1>
 */
package com.idexx.dicom.mapper;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.idexx.dicom.domain.MPPSNCreate;
import com.idexx.dicom.domain.MPPSNSet;
import com.idexx.dicom.domain.RequestDetails;
import com.idexx.dicom.sendimage.SendImageJobConstants;
import com.idexx.dicom.services.IdexxDicomServiceConstants;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.mpps.dto.MPPSNCreateDTO;
import com.idexx.dicom.services.mpps.dto.MPPSNSetDTO;
import com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO;
import com.idexx.imaging.imagemanager.soap.ExternalPatientIdDTO;
import com.idexx.imaging.imagemanager.soap.ImageDTO;
import com.idexx.imaging.imagemanager.soap.PatientDTO;
import com.idexx.imaging.imagemanager.soap.PatientSearchRequestDTO;
import com.idexx.imaging.imagemanager.soap.StoreImageMetaDataDTO;
import com.idexx.imaging.imagemanager.soap.StudyDTO;

/**
 * <pre>
 * Mapper class for Create Request service.
 * </pre>
 * 
 * @author smallela
 * @version 1.3
 */

@Component("entityMapper")
public class EntityMapper {
	
	private static final Logger LOG = Logger.getLogger(EntityMapper.class);

	public static final String INVALID_DATE_FORMAT = "Invalid date format";

	/**
	 * <pre>
	 * Method returns RequestDetails
	 * </pre>
	 * 
	 * @param dto
	 * @return
	 */
	public RequestDetails dtoToEntityMapper(RequestDetailsDTO requestDetailsDTO) {
		RequestDetails requestDetails = new RequestDetails();
		requestDetails.setAccessionNumber(requestDetailsDTO.getAccessionNumber());
		requestDetails.setApiKey(requestDetailsDTO.getApiKey());
		requestDetails.setModality(requestDetailsDTO.getModality());
		requestDetails.setPatientId(requestDetailsDTO.getPatientId());
		requestDetails.setRequestingDoctor(requestDetailsDTO.getRequestingDoctor());
		requestDetails.setRequestNotes(requestDetailsDTO.getRequestNotes());
		requestDetails.setSapId(requestDetailsDTO.getSapId());
		requestDetails.setStudyInstanceUID(requestDetailsDTO.getStudyInstanceUID());
		requestDetails.setCreateTimeStamp(new Timestamp(System.currentTimeMillis()));
		requestDetails.setStatus(IdexxDicomServiceConstants.MPPS_REQUEST_STATUS_PENDING);
		return requestDetails;
	}

	/**
	 * <pre>
	 * Method returns RequestDetailsDTO
	 * </pre>
	 * 
	 * @param requestDetails
	 * @return
	 * 
	 */
	public RequestDetailsDTO entityToDtoMapper(RequestDetails requestDetails) {
		RequestDetailsDTO requestDetailsDTO = new RequestDetailsDTO();
		requestDetailsDTO.setAccessionNumber(requestDetails.getAccessionNumber());
		requestDetailsDTO.setApiKey(requestDetails.getApiKey());
		requestDetailsDTO.setModality(requestDetails.getModality());
		requestDetailsDTO.setPatientId(requestDetails.getPatientId());
		requestDetailsDTO.setRequestingDoctor(requestDetails.getRequestingDoctor());
		requestDetailsDTO.setRequestNotes(requestDetails.getRequestNotes());
		requestDetailsDTO.setSapId(requestDetails.getSapId());
		requestDetailsDTO.setStudyInstanceUID(requestDetails.getStudyInstanceUID());
		requestDetailsDTO.setCreateTimeStamp(new Timestamp(System.currentTimeMillis()));
		requestDetailsDTO.setStatus(IdexxDicomServiceConstants.MPPS_REQUEST_STATUS_PENDING);
		return requestDetailsDTO;
	}

	/**
	 * <pre>
	 * Method returns PatientSearchRequestDTO
	 * </pre>
	 * 
	 * @param req
	 * @return
	 */
	public PatientSearchRequestDTO getPatientSearchRequestDTO(RequestDetailsDTO requestDetailsDTO) {
		PatientSearchRequestDTO patientSearchRequestDTO = new PatientSearchRequestDTO();
		patientSearchRequestDTO.setApiKey(requestDetailsDTO.getApiKey());
		patientSearchRequestDTO.setClientFirstName(requestDetailsDTO.getClientFirstName());
		patientSearchRequestDTO.setClientLastName(requestDetailsDTO.getClientLastName());
		patientSearchRequestDTO.setIncludeDeletes(true);
		patientSearchRequestDTO.setIncludeInactivePatients(true);
		patientSearchRequestDTO.setClinicId(Integer.parseInt(requestDetailsDTO.getSapId()));
		patientSearchRequestDTO.setApplicationPatientId(requestDetailsDTO.getPatientId());
		patientSearchRequestDTO.setIssuerOfPatientId(requestDetailsDTO.getPimsIssuer());		
		return patientSearchRequestDTO;
	}

	public MPPSNCreate dtoToEntityMapper(MPPSNCreateDTO dto) {
		MPPSNCreate req = new MPPSNCreate();
		req.setId(dto.getId());
		req.setMppsSOPInstanceUID(dto.getMppsSOPInstanceUID());
		req.setPatientId(dto.getPatientId());
		req.setPerformedStationAETitle(dto.getPerformedStationAETitle());
		req.setPerformedProcedureStepStartDate(dto.getPerformedProcedureStepStartDate());
		req.setPerformedProcedureStepEndDate(dto.getPerformedProcedureStepEndDate());
		req.setPerformedStationName(dto.getPerformedStationName());
		req.setPerformedLocation(dto.getPerformedLocation());
		req.setPerformedProcedureStepStatus(dto.getPerformedProcedureStepStatus());
		req.setStudyInstanceUID(dto.getStudyInstanceUID());
		req.setScheduledProcedureStepId(dto.getScheduledProcedureStepId());
		req.setCreateTimestamp(dto.getCreateTimestamp());
		req.setUpdateTimestamp(dto.getUpdateTimestamp());
		return req;
	}

	public MPPSNCreateDTO entityToDTOMapper(MPPSNCreate entity) {
		MPPSNCreateDTO req = new MPPSNCreateDTO();

		req.setId(entity.getId());
		req.setMppsSOPInstanceUID(entity.getMppsSOPInstanceUID());
		req.setPatientId(entity.getPatientId());
		req.setPerformedStationAETitle(entity.getPerformedStationAETitle());
		req.setPerformedProcedureStepStartDate(entity.getPerformedProcedureStepStartDate());
		req.setPerformedProcedureStepEndDate(entity.getPerformedProcedureStepEndDate());
		req.setPerformedStationName(entity.getPerformedStationName());
		req.setPerformedLocation(entity.getPerformedLocation());
		req.setPerformedProcedureStepStatus(entity.getPerformedProcedureStepStatus());
		req.setStudyInstanceUID(entity.getStudyInstanceUID());
		req.setScheduledProcedureStepId(entity.getScheduledProcedureStepId());
		req.setCreateTimestamp(entity.getCreateTimestamp());
		req.setUpdateTimestamp(entity.getUpdateTimestamp());
		return req;
	}

	public MPPSNSet dtoToEntityMapper(MPPSNSetDTO dto) {
		MPPSNSet req = new MPPSNSet();

		req.setId(dto.getId());
		req.setMppsNCreateId(dto.getMppsNCreateId());
		req.setRetrieveAETitle(dto.getRetrieveAETitle());
		req.setReferencedSOPInstanceUIDs(dto.getReferencedSOPInstanceUIDs());
		req.setSeriesDescription(dto.getSeriesDescription());
		req.setPerformingPhysicianName(dto.getPerformingPhysicianName());
		req.setProtocolName(dto.getProtocolName());
		req.setOperatorsName(dto.getOperatorsName());
		req.setSeriesInstanceUID(dto.getSeriesInstanceUID());
		req.setCreateTimestamp(dto.getCreateTimestamp());
		req.setUpdateTimestamp(dto.getUpdateTimestamp());
		return req;
	}

	/**
	 * <pre>
	 * Method to generate Study Instance Unique ID
	 * </pre>
	 * 
	 * @param req
	 * @return
	 */
	public String generateStudyInstanceUid(RequestDetailsDTO requestDetailsDTO) {
		SimpleDateFormat studySDF = new SimpleDateFormat(SendImageJobConstants.SIMPLE_DATE_FORMAT);
		String studyTimestamp = studySDF.format(new Date());
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(SendImageJobConstants.IDEXX_DICOM_PREFIX).append(".").append(requestDetailsDTO.getSapId())
				.append(".").append(studyTimestamp);
		return stringBuilder.toString();
	}

	/**
	 * <pre>
	 * Method returns PatientDTO
	 * </pre>
	 * 
	 * @param req
	 * @return
	 */
	public PatientDTO getPatient(RequestDetailsDTO req) {

	    PatientDTO patientDTO = new PatientDTO();
		
		ExternalPatientIdDTO externalPatientDTO = new ExternalPatientIdDTO();
		externalPatientDTO.setIssuerOfPatientId(req.getPimsIssuer());
		externalPatientDTO.setPimsPatientId(req.getPatientId());
		patientDTO.setApplicationPatientId(req.getPatientId());
		patientDTO.setBreed(req.getBreed());
		patientDTO.setClientFirstName(req.getClientFirstName());
		patientDTO.setClientLastName(req.getClientLastName());
		patientDTO.setClinicId(req.getSapId());
		patientDTO.setDob(getFormatDOB(req.getPatientDOB()));
		patientDTO.setGender(req.getSex());
		patientDTO.setPatientName(req.getPatientName());
		patientDTO.setSpecies(req.getSpecies());
		patientDTO.getExternalPatientIds().add(externalPatientDTO);

		return patientDTO;
	}

	
	/**
	 * <pre>
	 * Store Image Data DTO
	 * </pre>
	 * 
	 * @param req
	 * @return
	 */
	public StoreImageMetaDataDTO getStoreImageMetaData(RequestDetailsDTO req) {

		StoreImageMetaDataDTO storeImageMetaDataDTO = new StoreImageMetaDataDTO();
		ImageDTO imageDTO = new ImageDTO();

		storeImageMetaDataDTO.setApiKey(req.getApiKey());
		storeImageMetaDataDTO.setClinicId(Integer.parseInt(req.getSapId()));
		storeImageMetaDataDTO.setImage(imageDTO);
		storeImageMetaDataDTO.setPatient(getPatient(req));
		storeImageMetaDataDTO.setStudy(getStudy(req));

		return storeImageMetaDataDTO;
	}

	/**
	 * 
	 * <pre>
	 * Method to set the Study DTOs
	 * </pre>
	 * 
	 * @param req
	 * @param studyInstanceUid
	 * @return
	 *
	 */
	public StudyDTO getStudy(RequestDetailsDTO req) {
		StudyDTO studyDTO = new StudyDTO();
		studyDTO.setStudyDate(getStudydDate());
		studyDTO.setStudyInstanceUid(req.getStudyInstanceUID());
		studyDTO.setDoctor(req.getRequestingDoctor());
		return studyDTO;
	}

	/**
	 * Return Study date in XMLGregorianCalendar format.
	 * 
	 * @return
	 *
	 */
	protected XMLGregorianCalendar getStudydDate() {
		XMLGregorianCalendar xmlGC = null;

		SimpleDateFormat studySDF = new SimpleDateFormat(SendImageJobConstants.CREATE_PATIENT_DATE_FORMAT);
		String studyDate = studySDF.format(new Date());
		try {
			xmlGC = DatatypeFactory.newInstance().newXMLGregorianCalendar(studyDate);
		} catch (DatatypeConfigurationException e) {
			LOG.error("Exception in Study date format.", e);			
		}

		return xmlGC;
	}

	/**
	 * 
	 * <pre>
	 * Return date in XMLGregorianCalendar format.
	 * </pre>
	 * 
	 * @param strDdate
	 * @return
	 * @throws IdexxDicomAEConfigServiceException
	 *
	 */
	protected XMLGregorianCalendar getFormatDOB(String strDdate) {
		String strPatientDOB = null;
		XMLGregorianCalendar xmlGC = null;
		SimpleDateFormat sdf = new SimpleDateFormat(SendImageJobConstants.PATIENT_DOB_FORMAT);

		try {
			Date dobDate = sdf.parse(strDdate);
			SimpleDateFormat sdf1 = new SimpleDateFormat(SendImageJobConstants.CREATE_PATIENT_DATE_FORMAT);
			strPatientDOB = sdf1.format(dobDate);

			xmlGC = DatatypeFactory.newInstance().newXMLGregorianCalendar(strPatientDOB);
		} catch (ParseException e) {
			LOG.error(INVALID_DATE_FORMAT, e);			
		} catch (DatatypeConfigurationException e) {
			LOG.error(INVALID_DATE_FORMAT, e);			
		}

		return xmlGC;
	}

	/**
	 * 
	 * <pre>
	 * Return date in String format.
	 * </pre>
	 * 
	 * @param XMLGregorianCalendar
	 * @return
	 * @throws IdexxDicomAEConfigServiceException
	 *
	 */
	public String getDateFromXMLGregorianCalendar(XMLGregorianCalendar strDdate) {
		String strPatientDOB = null;
		try {
			SimpleDateFormat sdf1 = new SimpleDateFormat(SendImageJobConstants.CREATE_PATIENT_DATE_FORMAT);
			strPatientDOB = sdf1.format(strDdate.toGregorianCalendar().getTime());
		} catch (Exception e) {
			LOG.error(INVALID_DATE_FORMAT, e);			
		}

		return strPatientDOB;
	}

	public String getStringFromTimestamp(Timestamp timestamp) {
		String str = null;
		try {
			SimpleDateFormat sdf1 = new SimpleDateFormat(SendImageJobConstants.PATIENT_DOB_FORMAT);
			str = sdf1.format(timestamp.getTime());
		} catch (Exception e) {
			LOG.error(INVALID_DATE_FORMAT, e);			
		}
		return str;
	}

	public String getStringDateTimeFromTimestamp(Timestamp timestamp) {
		String str = null;
		try {
			SimpleDateFormat sdf1 = new SimpleDateFormat(SendImageJobConstants.CREATE_PATIENT_DATE_FORMAT);
			str = sdf1.format(timestamp.getTime());
		} catch (Exception e) {
			LOG.error(INVALID_DATE_FORMAT, e);			
		}
		return str;
	}
}
