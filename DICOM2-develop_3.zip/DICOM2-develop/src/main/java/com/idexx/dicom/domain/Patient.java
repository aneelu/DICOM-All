package com.idexx.dicom.domain;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "PATIENT")
public class Patient {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
	private String iD;

	@Column(name="NAME")
	private java.lang.String patientName;

	@Column(name="DOB")
	private Timestamp dob;

	@Column(name="SPECIES")
	private java.lang.String species;
	
	@Column(name="BREED")
	private java.lang.String breed;

	@Column(name="GENDER")
	private java.lang.String gender;
	
	@Column(name="APPLICATION_PATIENT_ID")
	private java.lang.String applicationPatientId;
	
	@Column(name="SAP_ID")
	private java.lang.String clinicId;
	
	@Column(name="WEIGHT")
	private java.lang.Integer weight;
	
	@Column(name="EDHD_NUMBER")
	private java.lang.String edhdNumber;
	
	@Column(name="WEIGHT_UNIT")
	private java.lang.String weightUnit;
	
	@Column(name="ACTIVE_FLAG")
	private java.lang.Integer activeFlag;
	
	@Column(name="LAST_MOD_DATE")
	private Timestamp lastModifiedDate;

	/**
	 * @return the id
	 */
	public String getID() {
		return iD;
	}

	/**
	 * @param id the id to set
	 */
	public void setID(String iD) {
		this.iD = iD;
	}

	/**
	 * @return the patientName
	 */
	public java.lang.String getPatientName() {
		return patientName;
	}

	/**
	 * @param patientName the patientName to set
	 */
	public void setPatientName(java.lang.String patientName) {
		this.patientName = patientName;
	}

	/**
	 * @return the dob
	 */
	public Timestamp getDob() {
		return dob;
	}

	/**
	 * @param dob the dob to set
	 */
	public void setDob(Timestamp dob) {
		this.dob = dob;
	}

	/**
	 * @return the species
	 */
	public java.lang.String getSpecies() {
		return species;
	}

	/**
	 * @param species the species to set
	 */
	public void setSpecies(java.lang.String species) {
		this.species = species;
	}

	/**
	 * @return the breed
	 */
	public java.lang.String getBreed() {
		return breed;
	}

	/**
	 * @param breed the breed to set
	 */
	public void setBreed(java.lang.String breed) {
		this.breed = breed;
	}

	/**
	 * @return the gender
	 */
	public java.lang.String getGender() {
		return gender;
	}

	/**
	 * @param gender the gender to set
	 */
	public void setGender(java.lang.String gender) {
		this.gender = gender;
	}

	/**
	 * @return the applicationPatientId
	 */
	public java.lang.String getApplicationPatientId() {
		return applicationPatientId;
	}

	/**
	 * @param applicationPatientId the applicationPatientId to set
	 */
	public void setApplicationPatientId(java.lang.String applicationPatientId) {
		this.applicationPatientId = applicationPatientId;
	}

	/**
	 * @return the clinicId
	 */
	public java.lang.String getClinicId() {
		return clinicId;
	}

	/**
	 * @param clinicId the clinicId to set
	 */
	public void setClinicId(java.lang.String clinicId) {
		this.clinicId = clinicId;
	}

	/**
	 * @return the weight
	 */
	public java.lang.Integer getWeight() {
		return weight;
	}

	/**
	 * @param weight the weight to set
	 */
	public void setWeight(java.lang.Integer weight) {
		this.weight = weight;
	}

	/**
	 * @return the edhdNumber
	 */
	public java.lang.String getEdhdNumber() {
		return edhdNumber;
	}

	/**
	 * @param edhdNumber the edhdNumber to set
	 */
	public void setEdhdNumber(java.lang.String edhdNumber) {
		this.edhdNumber = edhdNumber;
	}

	/**
	 * @return the weightUnit
	 */
	public java.lang.String getWeightUnit() {
		return weightUnit;
	}

	/**
	 * @param weightUnit the weightUnit to set
	 */
	public void setWeightUnit(java.lang.String weightUnit) {
		this.weightUnit = weightUnit;
	}

	/**
	 * @return the activeFlag
	 */
	public java.lang.Integer getActiveFlag() {
		return activeFlag;
	}

	/**
	 * @param activeFlag the activeFlag to set
	 */
	public void setActiveFlag(java.lang.Integer activeFlag) {
		this.activeFlag = activeFlag;
	}

	/**
	 * @return the lastModifiedDate
	 */
	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}

	/**
	 * @param lastModifiedDate the lastModifiedDate to set
	 */
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
