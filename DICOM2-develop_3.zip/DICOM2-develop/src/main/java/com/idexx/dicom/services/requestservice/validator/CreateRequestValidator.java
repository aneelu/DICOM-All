/**
 * <h1>Class to validate the Create Request mandatory parameters.</h1>
 */
package com.idexx.dicom.services.requestservice.validator;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.requestservice.dto.CreateRequestErrorCodesConstants;
import com.idexx.dicom.services.requestservice.dto.RequestDetailsDTO;

/**
 * <pre>
 * Class to validate the Create Request mandatory parameters.
 * </pre>
 * 
 * @author nayeemuddin
 * @version 1.3
 */
@Service("requestServiceValidator")
public class CreateRequestValidator {
	
	private static final Logger LOG = Logger.getLogger(CreateRequestValidator.class);

    /**
     * 
     * <pre>
     * Method to validate create request mandatory parameters.
     * </pre>
     * 
     * @param dto
     * @return
     * @throws IdexxDicomAEConfigServiceException
     *
     */
    public List<ErrorDTO> validate(final RequestDetailsDTO dto) throws IdexxDicomAEConfigServiceException {

	List<ErrorDTO> listOfErrors = new ArrayList<ErrorDTO>();

	if (StringUtils.isEmpty(dto.getApiKey()) || StringUtils.isEmpty(dto.getClientLastName())
		|| StringUtils.isEmpty(dto.getPatientId()) || StringUtils.isEmpty(dto.getPatientName())
		|| StringUtils.isEmpty(dto.getSapId()) || StringUtils.isEmpty(dto.getPimsIssuer())
		|| StringUtils.isEmpty(dto.getPatientDOB()) || StringUtils.isEmpty(dto.getBreed())
		|| StringUtils.isEmpty(dto.getClientFirstName()) || StringUtils.isEmpty(dto.getModality())
		|| StringUtils.isEmpty(dto.getSex()) || StringUtils.isEmpty(dto.getRequestingDoctor())
		|| StringUtils.isEmpty(dto.getSpecies())) {

	    dto.setAllInputsAvailable(false);

	    if (StringUtils.isEmpty(dto.getPatientDOB())) {
		listOfErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.PATIENT_DOB_ERROR_CODE, CreateRequestErrorCodesConstants.PATIENT_DOB_ERROR_CODE_MSG));
	    }

	    if (StringUtils.isEmpty(dto.getPatientId())) {
		listOfErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.PATIENT_ID_ERROR_CODE, CreateRequestErrorCodesConstants.PATIENT_ID_ERROR_CODE_MSG));
	    }

	    if (StringUtils.isEmpty(dto.getPatientName())) {
		listOfErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.PATIENT_NAME_ERROR_CODE, CreateRequestErrorCodesConstants.PATIENT_NAME_ERROR_CODE_MSG));
	    }

	    if (StringUtils.isEmpty(dto.getModality())) {
		listOfErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.MODALITY_ERROR_CODE, CreateRequestErrorCodesConstants.MODALITY_ERROR_CODE_MSG));
	    }

	    if (StringUtils.isEmpty(dto.getClientFirstName())) {
		listOfErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.CLIENT_FIRST_NAME_ERROR_CODE, CreateRequestErrorCodesConstants.CLIENT_FIRST_NAME_ERROR_CODE_MSG));
	    }

	    if (StringUtils.isEmpty(dto.getClientLastName())) {
		listOfErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.CLIENT_LAST_NAME_ERROR_CODE, CreateRequestErrorCodesConstants.CLIENT_LAST_NAME_ERROR_CODE_MSG));
	    }

	    if (StringUtils.isEmpty(dto.getSex())) {
		listOfErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.SEX_ERROR_CODE, CreateRequestErrorCodesConstants.SEX_ERROR_CODE_MSG));
	    }

	    if (StringUtils.isEmpty(dto.getBreed())) {
		listOfErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.BREED_ERROR_CODE, CreateRequestErrorCodesConstants.BREED_ERROR_CODE_MSG));
	    }

	    if (StringUtils.isEmpty(dto.getSpecies())) {
		listOfErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.SPECIES_ERROR_CODE, CreateRequestErrorCodesConstants.SPECIES_ERROR_CODE_MSG));
	    }

	    if (StringUtils.isEmpty(dto.getRequestingDoctor())) {
		listOfErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.DOCTOR_ERROR_CODE, CreateRequestErrorCodesConstants.DOCTOR_ERROR_CODE_MSG));
	    }

	    if (StringUtils.isEmpty(dto.getPimsIssuer())) {
		listOfErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.PIMS_ISSUER_ERROR_CODE, CreateRequestErrorCodesConstants.PIMS_ISSUER_ERROR_CODE_MSG));
	    }

	    if (StringUtils.isEmpty(dto.getApiKey())) {
		listOfErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.API_KEY_ERROR_CODE, CreateRequestErrorCodesConstants.API_KEY_ERROR_CODE_MSG));
	    }

	    if (StringUtils.isEmpty(dto.getSapId())) {
		listOfErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.SAP_ID_ERROR_CODE, CreateRequestErrorCodesConstants.SAP_ID_ERROR_CODE_MSG));
	    }
	} else {
	    dto.setAllInputsAvailable(true);
	}

	if (!StringUtils.isEmpty(dto.getPatientDOB())) {
	    XMLGregorianCalendar xmlGC = getFormatDOB(dto.getPatientDOB());
	    LOG.info("Patient date of birth: " + xmlGC);
	    if (null == xmlGC) {
		dto.setAllInputsAvailable(false);
		listOfErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.INVALID_PATIENT_DOB_ERROR_CODE, CreateRequestErrorCodesConstants.INVALID_PATIENT_DOB_ERROR_CODE_MSG));
	    }
	}

	if (!StringUtils.isEmpty(dto.getSapId()) && !NumberUtils.isNumber(dto.getSapId())) {
	    dto.setAllInputsAvailable(false);
	    listOfErrors.add(new ErrorDTO(CreateRequestErrorCodesConstants.SAP_ID_NUMERIC_ERROR_CODE, CreateRequestErrorCodesConstants.SAP_ID_NUMERIC_ERROR_CODE_MSG));
	}

	return listOfErrors;
    }
    
    



    /**
     * 
     * @param strDdate
     * @return
     *
     */
    protected XMLGregorianCalendar getFormatDOB(String strDdate) {
	String strPatientDOB = null;
	XMLGregorianCalendar xmlGC = null;
	SimpleDateFormat sdf = new SimpleDateFormat(CreateRequestErrorCodesConstants.PATIENT_DOB_FORMAT);

	try {
	    Date dobDate = sdf.parse(strDdate);
	    SimpleDateFormat sdf1 = new SimpleDateFormat(CreateRequestErrorCodesConstants.CREATE_PATIENT_DATE_FORMAT);
	    strPatientDOB = sdf1.format(dobDate);

	    xmlGC = DatatypeFactory.newInstance().newXMLGregorianCalendar(strPatientDOB);
	} catch (ParseException e) {
	    LOG.error(CreateRequestErrorCodesConstants.INVALID_PATIENT_DOB_ERROR_CODE, e);
	} catch (DatatypeConfigurationException e) {
	    LOG.error(CreateRequestErrorCodesConstants.INVALID_PATIENT_DOB_ERROR_CODE, e);
	}

	return xmlGC;
    }

}
