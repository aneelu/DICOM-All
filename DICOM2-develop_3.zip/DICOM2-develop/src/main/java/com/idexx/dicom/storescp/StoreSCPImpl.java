package com.idexx.dicom.storescp;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.security.GeneralSecurityException;
import java.util.Map;

import org.apache.commons.cli.ParseException;
import org.apache.log4j.Logger;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;
import org.dcm4che3.data.VR;
import org.dcm4che3.io.DicomOutputStream;
import org.dcm4che3.net.ApplicationEntity;
import org.dcm4che3.net.Association;
import org.dcm4che3.net.Device;
import org.dcm4che3.net.PDVInputStream;
import org.dcm4che3.net.Status;
import org.dcm4che3.net.TransferCapability;
import org.dcm4che3.net.pdu.PresentationContext;
import org.dcm4che3.net.service.BasicCEchoSCP;
import org.dcm4che3.net.service.BasicCStoreSCP;
import org.dcm4che3.net.service.DicomServiceException;
import org.dcm4che3.net.service.DicomServiceRegistry;
import org.dcm4che3.tool.storescp.StoreSCP;
import org.dcm4che3.util.SafeClose;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.idexx.dicom.dto.IdexxAuthorizationObject;
import com.idexx.dicom.services.IdexxDicomServiceConstants;
import com.idexx.dicom.store.DicomStoreServiceWithMetadataExtraction;
import com.idexx.dicom.store.authorization.IdexxAuthorization;
import com.idexx.dicom.store.impl.DicomStoreIMPluginService;
import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;

@Service("storeSCPImpl")
public class StoreSCPImpl {

	private static final Logger LOG = Logger.getLogger(StoreSCPImpl.class);
	
    int status;
    InputStream inputStream;

    @Autowired
    DicomStoreIMPluginService dicomStoreIMPluginService;

    @Autowired
    DicomStoreServiceWithMetadataExtraction dicomStoreService;

    public void init(Device device, ApplicationEntity ae, DicomServiceRegistry serviceRegistry)
	    throws IOException, ParseException, GeneralSecurityException {

	try {
	    StoreSCP main = new StoreSCP();
	    main.setStatus(0);
	    ae.addTransferCapability(new TransferCapability(null, "*", TransferCapability.Role.SCP, "*"));
	    serviceRegistry.addDicomService(new BasicCEchoSCP());
	    serviceRegistry.addDicomService(cstoreSCP);
	    device.setDimseRQHandler(serviceRegistry);

	} catch (IOException e) {
	    throw new DicomServiceException(Status.ProcessingFailure, e);
	}
    }

    private final BasicCStoreSCP cstoreSCP = new BasicCStoreSCP("*") {

	@Override
	protected void store(Association as, PresentationContext pc, Attributes rq, PDVInputStream data, Attributes rsp)
		throws IOException {
	    rsp.setInt(Tag.Status, VR.US, status);
	    String iuid = rq.getString(Tag.AffectedSOPInstanceUID);
	    String tsuid = pc.getTransferSyntax();
	    LOG.info( "Calling AET;" + as.getCallingAET());
	    LOG.info( "Called AET;" + as.getCalledAET());
	    Attributes attr = data.readDataset(tsuid);

	    InetAddress inetAddr = as.getSocket().getInetAddress();
	    Map<String, Object> props = dicomStoreIMPluginService.buildService();
	    IdexxAuthorization idexxAuthorization = dicomStoreService.getAuthorization(attr, as.getCallingAET(),
		    inetAddr.getHostAddress(), inetAddr.getHostName());
	    if (null == idexxAuthorization || (!idexxAuthorization.isAuthorized())) {
		throw new DicomServiceException(Status.ProcessingFailure, as.getCallingAET() + " is not Authorized ");
	    }
	    IdexxAuthorizationObject idexxAuthorizationObject = idexxAuthorization.getAuthorizationObject();
	    try {
		String storedImageReponse = dicomStoreService.callStoreImgMetaDataService(attr,
			idexxAuthorizationObject, as.getCallingAET(), props);
		LOG.info( "Stored Image Response created: " + storedImageReponse);

		try {
		    File file = getFileToWriteDCMFile(iuid + "." + props.get("fileType"));
		    DicomOutputStream out = new DicomOutputStream(file);
		    try {
			attr.writeTo(out);
		    } finally {
			SafeClose.close(out);			
		    }

		    storedImageReponse = dicomStoreService.callStoreUploadImgService(file, idexxAuthorizationObject,
			    storedImageReponse, as.getCallingAET(), props);
		    LOG.info( "upload Image Response created: " + storedImageReponse);

		} catch (IdexxServiceException_Exception e1) {
		    throw new DicomServiceException(Status.ProcessingFailure, as.getCallingAET() + " Exception :" + e1);
		}
	    } catch (Exception e) {
		throw new DicomServiceException(Status.ProcessingFailure, e);
	    }
	}

    };

    private File getFileToWriteDCMFile(String fileName) throws IOException {
	File dcmFile = null;
	String destFolder = "";
	destFolder = System.getProperty(IdexxDicomServiceConstants.JAVA_TEMP_LOCATION) + File.separator
	    + "tempFiles";
	File dir = new File(destFolder);
	if (!dir.exists()) {
	dir.mkdirs();
	}
	dcmFile = new File(dir.getAbsolutePath() + File.separator + fileName);
	return dcmFile;
    }

}
