/**
 * 
 */
package com.idexx.dicom;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.idexx.dicom.dao.store.SystemConfigDao;

/**
 * @author sbitla
 * 
 */
@Component
public class ImageManagerConfigurationProviderImpl implements
        ImageManagerConfigurationProvider {
    
    @Autowired
    SystemConfigDao sysConfigDao;
    
    /**
     * Constructor
     * 
     * @param sysConfigDao
     */
    public ImageManagerConfigurationProviderImpl(final SystemConfigDao sysConfigDao) {
        super();
        this.sysConfigDao = sysConfigDao;
    }
    public ImageManagerConfigurationProviderImpl() {
        super();
     
    }
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.store.ImageManagerConfigurationProvider#geCofingurationValues
     * ()
     */
    @Override
    public final Map<String, String> geCofingurationValues() {
        return sysConfigDao.getConfigValues();
    }
    
    public final String getConfigurationValue(final String configName) {
        return this.sysConfigDao.getConfigValueByConfigName(configName);
    }
    
}
