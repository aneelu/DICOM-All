/**
 * 
 */
package com.idexx.dicom.dao.store;

import javax.persistence.EntityManager;

import com.idexx.dicom.dao.store.impl.SystemConfigDaoImpl;
import com.idexx.dicom.dao.store.util.EntityManagerUtil;

/**
 * @author vkandagatla
 * 
 */
public class IdexxDicomSystemConfigDAoFactoryImpl implements IdexxDicomSystemConfigDAOFactory {
    private String context = "IDEXX_IM_PLGN";
    private static IdexxDicomSystemConfigDAOFactory instance;
    static {
        instance = new IdexxDicomSystemConfigDAoFactoryImpl();
    }
    
    public IdexxDicomSystemConfigDAOFactory getInstance() {
        return instance;
    }
    
    /**
     * Default Private
     */
    private IdexxDicomSystemConfigDAoFactoryImpl() {
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.store.dao.IdexxDicomSystemConfigDAOFactory#create()
     */
    @Override
    public final SystemConfigDao create() {
        EntityManager entityManager = EntityManagerUtil.getEntityManagerFactory(context).createEntityManager();
        SystemConfigDao sysConfigDao = new SystemConfigDaoImpl(entityManager);
        return sysConfigDao;
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.store.dao.IdexxDicomSystemConfigDAOFactory#create(java
     * .lang.String)
     */
    @Override
    public final SystemConfigDao create(final String context) {
        this.context = context;
        return this.create();
    }
    
}
