package com.idexx.dicom.echo.v13;

import java.io.IOException;

import org.dcm4che3.data.Attributes;
import org.dcm4che3.net.ApplicationEntity;
import org.dcm4che3.net.Connection;
import org.dcm4che3.net.Device;
import org.dcm4che3.tool.storescu.StoreSCU;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * 
 * @author lamarawadi
 * @version 1.3
 */
@Service("dicomEchoServiceImplV13")
public class DicomEchoServiceImpl {

	String remoteHostname = "aws-dico-jboss-dev01.dicom.idexxi.com";
	int remotePortNumber = 11112;
	String defaultCalledAET = "DCM4CHEE_MAIN";

	Device device = null;
	ApplicationEntity ae = null;
	Connection conn = null;

	public void init(Device device, ApplicationEntity ae, Connection conn) {
		this.device = device;
		this.ae = ae;
		this.conn = conn;
	}

	private static final Logger log = LoggerFactory.getLogger(DicomEchoServiceImpl.class);

	public boolean echo(final String callingAET) throws InterruptedException {
		return echo(callingAET, remoteHostname, remotePortNumber);
	}

	public boolean echo(final String callingAET, final String calledAET) throws InterruptedException {
		return echo(callingAET, calledAET, remoteHostname, remotePortNumber);
	}

	public boolean echo(final String callingAET, final String hostName, final int port) throws InterruptedException {
		return echo(callingAET, "DCM4CHEE_MAIN", hostName, port);
	}

	public boolean echo(final String callingAET, final String calledAET, final String hostName, final int port)
			throws InterruptedException {
		boolean returnValue = true;
		StoreSCU main = null;
		try {
			main = new StoreSCU(ae);
		} catch (IOException e) {
			log.error("Unable to echo the dicom server: " + e);
		}

		main.getAAssociateRQ().setCalledAET(calledAET);
		main.getRemoteConnection().setHostname(hostName);
		main.getRemoteConnection().setPort(port);
		main.getRemoteConnection().setTlsCipherSuites(conn.getTlsCipherSuites());
		main.getRemoteConnection().setTlsProtocols(conn.getTlsProtocols());
		main.setAttributes(new Attributes());

		try {
			main.open();
			main.echo();
		} catch (Exception exc) {
			log.error("Unable to echo the dicom server: " + exc);
			returnValue = false;
		} finally {
			try {
				main.close();
			} catch (IOException e) {
				log.error("Unable to echo the dicom server: " + e);
				returnValue = false;
			}
		}
		return returnValue;
	}
}