/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dicom.conf;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

/**
 * <pre>
 * Loading data source based on the environment
 * </pre>
 * 
 * @author vvanjarana
 * @version 1.3
 */
@Configuration
public class DBConfig {
	
	private static final Logger LOG = Logger.getLogger(DBConfig.class);

    @Autowired
    private Environment environment;

    public DriverManagerDataSource dataSource;

    @Profile("dev")
    @Bean
    public DataSource getDevConfigXml() {	
	LOG.info(
		"DriverClassName: " + environment.getRequiredProperty("jdbc.dev.driverClassName"));
	LOG.info( "jdbc.dev.url: " + environment.getRequiredProperty("jdbc.dev.url"));
	LOG.info(
		"jdbc.dev.username: " + environment.getRequiredProperty("jdbc.dev.username"));	
	dataSource = new DriverManagerDataSource();
	dataSource.setDriverClassName(environment.getRequiredProperty("jdbc.dev.driverClassName"));
	dataSource.setUrl(environment.getRequiredProperty("jdbc.dev.url"));
	dataSource.setUsername(environment.getRequiredProperty("jdbc.dev.username"));
	dataSource.setPassword(environment.getRequiredProperty("jdbc.dev.password"));
	return dataSource;
    }

    @Profile("qa")
    @Bean
    public DataSource getQAConfigXml() {
	LOG.info(
		"DriverClassName: " + environment.getRequiredProperty("jdbc.qa.driverClassName"));
	LOG.info( "jdbc.qa.url: " + environment.getRequiredProperty("jdbc.qa.url"));
	LOG.info(
		"jdbc.qa.username: " + environment.getRequiredProperty("jdbc.qa.username"));	
	dataSource = new DriverManagerDataSource();
	dataSource.setDriverClassName(environment.getRequiredProperty("jdbc.qa.driverClassName"));
	dataSource.setUrl(environment.getRequiredProperty("jdbc.qa.url"));
	dataSource.setUsername(environment.getRequiredProperty("jdbc.qa.username"));
	dataSource.setPassword(environment.getRequiredProperty("jdbc.qa.password"));
	return dataSource;
    }

    public DataSource getDataSource() {
	return this.dataSource;
    }

}
