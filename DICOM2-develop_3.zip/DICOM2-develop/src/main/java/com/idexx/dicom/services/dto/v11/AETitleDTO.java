package com.idexx.dicom.services.dto.v11;

/**
 * AETitleDTO hold information About AE
 */

import javax.xml.bind.annotation.XmlElement;

import org.apache.commons.lang.StringUtils;

/**
 * @author vkandagatla
 * 
 */
public class AETitleDTO extends IdexxAuthenticationDTO {
    private String aeTitle;
    
    private String instituteName;
    
    /**
     * @return the instituteName
     */
    public final String getInstituteName() {
        return instituteName;
    }
    
    /**
     * @param instituteName
     *            the instituteName to set
     */
    public final void setInstituteName(final String instituteName) {
        this.instituteName = StringUtils.trimToNull(instituteName);
    }
    
    /**
     * @return the aeTitle
     */
    @XmlElement(nillable = true, required = true)
    public final String getAeTitle() {
        return aeTitle;
    }
    
    /**
     * @param aeTitle
     *            the aeTitle to set
     */
    public final void setAeTitle(final String aeTitle) {
        this.aeTitle = StringUtils.trimToNull(aeTitle);
    }
    
}
