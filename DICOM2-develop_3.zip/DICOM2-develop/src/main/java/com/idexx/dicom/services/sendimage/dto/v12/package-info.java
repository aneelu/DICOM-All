/**
 * @author vkandagatla
 *
 */
package com.idexx.dicom.services.sendimage.dto.v12;
