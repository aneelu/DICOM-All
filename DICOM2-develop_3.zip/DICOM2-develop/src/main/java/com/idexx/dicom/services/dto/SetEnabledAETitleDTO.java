/**
 * 
 */
package com.idexx.dicom.services.dto;

/**
 * @author vkandagatla
 * 
 */
public class SetEnabledAETitleDTO extends AETitleDTO {
    private boolean enabled;
    
    /**
     * @return the enabled
     */
    public final boolean isEnabled() {
        return enabled;
    }
    
    /**
     * @param enabled
     *            the enabled to set
     */
    public final void setEnabled(final boolean enabled) {
        this.enabled = enabled;
    }
}
