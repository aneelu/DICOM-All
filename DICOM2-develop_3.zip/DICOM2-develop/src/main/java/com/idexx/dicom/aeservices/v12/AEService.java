/**
 * Service Contract to perform AE Service Actions.
 */
package com.idexx.dicom.aeservices.v12;

import com.idexx.dicom.services.dto.v12.AETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * @author vkandagatla
 * 
 */
public interface AEService {
    String GENERAL_DB_FAILURE = "ERR_general_db_fail";
    String NO_RECORD_FOUND = "ERR_no_record_found";
    
    void performService(AETitleDTO dto) throws IdexxDicomAEConfigServiceException;
    Object sendResponse();
    boolean isAPIKeyValid(String apiKey) throws IdexxDicomAEConfigServiceException;
}
