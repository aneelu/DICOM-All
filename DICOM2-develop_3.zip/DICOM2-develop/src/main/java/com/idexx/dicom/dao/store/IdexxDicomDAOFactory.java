/**
 * 
 */
package com.idexx.dicom.dao.store;

/**
 * @author vkandagatla
 *
 */
public interface IdexxDicomDAOFactory {
    DicomImMappingDAO getDicomImMappingDAO(String pContext);
}
