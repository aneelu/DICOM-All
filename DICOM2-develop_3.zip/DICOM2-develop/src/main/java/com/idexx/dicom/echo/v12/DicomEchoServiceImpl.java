package com.idexx.dicom.echo.v12;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service("dicomEchoServiceImplV12")
public class DicomEchoServiceImpl implements DicomEchoService {

    private static final Logger log = LoggerFactory.getLogger(DicomEchoServiceImpl.class);
 
    public boolean echo(final String callingAET) {
        return echo(callingAET, remoteHostname, remotePortNumber);
    }
    
    public boolean echo(final String callingAET, final String calledAET) {
        return echo(callingAET, calledAET, remoteHostname, remotePortNumber);
    }

    public boolean echo(final String callingAET,final String hostName,final int port) {
        return echo(callingAET, "DCM4CHEE_MAIN", hostName, port);
    }

    public boolean echo(final String callingAET, final String calledAET, final String hostName, final int port) {
    	return true;
    }
}