/**
 * 
 */
package com.idexx.dicom.dao.store;

import java.util.Map;

/**
 * @author vkandagatla
 * 
 */
public interface SystemConfigDao {
    
    Map<String, String> getConfigValues();
    
    String getConfigValueByConfigName(String configName);
}
