/**
 * 
 */
package com.idexx.dicom.entities.store;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author vkandagatla
 * 
 */
@Entity
@Table(name = "idx_dicom_components")
public class IdxDicomComponents implements Serializable {

    /**
     * Generated
     */
    private static final long serialVersionUID = -4073850813453485368L;
    private int id;
    private String componentName;
    private String requestType;

    /**
     * @return the id
     */
    @Id
    public int getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the componentName
     */
    @Column(name = "component_name")
    public String getComponentName() {
        return componentName;
    }

    /**
     * @param componentName
     *            the componentName to set
     */
    public void setComponentName(String componentName) {
        this.componentName = componentName;
    }

    /**
     * @return the requestType
     */
    @Column(name = "request_type")
    public String getRequestType() {
        return requestType;
    }

    /**
     * @param requestType
     *            the requestType to set
     */
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

}
