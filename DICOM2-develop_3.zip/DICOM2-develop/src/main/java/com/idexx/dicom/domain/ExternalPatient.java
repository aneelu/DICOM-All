package com.idexx.dicom.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@Table(name = "EXTERNAL_PATIENT_LINK")
@IdClass(ExternalPatientPK.class)
public class ExternalPatient {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="PATIENT_ID")
	private String patientID;

	@Id
	@Column(name="ISSUER_OF_PATIENT_ID")
	private String issuerOfPatientID;

	@Column(name="PIMS_PATIENT_ID")
	private String pimsPatientId;

	/**
	 * @return the patientId
	 */
	public String getPatientID() {
		return patientID;
	}

	/**
	 * @param patientId the patientId to set
	 */
	public void setPatientID(String patientID) {
		this.patientID = patientID;
	}

	/**
	 * @return the issuerOfPatientId
	 */
	public String getIssuerOfPatientID() {
		return issuerOfPatientID;
	}

	/**
	 * @param issuerOfPatientId the issuerOfPatientId to set
	 */
	public void setIssuerOfPatientID(String issuerOfPatientID) {
		this.issuerOfPatientID = issuerOfPatientID;
	}

	/**
	 * @return the pimsPatientId
	 */
	public String getPimsPatientId() {
		return pimsPatientId;
	}

	/**
	 * @param pimsPatientId the pimsPatientId to set
	 */
	public void setPimsPatientId(String pimsPatientId) {
		this.pimsPatientId = pimsPatientId;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
