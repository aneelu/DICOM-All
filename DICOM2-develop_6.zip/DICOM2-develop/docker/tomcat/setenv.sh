#!/bin/bash

JAVA_OPTS="$JAVA_OPTS -Xmx<JVM_HEAP>"
JAVA_OPTS="$JAVA_OPTS -XX:+UseConcMarkSweepGC -XX:+CMSPermGenSweepingEnabled -XX:+CMSClassUnloadingEnabled"
JAVA_OPTS="$JAVA_OPTS -Ddicom.env=<ENV>"
JAVA_OPTS="$JAVA_OPTS -Dspring.profiles.active=<ENV>"
JAVA_OPTS="$JAVA_OPTS -javaagent:<TOMCAT_HOMEDIR>/<TOMCAT_VERSION>/newrelic/newrelic.jar -Dnewrelic.environment=dicom-tc-<ENV>"
JAVA_OPTS="$JAVA_OPTS -Djdbc.<ENV>.url=<DB_URL>"
JAVA_OPTS="$JAVA_OPTS -Djdbc.<ENV>.username=<DB_USERNAME>"
JAVA_OPTS="$JAVA_OPTS -Djdbc.<ENV>.password=<DB_PASSWORD>"
JAVA_OPTS="$JAVA_OPTS -Djdbc.<ENV>.driverClassName=<DB_DRIVER_CLASS_NAME>"