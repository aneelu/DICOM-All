/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dicom.store.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.idexx.dicom.ImageManagerConfigurationProvider;
import com.idexx.dicom.sendimage.ImageManagerStoreServiceProviderWraper;
import com.idexx.dicom.store.DicomStoreServiceWithMetadataExtraction;
import com.idexx.imaging.imagemanager.soap.IDEXXImageManagerServices;

/**
 * <pre>Description of the class</pre>
 * @author vvanjarana
 * @version 1.3
 */
@Component("dicomStoreIMPluginService")
public class DicomStoreIMPluginService {
    
    @Autowired
    ImageManagerConfigurationProvider imageManagerConfigurationProvider;
    
    @Autowired
    ImageManagerStoreServiceProviderWraper imageManagerStoreServiceProviderWraper;
    
    private static final long DEFAULT_TIMEOUT = 60000L;
    
    public Map<String, Object> buildService() {
        long timeOut = DEFAULT_TIMEOUT;
        String contentType;
        String fileType;
        String genThumbNail;
        String imageManagerURL;
        String baseDir;
	Map<String, String> configMap = imageManagerConfigurationProvider.geCofingurationValues();
	String value = configMap.get("contentType");
        if (value == null) {
            contentType = "application\\dicom";
        } else {
            contentType = value;
        }

        value = configMap.get("imageManagerURL");
        if (value == null) {
            imageManagerURL = "http://localhost:8980/AssetManagerWar/soap/img-mgr-api-1.15";
        } else {
            imageManagerURL = value;
        }

        value = configMap.get("fileType");
        if (value == null) {
            fileType = "dcm";
        } else {
            fileType = value;
        }
        value = configMap.get("BaseDir");
        if (value == null) {
            baseDir = "/media/ephemeral0/dicom-services/dcm4chee-2.17.3-mysql/server/dcm4chee_main/archive/";
        } else {
            baseDir = value;
        }
        value = configMap.get("generateThumbnail");
        if (value == null) {
            genThumbNail = "false";
        } else {
            genThumbNail = value;
        }
        value = configMap.get("wsTimeout");
        if (value != null) {
            timeOut = Long.parseLong(value.trim());
        }
        //idexxImService = getHandler(imageManagerURL, timeOut);
        Map<String, Object> props = new HashMap<String, Object>();
        props.put("contentType", contentType);
        props.put("genThumbNail", genThumbNail);
        props.put("fileType", fileType);
        props.put("imageManagerServiceStoreHandler", getHandler(imageManagerURL, timeOut));
        props.put("baseDir", baseDir);
        return props;
    }
    
    public DicomStoreServiceWithMetadataExtraction getDicomStoreServiceWithMetadataExtractionInstance (Map<String, Object> props){
	return new DicomStoreServiceWithMetadataExtraction((String) props.get("contentType"),
                (String) props.get("fileType"), (String) props.get("genThumbNail"),
                (IDEXXImageManagerServices) props.get("imageManagerServiceStoreHandler"));
    }
    
    
    private IDEXXImageManagerServices getHandler(final String imageManagerStoreURL, final long timeout) {
	IDEXXImageManagerServices idexxImService = imageManagerStoreServiceProviderWraper.getService();
        return idexxImService;
    }
}
