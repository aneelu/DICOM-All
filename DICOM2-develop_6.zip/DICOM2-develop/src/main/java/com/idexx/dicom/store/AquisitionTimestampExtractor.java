/**
 * 
 */
package com.idexx.dicom.store;

import java.util.List;

import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;

import com.idexx.dicom.entities.store.DicomImageManagerMapping;

/**
 * @author vkandagatla
 * 
 */
public class AquisitionTimestampExtractor extends AbstractExtractor {

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.store.ImageManagerAttributeExtractorFromDicomElement#
     * exractAtribute(org.dcm4che.data.Dataset)
     */
    @Override
    public final String exractAtribute(final Attributes dataset) {
        String value = this.getTagValueAsString(Tag.AcquisitionDateTime, dataset);
        if (value != null && value.equalsIgnoreCase("null"))  {
            return null;
        }
        return value;
    }

    /**
     * @param defaultValueProvider
     */
    public AquisitionTimestampExtractor(final List<DicomImageManagerMapping> mapping,
            final DefaultValueProvider<String> defaultValueProvider) {
        super(mapping);
    }

}
