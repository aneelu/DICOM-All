/**
 * 
 */
package com.idexx.dicom.store;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;

import com.idexx.dicom.entities.store.DicomImageManagerMapping;

/**
 * @author anarayana
 * 
 */
public class ImageTitleExtractor extends AbstractExtractor {

	private static final Logger LOG = Logger.getLogger(ImageTitleExtractor.class);
	
    public ImageTitleExtractor(final List<DicomImageManagerMapping> mapping) {
        super(mapping);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.store.ImageManagerAttributeExtractorFromDicomElement#
     * exractAtribute(org.dcm4che.data.Dataset)
     */
    @Override
    public final String exractAtribute(final Attributes dataset) {
        
        String imageTitle = StringUtils.EMPTY;
        String tagComments = this.getTagValueAsString(Tag.ImageComments, dataset);
        String bodyPartExamined = this.getTagValueAsString(Tag.BodyPartExamined, dataset);
        
        LOG.info("exractAtribute == tagComments: " + tagComments + ", bodyPartExamined: " + bodyPartExamined);
        if (!StringUtils.isEmpty(tagComments)) {
            imageTitle =  tagComments;
            LOG.info("tagComments imageTitle: ");
        } else if (!StringUtils.isEmpty(bodyPartExamined)) {
            imageTitle = bodyPartExamined;
            LOG.info("bodyPartExamined imageTitle: ");
        }
        
        return imageTitle;
    }

}
