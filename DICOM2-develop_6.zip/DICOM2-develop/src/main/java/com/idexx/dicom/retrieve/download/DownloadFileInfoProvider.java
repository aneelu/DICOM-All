/**
 *     Provider class for Download File info class
 */
package com.idexx.dicom.retrieve.download;

import java.util.List;

import org.dcm4che3.data.Attributes;

import com.idexx.dicom.retrieve.download.impl.IdexxFileInfo;

/**
 * @author vkandagatla
 *
 */
public interface DownloadFileInfoProvider {
    int DATSET_MAX_BUFFER_LENGTH = 64;
    List<IdexxFileInfo> getFileInfoList(Attributes dataset, String callingAET, String calledAET) throws Exception;
}
