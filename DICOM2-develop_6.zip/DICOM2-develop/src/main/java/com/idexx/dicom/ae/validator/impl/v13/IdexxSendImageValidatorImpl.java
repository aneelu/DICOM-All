/**
 * <h1>Validate the Send Image mandatory parameters.</h1>
 */
package com.idexx.dicom.ae.validator.impl.v13;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v13.SendImageJobParamDTO;

/**
 * <pre>Class to validate the Send Image mandatory parameters.</pre>
 * @author nayeemuddin
 * @version 1.3
 */
@Service("idexxSendImageValidatorV13")
public class IdexxSendImageValidatorImpl {
	
	public final static String MISSING_MANDATORY = "ERR_argument_missing_mandatory";
	public final static String MISSING_INSTITUTE_NAME = "ERR_argument_missing_institute";
	public final static String RECORD_ALREADY_EXISTS = "ERR_record_already_exists";
	public final static String NO_RECORD_FOUND = "ERR_no_record_found";
	public final static String GENERAL_DB_FAILURE = "ERR_general_db_fail";
	public final static String INVALID_AETITLE = "ERR_invalid_AE_title";
	public final static String INVALID_DATE_RANGE = "ERR_invalid_date_range";
	public final static String INVALID_START_DATE = "ERR_invalid_start_date";
	public final static String INVALID_END_DATE = "ERR_invalid_end_date"; 
	
	/**
	 * 
	 * <pre>Method to validate the Send Image mandatory parameters.</pre>
	 * @param dto
	 * @return
	 * @throws IdexxDicomAEConfigServiceException
	 *
	 */
	public int validate(final SendImageJobParamDTO dto) throws IdexxDicomAEConfigServiceException {
        if (StringUtils.isEmpty(dto.getApiKey())
                || StringUtils.isEmpty(dto.getDestinationAETitle())
                || StringUtils.isEmpty(dto.getDestinationHost())
                || StringUtils.isEmpty(dto.getDestinationPort())
                || StringUtils.isEmpty(dto.getImageAssetId())
                || StringUtils.isEmpty(dto.getSendingAETitle())) {
            throw new IdexxDicomAEConfigServiceException(
                    MISSING_MANDATORY, MISSING_MANDATORY);
        }
        if (dto.getDestinationPort() <= 0) {
            throw new IdexxDicomAEConfigServiceException(
                    MISSING_MANDATORY, MISSING_MANDATORY);
        }
        return 1;
    }

}
