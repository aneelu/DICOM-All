package com.idexx.dicom.domain;

import java.io.Serializable;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

public class OwnerPK implements Serializable {
    private static final long serialVersionUID = 1561341072506779126L;
    private String clientID;
    private String patientID;

    /**
     * @return the clientID
     */
    public String getClientID() {
	return clientID;
    }

    /**
     * @param clientID
     *            the clientID to set
     */
    public void setClientID(String clientID) {
	this.clientID = clientID;
    }

    /**
     * @return the patientID
     */
    public String getPatientID() {
	return patientID;
    }

    /**
     * @param patientID
     *            the patientID to set
     */
    public void setPatientID(String patientID) {
	this.patientID = patientID;
    }

    /**
     * @return the serialversionuid
     */
    public static long getSerialversionuid() {
	return serialVersionUID;
    }

}