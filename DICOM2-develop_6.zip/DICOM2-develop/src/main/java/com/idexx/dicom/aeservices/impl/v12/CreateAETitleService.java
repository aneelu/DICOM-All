/**
 * 
 */
package com.idexx.dicom.aeservices.impl.v12;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.idexx.dicom.ae.entities.AEEntity;
import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.validator.v12.AETitleValidator;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.dto.v12.AETitleDTO;
import com.idexx.dicom.services.dto.v12.CreateAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * @author vkandagatla
 * 
 */
@Service("createAETitleServiceV12")
public class CreateAETitleService extends AbstractAEServiceImpl {
	
	private static final Logger LOG = Logger.getLogger(CreateAETitleService.class);
	
    @Autowired
    @Qualifier("createAETitleValidatorV12")
    private AETitleValidator validator;

    @Autowired
    private AETitleDao aeTitleDao;

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.aeservices.impl.AbstractAEServiceImpl#validate(com.idexx
     * .dicom.services.dto.IdexxDicomApplicationEntityDTO)
     */
    @Override
    @Transactional
    protected final int validate(final AETitleDTO dto) throws IdexxDicomAEConfigServiceException {
        return validator.validate(dto);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.aeservices.impl.AbstractAEServiceImpl#doService(com.idexx
     * .dicom.services.dto.IdexxDicomApplicationEntityDTO)
     */
    @Override
    @Transactional
    protected final int doService(final AETitleDTO dto) throws IdexxDicomAEConfigServiceException {

        CreateAETitleDTO createAEDTO = (CreateAETitleDTO) dto;
        try {
            LOG.info("isDvmSpecialist " + createAEDTO.isDvmSpecialist());
            LOG.info("AeTitle " + createAEDTO.getAeTitle());
            LOG.info("HostName " + createAEDTO.getHostName());
            LOG.info("Port " + createAEDTO.getPort());
            if (createAEDTO.isDvmSpecialist()) {
                AEEntity aeEntity = new AEEntity();
                aeEntity.setAeTitle(createAEDTO.getAeTitle());
                aeEntity.setHostName(createAEDTO.getHostName());
                aeEntity.setPort(createAEDTO.getPort());
                aeTitleDao.createAE(aeEntity);
            } else {
                String instituteName = null;
                AETitle aeTitle = new AETitle();
                aeTitle.setAeTitle(createAEDTO.getAeTitle());
                aeTitle.setApiKey(createAEDTO.getApiKey());
                aeTitle.setSapId(createAEDTO.getSapId());
                aeTitle.setEnabled(true);
                instituteName = createAEDTO.getInstituteName();
                if (instituteName == null) {
                    instituteName = "*";
                }
                aeTitle.setInstituteName(instituteName);
                aeTitle.setIdentifiedByaeTitleOnly(createAEDTO.isIdentifiedByAeTitleOnly());
                aeTitleDao.createAETitle(aeTitle);

            }
        } catch (IdexxDicomAEConfigDbException e) {
        	LOG.error(e);
            throw new IdexxDicomAEConfigServiceException(GENERAL_DB_FAILURE, GENERAL_DB_FAILURE);
        } catch (Exception e) {
            LOG.error(e);
            throw new IdexxDicomAEConfigServiceException(GENERAL_DB_FAILURE, GENERAL_DB_FAILURE);
        }
        return 1;
    }

}
