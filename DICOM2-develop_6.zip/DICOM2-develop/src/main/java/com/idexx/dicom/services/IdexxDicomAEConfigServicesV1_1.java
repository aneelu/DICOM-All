/**
 * IDEXX DICOM Web services.
 * This Implementation provides following services:
 * 1. Create AE Title - Creates new AE Title with given parameters
 * 2. Delete AE Title - delete given AE Title
 * 3. Read AE Title - read list of AE Titles for given AE Title name, inistitute name and with other params
 * 4. Set Enable AE Title - update AE Title, as enable/disable
 * 5. Details of the authorization failure instances for Store image.
 * 6. Send Image to third party AE
 * 7. Get the status of the C-move job requested through SendImage service
 */
package com.idexx.dicom.services;

import java.util.List;

import javax.annotation.Resource;
import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.ws.BindingType;
import javax.xml.ws.WebServiceContext;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.idexx.dicom.aeservices.v11.AEService;
import com.idexx.dicom.aeservices.v11.CancelSendJobService;
import com.idexx.dicom.aeservices.v11.GetStoreFailuresServiceIntf;
import com.idexx.dicom.aeservices.v11.SendImageJobService;
import com.idexx.dicom.aeservices.v11.SendImageStatusService;
import com.idexx.dicom.aeservices.v11.StoreErrorLogService;
import com.idexx.dicom.echo.DicomEchoService;
import com.idexx.dicom.services.dto.v11.AETitleDTO;
import com.idexx.dicom.services.dto.v11.CreateAETitleDTO;
import com.idexx.dicom.services.dto.v11.EchoDTO;
import com.idexx.dicom.services.dto.v11.IdexxDicomApplicationEntityDTO;
import com.idexx.dicom.services.dto.v11.IdexxErrorLogParamDTO;
import com.idexx.dicom.services.dto.v11.IdexxFailureLogParamDTO;
import com.idexx.dicom.services.dto.v11.ReadAETitleDTO;
import com.idexx.dicom.services.dto.v11.SetEnabledAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v11.CancelSendJobParamDTO;
import com.idexx.dicom.services.sendimage.dto.v11.IdexxSendImageJobStatusDTO;
import com.idexx.dicom.services.sendimage.dto.v11.SendImageJobParamDTO;
import com.idexx.dicom.services.sendimage.dto.v11.SendImageStatusParamDTO;

/**
 * @author anarayana
 * 
 */
@WebService(targetNamespace = "http://idexx.services.dicom.idexx.com/", 
portName = "IdexxDicomAEConfigServiceImplPortV1_1", serviceName = "IdexxDicomAEConfigServicesV1_1")
//@BindingType(value = "http://schemas.xmlsoap.org/wsdl/soap/http?mtom=true")
@BindingType(javax.xml.ws.soap.SOAPBinding.SOAP12HTTP_BINDING)
@Service("IdexxDicomAEConfigServicesV1_1")
public class IdexxDicomAEConfigServicesV1_1 extends SpringBeanAutowiringSupport {
	
	private static final Logger LOG = Logger.getLogger(IdexxDicomAEConfigServicesV1_1.class);
	
	@Resource
	private WebServiceContext wsContext;
	@Autowired
	@Qualifier("createAETitleServiceV11")
	private AEService createService;

	@Autowired
	@Qualifier("deleteAETitleServiceV11")
	private AEService deleteService;

	@Autowired
	@Qualifier("readAETitleServiceV11")
	private AEService readService;

	@Autowired
	@Qualifier("setAETitleStatusServiceV11")
	private AEService setEnabledAEService;

	@Autowired
	@Qualifier("getStoreFailuresServiceV11")
	private GetStoreFailuresServiceIntf getStoreFailuresService;

	@Autowired
	@Qualifier("storeErrorLogServiceV11")
	private StoreErrorLogService getStoreErrorLog;

	@Autowired
	@Qualifier("getIdexxSendImageValidatorV11")
	private SendImageJobService sendImageJobService;

	@Autowired
	@Qualifier("getSendImageStatusServiceV11")
	private SendImageStatusService sendImageStatusService;

    @Autowired
    @Qualifier("cancelSendJobServiceImplV11")
    private CancelSendJobService cancelSendJobService;

    @Autowired
    @Qualifier("dicomEchoServiceImplV11")
    private DicomEchoService dicomEchoService;

    /**
     * 
     * @param echoDTO
     * @throws IdexxDicomAEConfigServiceException
     */
    @WebMethod
    public final boolean echo(final EchoDTO echoDTO) throws IdexxDicomAEConfigServiceException {
        boolean isEcho = Boolean.FALSE;
        try {
            if (!echoDTO.isEmpty()) 
            {
                isEcho = dicomEchoService.echo(echoDTO.getAeTitle(), echoDTO.getCalledAeTitle(), echoDTO.getHostName(), echoDTO.getPortNumber());    
            } 
            else 
            {
                isEcho = dicomEchoService.echo(echoDTO.getAeTitle(), echoDTO.getHostName(), echoDTO.getPortNumber());
            }            
        } catch (NumberFormatException e) {
            LOG.error(e);
        } catch (InterruptedException e) {
            LOG.error(e);
        }
        return isEcho;
    }

	/**
	 * Register the AE or Add DVMSpecialist to AE list
	 * 
	 * @param aeDTO
	 * @throws IdexxDicomAEConfigServiceException
	 */
	@WebMethod
	public final void createAETitle(final CreateAETitleDTO aeDTO)
			throws IdexxDicomAEConfigServiceException {
	    
		createService.performService(aeDTO);
	}

	/**
	 * Read the details of the registered AE
	 * 
	 * @param aeTitle
	 * @return
	 * @throws IdexxDicomAEConfigServiceException
	 */
	@WebMethod
	public final List<IdexxDicomApplicationEntityDTO> readAETitle(
			final ReadAETitleDTO aeTitle)
			throws IdexxDicomAEConfigServiceException {

		readService.performService(aeTitle);
		@SuppressWarnings("unchecked")
		List<IdexxDicomApplicationEntityDTO> dtos = (List<IdexxDicomApplicationEntityDTO>) readService
				.sendResponse();

		return dtos;
	}

	/**
	 * Delete the registered AE title
	 * 
	 * @Param aeTitle
	 */
	@WebMethod
	public final void deleteAETitle(final AETitleDTO aeTitle)
			throws IdexxDicomAEConfigServiceException {
		deleteService.performService(aeTitle);
	}

	/**
	 * Enable/Disable the registered AE
	 * 
	 * @param aeTitle
	 * @throws IdexxDicomAEConfigServiceException
	 */
	@WebMethod
	public final void setEnableAETitle(final SetEnabledAETitleDTO aeTitle)
			throws IdexxDicomAEConfigServiceException {
		setEnabledAEService.performService(aeTitle);
	}

	/**
	 * Details of the authorization failure instances for Store image.
	 * 
	 * @param String
	 *            ipAddress
	 * @param Calendar
	 *            startDate
	 * @param Calendar
	 *            endDate
	 * @return List of AEAuthorizationFailureLogDTO
	 */
	@WebMethod
	public final List<com.idexx.dicom.services.dto.v11.IdexxFailureLogDTO> getFailures(
			final IdexxFailureLogParamDTO dto)
			throws IdexxDicomAEConfigServiceException {
		return getStoreFailuresService.performService(dto);
	}

	@WebMethod
	public final List<com.idexx.dicom.services.dto.v11.IdexxFailureLogDTO> getFailureErrorLogs(
			final IdexxErrorLogParamDTO dto)
			throws IdexxDicomAEConfigServiceException {
		return getStoreErrorLog.performService(dto);
	}

	/**
	 * Request to send Image to third party AE 
	 * 
	 * @param dto
	 * @return
	 * @throws IdexxDicomAEConfigServiceException
	 */
	@WebMethod
	public final String sendImage(final SendImageJobParamDTO dto)
			throws IdexxDicomAEConfigServiceException {
		return sendImageJobService.performService(dto);
	}

	/**
	 * Get the status of the C-move job requested through SendImage service
	 * 
	 * @param dto
	 * @return
	 * @throws IdexxDicomAEConfigServiceException
	 */
	@WebMethod
	public final List<IdexxSendImageJobStatusDTO> getCMoveJobStatus(
			final SendImageStatusParamDTO dto)
			throws IdexxDicomAEConfigServiceException {
		List<IdexxSendImageJobStatusDTO> aeResponse = (List<IdexxSendImageJobStatusDTO>) sendImageStatusService
				.performService(dto);
		return aeResponse;
	}

	
    /**
     * @param dto
     * @return
     * @throws IdexxDicomAEConfigServiceException
     */
    @WebMethod
    public final String cancelSendJob(final CancelSendJobParamDTO dto) throws IdexxDicomAEConfigServiceException {
        return cancelSendJobService.performService(dto);
    }

}
