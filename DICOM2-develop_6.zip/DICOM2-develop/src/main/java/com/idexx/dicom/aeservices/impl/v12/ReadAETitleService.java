/**
 * 
 */
package com.idexx.dicom.aeservices.impl.v12;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.validator.v12.AETitleValidator;
import com.idexx.dicom.dao.exceptions.IdexxDicomAEConfigDbException;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.services.dto.v12.AETitleDTO;
import com.idexx.dicom.services.dto.v12.IdexxDicomApplicationEntityDTO;
import com.idexx.dicom.services.dto.v12.ReadAETitleDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * @author vkandagatla
 * 
 */
@Service("readAETitleServiceV12")
public class ReadAETitleService extends AbstractAEServiceImpl {
	
	private static final Logger LOG = Logger.getLogger(ReadAETitleService.class);
	
    private static final int AE_TITLE_CASE = 1;
    private static final int AE_INSTITUTE_NAME_CASE = 2;
    private static final int AE_SAP_ID_CASE = 4;
    @Autowired
    @Qualifier("readAETitleValidatorV12")
    private AETitleValidator validator;

    private List<IdexxDicomApplicationEntityDTO> dtos;

    @Autowired
    private AETitleDao aeTitleDao;

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.aeservices.impl.AbstractAEServiceImpl#validate(com.idexx
     * .dicom.services.dto.IdexxDicomApplicationEntityDTO)
     */
    @Override
    protected final int validate(final AETitleDTO dto) throws IdexxDicomAEConfigServiceException {
        ReadAETitleDTO radDTO = (ReadAETitleDTO) dto;
        return validator.validate(radDTO);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.aeservices.impl.AbstractAEServiceImpl#doService(com.idexx
     * .dicom.services.dto.IdexxDicomApplicationEntityDTO)
     */
    @Override
    protected final int doService(final AETitleDTO dto) throws IdexxDicomAEConfigServiceException {
        // Cases
        final int aeAndInstituteName = 3;
        final int onlySap = 4;
        final int aeAndSap = 5;
        final int aeSapIn = 6;
        List<AETitle> aeTitleList = null;
        ReadAETitleDTO readAEDTO = (ReadAETitleDTO) dto;
        int queryCase = getQueryCase(readAEDTO);
        try {
            switch (queryCase) {
                case 1:
                    aeTitleList = aeTitleDao.findAETitle(readAEDTO.getAeTitle());
                    break;
                case aeAndInstituteName:
                    aeTitleList = aeTitleDao.findAETitle(readAEDTO.getAeTitle(), readAEDTO.getInstituteName());
                    break;
                case onlySap:
                    aeTitleList = aeTitleDao.findAETitleBySapId(readAEDTO.getSapId());
                    break;
                case aeAndSap:
                    aeTitleList = aeTitleDao.findAETitleByAETitleAndSapId(readAEDTO.getAeTitle(), readAEDTO.getSapId());
                    break;
                case aeSapIn:
                    aeTitleList = aeTitleDao.findAETitleBySapIdAndInstituteName(readAEDTO.getSapId(),
                            readAEDTO.getInstituteName());
                    break;

                default:
                    aeTitleList = aeTitleDao.findAETitle(readAEDTO.getAeTitle(), readAEDTO.getInstituteName(),
                            readAEDTO.getSapId());
                    break;
            }
            if ((null == aeTitleList) || (aeTitleList.isEmpty())) {
                throw new IdexxDicomAEConfigServiceException(NO_RECORD_FOUND, NO_RECORD_FOUND);
            }
            setDTOList(aeTitleList);

        } catch (IdexxDicomAEConfigDbException e) {
        	LOG.error(e);
            throw new IdexxDicomAEConfigServiceException(GENERAL_DB_FAILURE, GENERAL_DB_FAILURE);
        }

        return 1;
    }

    /**
     * This method set the AETitles to IdexxDicomApplicationEntityDTO list
     * 
     * @param aeTitleList
     */
    private void setDTOList(final List<AETitle> aeTitleList) {
        dtos = new ArrayList<IdexxDicomApplicationEntityDTO>();
        IdexxDicomApplicationEntityDTO dto = null;
        for (AETitle aeTitle : aeTitleList) {
            dto = new IdexxDicomApplicationEntityDTO();
            dto.setAeTitle(aeTitle.getAeTitle());
            dto.setApiKey(aeTitle.getApiKey());
            dto.setInstituteName(aeTitle.getInstituteName());
            dto.setIdentifiedByAeTitleOnly(aeTitle.isIdentifiedByaeTitleOnly());
            dto.setSapId(aeTitle.getSapId());
            if (aeTitle.getLastAccessedDateTime() != null) {
                dto.setLastAccessed(aeTitle.getLastAccessedDateTime());
            }
            dto.setCreatedDateTime(aeTitle.getCreatedDateTime());
            dto.setEnabled(aeTitle.isEnabled());
            dtos.add(dto);
        }
    }

    /**
     * 
     * @param dto
     * @return int
     */
    protected final int getQueryCase(final ReadAETitleDTO dto) {
        int caseNumber = 0;
        if (!StringUtils.isEmpty(dto.getAeTitle())) {
            caseNumber += AE_TITLE_CASE;
        }
        if (!StringUtils.isEmpty(dto.getInstituteName())) {
            caseNumber += AE_INSTITUTE_NAME_CASE;
        }
        if (!StringUtils.isEmpty(dto.getSapId())) {
            caseNumber += AE_SAP_ID_CASE;
        }
        return caseNumber;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.aeservices.impl.AbstractAEServiceImpl#sendResponse(com
     * .idexx.dicom.services.dto.IdexxDicomApplicationEntityDTO)
     */
    @Override
    public final Object sendResponse() {

        return dtos;
    }

}
