package com.idexx.dicom.aeservices.impl.v13;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.entities.IdexxDicomServiceFailureLog;
import com.idexx.dicom.ae.validator.impl.v13.GetStoreFailuresValidator;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.dao.ws.FailureServiceDao;
import com.idexx.dicom.services.dto.v13.IdexxFailureLogDTO;
import com.idexx.dicom.services.dto.v13.IdexxFailureLogParamDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * <pre>Description of the class</pre>
 * @author rkaranam
 * @version 1.3
 */
@Service("getStoreFailuresServiceV13")
public class GetStoreFailuresService {
	
	private static final Logger LOG = Logger.getLogger(GetStoreFailuresService.class);
	
    @Autowired
    @Qualifier("getStoreFailuresValidatorV13")
    private GetStoreFailuresValidator validator;
    
    private List<IdexxFailureLogDTO> dtos;
    
    @Autowired
    private FailureServiceDao failureLogDAO;

    @Autowired
    private AETitleDao aeTitleDao;
    
    @Transactional
    public List<IdexxFailureLogDTO> performService(final IdexxFailureLogParamDTO dto) throws IdexxDicomAEConfigServiceException {
        this.validate(dto);
        this.doService(dto);
        return dtos;
    }
    
    protected int validate(final IdexxFailureLogParamDTO dto) throws IdexxDicomAEConfigServiceException {
        IdexxFailureLogParamDTO failureParamDTO = (IdexxFailureLogParamDTO) dto;
        return validator.validate(failureParamDTO);
    }
    
    protected int doService(final IdexxFailureLogParamDTO dto) throws IdexxDicomAEConfigServiceException {
        List<IdexxDicomServiceFailureLog> failureLogList = null;
        IdexxFailureLogParamDTO iflDto = (IdexxFailureLogParamDTO) dto;
        failureLogList = failureLogDAO.getFailureLog(this.convertToDate(iflDto.getStartDate())
                , this.convertToDate(iflDto.getEndDate()));
        setDTOList(failureLogList);
        return 1;
    }
    
    /**
     * This method set the AETitles to IdexxDicomApplicationEntityDTO list
     * 
     * @param aeTitleList
     */
    private void setDTOList(final List<IdexxDicomServiceFailureLog> failureLogList) {
        List<AETitle> aeTitles = aeTitleDao.getAllAETitles();
        dtos = new ArrayList<IdexxFailureLogDTO>();
        IdexxFailureLogDTO dto = null;
        Calendar calender = Calendar.getInstance();
        
        for (IdexxDicomServiceFailureLog failureLog : failureLogList) {
            if (isUnregisteredAeTitle(aeTitles, failureLog)) {
                dto = new IdexxFailureLogDTO();
                dto.setIpAddress(failureLog.getIpAddress());
                dto.setAeTitle(failureLog.getAeTitle());
                dto.setInstituteName(failureLog.getInstituteName());
                dto.setManufacturer(failureLog.getManufacturer());
                dto.setManufacturerModelName(failureLog.getManufacturerModelName());
                dto.setModality(failureLog.getModality());
                dto.setPatientName(failureLog.getPatientName());
                calender.setTime(failureLog.getFailedDateTime());
                dto.setFailedDateTime(convertDateToUTCString(calender.getTime()));
                String responsiblePersonName = failureLog.getResponsiblePersonName();
                if (StringUtils.isEmpty(responsiblePersonName)) {
                    responsiblePersonName = "";
                }
                dto.setResponsiblePersonName(responsiblePersonName);
                String hostName = failureLog.getHostName();
                if (StringUtils.isEmpty(hostName)) {
                    hostName = "";
                }
                dto.setHostName(hostName);
                dtos.add(dto);
            }
        }
    }

    private boolean isUnregisteredAeTitle(List<AETitle> aeTitles, IdexxDicomServiceFailureLog failureLog) {
        boolean unregistered = true;
        for (AETitle aeTitle : aeTitles) {
            if (aeTitle.getAeTitle().trim().equals(failureLog.getAeTitle().trim()) 
                    && aeTitle.getInstituteName().trim().equals(failureLog.getInstituteName().trim())) {
                unregistered = false;
            }
        }
        return unregistered;
    }
    
    /**
     * 
     * @param date
     * @return
     */
    private Date convertToDate(final String date) {
        Date toDate = null;
        DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        try {
            toDate = formatter.parseDateTime(date).toDate();
        } catch (IllegalArgumentException iae) {
        	LOG.error(iae);
            LOG.info( "Date Format is invalid: Input Date is: "
                    + date + " :: " + iae.getLocalizedMessage());
        }
        return toDate;
    }
    
    /**
     * 
     * @param date
     * @return
     */
    private String convertDateToUTCString(final Date date) {
        String toDate = null;
        DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        toDate = formatter.print(new DateTime(date));
        return toDate;
    }
    
}
