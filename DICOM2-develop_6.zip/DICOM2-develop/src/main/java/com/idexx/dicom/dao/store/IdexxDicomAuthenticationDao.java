/**
 * Handles Idexx Dicom Services Authentication and Athentication Failure Logs to DB 
 */
package com.idexx.dicom.dao.store;

import java.util.List;

import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.entities.IdexxDicomServiceFailureLog;

/**
 * @author vkandagatla
 * 
 */
public interface IdexxDicomAuthenticationDao {
    List<AETitle> getAeTitle(String aeTitle);
    
    List<AETitle> getAeTitle(String aeTitle, String institueName);
    
    void updateAETitle(AETitle aeTitle);
    
    void logDicomServiceAuthorizationFailure(IdexxDicomServiceFailureLog log);
}
