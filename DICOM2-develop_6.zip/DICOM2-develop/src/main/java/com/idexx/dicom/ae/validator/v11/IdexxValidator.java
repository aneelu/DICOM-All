/**
 * 
 */
package com.idexx.dicom.ae.validator.v11;

/**
 * @author vkandagatla
 *
 */
public interface IdexxValidator {
    String MISSING_MANDATORY = "ERR_argument_missing_mandatory";
    String MISSING_INSTITUTE_NAME = "ERR_argument_missing_institute";
    String RECORD_ALREADY_EXISTS = "ERR_record_already_exists";
    String NO_RECORD_FOUND = "ERR_no_record_found";
    String GENERAL_DB_FAILURE = "ERR_general_db_fail";
    String INVALID_AETITLE = "ERR_invalid_AE_title";
    String INVALID_DATE_RANGE = "ERR_invalid_date_range";
    String INVALID_START_DATE = "ERR_invalid_start_date";
    String INVALID_END_DATE = "ERR_invalid_end_date";  
}
