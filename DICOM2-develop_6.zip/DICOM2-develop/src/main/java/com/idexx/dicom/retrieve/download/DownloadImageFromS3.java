/**
 *  Interface for downloading file from cloud
 */
package com.idexx.dicom.retrieve.download;
/**  
 * @author apinninti
 *
 */
public interface DownloadImageFromS3 {
    int DOWNLOAD_BUFFER_SIZE = 4096;
    int HTTP_SUCCESS_STATUS_CODE = 200;
    boolean downloadDicomImageFileFromCloud(String fileUrl, String fileName) throws Exception;
    
}
