/**
 * @author vkandagatla
 *
 */
package com.idexx.dicom.ae.entities;
