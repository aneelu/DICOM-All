package com.idexx.dicom.proxy.dcmqrscp;

import java.util.ArrayList;
import java.util.List;

import org.dcm4che3.data.Attributes;
import org.dcm4che3.net.service.InstanceLocator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.idexx.dicom.retrieve.download.DownloadFileInfoProvider;
import com.idexx.dicom.retrieve.download.impl.IdexxFileInfo;

public class ProxyRetrieveTask<T extends InstanceLocator> {

    static final Logger LOG = LoggerFactory.getLogger(ProxyRetrieveTask.class);
    
    @Autowired
    private DownloadFileInfoProvider dwnProvider;

	private Attributes keys;
	private String callingAET;
	private String calledAET;
	
    public ProxyRetrieveTask(Attributes keys, String callingAET, String calledAET) {
    	this.keys = keys;
    	this.callingAET = callingAET;
    	this.calledAET = calledAET;
	}
    
    public List<T> performTask() {
    	List<T> result = new ArrayList<T>();
        List<IdexxFileInfo> fileList = null;
        try {
        	fileList = dwnProvider.getFileInfoList(keys, callingAET, calledAET);
        } catch (Exception exp) {
            LOG.error(exp.getMessage(), exp);
        }
        if(fileList != null && fileList.size()>0) {
            for (IdexxFileInfo idexxFileInfo : fileList) {
                String cuid = idexxFileInfo.getSopCUID();
                String iuid = idexxFileInfo.getSopIUID();
                String tsuid = idexxFileInfo.getTsUID();
                String fileID = idexxFileInfo.getFileID();
                String baseDir = idexxFileInfo.getBasedir();
                // URL will never have backslash
                String uri = "file:///" + baseDir.replace('\\', '/') + '/' + fileID.replace('\\', '/');
                result.add((T) new InstanceLocator(cuid, iuid, tsuid, uri));
            }
        }    	
    	return result;
    }
}
