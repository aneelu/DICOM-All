package com.idexx.dicom.ae.entities;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(IdexxSendImageJob.class)
public abstract class IdexxSendImageJob_ {

	public static volatile SingularAttribute<IdexxSendImageJob, Integer> destinationPort;
	public static volatile SingularAttribute<IdexxSendImageJob, Integer> retriesCount;
	public static volatile SingularAttribute<IdexxSendImageJob, String> jobStatus;
	public static volatile SingularAttribute<IdexxSendImageJob, Timestamp> createdDateTime;
	public static volatile SingularAttribute<IdexxSendImageJob, String> s3ImageUrl;
	public static volatile SingularAttribute<IdexxSendImageJob, String> destinationHostName;
	public static volatile SingularAttribute<IdexxSendImageJob, Timestamp> updatedDateTime;
	public static volatile SingularAttribute<IdexxSendImageJob, String> jobId;
	public static volatile SingularAttribute<IdexxSendImageJob, String> downloadedIMFilePath;
	public static volatile SingularAttribute<IdexxSendImageJob, String> jobStatusDescription;
	public static volatile SingularAttribute<IdexxSendImageJob, String> imageAssetId;
	public static volatile SingularAttribute<IdexxSendImageJob, String> sendingAETitle;
	public static volatile SingularAttribute<IdexxSendImageJob, String> destinationAETitle;

}

