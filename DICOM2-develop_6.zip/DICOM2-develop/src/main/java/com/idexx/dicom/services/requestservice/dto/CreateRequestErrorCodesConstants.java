/**
 * <h1>Create Request service error codes with description.</h1>
 */
package com.idexx.dicom.services.requestservice.dto;

import javax.ws.rs.core.Response.Status;

/**
 * <pre>
 * Create Request service error codes with description.
 * </pre>
 * 
 * @author nayeemuddin
 * @version 1.3
 */
public class CreateRequestErrorCodesConstants {

	public static final String PATIENT_DOB_ERROR_CODE = "MISSING_PATIENT_BIRTH_DATE";
	public static final String PATIENT_DOB_ERROR_CODE_MSG = "The selected patient's date of birth is missing therefore we cannot process this request. Please enter a patient date of birth and begin your request again.";
	public static final String INVALID_PATIENT_DOB_ERROR_CODE = "INVALID_PATIENT_BIRTH_DATE";
	public static final String INVALID_PATIENT_DOB_ERROR_CODE_MSG = "The selected patient's date of birth is invalid therefore we cannot process this request. Please enter a valid patient date of birth and begin your request again.";	
	public static final String PATIENT_ID_ERROR_CODE = "MISSING_PATIENT_ID";
	public static final String PATIENT_ID_ERROR_CODE_MSG = "The selected patient's ID is missing, therefore we cannot process this request. Please enter a patient name and submit your begin again.";
	public static final String PATIENT_NAME_ERROR_CODE = "MISSING_PATIENT_NAME";
	public static final String PATIENT_NAME_ERROR_CODE_MSG = "The selected patient's name is missing, therefore we cannot process this request. Please enter a patient name and begin your request again.";
	public static final String CLIENT_FIRST_NAME_ERROR_CODE = "MISSING_CLIENT_FIRST_NAME";
	public static final String CLIENT_FIRST_NAME_ERROR_CODE_MSG = "The selected client's first name is missing, therefore we cannot process this request. Please enter a client first name and begin your request again.";
	public static final String CLIENT_LAST_NAME_ERROR_CODE = "MISSING_CLIENT_LAST_NAME";
	public static final String CLIENT_LAST_NAME_ERROR_CODE_MSG = "The selected client's last name is missing, therefore we cannot process this request. Please enter a client last name and begin your request again.";
	public static final String SEX_ERROR_CODE = "MISSING_PATIENT_SEX";
	public static final String SEX_ERROR_CODE_MSG = "The selected patient's sex is missing, therefore we cannot process this request. Please enter a patient sex and begin your request again.";
	public static final String BREED_ERROR_CODE = "MISSING_PATIENT_BREED";
	public static final String BREED_ERROR_CODE_MSG = "The selected patient's breed is missing, therefore we cannot process this request. Please enter a patient breed and begin your request again.";
	public static final String SPECIES_ERROR_CODE = "MISSING_PATIENT_SPECIES";
	public static final String SPECIES_ERROR_CODE_MSG = "The selected patient's species is missing, therefore we cannot process this request. Please enter a patient species and begin your request again.";
	public static final String DOCTOR_ERROR_CODE = "MISSING_DOCTOR";
	public static final String DOCTOR_ERROR_CODE_MSG = "Doctor is missing, therefore we cannot process this request. Please enter a doctor and begin your request again.";
	public static final String MODALITY_ERROR_CODE = "MISSING_MODALITY_TYPE";
	public static final String MODALITY_ERROR_CODE_MSG = "Modality Type is missing.";
	public static final String PIMS_ISSUER_ERROR_CODE = "MISSING_PIMS_ISSUER";
	public static final String PIMS_ISSUER_ERROR_CODE_MSG = "PIMS Issuer is missing from request data.";
	public static final String API_KEY_ERROR_CODE = "MISSING_API_KEY";
	public static final String API_KEY_ERROR_CODE_MSG = "API Key is missing from request data.";
	public static final String INVALID_API_KEY_ERROR_CODE = "INVALID_API_KEY";
	public static final String INVALID_API_KEY_ERROR_CODE_MSG = "API Key is invalid.";
	public static final String DICOM_FILE_IMPORT_FAILED_CODE = "DICOM_FILE_IMPORT_FAILED";
	public static final String DICOM_FILE_IMPORT_FAILED_CODE_MSG = "Unable to import dicom file from image manager.";
	public static final String SAP_ID_ERROR_CODE = "MISSING_SAP_ID";
	public static final String SAP_ID_ERROR_CODE_MSG = "SAP ID is missing from the request data.";
	public static final String SAP_ID_NUMERIC_ERROR_CODE = "SAP_ID_MUST_BE_NUMERIC";
	public static final String SAP_ID_NUMERIC_ERROR_CODE_MSG = "SAP ID must be numeric in request data.";
	public static final String DICOM_URL_ERROR_CODE = "MISSING_DICOM_URL";
	public static final String DICOM_URL_ERROR_CODE_MSG = "DICOM URL is missing from the request data.";
	
	
	
	public static final Status BAD_REQUEST_HTTP_STATUS_CODE = Status.BAD_REQUEST;
	public static final Status UNAUTHORIZED_HTTP_STATUS_CODE = Status.UNAUTHORIZED; 
	public static final Status SUCCESS_HTTP_STATUS_CODE = Status.OK; 
	
	public static final String CREATE_PATIENT_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";
    public static final String PATIENT_DOB_FORMAT = "yyyy-MM-dd";

}
