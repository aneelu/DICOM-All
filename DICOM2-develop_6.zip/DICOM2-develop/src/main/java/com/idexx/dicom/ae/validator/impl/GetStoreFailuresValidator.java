package com.idexx.dicom.ae.validator.impl;

import org.apache.log4j.Logger;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.stereotype.Service;

import com.idexx.dicom.ae.validator.StoreFailureServiceValidator;
import com.idexx.dicom.services.dto.IdexxFailureLogParamDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

/**
 * @author vkandagatla
 * 
 */
@Service("getStoreFailuresValidator")
public class GetStoreFailuresValidator implements StoreFailureServiceValidator {

	private static Logger LOG = Logger.getLogger(GetStoreFailuresValidator.class);

	public final int validate(final IdexxFailureLogParamDTO dto) throws IdexxDicomAEConfigServiceException {
		validateInputFields(dto);
		return 1;
	}

	/**
	 * @param dto
	 * @return
	 */
	private boolean isValidDateRange(final IdexxFailureLogParamDTO dto) {
		return dto.getStartDate().compareTo(dto.getEndDate()) <= 0;
	}

	/**
	 * @param dto
	 * @return
	 */
	private boolean isMandatoryFieldsEmpty(final IdexxFailureLogParamDTO dto) {
		return ((null != dto.getStartDate() && !dto.getStartDate().isEmpty())
				&& (null != dto.getEndDate() && !dto.getEndDate().isEmpty()));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.idexx.dicom.ae.validator.impl.AbstractAETitleValidator#
	 * validateInputFields(com.idexx.dicom.services.dto.AETitleDTO)
	 */
	protected final int validateInputFields(final IdexxFailureLogParamDTO dto)
			throws IdexxDicomAEConfigServiceException {
		IdexxFailureLogParamDTO iflDto = (IdexxFailureLogParamDTO) dto;
		if (!isMandatoryFieldsEmpty(iflDto)) {
			throw new IdexxDicomAEConfigServiceException(MISSING_MANDATORY, MISSING_MANDATORY);
		}
		if (!isValidDateFormat(dto.getStartDate())) {
			throw new IdexxDicomAEConfigServiceException(INVALID_START_DATE, INVALID_START_DATE);
		}
		if (!isValidDateFormat(dto.getEndDate())) {
			throw new IdexxDicomAEConfigServiceException(INVALID_END_DATE, INVALID_END_DATE);
		}
		if (!isValidDateRange(iflDto)) {
			throw new IdexxDicomAEConfigServiceException(INVALID_DATE_RANGE, INVALID_DATE_RANGE);
		}
		return 1;
	}

	private boolean isValidDateFormat(final String date) {
		boolean valid = false;
		DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
		try {
			formatter.parseDateTime(date);
			valid = true;
		} catch (UnsupportedOperationException uoe) {
			LOG.info("Date Format is invalid: Input Date is: " + date + " :: " + uoe);
		} catch (IllegalArgumentException iae) {
			LOG.info("Date Format is invalid: Input Date is: " + date + " :: " + iae);
		}
		return valid;
	}
}
