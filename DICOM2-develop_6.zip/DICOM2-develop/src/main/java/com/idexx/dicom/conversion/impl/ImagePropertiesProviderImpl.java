/**
 * 
 */
package com.idexx.dicom.conversion.impl;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

import org.apache.log4j.Logger;

import com.idexx.dicom.conversion.ImagePropertiesProvider;
import com.idexx.dicom.util.CommonUtil;

/**
 * @author vkandagatla
 * 
 */
public class ImagePropertiesProviderImpl implements ImagePropertiesProvider {
	
	private static final Logger LOG = Logger.getLogger(ImagePropertiesProviderImpl.class);
	
    private File imageFile;
    private String imageFileType;
    private static final String[] SUPPORTED_FORMATS = {"PNG", "JPG", "JPEG", "GIF", "BMP", "TIFF", "TIF", "JPEG 2000" };
    private static final String[] SAFE_FORMATS = {"DICOM", "JPG", "JPEG"};
    public ImagePropertiesProviderImpl(final String imageFilePath, final String imageFileType) throws IOException {
        imageFile = new File(imageFilePath);
        this.imageFileType = imageFileType;
    }
    
    /**
     * @return
     * @throws IOException 
     * @throws Exception
     *             Provides Image properties to build DICOM Image
     */
    public final ImageProperties getImageProperties() throws IOException  {
        String ext = CommonUtil.getFileNameExtension(imageFileType, "JPG");
        
        LOG.info( "File Extension: " + ext);
        Iterator<ImageReader> imageItr = ImageIO.getImageReadersByFormatName(this.imageFormatName());
        ImageReader imageReader = null;
        while (imageItr.hasNext()) {
            imageReader = imageItr.next();
            LOG.info( "Image Reader: " + imageReader.toString());
        }
        LOG.info( "Reading Image: " + imageFile);
        ImageInputStream iis = ImageIO.createImageInputStream(imageFile);
        imageReader.setInput(iis);
        BufferedImage image = imageReader.read(0);
        if (image == null) {
            throw new IOException("Invalid Image.");
        }
        File newFile = this.convertImage(image);
        
        BufferedImage newimage = ImageIO.read(newFile);
        
        ImageProperties imageProperties = null;
        
        int colorComponents = newimage.getColorModel().getNumColorComponents();
        int bitsPerPixel = newimage.getColorModel().getPixelSize();
        int bitsAllocated = (bitsPerPixel / colorComponents);
        int samplesPerPixel = colorComponents;
        int jpgLen = (int) newFile.length();
        int height = newimage.getHeight();
        int width = newimage.getWidth();
        
        FileInputStream fis = new FileInputStream(newFile);
        BufferedInputStream bis = new BufferedInputStream(fis);
        DataInputStream dis = new DataInputStream(bis);
        imageProperties = new ImageProperties(samplesPerPixel, height, width, bitsAllocated, jpgLen, dis, null);
        LOG.info( "Image Properties: " + imageProperties);
        return imageProperties;
    }
    
    private File convertImage(final BufferedImage bimage) throws IOException {
        String formatName = this.imageFormatName();
        LOG.info("File Format name:" + formatName);
        if (!this.isFormatSupported(formatName)) {
            throw new IOException("Unsupported Format: " + formatName);
        }
        for (String format : SAFE_FORMATS) {
            if (format.equalsIgnoreCase(formatName)) {
                return imageFile;
            }
        }
        if (!SUPPORTED_FORMATS[1].equalsIgnoreCase(formatName)
                || !SUPPORTED_FORMATS[2].equalsIgnoreCase(formatName)) {
            return this.convertPngToJpg(bimage);
        }
        
        return imageFile;
    }
    
    private boolean isFormatSupported(final String formatName) throws IOException {
        for (String supportFormat : SUPPORTED_FORMATS) {
            if (supportFormat.equalsIgnoreCase(formatName)) {
                return true;
            }
        }
        return false;
    }
    
    private String imageFormatName() throws IOException {
        ImageInputStream iis = ImageIO.createImageInputStream(imageFile);
        Iterator<ImageReader> readers = ImageIO.getImageReadersBySuffix(CommonUtil.getFileExtension(imageFile.getName()));
        ImageReader imageReader = null;
        for (; readers.hasNext();) {
            imageReader = readers.next();
            LOG.info( "Plugin: " + imageReader.toString());
            
        }
        imageReader.setInput(iis);
        return imageReader.getFormatName();
    }
    
    private File createTmpFile() {
        File output = new File("temp.jpg");
        if (output.exists()) {
            output.delete();
        }
        output.deleteOnExit();
        return output;
    }
    
    private File convertPngToJpg(final BufferedImage pngImage) throws IOException {
        File output = this.createTmpFile();
        
        int width = pngImage.getWidth();
        int height = pngImage.getHeight();
        BufferedImage bi2 = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics big = bi2.getGraphics();
        big.drawImage(pngImage, 0, 0, null);
        
        ImageIO.write(bi2, "jpg", output);
        return output;
    }
    
}
