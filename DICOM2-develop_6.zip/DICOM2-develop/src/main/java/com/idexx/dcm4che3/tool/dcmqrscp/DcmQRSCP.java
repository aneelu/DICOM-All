package com.idexx.dcm4che3.tool.dcmqrscp;

import java.io.IOException;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.ResourceBundle;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.log4j.Logger;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;
import org.dcm4che3.data.UID;
import org.dcm4che3.media.DicomDirReader;
import org.dcm4che3.media.DicomDirWriter;
import org.dcm4che3.media.RecordFactory;
import org.dcm4che3.net.ApplicationEntity;
import org.dcm4che3.net.Association;
import org.dcm4che3.net.Connection;
import org.dcm4che3.net.Device;
import org.dcm4che3.net.QueryOption;
import org.dcm4che3.net.TransferCapability;
import org.dcm4che3.net.pdu.ExtendedNegotiation;
import org.dcm4che3.net.pdu.PresentationContext;
import org.dcm4che3.net.service.BasicCFindSCP;
import org.dcm4che3.net.service.DicomServiceException;
import org.dcm4che3.net.service.DicomServiceRegistry;
import org.dcm4che3.net.service.InstanceLocator;
import org.dcm4che3.net.service.QueryRetrieveLevel;
import org.dcm4che3.net.service.QueryTask;
import org.dcm4che3.tool.common.CLIUtils;
import org.dcm4che3.tool.common.FilesetInfo;
import org.dcm4che3.util.AttributesFormat;
import org.dcm4che3.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.stereotype.Component;

import com.idexx.imaging.imagemanager.soap.IdexxServiceException_Exception;

/**
 * @author Gunter Zeilinger <gunterze@gmail.com>
 *
 */
@Component("dcmQRSCP")
public class DcmQRSCP<T extends InstanceLocator> {

	private static final Logger LOG = Logger.getLogger(DcmQRSCP.class);

	private static final String[] PATIENT_ROOT_LEVELS = { "PATIENT", "STUDY", "SERIES", "IMAGE" };
	private static ResourceBundle rb = ResourceBundle.getBundle("org.dcm4che3.tool.dcmqrscp.messages");

	private Device device = null;
	private ApplicationEntity ae = null;
	private Connection conn = null;

	private AttributesFormat filePathFormat;
	private RecordFactory recFact;
	private String availability;
	private boolean stgCmtOnSameAssoc;
	private boolean sendPendingCGet;
	private int sendPendingCMoveInterval;
	private final FilesetInfo fsInfo = new FilesetInfo();
	private DicomDirReader ddReader;
	private DicomDirWriter ddWriter;
	private Map<String, Connection> remoteConnections = new HashMap<String, Connection>();

	@Autowired
	private AutowireCapableBeanFactory beanFactory;

	private final class CFindSCPImpl extends BasicCFindSCP {

		private final String[] qrLevels;
		private final QueryRetrieveLevel rootLevel;

		public CFindSCPImpl(String sopClass, String... qrLevels) {
			super(sopClass);
			this.qrLevels = qrLevels;
			this.rootLevel = QueryRetrieveLevel.valueOf(qrLevels[0]);
		}

		@Override
		protected QueryTask calculateMatches(Association as, PresentationContext pc, Attributes rq, Attributes keys)
				throws DicomServiceException {
			try {
				String availability = getInstanceAvailability();
				String callingAETitle = as.getCallingAET();
				IdexxPatientQueryTask bean = new IdexxPatientQueryTask(as, pc, rq, keys, availability, callingAETitle);
				beanFactory.autowireBean(bean);
				bean.loadRequests(keys);
				return bean;
			} catch (IdexxServiceException_Exception exc) {
				LOG.error("Error while processsing C-Find request", exc);
			}
			throw new AssertionError();
		}

		private boolean relational(Association as, Attributes rq) {
			String cuid = rq.getString(Tag.AffectedSOPClassUID);
			ExtendedNegotiation extNeg = as.getAAssociateAC().getExtNegotiationFor(cuid);
			return QueryOption.toOptions(extNeg).contains(QueryOption.RELATIONAL);
		}
	}

	public DcmQRSCP() {
	}

	public void init(String[] args, Device device, ApplicationEntity ae, Connection conn,
			DicomServiceRegistry serviceRegistry) throws IOException {

		this.device = device;
		this.ae = ae;
		this.conn = conn;

		try {
			CommandLine cl = parseComandLine(args);

			CLIUtils.configure(fsInfo, cl);
			CLIUtils.configureBindServer(conn, ae, cl);
			CLIUtils.configure(conn, cl);
			DcmQRSCP.configureTransferCapability(this, cl);
			DcmQRSCP.configureInstanceAvailability(this, cl);
			DcmQRSCP.configureStgCmt(this, cl);
			DcmQRSCP.configureSendPending(this, cl);
			DcmQRSCP.configureRemoteConnections(this, cl);
			this.init(serviceRegistry);
		} catch (ParseException e) {
			LOG.error("ParseException in dcmqrscp: " + e);
		} catch (Exception e) {
			LOG.error("Exception in dcmqrscp: " + e);
		}

	}

	public void init(DicomServiceRegistry serviceRegistry) {
		device.setDimseRQHandler(createServiceRegistry(serviceRegistry));
	}

	private DicomServiceRegistry createServiceRegistry(DicomServiceRegistry serviceRegistry) {

		serviceRegistry
				.addDicomService(new CFindSCPImpl(UID.ModalityWorklistInformationModelFIND, PATIENT_ROOT_LEVELS));
		return serviceRegistry;
	}

	public final Device getDevice() {
		return device;
	}

	public void setDevice(Device device) {
		this.device = device;
	}

	public void setApplicationEntity(ApplicationEntity ae) {
		this.ae = ae;
	}

	public final AttributesFormat getFilePathFormat() {
		return filePathFormat;
	}

	public void setFilePathFormat(String pattern) {
		this.filePathFormat = new AttributesFormat(pattern);
	}

	public boolean isWriteable() {
		return false;
	}

	public final void setInstanceAvailability(String availability) {
		this.availability = availability;
	}

	public final String getInstanceAvailability() {
		return availability;
	}

	public boolean isStgCmtOnSameAssoc() {
		return stgCmtOnSameAssoc;
	}

	public void setStgCmtOnSameAssoc(boolean stgCmtOnSameAssoc) {
		this.stgCmtOnSameAssoc = stgCmtOnSameAssoc;
	}

	public final void setSendPendingCGet(boolean sendPendingCGet) {
		this.sendPendingCGet = sendPendingCGet;
	}

	public final boolean isSendPendingCGet() {
		return sendPendingCGet;
	}

	public final void setSendPendingCMoveInterval(int sendPendingCMoveInterval) {
		this.sendPendingCMoveInterval = sendPendingCMoveInterval;
	}

	public final int getSendPendingCMoveInterval() {
		return sendPendingCMoveInterval;
	}

	public final void setRecordFactory(RecordFactory recFact) {
		this.recFact = recFact;
	}

	public final RecordFactory getRecordFactory() {
		return recFact;
	}

	private static CommandLine parseComandLine(String[] args) throws ParseException {
		Options opts = new Options();
		CLIUtils.addFilesetInfoOptions(opts);
		CLIUtils.addBindServerOption(opts);
		CLIUtils.addConnectTimeoutOption(opts);
		CLIUtils.addAcceptTimeoutOption(opts);
		CLIUtils.addAEOptions(opts);
		CLIUtils.addCommonOptions(opts);
		CLIUtils.addResponseTimeoutOption(opts);
		addDicomDirOption(opts);
		addTransferCapabilityOptions(opts);
		addInstanceAvailabilityOption(opts);
		addStgCmtOptions(opts);
		addSendingPendingOptions(opts);
		addRemoteConnectionsOption(opts);
		return CLIUtils.parseComandLine(args, opts, rb, DcmQRSCP.class);
	}

	@SuppressWarnings("static-access")
	private static void addInstanceAvailabilityOption(Options opts) {
		opts.addOption(OptionBuilder.hasArg().withArgName("code").withDescription(rb.getString("availability"))
				.withLongOpt("availability").create());
	}

	private static void addStgCmtOptions(Options opts) {
		opts.addOption(null, "stgcmt-same-assoc", false, rb.getString("stgcmt-same-assoc"));
	}

	@SuppressWarnings("static-access")
	private static void addSendingPendingOptions(Options opts) {
		opts.addOption(null, "pending-cget", false, rb.getString("pending-cget"));
		opts.addOption(OptionBuilder.hasArg().withArgName("s").withDescription(rb.getString("pending-cmove"))
				.withLongOpt("pending-cmove").create());
	}

	@SuppressWarnings("static-access")
	private static void addDicomDirOption(Options opts) {
		opts.addOption(OptionBuilder.hasArg().withArgName("file").withDescription(rb.getString("dicomdir"))
				.withLongOpt("dicomdir").create());
		opts.addOption(OptionBuilder.hasArg().withArgName("pattern").withDescription(rb.getString("filepath"))
				.withLongOpt("filepath").create(null));
	}

	@SuppressWarnings("static-access")
	private static void addTransferCapabilityOptions(Options opts) {
		opts.addOption(null, "all-storage", false, rb.getString("all-storage"));
		opts.addOption(null, "no-storage", false, rb.getString("no-storage"));
		opts.addOption(null, "no-query", false, rb.getString("no-query"));
		opts.addOption(null, "no-retrieve", false, rb.getString("no-retrieve"));
		opts.addOption(null, "relational", false, rb.getString("relational"));
		opts.addOption(OptionBuilder.hasArg().withArgName("file|url")
				.withDescription(rb.getString("storage-sop-classes")).withLongOpt("storage-sop-classes").create());
		opts.addOption(OptionBuilder.hasArg().withArgName("file|url").withDescription(rb.getString("query-sop-classes"))
				.withLongOpt("query-sop-classes").create());
		opts.addOption(OptionBuilder.hasArg().withArgName("file|url")
				.withDescription(rb.getString("retrieve-sop-classes")).withLongOpt("retrieve-sop-classes").create());
	}

	@SuppressWarnings("static-access")
	private static void addRemoteConnectionsOption(Options opts) {
		opts.addOption(OptionBuilder.hasArg().withArgName("file|url").withDescription(rb.getString("ae-config"))
				.withLongOpt("ae-config").create());
	}

	private static void configureInstanceAvailability(DcmQRSCP main, CommandLine cl) {
		main.setInstanceAvailability(cl.getOptionValue("availability"));
	}

	private static void configureStgCmt(DcmQRSCP main, CommandLine cl) {
		main.setStgCmtOnSameAssoc(cl.hasOption("stgcmt-same-assoc"));
	}

	private static void configureSendPending(DcmQRSCP main, CommandLine cl) {
		main.setSendPendingCGet(cl.hasOption("pending-cget"));
		if (cl.hasOption("pending-cmove"))
			main.setSendPendingCMoveInterval(Integer.parseInt(cl.getOptionValue("pending-cmove")));
	}

	private static void configureTransferCapability(DcmQRSCP main, CommandLine cl) throws IOException {
		ApplicationEntity ae = main.ae;
		EnumSet<QueryOption> queryOptions = cl.hasOption("relational") ? EnumSet.of(QueryOption.RELATIONAL)
				: EnumSet.noneOf(QueryOption.class);
		boolean storage = !cl.hasOption("no-storage") && main.isWriteable();
		if (storage && cl.hasOption("all-storage")) {
			TransferCapability tc = new TransferCapability(null, "*", TransferCapability.Role.SCP, "*");
			tc.setQueryOptions(queryOptions);
			ae.addTransferCapability(tc);
		} else {
			ae.addTransferCapability(new TransferCapability(null, UID.VerificationSOPClass, TransferCapability.Role.SCP,
					UID.ImplicitVRLittleEndian));
			Properties storageSOPClasses = CLIUtils.loadProperties(
					cl.getOptionValue("storage-sop-classes", "resource:storage-sop-classes.properties"), null);
			if (storage)
				addTransferCapabilities(ae, storageSOPClasses, TransferCapability.Role.SCP, null);
			if (!cl.hasOption("no-retrieve")) {
				addTransferCapabilities(ae, storageSOPClasses, TransferCapability.Role.SCU, null);
				Properties p = CLIUtils.loadProperties(
						cl.getOptionValue("retrieve-sop-classes", "resource:retrieve-sop-classes.properties"), null);
				addTransferCapabilities(ae, p, TransferCapability.Role.SCP, queryOptions);
			}
			if (!cl.hasOption("no-query")) {
				Properties p = CLIUtils.loadProperties(
						cl.getOptionValue("query-sop-classes", "resource:query-sop-classes.properties"), null);
				addTransferCapabilities(ae, p, TransferCapability.Role.SCP, queryOptions);
			}
		}
	}

	private static void addTransferCapabilities(ApplicationEntity ae, Properties p, TransferCapability.Role role,
			EnumSet<QueryOption> queryOptions) {
		for (String cuid : p.stringPropertyNames()) {
			String ts = p.getProperty(cuid);
			TransferCapability tc = new TransferCapability(null, CLIUtils.toUID(cuid), role, CLIUtils.toUIDs(ts));
			tc.setQueryOptions(queryOptions);
			ae.addTransferCapability(tc);
		}
	}

	private static void configureRemoteConnections(DcmQRSCP main, CommandLine cl) throws Exception {
		String file = cl.getOptionValue("ae-config", "resource:ae.properties");
		Properties aeConfig = CLIUtils.loadProperties(file, null);
		for (Map.Entry<Object, Object> entry : aeConfig.entrySet()) {
			String aet = (String) entry.getKey();
			String value = (String) entry.getValue();
			try {
				String[] hostPortCiphers = StringUtils.split(value, ':');
				String[] ciphers = new String[hostPortCiphers.length - 2];
				System.arraycopy(hostPortCiphers, 2, ciphers, 0, ciphers.length);
				Connection remote = new Connection();
				remote.setHostname(hostPortCiphers[0]);
				remote.setPort(Integer.parseInt(hostPortCiphers[1]));
				remote.setTlsCipherSuites(ciphers);
				main.addRemoteConnection(aet, remote);
			} catch (Exception e) {
				LOG.error("Exception in configuring remote connection: " + e);
				throw new IllegalArgumentException("Invalid entry in " + file + ": " + aet + "=" + value);
			}
		}
	}

	final DicomDirReader getDicomDirReader() {
		return ddReader;
	}

	public void setDicomDirReader(DicomDirReader ddReader) {
		this.ddReader = ddReader;
	}

	final DicomDirWriter getDicomDirWriter() {
		return ddWriter;
	}

	public void addRemoteConnection(String aet, Connection remote) {
		remoteConnections.put(aet, remote);
	}

	Connection getRemoteConnection(String dest) {
		return remoteConnections.get(dest);
	}

	public Connection getConnection() {
		return conn;
	}

	public ApplicationEntity getApplicationEntity() {
		return ae;
	}

}
