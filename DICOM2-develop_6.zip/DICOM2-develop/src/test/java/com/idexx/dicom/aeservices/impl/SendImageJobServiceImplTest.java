/**
 * 
 */
package com.idexx.dicom.aeservices.impl;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.ae.entities.BaseDicomImPluginConfig;
import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.ae.validator.IdexxSendImageValidator;
import com.idexx.dicom.aeservices.IdexxDicomWSAthorizationService;
import com.idexx.dicom.constants.IdexxDicomTestConstants;
import com.idexx.dicom.dao.ws.IdexxSendImageJobDao;
import com.idexx.dicom.services.IdexxDicomServiceConstants;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.SendImageJobParamDTO;

// TODO: Auto-generated Javadoc
/**
 * The Class SendImageJobServiceImplTest.
 *
 * @author smallela
 * @version 1.3
 */
public class SendImageJobServiceImplTest {

	/** The send image job service. */
	@InjectMocks
	private SendImageJobServiceImpl sendImageJobService = new SendImageJobServiceImpl();

	/** The send image job dao. */
	@Mock
	private IdexxSendImageJobDao sendImageJobDao;

	/** The validator. */
	@Mock
	private IdexxSendImageValidator validator;

	/** The idexx dicom ws authorize service. */
	@Mock
	private IdexxDicomWSAthorizationService idexxDicomWsAuthorizeService;

	/** The config. */
	BaseDicomImPluginConfig config = new BaseDicomImPluginConfig();

	/** The send image job param dto. */
	SendImageJobParamDTO sendImageJobParamDTO = new SendImageJobParamDTO();

	/**
	 * Sets the up.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Before
	public void setUp() throws Exception {

		config.setConfigName(IdexxDicomServiceConstants.SEND_RETRY_COUNT);
		config.setConfigValue(String.valueOf(IdexxDicomServiceConstants.DEFAULT_SEND_RETRY_COUNT));

		sendImageJobParamDTO.setApiKey(IdexxDicomTestConstants.APIKEY);
		sendImageJobParamDTO.setDestinationAETitle(IdexxDicomTestConstants.DESTINATIONAETITLE);
		sendImageJobParamDTO.setDestinationHost(IdexxDicomTestConstants.DESTINATIONHOST);
		sendImageJobParamDTO.setDestinationPort(0);
		sendImageJobParamDTO.setImageAssetId(IdexxDicomTestConstants.IMAGEASSETID);

		MockitoAnnotations.initMocks(this);

	}

	/**
	 * Test perform service1.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public void testPerformService1() throws IdexxDicomAEConfigServiceException {

		when(idexxDicomWsAuthorizeService.authorize(any(String.class))).thenReturn(true);
		when(validator.validate(any(SendImageJobParamDTO.class))).thenReturn(1);
		when(sendImageJobDao.createJob(any(IdexxSendImageJob.class))).thenReturn(IdexxDicomTestConstants.JOBID);
		String val = sendImageJobService.performService(sendImageJobParamDTO);
		assertTrue("Invalid Response recieved", IdexxDicomTestConstants.JOBID.equals(val));
	}

}
