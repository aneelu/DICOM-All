/**
 * 
 */
package com.idexx.dicom.ae.validator.impl.v12;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.InjectMocks;

import com.idexx.dicom.services.dto.v12.IdexxErrorLogParamDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

// TODO: Auto-generated Javadoc
/**
 * The Class StoreErrorLogValidatorTest.
 *
 * @author smallela
 * @version 1.3
 */
public class StoreErrorLogValidatorTest {

	/** The store error validator. */
	@InjectMocks
	private StoreErrorLogValidatorImpl storeErrorValidator = new StoreErrorLogValidatorImpl();

	/** The idexx error log param dto. */
	IdexxErrorLogParamDTO idexxErrorLogParamDTO;

	/** The expected ex. */
	@Rule
	public ExpectedException expectedEx = ExpectedException.none();

	/**
	 * Sets the up.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Before
	public void setUp() throws Exception {

		idexxErrorLogParamDTO = new IdexxErrorLogParamDTO();
	}

	/**
	 * Test when start date is empty then return error msg.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Test
	public final void testWhenStartDateIsEmptyThenReturnErrorMsg() throws Exception {

		idexxErrorLogParamDTO.setStartDate(null);
		expectedEx.expect(IdexxDicomAEConfigServiceException.class);
		expectedEx.expectMessage("ERR_argument_missing_mandatory");
		storeErrorValidator.validate(idexxErrorLogParamDTO);
	}

	/**
	 * Test when end date is empty then return error msg.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Test
	public final void testWhenEndDateIsEmptyThenReturnErrorMsg() throws Exception {

		idexxErrorLogParamDTO.setEndDate(null);
		expectedEx.expect(IdexxDicomAEConfigServiceException.class);
		expectedEx.expectMessage("ERR_argument_missing_mandatory");
		storeErrorValidator.validate(idexxErrorLogParamDTO);
	}

	/**
	 * Test when start date is not valid then return error msg.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Test
	public final void testWhenStartDateIsNotValidThenReturnErrorMsg() throws Exception {

		idexxErrorLogParamDTO.setStartDate("abcd");
		idexxErrorLogParamDTO.setEndDate("2014-01-24T11:20:24.0z");
		expectedEx.expect(IdexxDicomAEConfigServiceException.class);
		expectedEx.expectMessage("ERR_invalid_start_date");
		storeErrorValidator.validate(idexxErrorLogParamDTO);
	}

	/**
	 * Test when end date is not valid then return error msg.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Test
	public final void testWhenEndDateIsNotValidThenReturnErrorMsg() throws Exception {

		idexxErrorLogParamDTO.setStartDate("2014-01-24T11:20:24.0z");
		idexxErrorLogParamDTO.setEndDate("abcd");
		expectedEx.expect(IdexxDicomAEConfigServiceException.class);
		expectedEx.expectMessage("ERR_invalid_end_date");
		storeErrorValidator.validate(idexxErrorLogParamDTO);
	}

	/**
	 * Test when start date is less than end date then return error msg.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Test
	public final void testWhenStartDateIsLessThanEndDateThenReturnErrorMsg() throws Exception {

		idexxErrorLogParamDTO.setStartDate("2014-04-29T12:00:00.0+05:30");
		idexxErrorLogParamDTO.setEndDate("2014-04-29T12:00:00.0+05:30");
		storeErrorValidator.validate(idexxErrorLogParamDTO);
	}

	/**
	 * Test when valid start end date then return success.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Test
	public final void testWhenValidStartEndDateThenReturnSuccess() throws Exception {

		idexxErrorLogParamDTO.setStartDate("2013-03-24T11:20:24.0z");
		idexxErrorLogParamDTO.setEndDate("2014-01-24T11:20:24.0z");
		boolean isValid = storeErrorValidator.validate(idexxErrorLogParamDTO);
		Assert.assertTrue(isValid);
	}
}
