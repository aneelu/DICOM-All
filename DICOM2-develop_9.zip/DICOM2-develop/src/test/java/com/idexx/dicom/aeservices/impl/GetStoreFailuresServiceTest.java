/**
 * 
 */
package com.idexx.dicom.aeservices.impl;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.idexx.dicom.ae.entities.AETitle;
import com.idexx.dicom.ae.entities.IdexxDicomServiceFailureLog;
import com.idexx.dicom.ae.validator.StoreFailureServiceValidator;
import com.idexx.dicom.constants.IdexxDicomTestConstants;
import com.idexx.dicom.dao.ws.AETitleDao;
import com.idexx.dicom.dao.ws.FailureServiceDao;
import com.idexx.dicom.services.dto.IdexxFailureLogDTO;
import com.idexx.dicom.services.dto.IdexxFailureLogParamDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

// TODO: Auto-generated Javadoc
/**
 * The Class GetStoreFailuresServiceTest.
 *
 * @author smallela
 * @version 1.3
 */
public class GetStoreFailuresServiceTest {

	/** The failure service. */
	@InjectMocks
	private GetStoreFailuresService failureService = new GetStoreFailuresService();

	/** The store failure service validator. */
	@Mock
	private StoreFailureServiceValidator storeFailureServiceValidator;

	/** The dtos. */
	@Mock
	private List<IdexxFailureLogDTO> dtos;

	/** The failure log dao. */
	@Mock
	private FailureServiceDao failureLogDAO;

	/** The ae title dao. */
	@Mock
	private AETitleDao aeTitleDao;

	/** The listofidexx dicom service failure log. */
	List<IdexxDicomServiceFailureLog> listofidexxDicomServiceFailureLog = new ArrayList<IdexxDicomServiceFailureLog>();

	/** The idexx dicom service failure log. */
	IdexxDicomServiceFailureLog idexxDicomServiceFailureLog = new IdexxDicomServiceFailureLog();

	/** The listofidexx failure log dto. */
	List<IdexxFailureLogDTO> listofidexxFailureLogDTO = new ArrayList<IdexxFailureLogDTO>();

	/** The idexx failure log param dto. */
	IdexxFailureLogParamDTO idexxFailureLogParamDTO = new IdexxFailureLogParamDTO();

	/** The listofae title. */
	List<AETitle> listofaeTitle = new ArrayList<AETitle>();

	/**
	 * Sets the up.
	 *
	 * @throws Exception
	 *             the exception
	 */
	@Before
	public final void setUp() throws Exception {

		idexxDicomServiceFailureLog.setAeTitle(IdexxDicomTestConstants.AETITLE);
		idexxDicomServiceFailureLog.setFailedDateTime(new Timestamp((new Date()).getTime()));
		idexxDicomServiceFailureLog.setIpAddress(IdexxDicomTestConstants.IPADDRESS);
		idexxDicomServiceFailureLog.setManufacturer(IdexxDicomTestConstants.MANUFACTURER);
		idexxDicomServiceFailureLog.setManufacturerModelName(IdexxDicomTestConstants.MANUFACTURERMODELNAME);
		idexxDicomServiceFailureLog.setModality(IdexxDicomTestConstants.MODALITY);
		idexxDicomServiceFailureLog.setPatientName(IdexxDicomTestConstants.PATIENTNAME);
		listofidexxDicomServiceFailureLog.add(idexxDicomServiceFailureLog);

		idexxFailureLogParamDTO.setEndDate("2015-05-15T23:58:59.1+05:30");
		idexxFailureLogParamDTO.setStartDate("2013-05-15T23:58:59.1+05:30");

		MockitoAnnotations.initMocks(this);

	}

	/**
	 * Test perform service1.
	 *
	 * @throws IdexxDicomAEConfigServiceException
	 *             the idexx dicom ae config service exception
	 */
	@Test
	public final void testPerformService1() throws IdexxDicomAEConfigServiceException {

		when(storeFailureServiceValidator.validate(any(IdexxFailureLogParamDTO.class))).thenReturn(1);
		when(failureLogDAO.getFailureLog(any(Date.class), any(Date.class)))
				.thenReturn(listofidexxDicomServiceFailureLog);
		when(aeTitleDao.getAllAETitles()).thenReturn(listofaeTitle);
		listofidexxFailureLogDTO = failureService.performService(idexxFailureLogParamDTO);
		assertTrue("GetStoreFailuresService failed", null != listofidexxFailureLogDTO);
	}

}
