package com.idexx.dicom.aeservices.v12;

import java.util.List;

import com.idexx.dicom.services.dto.v12.IdexxErrorLogParamDTO;
import com.idexx.dicom.services.dto.v12.IdexxFailureLogDTO;
import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;

public interface StoreErrorLogService {
	List<IdexxFailureLogDTO> performService(IdexxErrorLogParamDTO dto) throws IdexxDicomAEConfigServiceException;
}
