/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dicom.util;

import java.io.File;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.idexx.dicom.services.IdexxDicomServiceConstants;

/**
 * <pre>
 * Description of the class
 * </pre>
 * 
 * @author vvanjarana
 * @version 1.3
 */
@Service
public class CleanTempFiles {

    private static Logger log = Logger.getLogger(CleanTempFiles.class);

    @Scheduled(cron = "0 0 12 1/1 * ?")
    public void cleanTempFiles() {
	final long oldRecordTimestamp = new Date().getTime() - (60 * 60 * 1000);
	try {
	    File tempFiles = new File(
		    System.getProperty(IdexxDicomServiceConstants.JAVA_TEMP_LOCATION) + File.separator + "tempFiles");
	    File[] files = tempFiles.listFiles();
	    for (File file : files) {
		deleteFiles(file, oldRecordTimestamp);
	    }
	} catch (Exception e) {
	    log.error("Error while clearing temp files", e);
	}
    }

    public void deleteFiles(File f, Long oldRecs) {
	if (f.isDirectory()) {
	    File files[] = f.listFiles();
	    if(files!=null && files.length<=0) {
		f.delete();
		return;
	    }
	    for (File file : files) {
		if (file.isDirectory()) {
		    deleteFiles(file, oldRecs);
		} else {
		    log.info("file.lastModified(): " + file.lastModified() + " : oldRecordTimestamp: " + oldRecs);
		    if (file.lastModified() < oldRecs) {
			file.delete();
		    }
		}
	    }
	} else {
	    log.info("file.lastModified(): " + f.lastModified() + " : oldRecordTimestamp: " + oldRecs);
	    if (f.lastModified() < oldRecs) {
		f.delete();
	    }
	}
    }
}
