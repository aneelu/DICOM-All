/**
 * <h1>Description about your class</h1>
 */
package com.idexx.dicom.store;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.idexx.dicom.dao.store.DicomImMappingDAO;
import com.idexx.dicom.dao.store.impl.DicomImMappingDAOImpl;
import com.idexx.dicom.entities.store.DicomImageManagerMapping;

/**
 * Get DCIOM tags based on field name from DB
 * @author vvanjarana
 * @version 1.3
 */
@Service
public class ImageManagerAttributeProvider {
    
    
 @Autowired   
 private DicomImMappingDAO dao;
    
    /**
     * @param dao
     */
    public ImageManagerAttributeProvider(final DicomImMappingDAO dao) {
        super();
        this.dao = dao;
    }
    
    public ImageManagerAttributeProvider() {
        
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.store.ImageManagerAttributeProvider#getMappingTagAttributes
     * ()
     */
    public final Map<String, ImageManagerAttributeExtractorFromDicomElement> getMappingTagAttributes() {
        List<String> imFieldNames = dao.getEnabledImFieldNames();
        Map<String, ImageManagerAttributeExtractorFromDicomElement> tagAttributesMap 
        = new HashMap<String, ImageManagerAttributeExtractorFromDicomElement>();
        if (null == imFieldNames) {
            return tagAttributesMap;
        }
        ExtractorFactory factory = ExtractorFactory.createInstance();
        for (String fieldName : imFieldNames) {
            List<DicomImageManagerMapping> imMap = dao.getTagsByImFieldName(fieldName);
            tagAttributesMap.put(fieldName, factory.createExtractor(imMap, fieldName));
        }
        return tagAttributesMap;
    }
}
