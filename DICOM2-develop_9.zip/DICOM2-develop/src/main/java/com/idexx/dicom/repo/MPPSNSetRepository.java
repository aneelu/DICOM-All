package com.idexx.dicom.repo;

import com.idexx.dicom.domain.MPPSNSet;

public interface MPPSNSetRepository extends IdexxRepository<MPPSNSet, String> {
	}
