/**
 * DAO for DICOM tags and ImageManager Attributes Mappings 
 */
package com.idexx.dicom.dao.store;

import java.util.List;

import com.idexx.dicom.entities.store.DicomIMMappings;
import com.idexx.dicom.entities.store.DicomImageManagerMapping;

/**
 * @author vkandagatla
 * 
 */
public interface DicomImMappingDAO {
    String IMAGE_STORE_COMPONENT_NAME = "IMAGE_STORE";
    int IMAGE_STORE_COMPONENT_REQUEST_TYPE = 1;
    String COMPONENT_NAME_PARAM = "COMPONENT_NAME";
    String REQUEST_TYPE_PARAMS = "REQUEST_TYPE";
    List<String> getEnabledImFieldNames();
    
    List<DicomImageManagerMapping> getTagsByImFieldName(String imFieldName);
    
    /**
     * @param component
     * @param requestType
     * @return
     */
    List<DicomIMMappings> getMappingsByComponent(final String component, final int requestType);
}
