package com.idexx.dicom.repo;

import java.util.List;

import com.idexx.dicom.domain.Owner;

public interface OwnerRepo extends IdexxRepository<Owner, String> {
	List<Owner> findByPatientID(String patientId);
}
