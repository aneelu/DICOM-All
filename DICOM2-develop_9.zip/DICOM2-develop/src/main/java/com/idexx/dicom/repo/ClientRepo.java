package com.idexx.dicom.repo;

import com.idexx.dicom.domain.Client;

public interface ClientRepo extends IdexxRepository<Client, String> {
	Client findByID(String clientId);
}
