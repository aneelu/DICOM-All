/**
 * Implementation for DICOM IdexxFileInfo List Creation
 */
package com.idexx.dicom.retrieve.download.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.log4j.Logger;
import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;
import org.dcm4che3.io.DicomInputStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.idexx.dicom.retrieve.download.DownloadFileInfoProvider;
import com.idexx.dicom.retrieve.request.IdexxSearchImageWebserviceRequestHandler;

/**
 * @author vkandagatla
 * 
 */
@Component
public class DownloadFileInfoProviderImpl implements DownloadFileInfoProvider {
	
	@Autowired
    private IdexxSearchImageWebserviceRequestHandler imageSearchRequestHandler;
    private static final String DEFAULT_TSUID = "1.2.840.10008.1.2.1";
    private static final String FSGROUPID = "ONLINE_STORAGE";
	private static final Logger LOG = Logger.getLogger(DownloadFileInfoProviderImpl.class);

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.idexx.dicom.retrieve.download.DownloadFileInfoProvider#getFileInfoList
     * (org.dcm4che.data.Dataset, java.lang.String)
     */
    @Override
    public final List<IdexxFileInfo> getFileInfoList(final Attributes dataset, final String callingAET,
            final String calledAET) {
        List<IdexxFileInfo> fileList = new ArrayList<IdexxFileInfo>();
        try {
            List<String> fileName = imageSearchRequestHandler.idexxSearchImageService(dataset, callingAET);
            String baseDir = imageSearchRequestHandler.getBaseDir();
            for (String fName : fileName) {
                if (fName != null) {
                    File f = new File(baseDir + File.separator + fName);
                    IdexxFileInfo fi = fileToDataset(f, fName, calledAET, baseDir);
                    fileList.add(fi);
                    LOG.info(" String fileName " + fName + " Successful");
                }
            }
        } catch (Exception exp) {
            LOG.error("Exception in executing getFileInfoList()  " + exp.getMessage(), exp);
        }
        if (fileList.isEmpty()) {
            LOG.error("No Files downloaded for the given criteria");
        }
        LOG.info(" inside getFileInfoList ended : " + System.currentTimeMillis());
        return fileList;
    }

    /**
     * Loads a Dataset object from a file.
     * 
     * @param f
     *            the file containing teh Dataset.
     * @return the read in Dataset.
     */
    private IdexxFileInfo fileToDataset(final File f, 
            final String fileName, 
            final String calledAET, 
            final String bDir) throws IOException {
        Attributes ds = new Attributes();
        int size = 0;

        try (DicomInputStream inStream = new DicomInputStream(f)){            
            size = inStream.available();
            inStream.readAttributes(ds, -1, -1);
        }
        IdexxFileInfo fi = setFileInfoInformation(ds, fileName, calledAET, bDir);
        fi.setSize(size);
        fi.setMd5(this.getImageCheckSum(f));
        fi.setFsGroupID(FSGROUPID);
        fi.setAvailability(0);
        fi.setPatID(ds.getString(Tag.PatientID));
        fi.setPatName(ds.getString(Tag.PatientName));
        return fi;
    }

    /**
     * @param ds
     * @param fileName
     * @return Constructs the IdexxFileInfo object from DataSet and File
     */
    private IdexxFileInfo setFileInfoInformation(final Attributes ds, final String fileName, final String calledAET,
            final String bDir) {
        IdexxFileInfo fileInfo1 = new IdexxFileInfo();
        fileInfo1.setStatus(0);
        fileInfo1.setBasedir(bDir);
        fileInfo1.setFileID(fileName);
        fileInfo1.setFileRetrieveAET(calledAET);
        fileInfo1.setSopIUID(ds.getString(Tag.SOPInstanceUID));
        fileInfo1.setStudyIUID(ds.getString(Tag.StudyInstanceUID));
        fileInfo1.setSeriesIUID(ds.getString(Tag.SeriesInstanceUID));
        fileInfo1.setSopCUID(ds.getString(Tag.SOPClassUID));
        fileInfo1.setTsUID(ds.getString(Tag.TransferSyntaxUID));
        if (fileInfo1.getTsUID() == null || fileInfo1.getTsUID().length() == 0) {
            fileInfo1.setTsUID(DEFAULT_TSUID);
        }
        return fileInfo1;
    }

    /**
     * 
     * @param file
     * @return returns file checksum
     */
    private String getImageCheckSum(final File file) {
        String checkSum = null;
        try {
            FileInputStream fis = new FileInputStream(file);
            checkSum = DigestUtils.md5Hex(fis);
            fis.close();
        } catch (FileNotFoundException ex) {
            LOG.error(ex.getMessage(), ex);
        } catch (IOException ex) {
            LOG.error(ex.getLocalizedMessage(), ex);
        }

        return checkSum;
    }

}
