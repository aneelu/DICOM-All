/**
 * 
 */
package com.idexx.dicom.services;

/**
 * @author vkandagatla
 *
 */
public final class IdexxDicomServiceConstants {
    public static final String STATUS_PENDING = "PENDING";
    public static final String STATUS_PROGRESS = "IN_PROGRESS";
    public static final String STATUS_SUCCESS = "SUCCESSFUL";
    public static final String STATUS_FAIL = "FAILED";
    public static final String PENDING_INIT_DESC = "Pending for first time schedule";
    public static final String JOB_ID_DOES_NOT_EXIST = "JobId Not Exist";
    public static final String NO_JOBS_EXISTS = "GIVEN JOBS DOES NOT EXISTS";
    public static final String SEND_RETRY_COUNT = "sendRetriesCount";
    public static final int DEFAULT_SEND_RETRY_COUNT = 0;
    public static final String CONVERTED_IMAGES_DIR = "dicom-images-converted";
    public static final String DOWNLOADED_IMAGES_DIR = "dicom-images";
    public static final String DICOM_FILE_EXTENSION1 = "DCM";
    public static final String DICOM_FILE_EXTENSION2 = ".DCM";
    public static final String DOWNLOAD_FILE_PREFIX = "idexx_";
    public static final long DEFAULT_WS_TIMEOUT = 60000L;
    public static final String JAVA_TEMP_LOCATION = "java.io.tmpdir";
    public static final String MPPS_REQUEST_STATUS_PENDING = "MPPS_PENDING";
    public static final String MPPS_REQUEST_STATUS_INPROGRESS = "MPPS_IN PROGRESS";
    public static final String REQUEST_STATUS_CANCEL = "MPPS_CANCEL";
    public static final String MPPS_REQUEST_STATUS_SCHEDULED = "SCHEDULED";
    
    /**
     * Default Private
     */
    private IdexxDicomServiceConstants() {
    }
    
}
