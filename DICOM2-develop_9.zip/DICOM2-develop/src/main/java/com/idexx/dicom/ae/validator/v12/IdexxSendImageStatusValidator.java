/**
 * 
 */
package com.idexx.dicom.ae.validator.v12;

import com.idexx.dicom.services.exceptions.IdexxDicomAEConfigServiceException;
import com.idexx.dicom.services.sendimage.dto.v12.SendImageStatusParamDTO;

/**
 * @author mdindukurthi
 * 
 */
public interface IdexxSendImageStatusValidator extends IdexxValidator {

    int validate(SendImageStatusParamDTO dto) throws IdexxDicomAEConfigServiceException;

}
