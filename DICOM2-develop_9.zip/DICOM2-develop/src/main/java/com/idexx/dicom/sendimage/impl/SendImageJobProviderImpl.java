/**
 * 
 */
package com.idexx.dicom.sendimage.impl;


import java.util.List;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.idexx.dicom.ae.entities.IdexxSendImageJob;
import com.idexx.dicom.dao.sendimage.DicomJobDao;
import com.idexx.dicom.sendimage.SendImageJobProvider;

/**
 * @author vkandagatla
 * 
 */
@Service
public class SendImageJobProviderImpl implements SendImageJobProvider {
	
	private static final Logger LOG = Logger.getLogger(SendImageJobProviderImpl.class);
	
    @Autowired
    private DicomJobDao jobDao;
    
    /*
     * (non-Javadoc)
     * 
     * @see com.idexx.dicom.sendimage.SendImageJobProvider#getPendingJobs()
     */
    @Override
    @Transactional(value=TxType.REQUIRED)
    public final List<IdexxSendImageJob> getPendingJobs(String jobCount) {
        LOG.info("Getting JOBS");
        return this.jobDao.getPendingJobs(jobCount);
    }
    
    
    @Override
    public final  void updateInProgressJobs(String oldRecordsCount) {
        LOG.info("Update IN-PROGRESS JOBS");
        jobDao.updateAllInProgressJobs(oldRecordsCount);
    }    
    
    @Override
    @Transactional(value=TxType.REQUIRED)
    public final  void updateJobsToInProgressStatus(List<IdexxSendImageJob> jobs) {
        LOG.info("Update to IN-PROGRESS JOBS");
        jobDao.updateJobsToInProgressStatus(jobs);
    }  
  
}
